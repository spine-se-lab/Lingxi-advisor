"""Compatibility entry point for Grounded Analysis mode."""

from __future__ import annotations

import sys

from .generation import main


if __name__ == "__main__":
    if not any(
        item == "--generation-mode" or item.startswith("--generation-mode=")
        for item in sys.argv
    ):
        sys.argv.extend(["--generation-mode", "grounded_analysis"])
    main()
