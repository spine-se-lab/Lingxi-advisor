from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ...capabilities.codify.batch_preparation import (
    BatchPreparationOptions,
    BatchPreparationRequest,
    PreparedKnowledgeView,
    LingxiAdvisorCodifyBatch,
    LingxiAdvisorCodifyOperation,
)
from ...config import ServerSettings
from ...internal.search_retrieval.contracts import SWEbenchProInstance
from ...internal.search_retrieval.preretrieved_store import PreretrievedStore
from .operator_tools import OPERATOR_TOOLS

@dataclass(frozen=True)
class MCPServerPolicy:
    allowed_generation_modes: tuple[str, ...] = (
        'light',
        'grounded_analysis',
    )
    allow_live_search: bool = True
    allow_update_preretrieved: bool = False
    allow_refresh: bool = False
    allow_clone: bool = False
    allow_fetch: bool = False
    max_search_candidate_count: int = 20
    max_final_top_k: int = 5
    max_knowledge_chars: int = 1_000_000
    max_batch_size: int = 1_000

    def validate(self) -> None:
        supported = {'light', 'grounded_analysis'}
        if not self.allowed_generation_modes:
            raise ValueError('allowed_generation_modes cannot be empty')
        unknown = set(self.allowed_generation_modes) - supported
        if unknown:
            raise ValueError('unsupported generation mode')
        if self.max_search_candidate_count < 1:
            raise ValueError('max_search_candidate_count must be positive')
        if self.max_final_top_k < 1:
            raise ValueError('max_final_top_k must be positive')
        if self.max_final_top_k > self.max_search_candidate_count:
            raise ValueError('max_final_top_k exceeds candidate limit')
        if self.max_knowledge_chars < 1_000:
            raise ValueError('max_knowledge_chars must be at least 1000')
        if self.max_batch_size < 1:
            raise ValueError('max_batch_size must be positive')

class LingxiAdvisorOperatorMCPAdapter:
    def __init__(
        self,
        *,
        settings: ServerSettings,
        operation: LingxiAdvisorCodifyOperation,
        batch: LingxiAdvisorCodifyBatch,
        prepared_view: PreparedKnowledgeView,
        policy: MCPServerPolicy,
    ) -> None:
        self.settings = settings.resolved()
        self.operation = operation
        self.batch = batch
        self.prepared_view = prepared_view
        self.policy = policy
        self.policy.validate()
        self.preretrieved_dir = operation.preretrieved_dir
        self.knowledge_cache_dir = operation.codify.ensure_settings.knowledge_cache_dir
        self.output_root = operation.codify.ensure_settings.output_root

    def capabilities(self) -> dict[str, Any]:
        return {
            'schema_version': 1,
            'delivery_profile': 'operator',
            'tools': list(OPERATOR_TOOLS),
            'generation_modes': list(self.policy.allowed_generation_modes),
            'model_readiness': {
                'generator_configured': self.settings.generator_model_configured,
                'judge_configured': self.settings.judge_model_configured,
                'host_sampling_available': False,
                'note': 'Operator generation requires a configured model; supported modes do not imply model readiness.',
            },
            'allow_live_search': self.policy.allow_live_search,
            'allow_update_preretrieved': self.policy.allow_update_preretrieved,
            'allow_refresh': self.policy.allow_refresh,
            'grounded_allow_clone': self.policy.allow_clone,
            'grounded_allow_fetch': self.policy.allow_fetch,
            'max_search_candidate_count': self.policy.max_search_candidate_count,
            'max_final_top_k': self.policy.max_final_top_k,
            'batch': {
                'supported': True,
                'configured': self.settings.batch_input_path is not None,
                'max_batch_size': self.policy.max_batch_size,
                'background_execution': True,
                'continue_on_error': True,
                'resume': True,
            },
            'input_policy': {
                'public_instance_fields_only': True,
                'target_solution_patch_forbidden': True,
                'target_test_patch_forbidden': True,
                'server_paths_and_credentials_are_server_owned': True,
            },
        }

    async def prepare(
        self,
        *,
        instance: Mapping[str, Any],
        generation_mode: str = 'light',
        search_candidate_count: int = 5,
        final_top_k: int = 3,
        update_preretrieved: bool = False,
        run_gate_for_preretrieved: bool = False,
        search_type: str = 'semantic',
        fallback_search_type: str = 'hybrid',
        minimum_similarity_score: int = 2,
        maximum_misleading_risk: int = 3,
        resume: bool = True,
        refresh_instance_metadata: bool = False,
        refresh_search_cache: bool = False,
    ) -> dict[str, Any]:
        normalized = SWEbenchProInstance.from_mapping(instance)
        options = self._options(
            generation_mode=generation_mode,
            search_candidate_count=search_candidate_count,
            final_top_k=final_top_k,
            update_preretrieved=update_preretrieved,
            run_gate_for_preretrieved=run_gate_for_preretrieved,
            search_type=search_type,
            fallback_search_type=fallback_search_type,
            minimum_similarity_score=minimum_similarity_score,
            maximum_misleading_risk=maximum_misleading_risk,
            resume=resume,
            refresh_instance_metadata=refresh_instance_metadata,
            refresh_search_cache=refresh_search_cache,
        )
        self._validate_live_search(normalized)
        value = await self.operation.prepare(normalized.public_dict(), options)
        return self._agent_result(value)

    async def start_batch(
        self,
        *,
        generation_mode: str = 'light',
        search_candidate_count: int = 5,
        final_top_k: int = 3,
        update_preretrieved: bool = False,
        run_gate_for_preretrieved: bool = False,
        search_type: str = 'semantic',
        fallback_search_type: str = 'hybrid',
        minimum_similarity_score: int = 2,
        maximum_misleading_risk: int = 3,
        resume: bool = True,
        refresh_instance_metadata: bool = False,
        refresh_search_cache: bool = False,
        continue_on_error: bool = True,
        retry_failed: bool = False,
    ) -> dict[str, Any]:
        options = self._options(
            generation_mode=generation_mode,
            search_candidate_count=search_candidate_count,
            final_top_k=final_top_k,
            update_preretrieved=update_preretrieved,
            run_gate_for_preretrieved=run_gate_for_preretrieved,
            search_type=search_type,
            fallback_search_type=fallback_search_type,
            minimum_similarity_score=minimum_similarity_score,
            maximum_misleading_risk=maximum_misleading_risk,
            resume=resume,
            refresh_instance_metadata=refresh_instance_metadata,
            refresh_search_cache=refresh_search_cache,
        )
        result = await self.batch.start(
            BatchPreparationRequest(
                options=options,
                resume=resume,
                continue_on_error=continue_on_error,
                retry_failed=retry_failed,
            )
        )
        return self._redact_batch(result)

    def get_batch(
        self,
        *,
        batch_id: str,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        return self._redact_batch(
            self.batch.get_batch(
                batch_id=batch_id,
                offset=offset,
                limit=limit,
            )
        )

    def get_result(self, request_id: str) -> dict[str, Any]:
        return self._agent_result(self.batch.get_result(request_id))

    def read_knowledge(
        self,
        *,
        request_id: str,
        artifact_name: str,
    ) -> str:
        return self.prepared_view.read(
            request_id=request_id,
            artifact_name=artifact_name,
        )

    def _options(
        self,
        *,
        generation_mode: str,
        search_candidate_count: int,
        final_top_k: int,
        update_preretrieved: bool,
        run_gate_for_preretrieved: bool,
        search_type: str,
        fallback_search_type: str,
        minimum_similarity_score: int,
        maximum_misleading_risk: int,
        resume: bool,
        refresh_instance_metadata: bool,
        refresh_search_cache: bool,
    ) -> BatchPreparationOptions:
        self._validate_request_policy(
            generation_mode=generation_mode,
            search_candidate_count=search_candidate_count,
            final_top_k=final_top_k,
            update_preretrieved=update_preretrieved,
            refresh_requested=(
                refresh_instance_metadata or refresh_search_cache
            ),
        )
        return BatchPreparationOptions(
            generation_mode=generation_mode,  # type: ignore[arg-type]
            search_candidate_count=search_candidate_count,
            final_top_k=final_top_k,
            update_preretrieved=update_preretrieved,
            run_gate_for_preretrieved=run_gate_for_preretrieved,
            search_type=search_type,
            fallback_search_type=fallback_search_type,
            minimum_similarity_score=minimum_similarity_score,
            maximum_misleading_risk=maximum_misleading_risk,
            resume=resume,
            refresh_instance_metadata=refresh_instance_metadata,
            refresh_search_cache=refresh_search_cache,
        )

    def _validate_request_policy(
        self,
        *,
        generation_mode: str,
        search_candidate_count: int,
        final_top_k: int,
        update_preretrieved: bool,
        refresh_requested: bool,
    ) -> None:
        if generation_mode not in self.policy.allowed_generation_modes:
            raise PermissionError(f'generation mode is disabled: {generation_mode}')
        if search_candidate_count > self.policy.max_search_candidate_count:
            raise ValueError('search_candidate_count exceeds server limit')
        if final_top_k > self.policy.max_final_top_k:
            raise ValueError('final_top_k exceeds server limit')
        if final_top_k > search_candidate_count:
            raise ValueError('final_top_k cannot exceed search_candidate_count')
        if update_preretrieved and not self.policy.allow_update_preretrieved:
            raise PermissionError('Pre-retrieved writes are disabled.')
        if refresh_requested and not self.policy.allow_refresh:
            raise PermissionError('Refresh operations are disabled.')

    def _validate_live_search(self, instance: SWEbenchProInstance) -> None:
        if self.policy.allow_live_search:
            return
        rows, _rejected = PreretrievedStore(self.preretrieved_dir).find(instance)
        if not rows:
            raise PermissionError(
                'Live search is disabled and no valid candidate exists.'
            )

    def _agent_result(self, value: Mapping[str, Any]) -> dict[str, Any]:
        request_id = str(value.get('request_id') or '')
        artifacts = []
        for item in value.get('knowledge_artifacts', []):
            if not isinstance(item, Mapping):
                continue
            name = str(item.get('artifact_name') or '')
            artifacts.append({
                'artifact_name': name,
                'knowledge_uri': (
                    f'lingxi.advisor://runs/{request_id}/artifacts/{name}'
                ),
                'sha256': item.get('sha256'),
                'generation_mode': item.get('generation_mode'),
                'knowledge_cache_key': item.get('knowledge_cache_key'),
                'historical_candidate_fingerprint': item.get(
                    'historical_candidate_fingerprint'
                ),
                'repo': item.get('repo'),
                'historical_issue_number': item.get('historical_issue_number'),
                'cache_hit': item.get('cache_hit'),
            })
        fields = (
            'schema_version', 'status', 'instance_id', 'generation_mode',
            'retrieval_status', 'generation_status', 'retrieval_source',
            'selected_count', 'rejected_count', 'completed_count',
            'cache_hit_count', 'generated_count', 'failed_count',
        )
        result = {name: value.get(name) for name in fields}
        result['request_id'] = request_id
        result['resumed'] = bool(value.get('resumed'))
        result['retryable'] = bool(value.get('retryable'))
        result['result_uri'] = f'lingxi.advisor://runs/{request_id}/result'
        result['knowledge_artifacts'] = artifacts
        error = str(value.get('error') or '').strip()
        result['error'] = self._redact_server_paths(error) if error else None
        return result

    def _redact_batch(self, value: Mapping[str, Any]) -> dict[str, Any]:
        result = dict(value)
        error = str(result.get('error') or '').strip()
        result['error'] = self._redact_server_paths(error) if error else None
        for item in result.get('items', []):
            if not isinstance(item, dict):
                continue
            item_error = str(item.get('error') or '').strip()
            item['error'] = (
                self._redact_server_paths(item_error) if item_error else None
            )
        batch_id = str(result.get('batch_id') or '')
        result['batch_uri'] = f'lingxi.advisor://batches/{batch_id}'
        return result

    def _redact_server_paths(self, value: str) -> str:
        roots = (
            (self.settings.historical_worktree_root, '<worktree_root>'),
            (self.settings.repository_root, '<repository_root>'),
            (self.knowledge_cache_dir, '<knowledge_cache_dir>'),
            (self.preretrieved_dir, '<preretrieved_dir>'),
            (self.settings.cache_root, '<cache_root>'),
            (self.output_root, '<output_root>'),
            (self.settings.project_root, '<project_root>'),
        )
        return _redact_paths(value, roots)


def _redact_paths(
    value: str,
    roots: tuple[tuple[Path | None, str], ...],
) -> str:
    candidates: set[tuple[str, str]] = set()
    for path, replacement in roots:
        if path is None:
            continue
        expanded = path.expanduser()
        for text in (
            str(expanded),
            os.path.abspath(expanded),
            str(expanded.resolve()),
        ):
            if text:
                candidates.add((text, replacement))
    redacted = value
    for path_text, replacement in sorted(
        candidates,
        key=lambda item: len(item[0]),
        reverse=True,
    ):
        redacted = redacted.replace(path_text, replacement)
    return redacted

__all__ = ['MCPServerPolicy', 'LingxiAdvisorOperatorMCPAdapter']
