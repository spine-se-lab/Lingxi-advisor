from __future__ import annotations

import dataclasses
import re
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, Sequence

from ....artifacts.interface import KnowledgeArtifactRef
from ..lingxi_advisor_search.contracts import KnowledgeMatch

LINGXI_ADVISOR_APPLY_SCHEMA_VERSION = 1
LingxiAdvisorApplyStatus = Literal["completed", "partial", "failed"]

_SECTION_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.\-/]{0,159}$")
_FORBIDDEN_CONTEXT_KEYS = frozenset(
    {
        "patch",
        "target_patch",
        "test_patch",
        "gold_patch",
        "hidden_tests",
        "api_key",
        "credentials",
        "server_path",
    }
)


def _normalize_ref(value: Any) -> KnowledgeArtifactRef:
    if isinstance(value, KnowledgeArtifactRef):
        return value
    if isinstance(value, Mapping):
        return KnowledgeArtifactRef.from_mapping(value)
    raise TypeError("artifact selection must be an artifact-ref mapping")


@dataclass(frozen=True)
class LingxiAdvisorApplyRequest:
    """Path-free Apply request over one Search-approved target scope."""

    issue_description: str
    knowledge_matches: tuple[KnowledgeMatch, ...]
    context: Mapping[str, Any] = field(default_factory=dict)
    artifact_refs: tuple[KnowledgeArtifactRef, ...] = ()
    sections: tuple[str, ...] = ()
    max_content_chars: int = 160_000

    def validate(self) -> None:
        if not self.issue_description.strip():
            raise ValueError("issue_description cannot be empty")
        if len(self.issue_description) > 200_000:
            raise ValueError("issue_description exceeds the Apply limit")
        if len(self.knowledge_matches) > 100:
            raise ValueError("knowledge_matches exceeds the Apply limit")
        if self.max_content_chars < 1_000 or self.max_content_chars > 1_000_000:
            raise ValueError(
                "max_content_chars must be between 1000 and 1000000"
            )
        forbidden = sorted(
            str(key)
            for key in self.context
            if str(key).strip().lower() in _FORBIDDEN_CONTEXT_KEYS
        )
        if forbidden:
            raise ValueError(
                "Apply context contains forbidden field(s): "
                + ", ".join(forbidden)
            )
        if any(not _SECTION_RE.fullmatch(section) for section in self.sections):
            raise ValueError(
                "sections must be XML tag names or section paths"
            )
        scope_refs = {match.artifact_ref for match in self.knowledge_matches}
        if any(ref not in scope_refs for ref in self.artifact_refs):
            raise ValueError(
                "artifact_refs cannot select artifacts outside "
                "knowledge_matches"
            )

    @classmethod
    def from_mapping(
        cls,
        value: Mapping[str, Any],
    ) -> "LingxiAdvisorApplyRequest":
        if not isinstance(value, Mapping):
            raise TypeError("Apply request must be a mapping")
        raw_matches = value.get("knowledge_matches") or ()
        if not isinstance(raw_matches, Sequence) or isinstance(
            raw_matches, (str, bytes)
        ):
            raise TypeError("knowledge_matches must be a sequence")
        raw_context = value.get("context") or {}
        if not isinstance(raw_context, Mapping):
            raise TypeError("context must be a mapping")
        raw_refs = value.get("artifact_refs") or ()
        if not isinstance(raw_refs, Sequence) or isinstance(
            raw_refs, (str, bytes)
        ):
            raise TypeError("artifact_refs must be a sequence")
        raw_sections = value.get("sections") or ()
        if not isinstance(raw_sections, Sequence) or isinstance(
            raw_sections, (str, bytes)
        ):
            raise TypeError("sections must be a sequence")
        request = cls(
            issue_description=str(value.get("issue_description") or ""),
            knowledge_matches=tuple(
                item
                if isinstance(item, KnowledgeMatch)
                else KnowledgeMatch.from_mapping(item)
                for item in raw_matches
            ),
            context=dict(raw_context),
            artifact_refs=tuple(_normalize_ref(item) for item in raw_refs),
            sections=tuple(str(item).strip() for item in raw_sections),
            max_content_chars=int(
                value.get("max_content_chars") or 160_000
            ),
        )
        request.validate()
        return request

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "issue_description": self.issue_description,
            "knowledge_matches": [
                match.to_dict() for match in self.knowledge_matches
            ],
            "context": dict(self.context),
            "artifact_refs": [ref.to_dict() for ref in self.artifact_refs],
            "sections": list(self.sections),
            "max_content_chars": self.max_content_chars,
        }


@dataclass(frozen=True)
class KnowledgeChunk:
    chunk_id: str
    artifact_ref: KnowledgeArtifactRef
    artifact_sha256: str
    repo: str
    historical_issue_number: int | None
    historical_issue_url: str
    historical_issue_title: str
    section: str
    section_path: str
    ordinal: int
    content: str

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "KnowledgeChunk":
        if not isinstance(value, Mapping):
            raise TypeError("knowledge chunk must be a mapping")
        raw_ref = value.get("artifact_ref")
        if isinstance(raw_ref, KnowledgeArtifactRef):
            artifact_ref = raw_ref
        elif isinstance(raw_ref, Mapping):
            artifact_ref = KnowledgeArtifactRef.from_mapping(raw_ref)
        else:
            raise ValueError("knowledge chunk requires artifact_ref")
        raw_issue = value.get("historical_issue_number")
        issue_number = None if raw_issue in (None, "") else int(raw_issue)
        if issue_number is not None and issue_number < 1:
            raise ValueError(
                "knowledge chunk historical issue number must be positive"
            )
        return cls(
            chunk_id=str(value.get("chunk_id") or ""),
            artifact_ref=artifact_ref,
            artifact_sha256=str(value.get("artifact_sha256") or ""),
            repo=str(value.get("repo") or ""),
            historical_issue_number=issue_number,
            historical_issue_url=str(
                value.get("historical_issue_url") or ""
            ),
            historical_issue_title=str(
                value.get("historical_issue_title") or ""
            ),
            section=str(value.get("section") or ""),
            section_path=str(value.get("section_path") or ""),
            ordinal=int(value.get("ordinal", -1)),
            content=str(value.get("content") or ""),
        )

    def to_dict(self, *, include_content: bool = True) -> dict[str, Any]:
        value = dataclasses.asdict(self)
        value["artifact_ref"] = self.artifact_ref.to_dict()
        if not include_content:
            value.pop("content", None)
        return value


@dataclass
class LingxiAdvisorApplyResult:
    schema_version: int
    status: LingxiAdvisorApplyStatus
    content: str
    source_artifact_refs: list[KnowledgeArtifactRef] = field(
        default_factory=list
    )
    available_sections: list[str] = field(default_factory=list)
    assembled_artifact_count: int = 0
    selected_chunk_count: int = 0
    omitted_chunk_count: int = 0
    warnings: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        value = dataclasses.asdict(self)
        value["source_artifact_refs"] = [
            ref.to_dict() for ref in self.source_artifact_refs
        ]
        return value


__all__ = [
    "KnowledgeChunk",
    "LINGXI_ADVISOR_APPLY_SCHEMA_VERSION",
    "LingxiAdvisorApplyRequest",
    "LingxiAdvisorApplyResult",
    "LingxiAdvisorApplyStatus",
]
