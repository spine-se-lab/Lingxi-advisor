from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_PROJECT_ROOT = Path.cwd()


def _tokens_from_env() -> tuple[str, ...]:
    names = ["GITHUB_TOKEN"] + [f"GITHUB_TOKEN_{idx}" for idx in range(1, 16)]
    values: list[str] = []
    seen: set[str] = set()
    for name in names:
        value = (os.environ.get(name) or "").strip()
        if value and value not in seen:
            values.append(value)
            seen.add(value)
    return tuple(values)


def _path_from_env(name: str) -> Path | None:
    value = (os.environ.get(name) or "").strip()
    return Path(value).expanduser() if value else None


def _float_from_env(name: str, default: float) -> float:
    value = (os.environ.get(name) or "").strip()
    if not value:
        return default
    try:
        return float(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be a number") from exc


def _int_from_env(name: str, default: int) -> int:
    value = (os.environ.get(name) or "").strip()
    if not value:
        return default
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc


def _bool_from_env(name: str, default: bool) -> bool:
    value = (os.environ.get(name) or "").strip().lower()
    if not value:
        return default
    if value in {"1", "true", "yes", "on"}:
        return True
    if value in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} must be one of true/false, 1/0, yes/no, on/off")


def _first_env(*names: str) -> str | None:
    for name in names:
        value = (os.environ.get(name) or "").strip()
        if value:
            return value
    return None


@dataclass(frozen=True)
class ServerSettings:
    """Server-owned paths and credentials; never part of Agent tool input."""

    project_root: Path = DEFAULT_PROJECT_ROOT
    cache_root: Path | None = None
    output_root: Path | None = None
    repository_root: Path | None = None
    historical_worktree_root: Path | None = None
    batch_input_path: Path | None = None

    github_tokens: tuple[str, ...] = field(default=(), repr=False)
    github_timeout_seconds: float = 60.0
    github_max_retries: int = 5
    verify_ssl: bool = True
    trust_env: bool = True

    # Search & Retrieval: OpenAI-compatible structured similarity judge.
    judge_base_url: str | None = None
    judge_api_key: str | None = field(default=None, repr=False)
    judge_model: str | None = None
    judge_timeout_seconds: float = 300.0
    judge_max_retries: int = 3
    judge_max_output_tokens: int = 16384
    judge_verify_ssl: bool = True
    judge_trust_env: bool = True
    judge_max_current_issue_chars: int = 16_000
    judge_max_historical_issue_chars: int = 16_000
    judge_max_patch_chars: int = 24_000

    # Knowledge Generation: shared OpenAI-compatible Light/Grounded model.
    generator_base_url: str | None = None
    generator_api_key: str | None = field(default=None, repr=False)
    generator_model: str | None = None
    generator_timeout_seconds: float = 300.0
    generator_max_attempts: int = 5
    generator_retry_base_sleep_seconds: float = 2.0
    generator_retry_max_sleep_seconds: float = 30.0
    generator_max_output_tokens: int = 26_000
    generator_temperature: float = 1.0
    generator_verify_ssl: bool = True
    generator_trust_env: bool = True

    _resolved: bool = field(default=False, repr=False, compare=False)

    @property
    def judge_model_configured(self) -> bool:
        return bool(self.judge_api_key and self.judge_model)

    @property
    def generator_model_configured(self) -> bool:
        return bool(self.generator_api_key and self.generator_model)

    def resolved(self) -> "ServerSettings":
        """Snapshot environment once per application, including missing values."""
        if self._resolved:
            return self
        project_root = self.project_root.expanduser().resolve()
        cache_root = (self.cache_root or project_root / "cache").expanduser().resolve()
        output_root = (self.output_root or project_root / "outputs").expanduser().resolve()
        repository_root = (
            self.repository_root or cache_root / "repositories"
        ).expanduser().resolve()
        historical_worktree_root = (
            self.historical_worktree_root
            or cache_root / "historical_worktrees"
        ).expanduser().resolve()
        configured_batch_input = self.batch_input_path or _path_from_env(
            "LINGXI_ADVISOR_BATCH_INPUT_PATH"
        )
        batch_input_path = (
            configured_batch_input.expanduser().resolve()
            if configured_batch_input is not None
            else None
        )

        tokens = self.github_tokens or _tokens_from_env()

        judge_base_url = self.judge_base_url or _first_env(
            "LINGXI_ADVISOR_JUDGE_BASE_URL"
        )
        judge_api_key = self.judge_api_key or _first_env(
            "LINGXI_ADVISOR_JUDGE_API_KEY"
        )
        judge_model = self.judge_model or _first_env(
            "LINGXI_ADVISOR_JUDGE_MODEL"
        )
        generator_base_url = self.generator_base_url or _first_env(
            "LINGXI_ADVISOR_GENERATOR_BASE_URL"
        )
        generator_api_key = self.generator_api_key or _first_env(
            "LINGXI_ADVISOR_GENERATOR_API_KEY"
        )
        generator_model = self.generator_model or _first_env(
            "LINGXI_ADVISOR_GENERATOR_MODEL"
        )

        return ServerSettings(
            _resolved=True,
            project_root=project_root,
            cache_root=cache_root,
            output_root=output_root,
            repository_root=repository_root,
            historical_worktree_root=historical_worktree_root,
            batch_input_path=batch_input_path,
            github_tokens=tokens,
            github_timeout_seconds=self.github_timeout_seconds,
            github_max_retries=self.github_max_retries,
            verify_ssl=self.verify_ssl,
            trust_env=self.trust_env,
            judge_base_url=judge_base_url,
            judge_api_key=judge_api_key,
            judge_model=judge_model,
            judge_timeout_seconds=_float_from_env(
                "LINGXI_ADVISOR_JUDGE_TIMEOUT_SECONDS",
                self.judge_timeout_seconds,
            ),
            judge_max_retries=_int_from_env(
                "LINGXI_ADVISOR_JUDGE_MAX_RETRIES",
                self.judge_max_retries,
            ),
            judge_max_output_tokens=_int_from_env(
                "LINGXI_ADVISOR_JUDGE_MAX_OUTPUT_TOKENS",
                self.judge_max_output_tokens,
            ),
            judge_verify_ssl=_bool_from_env(
                "LINGXI_ADVISOR_JUDGE_VERIFY_SSL", self.judge_verify_ssl
            ),
            judge_trust_env=_bool_from_env(
                "LINGXI_ADVISOR_JUDGE_TRUST_ENV", self.judge_trust_env
            ),
            judge_max_current_issue_chars=_int_from_env(
                "LINGXI_ADVISOR_JUDGE_MAX_CURRENT_ISSUE_CHARS",
                self.judge_max_current_issue_chars,
            ),
            judge_max_historical_issue_chars=_int_from_env(
                "LINGXI_ADVISOR_JUDGE_MAX_HISTORICAL_ISSUE_CHARS",
                self.judge_max_historical_issue_chars,
            ),
            judge_max_patch_chars=_int_from_env(
                "LINGXI_ADVISOR_JUDGE_MAX_PATCH_CHARS",
                self.judge_max_patch_chars,
            ),
            generator_base_url=generator_base_url,
            generator_api_key=generator_api_key,
            generator_model=generator_model,
            generator_timeout_seconds=_float_from_env(
                "LINGXI_ADVISOR_GENERATOR_TIMEOUT_SECONDS",
                self.generator_timeout_seconds,
            ),
            generator_max_attempts=_int_from_env(
                "LINGXI_ADVISOR_GENERATOR_MAX_ATTEMPTS",
                self.generator_max_attempts,
            ),
            generator_retry_base_sleep_seconds=_float_from_env(
                "LINGXI_ADVISOR_GENERATOR_RETRY_BASE_SLEEP_SECONDS",
                self.generator_retry_base_sleep_seconds,
            ),
            generator_retry_max_sleep_seconds=_float_from_env(
                "LINGXI_ADVISOR_GENERATOR_RETRY_MAX_SLEEP_SECONDS",
                self.generator_retry_max_sleep_seconds,
            ),
            generator_max_output_tokens=_int_from_env(
                "LINGXI_ADVISOR_GENERATOR_MAX_OUTPUT_TOKENS",
                self.generator_max_output_tokens,
            ),
            generator_temperature=_float_from_env(
                "LINGXI_ADVISOR_GENERATOR_TEMPERATURE",
                self.generator_temperature,
            ),
            generator_verify_ssl=_bool_from_env(
                "LINGXI_ADVISOR_GENERATOR_VERIFY_SSL",
                self.generator_verify_ssl,
            ),
            generator_trust_env=_bool_from_env(
                "LINGXI_ADVISOR_GENERATOR_TRUST_ENV",
                self.generator_trust_env,
            ),
        )

    def ensure_directories(self) -> None:
        resolved = self.resolved()
        assert resolved.cache_root is not None
        assert resolved.output_root is not None
        assert resolved.repository_root is not None
        assert resolved.historical_worktree_root is not None
        for path in (
            resolved.project_root,
            resolved.cache_root,
            resolved.output_root,
            resolved.repository_root,
            resolved.historical_worktree_root,
        ):
            path.mkdir(parents=True, exist_ok=True)
