from __future__ import annotations

from .run_state import RunStatus

import dataclasses
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from .generation_contracts import (
    GENERATION_SCHEMA_VERSION,
    GenerationMode,
    validate_generation_mode,
)
from .search_retrieval.contracts import (
    SearchRetrievalOptions,
    SimilarityGateOptions,
    SWEbenchProInstance,
)

PREPARATION_SCHEMA_VERSION = 3


@dataclass(frozen=True)
class PreparationRequest:
    """Normalized request for the complete Knowledge Preparation pipeline."""

    instance: SWEbenchProInstance
    search_options: SearchRetrievalOptions
    gate_options: SimilarityGateOptions
    generation_mode: GenerationMode
    preretrieved_dir: Path
    knowledge_cache_dir: Path
    output_root: Path
    template_version: str
    generator_model: str
    resume: bool = True
    refresh_instance_metadata: bool = False
    allow_clone: bool = False
    allow_fetch: bool = False
    repository_root: Path | None = None
    historical_worktree_root: Path | None = None
    generation_runtime_options: Mapping[str, Any] = field(
        default_factory=dict
    )

    def validate(self) -> None:
        validate_generation_mode(self.generation_mode)
        self.search_options.validate()
        self.gate_options.validate()
        if not self.template_version.strip():
            raise ValueError("template_version cannot be empty")
        if not self.generator_model.strip():
            raise ValueError("generator_model cannot be empty")
        if not isinstance(self.generation_runtime_options, Mapping):
            raise TypeError("generation_runtime_options must be a mapping")
        if self.generation_mode == "grounded_analysis":
            if self.repository_root is None:
                raise ValueError(
                    "repository_root is required for grounded_analysis"
                )
            if self.historical_worktree_root is None:
                raise ValueError(
                    "historical_worktree_root is required for "
                    "grounded_analysis"
                )

    def to_dict(self) -> dict[str, Any]:
        value: dict[str, Any] = {
            "schema_version": PREPARATION_SCHEMA_VERSION,
            "instance": self.instance.public_dict(),
            "search_options": self.search_options.to_dict(),
            "gate_options": self.gate_options.to_dict(),
            "generation_mode": self.generation_mode,
            "preretrieved_dir": str(self.preretrieved_dir),
            "knowledge_cache_dir": str(self.knowledge_cache_dir),
            "output_root": str(self.output_root),
            "template_version": self.template_version,
            "generator_model": self.generator_model,
            "artifact_schema_version": GENERATION_SCHEMA_VERSION,
            "target_conditioned": False,
            "resume": self.resume,
            "refresh_instance_metadata": self.refresh_instance_metadata,
            "allow_clone": self.allow_clone,
            "allow_fetch": self.allow_fetch,
            "repository_root": (
                str(self.repository_root)
                if self.repository_root is not None
                else None
            ),
            "historical_worktree_root": (
                str(self.historical_worktree_root)
                if self.historical_worktree_root is not None
                else None
            ),
        }
        if self.generation_runtime_options:
            value["generation_runtime_options"] = dict(
                self.generation_runtime_options
            )
        return value


def preparation_request_id(request: PreparationRequest) -> str:
    """Return a stable identity for a complete preparation request."""

    request.validate()
    payload = request.to_dict()
    # Resume changes execution policy, not semantic output identity.
    payload.pop("resume", None)
    return hashlib.sha256(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()[:24]


@dataclass
class PreparationResult:
    schema_version: int
    request_id: str
    status: RunStatus | str
    instance_id: str
    generation_mode: str
    retrieval_status: str
    generation_status: str
    retrieval_source: str
    selected_count: int
    rejected_count: int
    completed_count: int
    cache_hit_count: int
    generated_count: int
    failed_count: int
    output_dir: str
    retrieval: dict[str, Any] = field(default_factory=dict)
    generation: dict[str, Any] = field(default_factory=dict)
    knowledge_artifacts: list[dict[str, Any]] = field(
        default_factory=list
    )
    resumed: bool = False
    retryable: bool = False
    error: str | None = None

    def __post_init__(self) -> None:
        self.status = RunStatus(self.status)

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PreparationResult":
        allowed = {item.name for item in dataclasses.fields(cls)}
        missing = [
            name
            for name in (
                "schema_version",
                "request_id",
                "status",
                "instance_id",
                "generation_mode",
                "retrieval_status",
                "generation_status",
                "retrieval_source",
                "selected_count",
                "rejected_count",
                "completed_count",
                "cache_hit_count",
                "generated_count",
                "failed_count",
                "output_dir",
            )
            if name not in value
        ]
        if missing:
            raise ValueError(
                "preparation result is missing field(s): "
                + ", ".join(missing)
            )
        return cls(**{key: value[key] for key in allowed if key in value})
