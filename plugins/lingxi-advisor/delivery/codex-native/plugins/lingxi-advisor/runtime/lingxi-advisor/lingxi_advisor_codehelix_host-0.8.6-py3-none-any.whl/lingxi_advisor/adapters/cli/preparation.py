from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

from ...api import prepare_historical_knowledge
from ...config import DEFAULT_PROJECT_ROOT, ServerSettings
from ...internal.search_retrieval.contracts import (
    SearchRetrievalOptions,
    SimilarityGateOptions,
)


def _load_dotenv(path: Path) -> None:
    if not path.is_file():
        return
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    load_dotenv(path, override=False)


def _instance(args: argparse.Namespace) -> dict[str, Any]:
    if args.instance_stdin:
        raw = sys.stdin.read()
    else:
        assert args.instance_json is not None
        raw = args.instance_json.read_text(encoding="utf-8")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("input must contain exactly one JSON object")
    return value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run the complete Knowledge Preparation pipeline: Search & "
            "Retrieval followed by cache-first Light or Grounded generation."
        )
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--instance-json", type=Path)
    source.add_argument("--instance-stdin", action="store_true")

    parser.add_argument(
        "--generation-mode",
        required=True,
        choices=["light", "grounded_analysis"],
    )
    parser.add_argument("--project-root", type=Path, default=DEFAULT_PROJECT_ROOT)
    parser.add_argument("--env-file", type=Path, default=None)
    parser.add_argument("--preretrieved-dir", type=Path, default=None)
    parser.add_argument("--knowledge-cache-dir", type=Path, default=None)
    parser.add_argument("--cache-root", type=Path, default=None)
    parser.add_argument("--output-root", type=Path, default=None)
    parser.add_argument("--repository-root", type=Path, default=None)
    parser.add_argument(
        "--historical-worktree-root",
        type=Path,
        default=None,
    )

    parser.add_argument("--search-candidate-count", type=int, default=10)
    parser.add_argument("--final-top-k", type=int, default=3)
    parser.add_argument(
        "--update-preretrieved",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    parser.add_argument(
        "--run-gate-for-preretrieved",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    parser.add_argument(
        "--search-type",
        choices=["semantic", "hybrid", "lexical"],
        default="semantic",
    )
    parser.add_argument(
        "--fallback-search-type",
        choices=["semantic", "hybrid", "lexical"],
        default="hybrid",
    )
    parser.add_argument("--per-page", type=int, default=100)
    parser.add_argument("--search-pages", type=int, default=3)
    parser.add_argument("--fallback-search-pages", type=int, default=2)
    parser.add_argument(
        "--max-search-hits-to-resolve",
        type=int,
        default=300,
    )
    parser.add_argument(
        "--primary-query-text-max-chars",
        type=int,
        default=256,
        help=(
            "Maximum GitHub search keyword-text characters; cannot exceed 256."
        ),
    )
    parser.add_argument(
        "--query-text-max-chars",
        type=int,
        default=256,
        help=(
            "Maximum keyword-text characters for extracted-keyword fallbacks; "
            "cannot exceed --primary-query-text-max-chars."
        ),
    )
    parser.add_argument(
        "--github-query-max-total-chars",
        type=int,
        default=512,
        help=(
            "Local total-query cap for extracted-keyword fallback phases; "
            "GitHub's official 256-character limit applies to keyword text."
        ),
    )
    parser.add_argument(
        "--max-single-term-fallbacks",
        type=int,
        default=2,
        help=(
            "Maximum number of final lexical fallbacks built only from "
            "high-signal code identifiers."
        ),
    )
    parser.add_argument("--max-phases", type=int, default=None)
    parser.add_argument("--search-sleep-seconds", type=float, default=0.0)
    parser.add_argument("--text-match", action="store_true")
    parser.add_argument("--refresh-search-cache", action="store_true")
    parser.add_argument("--refresh-closed-issues", action="store_true")
    parser.add_argument("--refresh-closed-pulls", action="store_true")
    parser.add_argument("--refresh-repository", action="store_true")
    parser.add_argument(
        "--closed-issues-ttl-seconds",
        type=int,
        default=86_400,
    )
    parser.add_argument(
        "--closed-pulls-ttl-seconds",
        type=int,
        default=86_400,
    )
    parser.add_argument(
        "--disable-commit-message-fallback",
        action="store_true",
    )
    parser.add_argument("--no-patch-text", action="store_true")
    parser.add_argument("--enable-issue-number-guard", action="store_true")
    parser.add_argument("--minimum-similarity-score", type=int, default=2)
    parser.add_argument("--maximum-misleading-risk", type=int, default=3)
    parser.add_argument("--refresh-instance-metadata", action="store_true")

    parser.add_argument("--judge-base-url", type=str, default=None)
    parser.add_argument("--judge-api-key", type=str, default=None)
    parser.add_argument("--judge-model", type=str, default=None)
    parser.add_argument("--judge-timeout-seconds", type=float, default=300.0)
    parser.add_argument("--judge-max-retries", type=int, default=3)
    parser.add_argument(
        "--judge-max-output-tokens",
        type=int,
        default=4096,
    )
    parser.add_argument("--generator-base-url", type=str, default=None)
    parser.add_argument("--generator-api-key", type=str, default=None)
    parser.add_argument("--generator-model", type=str, default=None)
    parser.add_argument(
        "--generator-timeout-seconds",
        type=float,
        default=300.0,
    )
    parser.add_argument("--generator-max-attempts", type=int, default=5)
    parser.add_argument(
        "--generator-retry-base-sleep-seconds",
        type=float,
        default=2.0,
    )
    parser.add_argument(
        "--generator-retry-max-sleep-seconds",
        type=float,
        default=30.0,
    )
    parser.add_argument(
        "--generator-max-output-tokens",
        type=int,
        default=26_000,
    )
    parser.add_argument(
        "--generator-temperature",
        type=float,
        default=1.0,
    )
    parser.add_argument(
        "--aspect-mode",
        choices=["base_split", "g_from_issue_plus_fg_calltrace"],
        default="g_from_issue_plus_fg_calltrace",
    )
    parser.add_argument("--template-version", type=str, default=None)

    parser.add_argument("--allow-clone", action="store_true")
    parser.add_argument("--allow-fetch", action="store_true")
    parser.add_argument(
        "--grounded-max-agent-turns",
        type=int,
        default=24,
    )
    parser.add_argument(
        "--grounded-max-tool-calls",
        type=int,
        default=20,
    )
    parser.add_argument(
        "--grounded-max-tool-output-chars",
        type=int,
        default=16_000,
    )
    parser.add_argument(
        "--grounded-max-context-chars",
        type=int,
        default=480_000,
    )
    parser.add_argument(
        "--grounded-reserved-context-fraction",
        type=float,
        default=0.15,
    )
    parser.add_argument(
        "--grounded-context-chars-per-token",
        type=int,
        default=4,
    )
    parser.add_argument(
        "--grounded-max-compacted-tool-output-chars",
        type=int,
        default=2_000,
    )
    parser.add_argument(
        "--grounded-max-file-bytes",
        type=int,
        default=2_000_000,
    )
    parser.add_argument(
        "--grounded-max-search-results",
        type=int,
        default=200,
    )
    parser.add_argument(
        "--grounded-max-glob-results",
        type=int,
        default=500,
    )
    parser.add_argument(
        "--grounded-repository-host",
        type=str,
        default="github.com",
    )
    parser.add_argument(
        "--grounded-verify-repository-identity",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument(
        "--grounded-consistency-policy",
        choices=["strict", "warn"],
        default="strict",
    )
    parser.add_argument(
        "--grounded-worktree-gc-max-count-per-repo",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--grounded-worktree-gc-max-age-days",
        type=float,
        default=0.0,
    )
    parser.add_argument(
        "--grounded-worktree-gc-max-bytes-per-repo",
        type=int,
        default=0,
    )

    parser.add_argument(
        "--resume",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument("--disable-ssl-verify", action="store_true")
    parser.add_argument("--no-trust-env", action="store_true")
    parser.add_argument("--disable-judge-ssl-verify", action="store_true")
    parser.add_argument("--no-judge-trust-env", action="store_true")
    parser.add_argument(
        "--disable-generator-ssl-verify",
        action="store_true",
    )
    parser.add_argument("--no-generator-trust-env", action="store_true")
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    project_root = args.project_root.expanduser().resolve()
    env_file = (args.env_file or project_root / ".env").expanduser().resolve()
    _load_dotenv(env_file)

    settings = ServerSettings(
        project_root=project_root,
        cache_root=args.cache_root,
        output_root=args.output_root,
        repository_root=args.repository_root,
        historical_worktree_root=args.historical_worktree_root,
        verify_ssl=not args.disable_ssl_verify,
        trust_env=not args.no_trust_env,
        judge_base_url=args.judge_base_url,
        judge_api_key=args.judge_api_key,
        judge_model=args.judge_model,
        judge_timeout_seconds=args.judge_timeout_seconds,
        judge_max_retries=args.judge_max_retries,
        judge_max_output_tokens=args.judge_max_output_tokens,
        judge_verify_ssl=not args.disable_judge_ssl_verify,
        judge_trust_env=not args.no_judge_trust_env,
        generator_base_url=args.generator_base_url,
        generator_api_key=args.generator_api_key,
        generator_model=args.generator_model,
        generator_timeout_seconds=args.generator_timeout_seconds,
        generator_max_attempts=args.generator_max_attempts,
        generator_retry_base_sleep_seconds=(
            args.generator_retry_base_sleep_seconds
        ),
        generator_retry_max_sleep_seconds=(
            args.generator_retry_max_sleep_seconds
        ),
        generator_max_output_tokens=args.generator_max_output_tokens,
        generator_temperature=args.generator_temperature,
        generator_verify_ssl=not args.disable_generator_ssl_verify,
        generator_trust_env=not args.no_generator_trust_env,
    )
    search_options = SearchRetrievalOptions(
        search_candidate_count=args.search_candidate_count,
        final_top_k=args.final_top_k,
        update_preretrieved=args.update_preretrieved,
        run_gate_for_preretrieved=args.run_gate_for_preretrieved,
        search_type=args.search_type,
        fallback_search_type=args.fallback_search_type,
        per_page=args.per_page,
        search_pages=args.search_pages,
        fallback_search_pages=args.fallback_search_pages,
        max_search_hits_to_resolve=args.max_search_hits_to_resolve,
        primary_query_text_max_chars=args.primary_query_text_max_chars,
        query_text_max_chars=args.query_text_max_chars,
        github_query_max_total_chars=args.github_query_max_total_chars,
        max_single_term_fallbacks=args.max_single_term_fallbacks,
        search_sleep_seconds=args.search_sleep_seconds,
        text_match=args.text_match,
        refresh_search_cache=args.refresh_search_cache,
        refresh_closed_issues=args.refresh_closed_issues,
        closed_issues_ttl_seconds=args.closed_issues_ttl_seconds,
        refresh_closed_pulls=args.refresh_closed_pulls,
        closed_pulls_ttl_seconds=args.closed_pulls_ttl_seconds,
        max_phases=args.max_phases,
        include_patch_text=not args.no_patch_text,
        enable_issue_number_guard=args.enable_issue_number_guard,
        enable_commit_message_fallback=(
            not args.disable_commit_message_fallback
        ),
        refresh_repository=args.refresh_repository,
    )
    gate_options = SimilarityGateOptions(
        minimum_similarity_score=args.minimum_similarity_score,
        maximum_misleading_risk=args.maximum_misleading_risk,
    )
    result = prepare_historical_knowledge(
        _instance(args),
        generation_mode=args.generation_mode,
        search_options=search_options,
        gate_options=gate_options,
        settings=settings,
        preretrieved_dir=args.preretrieved_dir,
        knowledge_cache_dir=args.knowledge_cache_dir,
        output_root=args.output_root,
        template_version=args.template_version,
        resume=args.resume,
        refresh_instance_metadata=args.refresh_instance_metadata,
        repository_root=args.repository_root,
        historical_worktree_root=args.historical_worktree_root,
        allow_clone=args.allow_clone,
        allow_fetch=args.allow_fetch,
        grounded_max_agent_turns=args.grounded_max_agent_turns,
        grounded_max_tool_calls=args.grounded_max_tool_calls,
        grounded_max_tool_output_chars=(
            args.grounded_max_tool_output_chars
        ),
        grounded_max_context_chars=args.grounded_max_context_chars,
        grounded_reserved_context_fraction=(
            args.grounded_reserved_context_fraction
        ),
        grounded_context_chars_per_token=(
            args.grounded_context_chars_per_token
        ),
        grounded_max_compacted_tool_output_chars=(
            args.grounded_max_compacted_tool_output_chars
        ),
        grounded_max_file_bytes=args.grounded_max_file_bytes,
        grounded_max_search_results=args.grounded_max_search_results,
        grounded_max_glob_results=args.grounded_max_glob_results,
        grounded_repository_host=args.grounded_repository_host,
        grounded_verify_repository_identity=(
            args.grounded_verify_repository_identity
        ),
        grounded_consistency_policy=args.grounded_consistency_policy,
        grounded_worktree_gc_max_count_per_repo=(
            args.grounded_worktree_gc_max_count_per_repo
        ),
        grounded_worktree_gc_max_age_days=(
            args.grounded_worktree_gc_max_age_days
        ),
        grounded_worktree_gc_max_bytes_per_repo=(
            args.grounded_worktree_gc_max_bytes_per_repo
        ),
        light_aspect_mode=args.aspect_mode,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "failed":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
