from __future__ import annotations

from .internal.policy import ExecutionPolicy

import dataclasses
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .artifacts import (
    FilesystemKnowledgeArtifactStore,
    KnowledgeArtifactStore,
)
from .capabilities.activate.lingxi_advisor_apply import LingxiAdvisorActivationApply
from .capabilities.activate.lingxi_advisor_search import LingxiAdvisorActivationSearch
from .capabilities.codify.lingxi_advisor_knowledge import (
    CodifyEnsureSettings,
    LingxiAdvisorCodify,
)
from .config import ServerSettings
from .internal.generation_service import KnowledgeGenerationService
from .internal.grounded_analysis.contracts import GroundedAnalysisConfig
from .internal.grounded_analysis.llm import GroundedLLMClient
from .internal.knowledge_template import DEFAULT_TEMPLATE_VERSIONS
from .internal.light_generation.contracts import LightGeneratorConfig
from .internal.light_generation.generator import LLMClient
from .internal.preparation_service import KnowledgePreparationService
from .internal.search_retrieval.service import SearchRetrievalService
from .internal.search_retrieval.safety import LeakageDetector
from .internal.search_retrieval.similarity_gate import JudgeClient


@dataclass(frozen=True)
class LingxiAdvisorCapabilities:
    """Configured Codify, Activation, and Artifact Store interfaces."""

    codify: LingxiAdvisorCodify
    activation: LingxiAdvisorActivationSearch
    apply: LingxiAdvisorActivationApply
    artifact_store: KnowledgeArtifactStore


def _light_config(
    settings: ServerSettings,
    *,
    aspect_mode: str = "g_from_issue_plus_fg_calltrace",
    model_override: str | None = None,
    base_url_override: str | None = None,
) -> LightGeneratorConfig:
    resolved = settings.resolved()
    model = model_override or resolved.generator_model or "unconfigured"
    base_url = (
        base_url_override
        or resolved.generator_base_url
        or (
            "https://api.openai.com/v1"
            if resolved.generator_model_configured
            else "https://api.openai.invalid/v1"
        )
    )
    return LightGeneratorConfig(
        model=model,
        base_url=base_url,
        api_key=resolved.generator_api_key,
        timeout_seconds=resolved.generator_timeout_seconds,
        max_attempts=resolved.generator_max_attempts,
        retry_base_sleep_seconds=(
            resolved.generator_retry_base_sleep_seconds
        ),
        retry_max_sleep_seconds=(
            resolved.generator_retry_max_sleep_seconds
        ),
        max_output_tokens=resolved.generator_max_output_tokens,
        temperature=resolved.generator_temperature,
        verify_ssl=resolved.generator_verify_ssl,
        trust_env=resolved.generator_trust_env,
        aspect_mode=aspect_mode,
    )


def _grounded_config(
    settings: ServerSettings,
    *,
    allow_clone: bool,
    allow_fetch: bool,
    repository_root: str | Path | None,
    historical_worktree_root: str | Path | None,
    max_agent_turns: int = 24,
    max_tool_calls: int = 20,
    max_tool_output_chars: int = 16_000,
    max_context_chars: int = 480_000,
    reserved_context_fraction: float = 0.15,
    context_chars_per_token: int = 4,
    max_compacted_tool_output_chars: int = 2_000,
    max_file_bytes: int = 2_000_000,
    max_search_results: int = 200,
    max_glob_results: int = 500,
    repository_host: str = "github.com",
    verify_repository_identity: bool = True,
    grounding_consistency_policy: str = "strict",
    worktree_gc_max_count_per_repo: int = 0,
    worktree_gc_max_age_days: float = 0.0,
    worktree_gc_max_bytes_per_repo: int = 0,
    model_override: str | None = None,
    base_url_override: str | None = None,
) -> GroundedAnalysisConfig:
    resolved = settings.resolved()
    assert resolved.repository_root is not None
    assert resolved.historical_worktree_root is not None
    model = model_override or resolved.generator_model or "unconfigured"
    base_url = (
        base_url_override
        or resolved.generator_base_url
        or (
            "https://api.openai.com/v1"
            if resolved.generator_model_configured
            else "https://api.openai.invalid/v1"
        )
    )
    return GroundedAnalysisConfig(
        repository_root=(
            Path(repository_root).expanduser().resolve()
            if repository_root is not None
            else resolved.repository_root
        ),
        worktree_root=(
            Path(historical_worktree_root).expanduser().resolve()
            if historical_worktree_root is not None
            else resolved.historical_worktree_root
        ),
        model=model,
        base_url=base_url,
        api_key=resolved.generator_api_key,
        timeout_seconds=resolved.generator_timeout_seconds,
        max_attempts=resolved.generator_max_attempts,
        retry_base_sleep_seconds=(
            resolved.generator_retry_base_sleep_seconds
        ),
        retry_max_sleep_seconds=(
            resolved.generator_retry_max_sleep_seconds
        ),
        max_output_tokens=resolved.generator_max_output_tokens,
        temperature=resolved.generator_temperature,
        verify_ssl=resolved.generator_verify_ssl,
        trust_env=resolved.generator_trust_env,
        allow_clone=allow_clone,
        allow_fetch=allow_fetch,
        max_agent_turns=max_agent_turns,
        max_tool_calls=max_tool_calls,
        max_tool_output_chars=max_tool_output_chars,
        max_context_chars=max_context_chars,
        reserved_context_fraction=reserved_context_fraction,
        context_chars_per_token=context_chars_per_token,
        max_compacted_tool_output_chars=(
            max_compacted_tool_output_chars
        ),
        max_file_bytes=max_file_bytes,
        max_search_results=max_search_results,
        max_glob_results=max_glob_results,
        repository_host=repository_host,
        verify_repository_identity=verify_repository_identity,
        grounding_consistency_policy=grounding_consistency_policy,
        worktree_gc_max_count_per_repo=(
            worktree_gc_max_count_per_repo
        ),
        worktree_gc_max_age_days=worktree_gc_max_age_days,
        worktree_gc_max_bytes_per_repo=(
            worktree_gc_max_bytes_per_repo
        ),
    )


def _configured_generator_model(settings: ServerSettings) -> str:
    resolved = settings.resolved()
    if not resolved.generator_model_configured:
        raise RuntimeError(
            "Operator generation requires LINGXI_ADVISOR_GENERATOR_API_KEY "
            "and LINGXI_ADVISOR_GENERATOR_MODEL. Agent Host model fallback is "
            "available only during an MCP Activation request."
        )
    assert resolved.generator_model is not None
    return resolved.generator_model


def build_lingxi_advisor_capabilities(
    *,
    settings: ServerSettings | None = None,
    preretrieved_dir: str | Path | None = None,
    knowledge_cache_dir: str | Path | None = None,
    output_root: str | Path | None = None,
    repository_root: str | Path | None = None,
    historical_worktree_root: str | Path | None = None,
    allow_clone: bool = False,
    allow_fetch: bool = False,
    light_aspect_mode: str = "g_from_issue_plus_fg_calltrace",
    write_retrieval_artifacts: bool = True,
    assembly_root: str | Path | None = None,
    judge_client_factory: Callable[[], JudgeClient] | None = None,
    light_client: LLMClient | None = None,
    grounded_client: GroundedLLMClient | None = None,
    host_model_identity: str = "agent-host",
    execution_policy: ExecutionPolicy | None = None,
    leakage_detector: LeakageDetector | None = None,
) -> LingxiAdvisorCapabilities:
    """Build path-bound implementations behind path-free capabilities."""

    resolved = (settings or ServerSettings()).resolved()
    resolved_output_root = (
        Path(output_root).expanduser().resolve()
        if output_root is not None
        else resolved.output_root or resolved.project_root / "outputs"
    )
    resolved_cache_dir = (
        Path(knowledge_cache_dir).expanduser().resolve()
        if knowledge_cache_dir is not None
        else resolved.project_root / "knowl_cache"
    )
    resolved_preretrieved_dir = (
        Path(preretrieved_dir).expanduser().resolve()
        if preretrieved_dir is not None
        else resolved.project_root / "preretrieved_issues"
    )
    use_host_generator = light_client is not None or grounded_client is not None
    generator_model_override = (
        host_model_identity
        if use_host_generator and not resolved.generator_model_configured
        else None
    )
    generator_base_url_override = (
        "mcp://agent-host"
        if generator_model_override is not None
        else None
    )
    light_configuration = _light_config(
        resolved,
        aspect_mode=light_aspect_mode,
        model_override=generator_model_override,
        base_url_override=generator_base_url_override,
    )
    grounded_configuration = _grounded_config(
        resolved,
        allow_clone=allow_clone,
        allow_fetch=allow_fetch,
        repository_root=repository_root,
        historical_worktree_root=historical_worktree_root,
        model_override=generator_model_override,
        base_url_override=generator_base_url_override,
    )
    return _compose_capabilities(
        resolved=resolved,
        resolved_output_root=resolved_output_root,
        resolved_cache_dir=resolved_cache_dir,
        resolved_preretrieved_dir=resolved_preretrieved_dir,
        light_configuration=light_configuration,
        grounded_configuration=grounded_configuration,
        allow_clone=allow_clone, allow_fetch=allow_fetch,
        write_retrieval_artifacts=write_retrieval_artifacts,
        assembly_root=assembly_root,
        judge_client_factory=judge_client_factory,
        light_client=light_client, grounded_client=grounded_client,
        execution_policy=execution_policy,
        leakage_detector=leakage_detector,
    )


def _compose_capabilities(
    *, resolved: ServerSettings,
    resolved_output_root: Path, resolved_cache_dir: Path,
    resolved_preretrieved_dir: Path,
    light_configuration: LightGeneratorConfig | None,
    grounded_configuration: GroundedAnalysisConfig | None,
    allow_clone: bool = False, allow_fetch: bool = False,
    write_retrieval_artifacts: bool = True,
    assembly_root: str | Path | None = None,
    judge_client_factory: Callable[[], JudgeClient] | None = None,
    light_client: LLMClient | None = None,
    grounded_client: GroundedLLMClient | None = None,
    execution_policy: ExecutionPolicy | None = None,
    leakage_detector: LeakageDetector | None = None,
) -> LingxiAdvisorCapabilities:
    """Own the shared object graph; callers supply resolved configuration."""
    if light_configuration is None and grounded_configuration is None:
        raise ValueError("at least one generation configuration is required")
    runtime_settings = dataclasses.replace(
        resolved,
        output_root=resolved_output_root,
        repository_root=(grounded_configuration.repository_root if grounded_configuration else resolved.repository_root),
        historical_worktree_root=(grounded_configuration.worktree_root if grounded_configuration else resolved.historical_worktree_root),
    )
    search_service = SearchRetrievalService(
        settings=runtime_settings,
        judge_client_factory=judge_client_factory,
        policy=execution_policy,
        leakage_detector=leakage_detector,
    )
    generation_service = KnowledgeGenerationService(
        light_config=light_configuration,
        light_client=light_client,
        grounded_config=grounded_configuration,
        grounded_client=grounded_client,
        policy=execution_policy,
    )
    artifact_store = FilesystemKnowledgeArtifactStore(
        resolved_cache_dir
    )
    codify = LingxiAdvisorCodify(
        preparation_service=KnowledgePreparationService(
            search_service=search_service,
            generation_service=generation_service,
        ),
        artifact_store=artifact_store,
        generation_service_factory=lambda _mode: generation_service,
        ensure_settings=CodifyEnsureSettings(
            knowledge_cache_dir=resolved_cache_dir,
            output_root=resolved_output_root,
            generator_model=(light_configuration.model if light_configuration else grounded_configuration.model),
            template_versions=DEFAULT_TEMPLATE_VERSIONS,
            allow_clone=allow_clone,
            allow_fetch=allow_fetch,
            repository_root=(grounded_configuration.repository_root if grounded_configuration else resolved.repository_root),
            historical_worktree_root=(grounded_configuration.worktree_root if grounded_configuration else resolved.historical_worktree_root),
            runtime_options={
                **({"grounded_analysis": grounded_configuration.public_dict()}
                   if grounded_configuration is not None else {})
            },
        ),
    )
    activation = LingxiAdvisorActivationSearch(
        candidate_selector=search_service,
        artifact_store=artifact_store,
        codify=codify,
        preretrieved_dir=resolved_preretrieved_dir,
        write_retrieval_artifacts=write_retrieval_artifacts,
    )
    apply_capability = LingxiAdvisorActivationApply(
        artifact_store=artifact_store,
        assembly_root=(
            Path(assembly_root).expanduser().resolve()
            if assembly_root is not None
            else resolved.project_root / "lingxi_advisor_store"
        ),
    )
    return LingxiAdvisorCapabilities(
        codify=codify,
        activation=activation,
        apply=apply_capability,
        artifact_store=artifact_store,
    )


