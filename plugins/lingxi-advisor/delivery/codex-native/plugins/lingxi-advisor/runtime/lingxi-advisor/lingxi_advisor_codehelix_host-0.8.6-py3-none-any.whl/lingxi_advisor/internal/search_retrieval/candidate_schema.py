from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Mapping

from .contracts import SWEbenchProInstance

_SHA40_RE = re.compile(r"^[0-9a-fA-F]{40}$")


def _text(value: Any) -> str:
    return str(value or "").strip()


def _int(value: Any) -> int | None:
    if value in (None, "") or isinstance(value, bool):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _metadata(row: Mapping[str, Any]) -> Mapping[str, Any]:
    value = row.get("retrieved_metadata") or row.get("metadata")
    return value if isinstance(value, Mapping) else {}


def historical_issue_description(row: Mapping[str, Any]) -> str:
    for key in (
        "historical_issue_description",
        "retrieved_issue_desc",
        "issue_description",
    ):
        text = _text(row.get(key))
        if text:
            return text
    return "\n\n".join(
        part
        for part in (
            _text(row.get("historical_issue_title") or row.get("retrieved_issue_title")),
            _text(row.get("historical_issue_body") or row.get("retrieved_issue_body")),
        )
        if part
    )


def historical_patch(row: Mapping[str, Any]) -> str:
    for key in (
        "historical_patch",
        "retrieved_issue_ground_truth_patch",
        "retrieved_patch",
        "patch",
        "pr_patch",
        "merge_commit_patch",
    ):
        text = _text(row.get(key))
        if text:
            return text
    return ""


def candidate_repo(row: Mapping[str, Any], instance: SWEbenchProInstance | None = None) -> str:
    metadata = _metadata(row)
    for value in (
        row.get("repo"),
        row.get("historical_repo"),
        row.get("retrieved_repo"),
        metadata.get("repo"),
        row.get("instance_repo"),
        instance.repo if instance is not None else None,
    ):
        text = _text(value).strip("/")
        if "/" in text:
            return text
    return ""


def historical_issue_number(row: Mapping[str, Any]) -> int | None:
    metadata = _metadata(row)
    for value in (
        row.get("historical_issue_number"),
        row.get("retrieved_issue_number"),
        row.get("issue_number"),
        metadata.get("issue_number"),
        metadata.get("issue_number_int"),
    ):
        parsed = _int(value)
        if parsed is not None:
            return parsed
    return None


def historical_issue_url(row: Mapping[str, Any], repo: str, issue_number: int | None) -> str:
    metadata = _metadata(row)
    for value in (
        row.get("historical_issue_url"),
        row.get("retrieved_issue_url"),
        metadata.get("issue_url"),
        row.get("html_url"),
    ):
        text = _text(value)
        if text:
            return text
    if repo and issue_number is not None:
        return f"https://github.com/{repo}/issues/{issue_number}"
    return ""


def historical_fix_commit(row: Mapping[str, Any]) -> str | None:
    metadata = _metadata(row)

    def valid(value: Any) -> str | None:
        text = _text(value).lower()
        return text if _SHA40_RE.fullmatch(text) else None

    for value in (
        row.get("historical_fix_commit"),
        row.get("retrieved_grounding_commit_id"),
        metadata.get("retrieved_grounding_commit_id"),
        row.get("retrieved_commit_id"),
        metadata.get("retrieved_commit_id"),
        row.get("merge_commit_sha"),
        row.get("head_sha"),
    ):
        sha = valid(value)
        if sha:
            return sha
    commit_ids = row.get("retrieved_commit_ids")
    if isinstance(commit_ids, list):
        for value in reversed(commit_ids):
            sha = valid(value)
            if sha:
                return sha
    return None


def candidate_fingerprint(row: Mapping[str, Any], instance: SWEbenchProInstance | None = None) -> str:
    patch = historical_patch(row)
    payload = {
        "repo": candidate_repo(row, instance),
        "historical_issue_number": historical_issue_number(row),
        "historical_issue_url": historical_issue_url(
            row,
            candidate_repo(row, instance),
            historical_issue_number(row),
        ),
        "historical_fix_commit": historical_fix_commit(row),
        "patch_sha256": hashlib.sha256(
            patch.encode("utf-8", errors="replace")
        ).hexdigest(),
    }
    return hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()[:24]


def canonical_candidate_row(
    row: Mapping[str, Any],
    *,
    instance: SWEbenchProInstance,
    retrieval_source: str,
    retrieval_rank: int,
    source_path: str | None = None,
) -> dict[str, Any]:
    """Return the unified Search & Retrieval candidate schema.

    Legacy fields are retained for safety checks and for old downstream readers,
    but the canonical fields are the ``historical_*`` names.
    """

    candidate = dict(row)
    repo = candidate_repo(candidate, instance)
    issue_number = historical_issue_number(candidate)
    issue_desc = historical_issue_description(candidate)
    patch = historical_patch(candidate)
    issue_url = historical_issue_url(candidate, repo, issue_number)
    fix_commit = historical_fix_commit(candidate)
    fingerprint = (
        _text(candidate.get("historical_candidate_fingerprint"))
        or candidate_fingerprint(candidate, instance)
    )

    candidate["schema_version"] = 1
    candidate["instance_id"] = instance.instance_id
    candidate["repo"] = instance.repo
    candidate["instance_repo"] = instance.repo
    candidate["instance_base_commit"] = instance.base_commit
    candidate["problem_statement"] = instance.problem_statement
    candidate["requirements"] = instance.requirements
    if instance.instance_issue_number is not None:
        candidate["instance_issue_number"] = instance.instance_issue_number
    if instance.instance_create_at:
        candidate["instance_create_at"] = instance.instance_create_at
    if instance.base_commit_created_at:
        candidate["instance_base_commit_created_at"] = instance.base_commit_created_at

    candidate["retrieval_source"] = retrieval_source
    candidate["retrieval_rank"] = int(retrieval_rank)
    candidate["candidate_position"] = int(retrieval_rank) - 1
    candidate.pop("candidate_pool_position", None)
    candidate.pop("reranked_position", None)
    candidate.pop("qwen_reranked", None)
    candidate.pop("relevance_score", None)
    candidate.pop("reranker_score", None)
    candidate.pop("reranker_model", None)
    candidate.pop("reranking_error", None)

    candidate["historical_issue_number"] = issue_number
    candidate["historical_issue_url"] = issue_url
    candidate["historical_issue_description"] = issue_desc
    candidate["historical_patch"] = patch
    candidate["historical_fix_commit"] = fix_commit
    candidate["historical_candidate_fingerprint"] = fingerprint
    candidate["historical_patch_sha256"] = hashlib.sha256(
        patch.encode("utf-8", errors="replace")
    ).hexdigest()

    # Compatibility fields consumed by the existing safety and generation helpers.
    candidate.setdefault("retrieved_repo", repo)
    candidate.setdefault("retrieved_issue_number", issue_number)
    candidate.setdefault("retrieved_issue_url", issue_url)
    candidate.setdefault("retrieved_issue_desc", issue_desc)
    candidate.setdefault("retrieved_patch", patch)
    candidate.setdefault("retrieved_issue_ground_truth_patch", patch)
    if fix_commit:
        candidate.setdefault("retrieved_commit_id", fix_commit)
    if source_path is not None:
        candidate["preretrieved_source_path"] = source_path
    return candidate


def row_is_invalidated(row: Mapping[str, Any]) -> bool:
    for key in (
        "invalid",
        "superseded",
        "leakage_contaminated",
        "leakage_contamination",
    ):
        if row.get(key) is True:
            return True
    status = _text(row.get("status")).lower()
    return status in {"invalid", "superseded", "leakage", "leakage_contaminated"}
