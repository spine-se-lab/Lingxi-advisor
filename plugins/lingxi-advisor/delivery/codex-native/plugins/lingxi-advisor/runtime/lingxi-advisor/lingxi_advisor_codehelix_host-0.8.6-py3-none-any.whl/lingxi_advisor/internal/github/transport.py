"""GitHub HTTP transport, pagination and rate-limit rotation."""
from __future__ import annotations

from ..execution import checkpoint, bounded_timeout, interruptible_sleep, execution_scope, ExecutionFailure

import os
import re
import time
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

from .common import (
    logger,
    safe_str,
)
from .query import (
    effective_query_component_lengths,
)

import httpx
from ..tls import httpx_verify


class GithubAPIError(RuntimeError):
    """Structured GitHub REST error that preserves the HTTP status code."""

    def __init__(
        self,
        *,
        status_code: int,
        method: str,
        url: str,
        response_text: str,
    ) -> None:
        self.status_code = int(status_code)
        self.method = method
        self.url = url
        self.response_text = response_text
        super().__init__(
            f"GitHub API error {self.status_code} for {method} {url}: "
            f"{response_text[:2000]}"
        )


class GithubTokenRotator:
    def __init__(self, tokens: Sequence[str]):
        cleaned: List[str] = []
        seen: set[str] = set()
        for token in tokens:
            token = safe_str(token)
            if token and token not in seen:
                cleaned.append(token)
                seen.add(token)
        if not cleaned:
            raise RuntimeError("At least one GitHub token is required.")
        self.tokens = cleaned
        self.index = 0
        self.blocked_until: Dict[str, float] = {}

    def token_count(self) -> int:
        return len(self.tokens)

    def current_token(self) -> str:
        with execution_scope(60):
            while True:
                checkpoint()
                now = time.time()
                for offset in range(len(self.tokens)):
                    idx = (self.index + offset) % len(self.tokens)
                    token = self.tokens[idx]
                    if self.blocked_until.get(token, 0.0) <= now:
                        self.index = idx
                        return token
                wait = max(1, int(min(self.blocked_until.values()) - now))
                logger.warning("All GitHub tokens are rate limited. Sleeping %s seconds.", wait)
                interruptible_sleep(wait)

    def mark_limited_and_rotate(self, token: str, reset_epoch: Optional[int] = None) -> str:
        self.blocked_until[token] = (float(reset_epoch) + 5.0) if reset_epoch else (time.time() + 60.0)
        try:
            idx = self.tokens.index(token)
        except ValueError:
            idx = self.index
        self.index = (idx + 1) % len(self.tokens)
        return self.current_token()


def load_github_tokens_from_env() -> List[str]:
    names = ["GITHUB_TOKEN"] + [f"GITHUB_TOKEN_{idx}" for idx in range(1, 16)]
    tokens: List[str] = []
    seen: set[str] = set()
    for name in names:
        token = safe_str(os.environ.get(name))
        if token and token not in seen:
            tokens.append(token)
            seen.add(token)
    return tokens


class GithubClient:
    def __init__(
        self,
        token_rotator: GithubTokenRotator,
        timeout: float = 60.0,
        verify_ssl: bool = False,
        trust_env: bool = True,
        max_retries: int = 5,
    ):
        self.base_url = "https://api.github.com"
        self.token_rotator = token_rotator
        self.current_token = token_rotator.current_token()
        self.max_retries = max_retries
        self.timeout_seconds = timeout
        self._last_headers: Dict[str, str] = {}
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "knowledge-similarity-github-api-v4",
        }
        verify = httpx_verify(verify_ssl)
        self.client = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
            verify=verify,
            trust_env=trust_env,
        )
        self._apply_token()

    def close(self) -> None:
        self.client.close()

    def _apply_token(self) -> None:
        self.client.headers["Authorization"] = f"Bearer {self.current_token}"

    def _sync_token(self) -> None:
        token = self.token_rotator.current_token()
        if token != self.current_token:
            self.current_token = token
            self._apply_token()

    @staticmethod
    def _reset_epoch(headers: Dict[str, str]) -> Optional[int]:
        raw = headers.get("x-ratelimit-reset")
        return int(raw) if raw and raw.isdigit() else None

    def _handle_rate_limit(self, resp: httpx.Response, attempt: int) -> bool:
        remaining = resp.headers.get("x-ratelimit-remaining")
        if resp.status_code == 403 and remaining == "0":
            self.current_token = self.token_rotator.mark_limited_and_rotate(
                self.current_token,
                reset_epoch=self._reset_epoch(dict(resp.headers)),
            )
            self._apply_token()
            return True
        if resp.status_code in {403, 429} and "rate limit" in resp.text.lower():
            retry_after = resp.headers.get("retry-after")
            wait = int(retry_after) + 1 if retry_after and retry_after.isdigit() else min(300, 30 * (2 ** min(attempt, 4)))
            logger.warning("GitHub secondary rate limit. Sleeping %s seconds.", wait)
            interruptible_sleep(wait)
            return True
        return False

    def request_json(self, method: str, url: str, *, accept: Optional[str] = None, allow_404: bool = False, **kwargs: Any) -> Any:
        max_attempts = max(1, self.max_retries * self.token_rotator.token_count())
        last_error: Optional[BaseException] = None
        request_headers = dict(kwargs.pop("headers", {}) or {})
        if accept:
            request_headers["Accept"] = accept
        for attempt in range(max_attempts):
            checkpoint()
            self._sync_token()
            try:
                resp = self.client.request(method, url, headers=request_headers or None, timeout=bounded_timeout(self.timeout_seconds), **kwargs)
                self._last_headers = dict(resp.headers)
            except httpx.HTTPError as exc:
                last_error = exc
                wait = min(120, 5 * (2 ** min(attempt, 4)))
                logger.warning("GitHub request failed: %s. Retrying in %s seconds.", exc, wait)
                interruptible_sleep(wait)
                continue
            if self._handle_rate_limit(resp, attempt):
                last_error = ExecutionFailure('rate_limited', 'GitHub rate limit retry budget exhausted', retryable=True)
                continue
            if allow_404 and resp.status_code == 404:
                return None
            if resp.status_code in {500, 502, 503, 504}:
                last_error = GithubAPIError(status_code=resp.status_code, method=method, url=url, response_text=resp.text)
                wait = min(120, 5 * (2 ** min(attempt, 4)))
                logger.warning("GitHub server error %s. Retrying in %s seconds.", resp.status_code, wait)
                interruptible_sleep(wait)
                continue
            if resp.status_code >= 400:
                raise GithubAPIError(
                    status_code=resp.status_code,
                    method=method,
                    url=url,
                    response_text=resp.text,
                )
            return resp.json() if resp.content else None
        if last_error is not None:
            raise RuntimeError(f"GitHub request failed after retries: {method} {url}: {last_error}") from last_error
        raise RuntimeError(f"GitHub request failed after retries: {method} {url}")

    def request_text(self, method: str, url: str, *, accept: str, allow_404: bool = False, **kwargs: Any) -> Optional[str]:
        max_attempts = max(1, self.max_retries * self.token_rotator.token_count())
        last_error: Optional[BaseException] = None
        for attempt in range(max_attempts):
            checkpoint()
            self._sync_token()
            try:
                resp = self.client.request(method, url, headers={"Accept": accept}, timeout=bounded_timeout(self.timeout_seconds), **kwargs)
                self._last_headers = dict(resp.headers)
            except httpx.HTTPError as exc:
                last_error = exc
                wait = min(120, 5 * (2 ** min(attempt, 4)))
                logger.warning("GitHub text request failed: %s. Retrying in %s seconds.", exc, wait)
                interruptible_sleep(wait)
                continue
            if self._handle_rate_limit(resp, attempt):
                last_error = ExecutionFailure('rate_limited', 'GitHub rate limit retry budget exhausted', retryable=True)
                continue
            if allow_404 and resp.status_code == 404:
                return None
            if resp.status_code in {500, 502, 503, 504}:
                last_error = GithubAPIError(status_code=resp.status_code, method=method, url=url, response_text=resp.text)
                wait = min(120, 5 * (2 ** min(attempt, 4)))
                logger.warning("GitHub server error %s. Retrying in %s seconds.", resp.status_code, wait)
                interruptible_sleep(wait)
                continue
            if resp.status_code >= 400:
                raise GithubAPIError(status_code=resp.status_code, method=method, url=url, response_text=resp.text)
            return resp.text
        if last_error is not None:
            raise RuntimeError(f"GitHub text request failed after retries: {method} {url}: {last_error}") from last_error
        raise RuntimeError(f"GitHub text request failed after retries: {method} {url}")

    def paginate(self, url: str, params: Optional[Dict[str, Any]] = None) -> Iterator[Any]:
        next_url: Optional[str] = url
        current_params = dict(params or {})
        while next_url:
            data = self.request_json(
                "GET",
                next_url,
                params=current_params if next_url == url else None,
            )
            if not isinstance(data, list):
                raise RuntimeError(f"Expected list response for pagination: {url}; got {type(data).__name__}")
            yield from data
            response_links = httpx.Response(
                200,
                headers=self._last_headers,
            ).links
            next_link = response_links.get("next", {}).get("url")
            if next_link and next_link.startswith(self.base_url):
                next_link = next_link[len(self.base_url):]
            next_url = next_link
            current_params = {}

    def search_issues_or_prs(
        self,
        *,
        query: str,
        search_type: str,
        per_page: int,
        page: int,
        text_match: bool,
    ) -> Dict[str, Any]:
        """Search issues/PRs once with a pre-normalized, pre-bounded query.

        Query construction owns normalization and the documented GitHub
        search-text limit. A 414/422 response is therefore recorded as a
        structured query failure; it is never used to drive query rewriting or
        additional probe requests.
        """
        headers = (
            {"Accept": "application/vnd.github.text-match+json"}
            if text_match
            else None
        )
        original_query = re.sub(r"\s+", " ", query).strip()

        def execute(search_query: str) -> Dict[str, Any]:
            params = {
                "q": search_query,
                "advanced_search": "true",
                "search_type": search_type,
                "per_page": int(per_page),
                "page": int(page),
            }
            payload = self.request_json(
                "GET",
                "/search/issues",
                params=params,
                headers=headers or {},
            )
            return payload if isinstance(payload, dict) else {}

        def annotate(
            payload: Dict[str, Any],
            *,
            effective_query: str,
            attempts: int,
            query_error: Optional[str],
        ) -> Dict[str, Any]:
            result = dict(payload)
            lengths = effective_query_component_lengths(
                original_query,
                effective_query,
            )
            result.update(
                {
                    "_search_query_original": original_query,
                    "_search_query_effective": effective_query,
                    "_search_query_effective_text": lengths[
                        "effective_query_text"
                    ],
                    "_search_query_original_chars": len(original_query),
                    "_search_query_effective_chars": len(effective_query),
                    "_search_query_auto_truncated": (
                        effective_query != original_query
                    ),
                    "_search_query_request_attempts": attempts,
                    "_search_query_original_422_error": query_error,
                    "_search_query_failed": bool(query_error),
                    "_search_problem_original_chars": lengths[
                        "problem_original_chars"
                    ],
                    "_search_problem_effective_chars": lengths[
                        "problem_effective_chars"
                    ],
                    "_search_requirements_original_chars": lengths[
                        "requirements_original_chars"
                    ],
                    "_search_requirements_effective_chars": lengths[
                        "requirements_effective_chars"
                    ],
                }
            )
            return result

        try:
            return annotate(
                execute(original_query),
                effective_query=original_query,
                attempts=1,
                query_error=None,
            )
        except GithubAPIError as exc:
            if exc.status_code not in {414, 422}:
                raise
            error = str(exc)[:2000]
            logger.error(
                "GitHub rejected a pre-normalized search query. "
                "status=%s query=%r error=%s",
                exc.status_code,
                original_query,
                error[:1000],
            )
            failed = annotate(
                {
                    "items": [],
                    "total_count": 0,
                    "incomplete_results": False,
                    "query_error": error,
                    "query_error_status_code": exc.status_code,
                },
                effective_query=original_query,
                attempts=1,
                query_error=error,
            )
            failed["_search_query_failed"] = True
            return failed

    def graphql(self, query: str, variables: Dict[str, Any]) -> Dict[str, Any]:
        max_attempts = max(1, self.max_retries * self.token_rotator.token_count())
        for _ in range(max_attempts):
            data = self.request_json("POST", "/graphql", json={"query": query, "variables": variables}) or {}
            errors = data.get("errors") if isinstance(data, dict) else None
            if errors and self._is_graphql_rate_limit_error(errors):
                self.current_token = self.token_rotator.mark_limited_and_rotate(
                    self.current_token,
                    reset_epoch=self._reset_epoch(self._last_headers),
                )
                self._apply_token()
                continue
            if errors:
                raise RuntimeError(f"GitHub GraphQL errors: {errors}")
            return data
        raise RuntimeError("GitHub GraphQL request failed after rotating through available tokens.")

    @staticmethod
    def _is_graphql_rate_limit_error(errors: Any) -> bool:
        if not isinstance(errors, list):
            return False
        for err in errors:
            if not isinstance(err, dict):
                continue
            if err.get("type") == "RATE_LIMIT" or err.get("code") == "graphql_rate_limit":
                return True
            if "rate limit" in safe_str(err.get("message")).lower():
                return True
        return False

    @staticmethod
    def split_repo(repo: str) -> Tuple[str, str]:
        owner, name = repo.split("/", 1)
        return owner, name

    def get_issue(self, repo: str, issue_number: int) -> Optional[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        return self.request_json("GET", f"/repos/{owner}/{name}/issues/{int(issue_number)}", allow_404=True)

    def get_commit_at_or_before(
        self,
        repo: str,
        created_at: str,
    ) -> Optional[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        payload = self.request_json(
            "GET",
            f"/repos/{owner}/{name}/commits",
            params={"until": created_at, "per_page": 1},
        )
        if not isinstance(payload, list) or not payload:
            return None
        commit = payload[0]
        return commit if isinstance(commit, dict) else None

    def get_pr(self, repo: str, pr_number: int) -> Optional[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        return self.request_json("GET", f"/repos/{owner}/{name}/pulls/{int(pr_number)}", allow_404=True)

    def get_pr_files(self, repo: str, pr_number: int) -> List[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        return list(self.paginate(f"/repos/{owner}/{name}/pulls/{int(pr_number)}/files", params={"per_page": 100}))

    def get_pr_commits(self, repo: str, pr_number: int) -> List[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        return list(self.paginate(f"/repos/{owner}/{name}/pulls/{int(pr_number)}/commits", params={"per_page": 100}))

    def get_pr_patch(self, repo: str, pr_number: int) -> str:
        owner, name = self.split_repo(repo)
        return self.request_text("GET", f"/repos/{owner}/{name}/pulls/{int(pr_number)}", accept="application/vnd.github.v3.patch") or ""

    def get_commit(self, repo: str, sha: str) -> Optional[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        return self.request_json("GET", f"/repos/{owner}/{name}/commits/{sha}", allow_404=True)

    def get_commit_patch(self, repo: str, sha: str) -> str:
        owner, name = self.split_repo(repo)
        return self.request_text("GET", f"/repos/{owner}/{name}/commits/{sha}", accept="application/vnd.github.v3.patch", allow_404=True) or ""

    def get_commit_associated_prs(self, repo: str, sha: str) -> List[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        payload = self.request_json("GET", f"/repos/{owner}/{name}/commits/{sha}/pulls", allow_404=True)
        return payload or []

    def get_issue_latest_pr_closer_event_graphql(self, repo: str, issue_number: int) -> Optional[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        cursor: Optional[str] = None
        latest_pr_event: Optional[Dict[str, Any]] = None
        query = """
        query($owner: String!, $name: String!, $issueNumber: Int!, $cursor: String) {
          repository(owner: $owner, name: $name) {
            issue(number: $issueNumber) {
              number
              timelineItems(first: 100, after: $cursor, itemTypes: [CLOSED_EVENT]) {
                pageInfo { hasNextPage endCursor }
                nodes {
                  __typename
                  ... on ClosedEvent {
                    createdAt
                    actor { login }
                    closer {
                      __typename
                      ... on PullRequest {
                        number
                        title
                        url
                        state
                        merged
                        mergedAt
                        closedAt
                        baseRefName
                        headRefName
                        baseRefOid
                        headRefOid
                        mergeCommit { oid }
                      }
                      ... on Commit { oid url }
                    }
                  }
                }
              }
            }
          }
        }
        """
        while True:
            data = self.graphql(query, {"owner": owner, "name": name, "issueNumber": int(issue_number), "cursor": cursor})
            issue_data = data.get("data", {}).get("repository", {}).get("issue")
            if not issue_data:
                return latest_pr_event
            timeline = issue_data.get("timelineItems", {}) or {}
            nodes = timeline.get("nodes", []) or []
            for event in nodes:
                if event.get("__typename") != "ClosedEvent":
                    continue
                closer = event.get("closer") or {}
                if closer.get("__typename") == "PullRequest":
                    latest_pr_event = event
            page_info = timeline.get("pageInfo", {}) or {}
            if not page_info.get("hasNextPage"):
                break
            cursor = page_info.get("endCursor")
            if not cursor:
                break
        return latest_pr_event

    def get_issue_closing_prs_graphql(
        self,
        repo: str,
        issue_number: int,
    ) -> List[Dict[str, Any]]:
        """Return canonical PR relations recorded on an issue by GitHub."""
        owner, name = self.split_repo(repo)
        query = """
        query($owner: String!, $name: String!, $issueNumber: Int!) {
          repository(owner: $owner, name: $name) {
            issue(number: $issueNumber) {
              closedByPullRequestsReferences(first: 20, includeClosedPrs: true) {
                nodes {
                  number
                  title
                  url
                  state
                  merged
                  mergedAt
                }
              }
            }
          }
        }
        """
        data = self.graphql(
            query,
            {
                "owner": owner,
                "name": name,
                "issueNumber": int(issue_number),
            },
        )
        data_payload = data.get("data") or {}
        repository_payload = data_payload.get("repository") or {}
        issue_payload = repository_payload.get("issue") or {}
        relation_payload = issue_payload.get("closedByPullRequestsReferences") or {}
        nodes = relation_payload.get("nodes") or []
        return [node for node in nodes if isinstance(node, dict)]

    def get_pr_closing_issues_graphql(self, repo: str, pr_number: int) -> List[Dict[str, Any]]:
        owner, name = self.split_repo(repo)
        query = """
        query($owner: String!, $name: String!, $prNumber: Int!) {
          repository(owner: $owner, name: $name) {
            pullRequest(number: $prNumber) {
              closingIssuesReferences(first: 50) {
                nodes {
                  number
                  title
                  body
                  url
                  createdAt
                  updatedAt
                  closedAt
                  state
                  stateReason
                  labels(first: 50) { nodes { name } }
                }
              }
            }
          }
        }
        """
        data = self.graphql(query, {"owner": owner, "name": name, "prNumber": int(pr_number)})
        nodes = (
            data.get("data", {})
            .get("repository", {})
            .get("pullRequest", {})
            .get("closingIssuesReferences", {})
            .get("nodes", [])
            or []
        )
        issues: List[Dict[str, Any]] = []
        for node in nodes:
            if not isinstance(node, dict):
                continue
            labels = node.get("labels", {}).get("nodes", []) if isinstance(node.get("labels"), dict) else []
            issues.append({
                "number": node.get("number"),
                "title": node.get("title"),
                "body": node.get("body") or "",
                "html_url": node.get("url"),
                "state": safe_str(node.get("state")).lower(),
                "state_reason": node.get("stateReason"),
                "created_at": node.get("createdAt"),
                "updated_at": node.get("updatedAt"),
                "closed_at": node.get("closedAt"),
                "labels": [{"name": label.get("name")} for label in labels if isinstance(label, dict)],
            })
        return issues
