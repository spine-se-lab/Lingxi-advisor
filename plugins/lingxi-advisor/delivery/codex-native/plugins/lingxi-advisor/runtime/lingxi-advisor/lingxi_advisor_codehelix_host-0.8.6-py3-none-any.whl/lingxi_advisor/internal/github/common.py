"""Normalization, historical timestamps and local Git access."""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional



SCRIPT_VERSION = "v4_semantic_signal_dense_20260828"


logger = logging.getLogger("git_search.github_api_retrieval_v4")


SHA40_RE = re.compile(r"\b[0-9a-fA-F]{40}\b")


GITHUB_SEARCH_TEXT_MAX_CHARS = 256


DERIVED_ISSUE_TITLE_MAX_CHARS = 120


def safe_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (list, tuple, set)):
        return "\n".join(part for part in (safe_str(x) for x in value) if part)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return str(value).strip()


def safe_float(value: Any, default: float = 0.0) -> float:
    if value is None or isinstance(value, bool):
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_int(value: Any, default: int = 0) -> int:
    if value is None or isinstance(value, bool):
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_filename_part(value: str, max_len: int = 180) -> str:
    value = re.sub(r"[^\w\-.]+", "_", str(value).strip()).strip("._")
    if not value:
        value = "empty"
    if len(value) > max_len:
        digest = hashlib.md5(value.encode("utf-8")).hexdigest()[:12]
        value = f"{value[:max_len - 13]}_{digest}"
    return value


def content_hash(text: str, length: int = 16) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()[:length]


def normalize_repo(repo: Any) -> str:
    return safe_str(repo).strip().strip("/")


def repo_identity_key(repo: Any) -> str:
    """Return a comparison-only repository identity while preserving display case."""
    return normalize_repo(repo).casefold()


def same_repository(left: Any, right: Any) -> bool:
    """Compare normalized repository identities without requiring display-case equality."""
    left_key = repo_identity_key(left)
    right_key = repo_identity_key(right)
    return bool(left_key and right_key and left_key == right_key)


def repo_name_from_repo(repo: str) -> str:
    return repo.split("/")[-1] if repo else ""


def repo_local_name(repo: str) -> str:
    owner, name = repo.split("/", 1)
    return f"{safe_filename_part(owner)}__{safe_filename_part(name)}"


def resolve_repo_checkout(repo: str, repo_checkout_root: Path) -> Optional[Path]:
    path = repo_checkout_root / repo_local_name(repo)
    return path if (path / ".git").exists() else None


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, raw in enumerate(handle, start=1):
            line = raw.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"Invalid JSON at {path}:{line_no}: {exc}") from exc
            if not isinstance(obj, dict):
                raise RuntimeError(f"Expected JSON object at {path}:{line_no}")
            obj.setdefault("_source_line", line_no)
            rows.append(obj)
    return rows


def read_json(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return obj if isinstance(obj, dict) else None


from ..io_utils import write_json_atomic, write_jsonl_atomic


def load_instance_filter(path: Optional[Path]) -> Optional[set[str]]:
    if path is None:
        return None
    if not path.exists():
        raise FileNotFoundError(f"Instance filter not found: {path}")

    ids: set[str] = set()
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                raise RuntimeError(f"CSV has no header: {path}")
            column = "instance_id" if "instance_id" in reader.fieldnames else reader.fieldnames[0]
            for row in reader:
                value = safe_str(row.get(column)).removeprefix("scale-ai/")
                if value:
                    ids.add(value)
        return ids

    with path.open("r", encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("{"):
                obj = json.loads(line)
                value = safe_str(obj.get("instance_id"))
            else:
                value = safe_str(line.split("\t")[-1])
            value = value.removeprefix("scale-ai/")
            if value:
                ids.add(value)
    return ids


def parse_datetime_to_utc(value: Any) -> Optional[dt.datetime]:
    text = safe_str(value)
    if not text:
        return None

    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        try:
            number = float(text)
            if number > 10_000_000_000:
                number /= 1000.0
            return dt.datetime.fromtimestamp(number, tz=dt.timezone.utc)
        except Exception:
            return None

    if text.endswith("Z"):
        text = text[:-1] + "+00:00"

    for candidate in (text, text.replace(" ", "T")):
        try:
            parsed = dt.datetime.fromisoformat(candidate)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=dt.timezone.utc)
            return parsed.astimezone(dt.timezone.utc)
        except ValueError:
            pass

    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%b %d, %Y, %I:%M:%S %p"):
        try:
            parsed = dt.datetime.strptime(text, fmt)
            return parsed.replace(tzinfo=dt.timezone.utc)
        except ValueError:
            pass

    return None


def datetime_to_ts(value: Optional[dt.datetime]) -> float:
    return float(value.timestamp()) if value is not None else 0.0


def isoformat_utc(value: Optional[dt.datetime]) -> str:
    if value is None:
        return ""
    return value.astimezone(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def parse_issue_number_int(value: Any) -> Optional[int]:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    if isinstance(value, float):
        return int(value) if value > 0 and value.is_integer() else None
    match = re.search(r"\d+", safe_str(value))
    if not match:
        return None
    number = int(match.group(0))
    return number if number > 0 else None


def instance_identifier(instance: Dict[str, Any]) -> str:
    instance_id = safe_str(instance.get("instance_id"))
    if instance_id:
        return instance_id
    repo = normalize_repo(instance.get("repo"))
    base_commit = safe_str(instance.get("base_commit"))
    raw = json.dumps(instance, ensure_ascii=False, sort_keys=True)
    return f"{repo}-{base_commit}-{content_hash(raw)}"


def infer_target_commit_from_instance(instance: Dict[str, Any]) -> str:
    for key in ("target_commit", "patch_commit", "solution_commit", "commit", "resolved_commit"):
        value = safe_str(instance.get(key)).lower()
        if SHA40_RE.fullmatch(value):
            return value

    instance_id = instance_identifier(instance)
    base_commit = safe_str(instance.get("base_commit")).lower()
    candidates = [m.group(0).lower() for m in SHA40_RE.finditer(instance_id)]
    for sha in candidates:
        if sha != base_commit:
            return sha
    return candidates[0] if candidates else ""


def extract_sha_set(value: Any) -> set[str]:
    if value is None:
        return set()
    if isinstance(value, dict):
        text = json.dumps(value, ensure_ascii=False, sort_keys=True)
        return {m.group(0).lower() for m in SHA40_RE.finditer(text)}
    if isinstance(value, (list, tuple, set)):
        result: set[str] = set()
        for item in value:
            result.update(extract_sha_set(item))
        return result
    return {m.group(0).lower() for m in SHA40_RE.finditer(safe_str(value))}


def run_git(
    repo_path: Path,
    *args: str,
    check: bool = True,
    timeout: float | None = None,
) -> str:
    proc = subprocess.run(
        ["git", "-C", str(repo_path), *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=check,
        timeout=timeout,
    )
    return proc.stdout.strip()


def get_commit_time_from_git(repo_path: Optional[Path], sha: str) -> Optional[dt.datetime]:
    if not repo_path or not sha:
        return None
    try:
        out = run_git(
            repo_path,
            "show",
            "-s",
            "--format=%cI",
            sha,
            timeout=30.0,
        )
    except Exception:
        return None
    return parse_datetime_to_utc(out)


def commit_exists_locally(repo_path: Optional[Path], sha: str) -> bool:
    if not repo_path or not sha:
        return False
    proc = subprocess.run(
        ["git", "-C", str(repo_path), "cat-file", "-e", f"{sha}^{{commit}}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        text=True,
        timeout=30.0,
    )
    return proc.returncode == 0


def is_blobless_partial_clone(repo_path: Path) -> bool:
    """Return whether the server-owned repository omits blobs by design."""

    config_path = repo_path / ".git" / "config"
    try:
        config_text = config_path.read_text(
            encoding="utf-8",
            errors="replace",
        )
    except OSError:
        return False
    return bool(
        re.search(r"(?im)^\s*promisor\s*=\s*true\s*$", config_text)
        and re.search(
            r"(?im)^\s*partialclonefilter\s*=\s*blob:none\s*$",
            config_text,
        )
    )


def format_patch_from_local_git(repo_path: Path, sha: str) -> str:
    return run_git(
        repo_path,
        "format-patch",
        "-1",
        "--stdout",
        sha,
        timeout=60.0,
    )


def commit_time_cache_path(cache_dir: Path, repo: str, sha: str) -> Path:
    return cache_dir / f"{safe_filename_part(repo)}-{safe_filename_part(sha)}.json"
