from __future__ import annotations

import dataclasses
import logging
from typing import Any, Mapping

from .contracts import (
    GroundedAnalysisConfig,
    GroundedAnalysisInput,
    GroundedAnalysisResult,
)
from .generator import GroundedKnowledgeGenerator
from .grounding_validation import GroundingConsistencyValidator
from .llm import GroundedLLMClient
from .worktree_manager import (
    HistoricalWorktreeManager,
    WorktreeGCResult,
    WorktreeHandle,
)

logger = logging.getLogger(__name__)


class GroundedAnalysisService:
    """Candidate-level facade for worktree-grounded generation."""

    def __init__(
        self,
        config: GroundedAnalysisConfig,
        *,
        client: GroundedLLMClient | None = None,
        worktree_manager: HistoricalWorktreeManager | None = None,
    ) -> None:
        config.validate()
        self.config = config
        self._client = client
        self._worktree_manager = worktree_manager or (
            HistoricalWorktreeManager(
                repository_root=config.repository_root,
                worktree_root=config.worktree_root,
                allow_clone=config.allow_clone,
                allow_fetch=config.allow_fetch,
                git_timeout_seconds=config.timeout_seconds,
                repository_host=config.repository_host,
                verify_repository_identity=(config.verify_repository_identity),
                gc_max_count_per_repo=(config.worktree_gc_max_count_per_repo),
                gc_max_age_days=config.worktree_gc_max_age_days,
                gc_max_bytes_per_repo=(config.worktree_gc_max_bytes_per_repo),
            )
        )
        self._grounding_validator = GroundingConsistencyValidator(config)
        self._generator: GroundedKnowledgeGenerator | None = None

    def _get_generator(self) -> GroundedKnowledgeGenerator:
        if self._generator is None:
            self._generator = GroundedKnowledgeGenerator(
                self.config,
                client=self._client,
            )
        return self._generator

    def _generate_under_lease(
        self,
        value: GroundedAnalysisInput,
        *,
        worktree: WorktreeHandle,
    ) -> GroundedAnalysisResult:
        gc_result = WorktreeGCResult()
        validation = self._grounding_validator.validate(
            value,
            worktree=worktree,
        )
        logger.info(
            "Grounding consistency validation completed: repo=%s "
            "historical_issue=#%d status=%s patch_paths=%d "
            "commit_paths=%d warnings=%d",
            value.repo,
            value.historical_issue_number,
            validation.status,
            len(validation.patch_changed_paths),
            len(validation.commit_changed_paths),
            len(validation.warnings),
        )
        for warning in validation.warnings:
            logger.warning(
                "Grounding consistency warning: repo=%s historical_issue=#%d detail=%s",
                value.repo,
                value.historical_issue_number,
                warning,
            )
        generated = self._get_generator().generate(
            value,
            worktree=worktree,
        )
        try:
            gc_result = self._worktree_manager.garbage_collect(
                repo=value.repo,
                keep_commits=(value.historical_fix_commit,),
            )
        except Exception:
            logger.exception(
                "Grounded worktree GC failed without invalidating the "
                "generated knowledge: repo=%s commit=%s",
                value.repo,
                value.historical_fix_commit,
            )
        return dataclasses.replace(
            generated,
            grounding_validation=validation.to_dict(),
            worktree_post_verified=True,
            worktree_gc_removed_count=gc_result.removed_count,
        )

    def generate(
        self,
        candidate: Mapping[str, Any],
    ) -> tuple[GroundedAnalysisInput, GroundedAnalysisResult]:
        value = GroundedAnalysisInput.from_candidate(candidate)
        evidence_commits: tuple[str, ...]
        generated: GroundedAnalysisResult | None = None
        with self._worktree_manager.lease(
            repo=value.repo,
            commit=value.historical_fix_commit,
        ) as preflight_worktree:
            evidence_commits = self._grounding_validator.required_evidence_commits(
                value,
                worktree=preflight_worktree,
            )
            if not evidence_commits:
                generated = self._generate_under_lease(
                    value,
                    worktree=preflight_worktree,
                )
        if not evidence_commits:
            # The lease exit above performed the mandatory second
            # HEAD/root/clean verification before this result can be returned.
            assert generated is not None
            return value, generated

        with self._worktree_manager.lease(
            repo=value.repo,
            commit=value.historical_fix_commit,
            evidence_commits=evidence_commits,
        ) as worktree:
            generated = self._generate_under_lease(
                value,
                worktree=worktree,
            )
        # A successful exit from the final lease performs the mandatory second
        # HEAD/root/clean verification immediately before returning to the
        # dispatcher, so cache storage cannot occur after a dirty analysis.
        assert generated is not None
        return value, generated
