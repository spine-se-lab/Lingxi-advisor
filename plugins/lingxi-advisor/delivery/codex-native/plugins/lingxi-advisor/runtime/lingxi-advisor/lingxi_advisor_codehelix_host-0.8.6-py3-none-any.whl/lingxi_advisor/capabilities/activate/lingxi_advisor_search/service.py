from __future__ import annotations

from dataclasses import dataclass
import logging
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence

from ....artifacts.interface import (
    KnowledgeArtifact,
    KnowledgeArtifactRef,
    KnowledgeArtifactStore,
)
from ....internal.generation_contracts import GenerationMode
from ....internal.search_retrieval.contracts import SearchRetrievalResult
from ...codify.lingxi_advisor_knowledge.contracts import HistoricalCandidate
from .contracts import (
    LINGXI_ADVISOR_SEARCH_SCHEMA_VERSION,
    KnowledgeMatch,
    LingxiAdvisorSearchRequest,
    LingxiAdvisorSearchResult,
    UnresolvedKnowledge,
)


logger = logging.getLogger(__name__)


def _log_value(value: Any, *, fallback: str = "not_provided") -> str:
    """Return bounded, single-line metadata suitable for normal logs."""

    normalized = " ".join(str(value or "").split())
    return (normalized[:160] if normalized else fallback)


class CandidateSelector(Protocol):
    def run(
        self,
        instance: Mapping[str, Any],
        options: Any = None,
        gate_options: Any = None,
        *,
        preretrieved_dir: str | Path | None = None,
        write_artifacts: bool = True,
        refresh_instance_metadata: bool = False,
        use_test_patch_for_metadata: bool = False,
    ) -> SearchRetrievalResult: ...


class CodifyEnsure(Protocol):
    def ref_for_candidate(
        self,
        candidate: HistoricalCandidate,
        *,
        generation_mode: GenerationMode,
    ) -> KnowledgeArtifactRef: ...

    def ensure(
        self,
        candidates: Sequence[HistoricalCandidate],
        *,
        generation_mode: GenerationMode,
        resume: bool = True,
    ) -> Sequence[KnowledgeArtifactRef]: ...

    def artifact_is_current(
        self,
        candidate: HistoricalCandidate,
        artifact: KnowledgeArtifact,
        *,
        generation_mode: GenerationMode,
    ) -> bool: ...


@dataclass
class _SelectedArtifact:
    candidate: HistoricalCandidate
    ref: KnowledgeArtifactRef | None
    initial_hit: bool = False
    artifact: KnowledgeArtifact | None = None
    error: str | None = None


class LingxiAdvisorActivationSearch:
    """Select candidates and return their reusable XML in one runtime call."""

    def __init__(
        self,
        *,
        candidate_selector: CandidateSelector,
        artifact_store: KnowledgeArtifactStore,
        codify: CodifyEnsure,
        preretrieved_dir: Path | None = None,
        write_retrieval_artifacts: bool = True,
    ) -> None:
        self._candidate_selector = candidate_selector
        self._artifact_store = artifact_store
        self._codify = codify
        self._preretrieved_dir = preretrieved_dir
        self._write_retrieval_artifacts = write_retrieval_artifacts

    @property
    def preretrieved_dir(self) -> Path | None:
        return self._preretrieved_dir

    def search(
        self,
        request: LingxiAdvisorSearchRequest,
    ) -> LingxiAdvisorSearchResult:
        try:
            request.validate()
        except Exception as exc:
            logger.error(
                "LingxiAdvisor search failed: stage=request_validation "
                "reason=%s can_continue=false",
                type(exc).__name__,
            )
            raise

        target = request.resolved_target_issue
        logger.info(
            "LingxiAdvisor search started: repo=%s issue_type=%s "
            "leakage_check=%s generation_mode=%s",
            _log_value(request.repository),
            request.resolved_issue_mode,
            request.target_leakage_check_enabled,
            request.generation_mode,
        )
        logger.debug(
            "Issue context resolved: instance_id=%s issue_number=%s "
            "target_present=%s",
            _log_value(request.instance_id),
            target.issue_number if target is not None else None,
            target is not None,
        )
        live_instance = request.live_instance()
        retrieval_path = (
            "repository_historical"
            if live_instance is not None
            else "approved_preretrieved"
        )
        logger.info(
            "Historical retrieval started: path=%s repo=%s",
            retrieval_path,
            _log_value(request.repository),
        )
        try:
            if live_instance is not None:
                retrieval = self._candidate_selector.run(
                    live_instance,
                    request.search_options,
                    request.gate_options,
                    preretrieved_dir=self._preretrieved_dir,
                    write_artifacts=self._write_retrieval_artifacts,
                    refresh_instance_metadata=(
                        request.refresh_instance_metadata
                    ),
                    use_test_patch_for_metadata=False,
                )
            else:
                find_existing = getattr(
                    self._candidate_selector,
                    "find_existing",
                    None,
                )
                if not callable(find_existing):
                    raise RuntimeError(
                        "Candidate selector cannot search existing knowledge "
                        "without repository context."
                    )
                retrieval = find_existing(
                    issue_description=request.issue_description,
                    context=request.context,
                    options=request.search_options,
                    gate_options=request.gate_options,
                    preretrieved_dir=self._preretrieved_dir,
                )
        except Exception as exc:
            logger.error(
                "LingxiAdvisor search failed: stage=historical_retrieval "
                "reason=%s can_continue=false",
                type(exc).__name__,
            )
            result = self._failed_result(
                request,
                error=f"candidate selection failed: {exc}",
            )
            self._log_result(result)
            return result

        logger.info(
            "Historical retrieval completed: status=%s source=%s "
            "selected=%d rejected=%d live_search=%s",
            retrieval.status,
            retrieval.retrieval_source,
            retrieval.selected_count,
            retrieval.rejected_count,
            bool(retrieval.stats.get("live_github_search_ran")),
        )

        if retrieval.status == "failed":
            logger.error(
                "LingxiAdvisor search failed: stage=historical_retrieval "
                "reason=retrieval_result_failed can_continue=false"
            )
            result = self._failed_result(
                request,
                retrieval=retrieval,
                error=(
                    retrieval.error
                    or "candidate selection returned failed"
                ),
            )
            self._log_result(result)
            return result
        if not retrieval.selected_candidates:
            logger.info(
                "Historical retrieval returned no safe candidates: "
                "source=%s rejected=%d",
                retrieval.retrieval_source,
                retrieval.rejected_count,
            )
            result = LingxiAdvisorSearchResult(
                schema_version=LINGXI_ADVISOR_SEARCH_SCHEMA_VERSION,
                status="no_candidates",
                instance_id=request.instance_id,
                generation_mode=request.generation_mode,
                prepare_if_missing=True,
                issue_mode=request.resolved_issue_mode,
                target_leakage_check=(
                    request.target_leakage_check_enabled
                ),
                retrieval_status=retrieval.status,
                retrieval_source=retrieval.retrieval_source,
                selected_count=0,
                rejected_count=retrieval.rejected_count,
                completed_count=0,
                cache_hit_count=0,
                generated_count=0,
                missing_count=0,
                failed_count=0,
                retrieval_request_id=retrieval.request_id,
            )
            self._log_result(result)
            return result

        logger.info(
            "Artifact lookup started: candidates=%d generation_mode=%s",
            len(retrieval.selected_candidates),
            request.generation_mode,
        )
        selected = [
            self._resolve_selected(candidate, request.generation_mode)
            for candidate in retrieval.selected_candidates
        ]
        missing = [item for item in selected if item.artifact is None]
        initial_cache_hits = sum(item.initial_hit for item in selected)
        logger.info(
            "Artifact lookup completed: candidates=%d cache_hits=%d "
            "generation_required=%d",
            len(selected),
            initial_cache_hits,
            len(missing),
        )
        if initial_cache_hits:
            logger.info(
                "Knowledge artifact reused: cache_hits=%d",
                initial_cache_hits,
            )
        ensure_error: str | None = None
        if missing:
            logger.info(
                "Knowledge generation triggered: candidates=%d mode=%s",
                len(missing),
                request.generation_mode,
            )
            try:
                self._codify.ensure(
                    [item.candidate for item in missing],
                    generation_mode=request.generation_mode,
                    resume=request.resume,
                )
            except Exception as exc:
                ensure_error = f"Codify ensure failed: {exc}"
                logger.error(
                    "Knowledge generation failed: stage=codify_ensure "
                    "candidates=%d reason=%s can_continue=true",
                    len(missing),
                    type(exc).__name__,
                )

            for item in missing:
                if item.ref is None:
                    continue
                try:
                    found = self._artifact_store.lookup(
                        generation_mode=item.ref.generation_mode,
                        knowledge_cache_key=item.ref.knowledge_cache_key,
                    )
                    if found is None:
                        item.error = ensure_error or "artifact remains missing"
                        continue
                    artifact = self._artifact_store.read(found)
                    if not self._codify.artifact_is_current(
                        item.candidate,
                        artifact,
                        generation_mode=request.generation_mode,
                    ):
                        item.error = (
                            ensure_error
                            or "artifact provenance remains out of date"
                        )
                        continue
                    item.artifact = artifact
                    item.error = None
                except Exception as exc:
                    item.error = f"artifact read failed after ensure: {exc}"

            generated_after_ensure = sum(
                item.artifact is not None and not item.initial_hit
                for item in selected
            )
            unresolved_after_ensure = sum(
                item.artifact is None for item in selected
            )
            logger.info(
                "Knowledge generation finished: requested=%d generated=%d "
                "unresolved=%d",
                len(missing),
                generated_after_ensure,
                unresolved_after_ensure,
            )
            if unresolved_after_ensure:
                logger.error(
                    "Knowledge generation produced no usable artifact for "
                    "some candidates: unresolved=%d can_continue=%s",
                    unresolved_after_ensure,
                    generated_after_ensure > 0,
                )

        matches = [
            self._knowledge_match(item)
            for item in selected
            if item.artifact is not None and item.ref is not None
        ]
        unresolved = [
            self._unresolved(item)
            for item in selected
            if item.artifact is None
        ]
        cache_hit_count = sum(item.initial_hit for item in selected)
        generated_count = sum(
            item.artifact is not None and not item.initial_hit
            for item in selected
        )
        failed_count = len(unresolved)
        if not unresolved:
            status = (
                "partial"
                if retrieval.status == "partial"
                else "completed"
            )
        elif matches:
            status = "partial"
        else:
            status = "failed"
        result_error = ensure_error
        if status == "failed" and result_error is None:
            result_error = (
                "No selected knowledge artifact was readable after "
                "Codify ensure."
            )

        result = LingxiAdvisorSearchResult(
            schema_version=LINGXI_ADVISOR_SEARCH_SCHEMA_VERSION,
            status=status,
            instance_id=request.instance_id,
            generation_mode=request.generation_mode,
            prepare_if_missing=True,
            issue_mode=request.resolved_issue_mode,
            target_leakage_check=(
                request.target_leakage_check_enabled
            ),
            retrieval_status=retrieval.status,
            retrieval_source=retrieval.retrieval_source,
            selected_count=retrieval.selected_count,
            rejected_count=retrieval.rejected_count,
            completed_count=len(matches),
            cache_hit_count=cache_hit_count,
            generated_count=generated_count,
            missing_count=len(unresolved),
            failed_count=failed_count,
            knowledge_matches=matches,
            unresolved_knowledge=unresolved,
            retrieval_request_id=retrieval.request_id,
            error=result_error,
        )
        self._log_result(result)
        return result

    @staticmethod
    def _log_result(result: LingxiAdvisorSearchResult) -> None:
        log = logger.error if result.status == "failed" else logger.info
        log(
            "LingxiAdvisor search completed: status=%s retrieval_status=%s "
            "source=%s selected=%d matches=%d cache_hits=%d generated=%d "
            "failed=%d",
            result.status,
            result.retrieval_status,
            result.retrieval_source,
            result.selected_count,
            result.completed_count,
            result.cache_hit_count,
            result.generated_count,
            result.failed_count,
        )

    def _resolve_selected(
        self,
        candidate: HistoricalCandidate,
        generation_mode: GenerationMode,
    ) -> _SelectedArtifact:
        try:
            ref = self._codify.ref_for_candidate(
                candidate,
                generation_mode=generation_mode,
            )
        except Exception as exc:
            return _SelectedArtifact(
                candidate=candidate,
                ref=None,
                error=f"artifact identity failed: {exc}",
            )
        try:
            found = self._artifact_store.lookup(
                generation_mode=ref.generation_mode,
                knowledge_cache_key=ref.knowledge_cache_key,
            )
            if found is None:
                return _SelectedArtifact(
                    candidate=candidate,
                    ref=ref,
                    error="artifact is not present",
                )
            artifact = self._artifact_store.read(found)
            if not self._codify.artifact_is_current(
                candidate,
                artifact,
                generation_mode=generation_mode,
            ):
                return _SelectedArtifact(
                    candidate=candidate,
                    ref=ref,
                    error=(
                        "artifact provenance does not match the selected "
                        "historical evidence and active generation configuration"
                    ),
                )
            return _SelectedArtifact(
                candidate=candidate,
                ref=ref,
                initial_hit=True,
                artifact=artifact,
            )
        except Exception as exc:
            return _SelectedArtifact(
                candidate=candidate,
                ref=ref,
                error=f"artifact read failed: {exc}",
            )

    @staticmethod
    def _knowledge_match(item: _SelectedArtifact) -> KnowledgeMatch:
        assert item.ref is not None
        assert item.artifact is not None
        candidate = item.candidate
        issue_number = _optional_int(
            candidate.get("historical_issue_number")
        )
        return KnowledgeMatch(
            artifact_ref=item.ref,
            knowledge_xml=item.artifact.knowledge_xml,
            artifact_sha256=str(item.artifact.artifact_sha256 or ""),
            repo=str(
                candidate.get("repo")
                or candidate.get("instance_repo")
                or ""
            ),
            historical_issue_number=issue_number,
            historical_issue_url=str(
                candidate.get("historical_issue_url") or ""
            ),
            historical_issue_title=str(
                candidate.get("historical_issue_title")
                or candidate.get("retrieved_issue_title")
                or ""
            ),
            historical_candidate_fingerprint=str(
                candidate.get("historical_candidate_fingerprint") or ""
            ),
            cache_hit=item.initial_hit,
            metadata={
                key: candidate[key]
                for key in (
                    "retrieval_tier",
                    "github_rank_in_query",
                    "similarity_score",
                    "misleading_risk",
                    "llm_similarity_score",
                    "llm_misleading_risk",
                    "llm_gate_policy_version",
                    "llm_gate_prompt_version",
                    "llm_gate_model_selected",
                    "llm_gate_match_basis",
                    "llm_gate_selection_tier",
                    "llm_gate_policy_reasons",
                    "llm_gate_evidence",
                    "historical_fix_commit",
                )
                if key in candidate
            },
        )

    @staticmethod
    def _unresolved(
        item: _SelectedArtifact,
    ) -> UnresolvedKnowledge:
        candidate = item.candidate
        reason = item.error or "artifact is not present"
        return UnresolvedKnowledge(
            artifact_ref=item.ref,
            repo=str(
                candidate.get("repo")
                or candidate.get("instance_repo")
                or ""
            ),
            historical_issue_number=_optional_int(
                candidate.get("historical_issue_number")
            ),
            historical_candidate_fingerprint=str(
                candidate.get("historical_candidate_fingerprint") or ""
            ),
            reason=reason,
        )

    @staticmethod
    def _failed_result(
        request: LingxiAdvisorSearchRequest,
        *,
        retrieval: SearchRetrievalResult | None = None,
        error: str,
    ) -> LingxiAdvisorSearchResult:
        return LingxiAdvisorSearchResult(
            schema_version=LINGXI_ADVISOR_SEARCH_SCHEMA_VERSION,
            status="failed",
            instance_id=request.instance_id,
            generation_mode=request.generation_mode,
            prepare_if_missing=True,
            issue_mode=request.resolved_issue_mode,
            target_leakage_check=(
                request.target_leakage_check_enabled
            ),
            retrieval_status=(retrieval.status if retrieval else "failed"),
            retrieval_source=(
                retrieval.retrieval_source if retrieval else "unknown"
            ),
            selected_count=(retrieval.selected_count if retrieval else 0),
            rejected_count=(retrieval.rejected_count if retrieval else 0),
            completed_count=0,
            cache_hit_count=0,
            generated_count=0,
            missing_count=(retrieval.selected_count if retrieval else 0),
            failed_count=(retrieval.selected_count if retrieval else 1),
            retrieval_request_id=(retrieval.request_id if retrieval else None),
            error=error,
        )


def _optional_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


__all__ = ["LingxiAdvisorActivationSearch"]
