"""External delivery adapters for LingxiAdvisor capabilities."""
