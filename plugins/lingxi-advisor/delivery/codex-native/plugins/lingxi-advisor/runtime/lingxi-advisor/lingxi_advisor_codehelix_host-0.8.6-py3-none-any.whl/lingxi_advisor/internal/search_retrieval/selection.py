from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .candidate_schema import candidate_fingerprint
from .contracts import SWEbenchProInstance
from .grounding import GroundingPreflightService
from .similarity_gate import SimilarityGateDecision


@dataclass(frozen=True)
class SelectionResult:
    selected: list[dict[str, Any]]
    rejected: list[dict[str, Any]]
    gate_audit: list[dict[str, Any]]


class FinalTopKSelector:
    def __init__(self, *, grounding_preflight: GroundingPreflightService) -> None:
        self.grounding_preflight = grounding_preflight

    def from_preretrieved(
        self,
        *,
        rows: list[dict[str, Any]],
        final_top_k: int,
    ) -> SelectionResult:
        selected: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []
        for index, row in enumerate(rows):
            payload = dict(row)
            if index < final_top_k:
                payload["llm_gate_decision"] = "preselected"
                payload["llm_gate_reason"] = (
                    "Candidate came from the pre-retrieved store and was not re-judged."
                )
                payload["final_selected_position"] = len(selected)
                payload["grounding_preflight"] = self.grounding_preflight.preflight(
                    payload
                ).to_dict()
                selected.append(payload)
            else:
                payload["llm_gate_decision"] = "not_selected"
                payload["llm_gate_reason"] = "Pre-retrieved candidate is outside final_top_k."
                rejected.append(payload)
        return SelectionResult(selected=selected, rejected=rejected, gate_audit=[])

    def from_gate_decisions(
        self,
        *,
        rows: list[dict[str, Any]],
        decisions: list[SimilarityGateDecision],
        instance: SWEbenchProInstance,
        final_top_k: int,
    ) -> SelectionResult:
        by_key = {decision.candidate_key: decision for decision in decisions}
        selected_pool: list[tuple[dict[str, Any], SimilarityGateDecision, int]] = []
        rejected: list[dict[str, Any]] = []
        gate_audit: list[dict[str, Any]] = []

        for index, row in enumerate(rows):
            key = candidate_fingerprint(row, instance)
            decision = by_key.get(key)
            payload = dict(row)
            if decision is None:
                payload["llm_gate_decision"] = "rejected"
                payload["llm_gate_reason"] = "Candidate was not evaluated by the LLM gate."
                rejected.append(payload)
                continue
            gate_audit.append(decision.to_dict())
            payload["llm_gate_decision"] = "selected" if decision.selected else "rejected"
            payload["llm_gate_reason"] = decision.reason
            payload["llm_similarity_score"] = decision.similarity_score
            payload["llm_misleading_risk"] = decision.misleading_risk
            payload["llm_gate_policy_version"] = decision.policy_version
            payload["llm_gate_prompt_version"] = decision.prompt_version
            payload["llm_gate_model_selected"] = decision.model_selected
            payload["llm_gate_match_basis"] = list(decision.match_basis)
            payload["llm_gate_selection_tier"] = decision.selection_tier
            payload["llm_gate_policy_reasons"] = list(
                decision.policy_reasons
            )
            payload["llm_gate_evidence"] = {
                "failure_mode": decision.failure_mode_evidence,
                "repair_transfer": decision.repair_transfer_evidence,
                "localization_help": decision.localization_help,
                "main_risk": decision.main_risk,
            }
            if decision.selected:
                selected_pool.append((payload, decision, index))
            else:
                rejected.append(payload)

        selected_pool.sort(
            key=lambda item: (
                -(item[1].similarity_score if item[1].similarity_score is not None else -1),
                item[1].misleading_risk if item[1].misleading_risk is not None else 99,
                item[2],
            )
        )
        selected: list[dict[str, Any]] = []
        for payload, _decision, _index in selected_pool[:final_top_k]:
            payload["final_selected_position"] = len(selected)
            payload["grounding_preflight"] = self.grounding_preflight.preflight(
                payload
            ).to_dict()
            selected.append(payload)
        for payload, decision, _index in selected_pool[final_top_k:]:
            payload["llm_gate_decision"] = "not_selected"
            payload["llm_gate_reason"] = (
                "Candidate passed the LLM gate but is outside final_top_k."
            )
            payload["llm_similarity_score"] = decision.similarity_score
            payload["llm_misleading_risk"] = decision.misleading_risk
            rejected.append(payload)
        return SelectionResult(selected=selected, rejected=rejected, gate_audit=gate_audit)
