from __future__ import annotations

import json
from typing import Any

OPERATOR_TOOLS = (
    'lingxi.advisor.knowledge_preparation_capabilities',
    'lingxi.advisor.prepare_historical_knowledge',
    'lingxi.advisor.start_preparation_batch',
    'lingxi.advisor.get_preparation_batch',
    'lingxi.advisor.get_preparation_result',
    'lingxi.advisor.read_prepared_knowledge',
)

def _register_operator_tools(mcp: Any, *, operator: Any) -> None:
    _require_operator_adapter(operator)

    @mcp.tool(name='lingxi.advisor.knowledge_preparation_capabilities')
    def capabilities_tool() -> dict[str, Any]:
        return operator.capabilities()

    @mcp.tool(name='lingxi.advisor.prepare_historical_knowledge')
    async def prepare_tool(
        instance: dict[str, Any],
        generation_mode: str = 'light',
        search_candidate_count: int = 5,
        final_top_k: int = 3,
        update_preretrieved: bool = False,
        run_gate_for_preretrieved: bool = False,
        search_type: str = 'semantic',
        fallback_search_type: str = 'hybrid',
        minimum_similarity_score: int = 2,
        maximum_misleading_risk: int = 3,
        resume: bool = True,
        refresh_instance_metadata: bool = False,
        refresh_search_cache: bool = False,
    ) -> dict[str, Any]:
        return await operator.prepare(
            instance=instance,
            generation_mode=generation_mode,
            search_candidate_count=search_candidate_count,
            final_top_k=final_top_k,
            update_preretrieved=update_preretrieved,
            run_gate_for_preretrieved=run_gate_for_preretrieved,
            search_type=search_type,
            fallback_search_type=fallback_search_type,
            minimum_similarity_score=minimum_similarity_score,
            maximum_misleading_risk=maximum_misleading_risk,
            resume=resume,
            refresh_instance_metadata=refresh_instance_metadata,
            refresh_search_cache=refresh_search_cache,
        )

    @mcp.tool(name='lingxi.advisor.start_preparation_batch')
    async def start_batch_tool(
        generation_mode: str = 'light',
        search_candidate_count: int = 5,
        final_top_k: int = 3,
        update_preretrieved: bool = False,
        run_gate_for_preretrieved: bool = False,
        search_type: str = 'semantic',
        fallback_search_type: str = 'hybrid',
        minimum_similarity_score: int = 2,
        maximum_misleading_risk: int = 3,
        resume: bool = True,
        refresh_instance_metadata: bool = False,
        refresh_search_cache: bool = False,
        continue_on_error: bool = True,
        retry_failed: bool = False,
    ) -> dict[str, Any]:
        return await operator.start_batch(
            generation_mode=generation_mode,
            search_candidate_count=search_candidate_count,
            final_top_k=final_top_k,
            update_preretrieved=update_preretrieved,
            run_gate_for_preretrieved=run_gate_for_preretrieved,
            search_type=search_type,
            fallback_search_type=fallback_search_type,
            minimum_similarity_score=minimum_similarity_score,
            maximum_misleading_risk=maximum_misleading_risk,
            resume=resume,
            refresh_instance_metadata=refresh_instance_metadata,
            refresh_search_cache=refresh_search_cache,
            continue_on_error=continue_on_error,
            retry_failed=retry_failed,
        )

    @mcp.tool(name='lingxi.advisor.get_preparation_batch')
    def get_batch_tool(
        batch_id: str,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        return operator.get_batch(
            batch_id=batch_id,
            offset=offset,
            limit=limit,
        )

    @mcp.tool(name='lingxi.advisor.get_preparation_result')
    def get_result_tool(request_id: str) -> dict[str, Any]:
        return operator.get_result(request_id)

    @mcp.tool(name='lingxi.advisor.read_prepared_knowledge')
    def read_knowledge_tool(request_id: str, artifact_name: str) -> str:
        return operator.read_knowledge(
            request_id=request_id,
            artifact_name=artifact_name,
        )

    @mcp.resource(
        'lingxi.advisor://runs/{request_id}/result',
        mime_type='application/json',
    )
    def result_resource(request_id: str) -> str:
        return json.dumps(
            operator.get_result(request_id),
            ensure_ascii=False,
            indent=2,
        )

    @mcp.resource(
        'lingxi.advisor://runs/{request_id}/artifacts/{artifact_name}',
        mime_type='application/xml',
    )
    def knowledge_resource(request_id: str, artifact_name: str) -> str:
        return operator.read_knowledge(
            request_id=request_id,
            artifact_name=artifact_name,
        )

    @mcp.resource(
        'lingxi.advisor://batches/{batch_id}',
        mime_type='application/json',
    )
    def batch_resource(batch_id: str) -> str:
        return json.dumps(
            operator.get_batch(batch_id=batch_id, offset=0, limit=100),
            ensure_ascii=False,
            indent=2,
        )

def _require_operator_adapter(operator: Any) -> None:
    required = (
        'capabilities',
        'prepare',
        'start_batch',
        'get_batch',
        'get_result',
        'read_knowledge',
    )
    missing = [
        name for name in required
        if not callable(getattr(operator, name, None))
    ]
    if missing:
        raise TypeError(
            'Operator adapter is missing method(s): ' + ', '.join(missing)
        )


__all__ = ['OPERATOR_TOOLS']
