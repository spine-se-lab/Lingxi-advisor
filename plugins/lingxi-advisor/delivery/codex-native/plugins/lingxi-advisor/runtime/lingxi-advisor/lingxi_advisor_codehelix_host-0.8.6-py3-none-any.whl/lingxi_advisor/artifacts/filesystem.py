from __future__ import annotations

from pathlib import Path

from .interface import (
    KnowledgeArtifact,
    KnowledgeArtifactRef,
)
from ..internal.generation_contracts import GenerationMode
from ..internal.knowledge_cache import KnowledgeCache


class FilesystemKnowledgeArtifactStore:
    """Artifact Store adapter backed by the existing validated XML cache."""

    def __init__(
        self,
        root: Path | None = None,
        *,
        cache: KnowledgeCache | None = None,
    ) -> None:
        if (root is None) == (cache is None):
            raise ValueError("provide exactly one of root or cache")
        self._cache = cache or KnowledgeCache(Path(root))  # type: ignore[arg-type]

    @property
    def root(self) -> Path:
        return self._cache.root

    def lookup(
        self,
        *,
        generation_mode: GenerationMode,
        knowledge_cache_key: str,
    ) -> KnowledgeArtifactRef | None:
        ref = KnowledgeArtifactRef(
            generation_mode=generation_mode,
            knowledge_cache_key=knowledge_cache_key,
        )
        entry = self._cache.lookup(
            generation_mode=ref.generation_mode,
            cache_key=ref.knowledge_cache_key,
        )
        return ref if entry is not None else None

    def read(
        self,
        artifact_ref: KnowledgeArtifactRef,
    ) -> KnowledgeArtifact:
        snapshot = self._cache.read(
            generation_mode=artifact_ref.generation_mode,
            cache_key=artifact_ref.knowledge_cache_key,
        )
        if snapshot is None:
            raise FileNotFoundError(
                "knowledge artifact does not exist or failed validation: "
                f"{artifact_ref.generation_mode}/"
                f"{artifact_ref.knowledge_cache_key}"
            )
        entry, xml_text = snapshot
        return KnowledgeArtifact(
            ref=artifact_ref,
            knowledge_xml=xml_text,
            historical_candidate_fingerprint=(
                entry.historical_candidate_fingerprint
            ),
            historical_patch_sha256=entry.historical_patch_sha256,
            template_version=entry.template_version,
            generator_model=entry.generator_model,
            target_conditioned=entry.target_conditioned,
            instance_id=entry.instance_id,
            artifact_schema_version=entry.artifact_schema_version,
            artifact_sha256=entry.artifact_sha256,
        )

    def store(
        self,
        artifact: KnowledgeArtifact,
    ) -> KnowledgeArtifactRef:
        ref = artifact.ref
        with self._cache.generation_lock(
            generation_mode=ref.generation_mode,
            cache_key=ref.knowledge_cache_key,
        ):
            self._cache.store(
                generation_mode=ref.generation_mode,
                cache_key=ref.knowledge_cache_key,
                xml_text=artifact.knowledge_xml,
                historical_candidate_fingerprint=(
                    artifact.historical_candidate_fingerprint
                ),
                historical_patch_sha256=(
                    artifact.historical_patch_sha256
                ),
                template_version=artifact.template_version,
                generator_model=artifact.generator_model,
                target_conditioned=artifact.target_conditioned,
                instance_id=artifact.instance_id,
            )
        return ref

