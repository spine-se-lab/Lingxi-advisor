from __future__ import annotations

from .execution import bounded_execution

import hashlib
import logging
from pathlib import Path
from typing import Any, Mapping, Protocol

from .execution import FailureReport, ExecutionFailure
from .generation_contracts import GenerationRequest, GenerationResult
from .io_utils import (
    read_json,
    safe_part,
    write_json_atomic,
    write_jsonl_atomic,
    write_text_atomic,
)
from .knowledge_validation import validate_knowledge_content
from .locking import FileLock
from .preparation_contracts import (
    PREPARATION_SCHEMA_VERSION,
    PreparationRequest,
    PreparationResult,
    preparation_request_id,
)
from .search_retrieval.contracts import SearchRetrievalResult

logger = logging.getLogger(__name__)


class SearchStage(Protocol):
    def run(
        self,
        instance: Mapping[str, Any],
        options: Any = None,
        gate_options: Any = None,
        *,
        preretrieved_dir: str | Path | None = None,
        write_artifacts: bool = True,
        refresh_instance_metadata: bool = False,
        use_test_patch_for_metadata: bool = False,
    ) -> SearchRetrievalResult: ...


class GenerationStage(Protocol):
    def run_candidates(self, request: GenerationRequest, candidates: list[dict[str, Any]]) -> GenerationResult: ...


def preparation_runs_root(output_root: Path) -> Path:
    root = output_root.expanduser().resolve()
    if root.name == "knowledge_preparation_runs":
        return root
    return root / "knowledge_preparation_runs"


def _first_error(rows: list[Mapping[str, Any]]) -> str | None:
    for row in rows:
        value = str(row.get("error") or "").strip()
        if value:
            return value
    return None


class KnowledgePreparationService:
    """Compose Search & Retrieval and Knowledge Generation without duplicating them."""

    def __init__(
        self,
        *,
        search_service: SearchStage | None = None,
        generation_service: GenerationStage | None = None,
    ) -> None:
        self.search_service = search_service
        self.generation_service = generation_service

    @bounded_execution
    def run(self, request: PreparationRequest) -> PreparationResult:
        request.validate()
        request_id = preparation_request_id(request)
        root = preparation_runs_root(request.output_root)
        run_dir = (
            root
            / safe_part(request.instance.instance_id)
            / request_id
        )
        lock_path = root / ".locks" / f"{request_id}.lock"

        with FileLock(lock_path):
            if request.resume:
                resumed = self._load_resumable_result(
                    run_dir=run_dir,
                    request_id=request_id,
                )
                if resumed is not None:
                    logger.info(
                        "Knowledge preparation resume hit: request_id=%s "
                        "status=%s",
                        request_id,
                        resumed.status,
                    )
                    return resumed

            write_json_atomic(
                run_dir / "request.json",
                {
                    "request_id": request_id,
                    **request.to_dict(),
                },
            )
            logger.info(
                "Knowledge preparation started: request_id=%s instance=%s "
                "mode=%s",
                request_id,
                request.instance.instance_id,
                request.generation_mode,
            )

            retrieval = self._run_retrieval(request, run_dir)
            if isinstance(retrieval, FailureReport):
                return self._finalize_without_generation(
                    request=request,
                    request_id=request_id,
                    run_dir=run_dir,
                    retrieval=None,
                    status="failed",
                    retrieval_status="failed",
                    error=retrieval.error,
                    retryable=retrieval.retryable,
                )

            self._publish_retrieval_artifacts(
                retrieval=retrieval,
                run_dir=run_dir,
            )
            if retrieval.status == "failed":
                return self._finalize_without_generation(
                    request=request,
                    request_id=request_id,
                    run_dir=run_dir,
                    retrieval=retrieval,
                    status="failed",
                    retrieval_status="failed",
                    error=retrieval.error or "Search & Retrieval failed.",
                    retryable=True,
                )
            if not retrieval.selected_candidates:
                return self._finalize_without_generation(
                    request=request,
                    request_id=request_id,
                    run_dir=run_dir,
                    retrieval=retrieval,
                    status="no_candidates",
                    retrieval_status=retrieval.status,
                    error=None,
                    retryable=False,
                )

            generation = self._run_generation(
                request=request,
                candidates=retrieval.selected_candidates,
            )
            if isinstance(generation, FailureReport):
                return self._finalize_generation_exception(
                    request=request,
                    request_id=request_id,
                    run_dir=run_dir,
                    retrieval=retrieval,
                    failure=generation,
                )

            manifest_rows, artifacts = self._publish_generation_artifacts(
                generation=generation,
                retrieval=retrieval,
                run_dir=run_dir,
            )
            write_jsonl_atomic(
                run_dir / "generation_manifest.jsonl",
                manifest_rows,
            )
            self._publish_generation_stage_metadata(
                generation=generation,
                run_dir=run_dir,
            )
            result = self._result_from_stages(
                request=request,
                request_id=request_id,
                run_dir=run_dir,
                retrieval=retrieval,
                generation=generation,
                manifest_rows=manifest_rows,
                artifacts=artifacts,
            )
            self._write_final_artifacts(run_dir, result)
            logger.info(
                "Knowledge preparation finished: request_id=%s status=%s "
                "selected=%d completed=%d cache_hits=%d failed=%d",
                request_id,
                result.status,
                result.selected_count,
                result.completed_count,
                result.cache_hit_count,
                result.failed_count,
            )
            return result

    def _run_retrieval(
        self,
        request: PreparationRequest,
        run_dir: Path,
    ) -> SearchRetrievalResult | FailureReport:
        if self.search_service is None:
            raise RuntimeError("Search & Retrieval service is not configured")
        try:
            return self.search_service.run(
                request.instance.public_dict(),
                request.search_options,
                request.gate_options,
                preretrieved_dir=request.preretrieved_dir,
                write_artifacts=True,
                refresh_instance_metadata=(
                    request.refresh_instance_metadata
                ),
                # Unified production entry points never inspect target test
                # patches for metadata recovery.
                use_test_patch_for_metadata=False,
            )
        except ExecutionFailure as exc:
            if exc.code in {"cancelled", "deadline_exceeded"}:
                raise
            return FailureReport.from_exception(exc)
        except Exception as exc:
            logger.exception(
                "Search & Retrieval failed before returning a result: %s",
                exc,
            )
            write_json_atomic(
                run_dir / "search_exception.json",
                {
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                },
            )
            return FailureReport.from_exception(exc)

    def _run_generation(
        self,
        *,
        request: PreparationRequest,
        candidates: list[dict[str, Any]],
    ) -> GenerationResult | FailureReport:
        if self.generation_service is None:
            raise RuntimeError("Knowledge Generation service is not configured")
        generation_request = GenerationRequest(
            input_jsonl=None,
            knowledge_cache_dir=request.knowledge_cache_dir,
            output_root=request.output_root,
            generation_mode=request.generation_mode,
            template_version=request.template_version,
            generator_model=request.generator_model,
            target_conditioned=False,
            resume=request.resume,
            allow_clone=request.allow_clone,
            allow_fetch=request.allow_fetch,
            repository_root=(
                request.repository_root
                if request.generation_mode == "grounded_analysis"
                else None
            ),
            historical_worktree_root=(
                request.historical_worktree_root
                if request.generation_mode == "grounded_analysis"
                else None
            ),
            runtime_options=request.generation_runtime_options,
        )
        try:
            return self.generation_service.run_candidates(generation_request, candidates)
        except ExecutionFailure as exc:
            if exc.code in {"cancelled", "deadline_exceeded"}:
                raise
            return FailureReport.from_exception(exc)
        except Exception as exc:
            logger.exception(
                "Knowledge Generation failed before returning a result: %s",
                exc,
            )
            return FailureReport.from_exception(exc)

    @staticmethod
    def _copy_text_if_present(source: Path, destination: Path) -> bool:
        if not source.is_file():
            return False
        write_text_atomic(
            destination,
            source.read_text(encoding="utf-8"),
        )
        return True

    def _publish_retrieval_artifacts(
        self,
        *,
        retrieval: SearchRetrievalResult,
        run_dir: Path,
    ) -> None:
        source_dir = (
            Path(retrieval.output_dir).expanduser().resolve()
            if retrieval.output_dir
            else None
        )
        mappings = {
            "safe_candidate_pool.jsonl": "safe_candidate_pool.jsonl",
            "review_candidate_pool.jsonl": "review_candidate_pool.jsonl",
            "selected_historical_issues.jsonl": (
                "selected_historical_issues.jsonl"
            ),
            "rejected_historical_issues.jsonl": (
                "rejected_historical_issues.jsonl"
            ),
            "search_audit.jsonl": "search_audit.jsonl",
            "rejection_audit.jsonl": "rejection_audit.jsonl",
            "gate_audit.jsonl": "gate_audit.jsonl",
            "request.json": "search_request.json",
            "summary.json": "search_summary.json",
            "result.json": "search_result.json",
            "manifest.json": "search_manifest.json",
        }
        copied: set[str] = set()
        if source_dir is not None:
            for source_name, destination_name in mappings.items():
                if self._copy_text_if_present(
                    source_dir / source_name,
                    run_dir / destination_name,
                ):
                    copied.add(destination_name)

        if "selected_historical_issues.jsonl" not in copied:
            write_jsonl_atomic(
                run_dir / "selected_historical_issues.jsonl",
                retrieval.selected_candidates,
            )
        if "rejected_historical_issues.jsonl" not in copied:
            write_jsonl_atomic(
                run_dir / "rejected_historical_issues.jsonl",
                retrieval.rejected_candidates,
            )
        for name in (
            "safe_candidate_pool.jsonl",
            "review_candidate_pool.jsonl",
            "search_audit.jsonl",
            "rejection_audit.jsonl",
            "gate_audit.jsonl",
        ):
            if name not in copied:
                write_jsonl_atomic(run_dir / name, [])

    def _publish_generation_stage_metadata(
        self,
        *,
        generation: GenerationResult,
        run_dir: Path,
    ) -> None:
        source_dir = (
            Path(generation.output_dir).expanduser().resolve()
            if generation.output_dir
            else None
        )
        if source_dir is None:
            return
        mappings = {
            "request.json": "generation_request.json",
            "summary.json": "generation_summary.json",
            "result.json": "generation_result.json",
            "manifest.json": "generation_stage_manifest.json",
        }
        for source_name, destination_name in mappings.items():
            self._copy_text_if_present(
                source_dir / source_name,
                run_dir / destination_name,
            )

    def _publish_generation_artifacts(
        self,
        *,
        generation: GenerationResult,
        retrieval: SearchRetrievalResult,
        run_dir: Path,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        by_fingerprint = {
            str(row.get("historical_candidate_fingerprint") or ""): row
            for row in retrieval.selected_candidates
        }
        manifest_rows: list[dict[str, Any]] = []
        artifacts: list[dict[str, Any]] = []
        used_names: set[str] = set()

        for source_row in generation.manifest_rows:
            row = dict(source_row)
            source_path_text = str(row.get("knowledge_path") or "").strip()
            if (
                row.get("generation_status") != "completed"
                or not source_path_text
            ):
                manifest_rows.append(row)
                continue
            try:
                source_path = Path(source_path_text).expanduser().resolve()
                xml_text = source_path.read_text(encoding="utf-8")
                digest = validate_knowledge_content(
                    xml_text, expected_sha256=str(row.get("knowledge_sha256") or "").strip()
                )
                candidate_name = safe_part(source_path.stem) + ".xml"
                if candidate_name in used_names:
                    suffix = safe_part(
                        str(
                            row.get(
                                "historical_candidate_fingerprint"
                            )
                            or row.get("knowledge_cache_key")
                            or digest[:12]
                        ),
                        max_len=48,
                    )
                    candidate_name = (
                        safe_part(source_path.stem) + "__" + suffix + ".xml"
                    )
                used_names.add(candidate_name)
                destination = run_dir / "knowledge" / candidate_name
                write_text_atomic(destination, xml_text)
                row["stage_knowledge_path"] = source_path_text
                row["knowledge_path"] = str(destination)
                row["knowledge_sha256"] = digest

                fingerprint = str(
                    row.get("historical_candidate_fingerprint") or ""
                )
                candidate = by_fingerprint.get(fingerprint, {})
                artifacts.append(
                    {
                        "artifact_name": candidate_name,
                        "path": str(destination),
                        "sha256": digest,
                        "generation_mode": row.get("generation_mode"),
                        "knowledge_cache_key": row.get(
                            "knowledge_cache_key"
                        ),
                        "historical_candidate_fingerprint": fingerprint,
                        "repo": candidate.get("repo"),
                        "historical_issue_number": candidate.get(
                            "historical_issue_number"
                        ),
                        "cache_hit": bool(row.get("cache_hit")),
                    }
                )
            except Exception as exc:
                logger.exception(
                    "Failed to publish a generated artifact into the unified "
                    "run: %s",
                    exc,
                )
                row["generation_status"] = "failed"
                row["preparation_publication_error"] = (
                    f"{type(exc).__name__}: {exc}"
                )
                row["error"] = row["preparation_publication_error"]
                row["knowledge_path"] = None
            manifest_rows.append(row)
        return manifest_rows, artifacts

    def _result_from_stages(
        self,
        *,
        request: PreparationRequest,
        request_id: str,
        run_dir: Path,
        retrieval: SearchRetrievalResult,
        generation: GenerationResult,
        manifest_rows: list[dict[str, Any]],
        artifacts: list[dict[str, Any]],
    ) -> PreparationResult:
        completed_count = sum(
            row.get("generation_status") == "completed"
            for row in manifest_rows
        )
        cache_hit_count = sum(
            row.get("generation_status") == "completed"
            and row.get("cache_hit") is True
            for row in manifest_rows
        )
        generated_count = completed_count - cache_hit_count
        failed_count = len(manifest_rows) - completed_count
        if failed_count and not completed_count:
            status = "failed"
        elif failed_count:
            status = "partial"
        elif retrieval.status == "partial":
            status = "partial"
        elif generation.status == "no_candidates":
            status = "no_candidates"
        else:
            status = "completed"

        error = (
            retrieval.error
            or generation.error
            or _first_error(manifest_rows)
        )
        return PreparationResult(
            schema_version=PREPARATION_SCHEMA_VERSION,
            request_id=request_id,
            status=status,
            instance_id=request.instance.instance_id,
            generation_mode=request.generation_mode,
            retrieval_status=retrieval.status,
            generation_status=generation.status,
            retrieval_source=retrieval.retrieval_source,
            selected_count=retrieval.selected_count,
            rejected_count=retrieval.rejected_count,
            completed_count=completed_count,
            cache_hit_count=cache_hit_count,
            generated_count=generated_count,
            failed_count=failed_count,
            output_dir=str(run_dir),
            retrieval=self._retrieval_summary(retrieval),
            generation=self._generation_summary(
                generation,
                completed_count=completed_count,
                cache_hit_count=cache_hit_count,
                generated_count=generated_count,
                failed_count=failed_count,
            ),
            knowledge_artifacts=artifacts,
            resumed=False,
            retryable=any(bool(row.get("retryable")) for row in manifest_rows if row.get("generation_status") == "failed"),
            error=error,
        )

    def _finalize_without_generation(
        self,
        *,
        request: PreparationRequest,
        request_id: str,
        run_dir: Path,
        retrieval: SearchRetrievalResult | None,
        status: str,
        retrieval_status: str,
        error: str | None,
        retryable: bool,
    ) -> PreparationResult:
        for name in (
            "safe_candidate_pool.jsonl",
            "review_candidate_pool.jsonl",
            "selected_historical_issues.jsonl",
            "rejected_historical_issues.jsonl",
            "search_audit.jsonl",
            "rejection_audit.jsonl",
            "gate_audit.jsonl",
        ):
            if not (run_dir / name).is_file():
                write_jsonl_atomic(run_dir / name, [])
        write_jsonl_atomic(run_dir / "generation_manifest.jsonl", [])
        selected_count = retrieval.selected_count if retrieval else 0
        rejected_count = retrieval.rejected_count if retrieval else 0
        result = PreparationResult(
            schema_version=PREPARATION_SCHEMA_VERSION,
            request_id=request_id,
            status=status,
            instance_id=request.instance.instance_id,
            generation_mode=request.generation_mode,
            retrieval_status=retrieval_status,
            generation_status="skipped",
            retrieval_source=(
                retrieval.retrieval_source if retrieval else "unknown"
            ),
            selected_count=selected_count,
            rejected_count=rejected_count,
            completed_count=0,
            cache_hit_count=0,
            generated_count=0,
            failed_count=selected_count if status == "failed" else 0,
            output_dir=str(run_dir),
            retrieval=(
                self._retrieval_summary(retrieval)
                if retrieval is not None
                else {
                    "status": "failed",
                    "error": error,
                }
            ),
            generation={
                "status": "skipped",
                "reason": (
                    "retrieval_failed"
                    if status == "failed"
                    else "no_selected_candidates"
                ),
            },
            knowledge_artifacts=[],
            resumed=False,
            retryable=retryable,
            error=error,
        )
        self._write_final_artifacts(run_dir, result)
        return result

    def _finalize_generation_exception(
        self,
        *,
        request: PreparationRequest,
        request_id: str,
        run_dir: Path,
        retrieval: SearchRetrievalResult,
        failure: FailureReport,
    ) -> PreparationResult:
        rows = [
            {
                "instance_id": request.instance.instance_id,
                "historical_candidate_fingerprint": row.get(
                    "historical_candidate_fingerprint"
                ),
                "generation_mode": request.generation_mode,
                "cache_hit": False,
                "generation_status": "failed",
                "knowledge_path": None,
                "error_code": failure.code,
                "retryable": failure.retryable,
                "error": (
                    "Knowledge Generation raised an exception before "
                    "returning a result; see logs."
                ),
            }
            for row in retrieval.selected_candidates
        ]
        write_jsonl_atomic(
            run_dir / "generation_manifest.jsonl",
            rows,
        )
        result = PreparationResult(
            schema_version=PREPARATION_SCHEMA_VERSION,
            request_id=request_id,
            status="failed",
            instance_id=request.instance.instance_id,
            generation_mode=request.generation_mode,
            retrieval_status=retrieval.status,
            generation_status="failed",
            retrieval_source=retrieval.retrieval_source,
            selected_count=retrieval.selected_count,
            rejected_count=retrieval.rejected_count,
            completed_count=0,
            cache_hit_count=0,
            generated_count=0,
            failed_count=retrieval.selected_count,
            output_dir=str(run_dir),
            retrieval=self._retrieval_summary(retrieval),
            generation={
                "status": "failed",
                "error": (
                    "Knowledge Generation raised an exception before "
                    "returning a result; see logs."
                ),
            },
            knowledge_artifacts=[],
            resumed=False,
            retryable=failure.retryable,
            error=(
                "Knowledge Generation raised an exception before returning "
                "a result; see logs."
            ),
        )
        self._write_final_artifacts(run_dir, result)
        return result

    @staticmethod
    def _retrieval_summary(
        retrieval: SearchRetrievalResult,
    ) -> dict[str, Any]:
        return {
            "schema_version": retrieval.schema_version,
            "request_id": retrieval.request_id,
            "status": retrieval.status,
            "retrieval_source": retrieval.retrieval_source,
            "search_candidate_count": retrieval.search_candidate_count,
            "final_top_k": retrieval.final_top_k,
            "selected_count": retrieval.selected_count,
            "rejected_count": retrieval.rejected_count,
            "boundary": retrieval.boundary,
            "stats": retrieval.stats,
            "stage_output_dir": retrieval.output_dir,
            "error": retrieval.error,
        }

    @staticmethod
    def _generation_summary(
        generation: GenerationResult,
        *,
        completed_count: int,
        cache_hit_count: int,
        generated_count: int,
        failed_count: int,
    ) -> dict[str, Any]:
        return {
            "schema_version": generation.schema_version,
            "request_id": generation.request_id,
            "status": generation.status,
            "generation_mode": generation.generation_mode,
            "selected_count": generation.selected_count,
            "completed_count": completed_count,
            "cache_hit_count": cache_hit_count,
            "generated_count": generated_count,
            "failed_count": failed_count,
            "stage_output_dir": generation.output_dir,
            "error": generation.error,
        }

    @staticmethod
    def _write_final_artifacts(
        run_dir: Path,
        result: PreparationResult,
    ) -> None:
        (run_dir / "knowledge").mkdir(parents=True, exist_ok=True)
        write_json_atomic(run_dir / "result.json", result.to_dict())
        write_json_atomic(
            run_dir / "summary.json",
            {
                "schema_version": result.schema_version,
                "request_id": result.request_id,
                "status": result.status,
                "instance_id": result.instance_id,
                "generation_mode": result.generation_mode,
                "retrieval_status": result.retrieval_status,
                "generation_status": result.generation_status,
                "retrieval_source": result.retrieval_source,
                "selected_count": result.selected_count,
                "rejected_count": result.rejected_count,
                "completed_count": result.completed_count,
                "cache_hit_count": result.cache_hit_count,
                "generated_count": result.generated_count,
                "failed_count": result.failed_count,
                "artifact_count": len(result.knowledge_artifacts),
                "retryable": result.retryable,
                "error": result.error,
            },
        )
        write_json_atomic(
            run_dir / "manifest.json",
            {
                "schema_version": result.schema_version,
                "request_id": result.request_id,
                "status": result.status,
                "request": str(run_dir / "request.json"),
                "safe_candidate_pool": str(
                    run_dir / "safe_candidate_pool.jsonl"
                ),
                "review_candidate_pool": str(
                    run_dir / "review_candidate_pool.jsonl"
                ),
                "selected_historical_issues": str(
                    run_dir / "selected_historical_issues.jsonl"
                ),
                "rejected_historical_issues": str(
                    run_dir / "rejected_historical_issues.jsonl"
                ),
                "search_audit": str(run_dir / "search_audit.jsonl"),
                "rejection_audit": str(
                    run_dir / "rejection_audit.jsonl"
                ),
                "gate_audit": str(run_dir / "gate_audit.jsonl"),
                "generation_manifest": str(
                    run_dir / "generation_manifest.jsonl"
                ),
                "knowledge_dir": str(run_dir / "knowledge"),
                "summary": str(run_dir / "summary.json"),
                "result": str(run_dir / "result.json"),
                "retrieval_stage_output_dir": result.retrieval.get(
                    "stage_output_dir"
                ),
                "generation_stage_output_dir": result.generation.get(
                    "stage_output_dir"
                ),
            },
        )

    def _load_resumable_result(
        self,
        *,
        run_dir: Path,
        request_id: str,
    ) -> PreparationResult | None:
        value = read_json(run_dir / "result.json")
        if value is None:
            return None
        try:
            result = PreparationResult.from_dict(value)
        except (TypeError, ValueError):
            return None
        if (
            result.schema_version != PREPARATION_SCHEMA_VERSION
            or result.request_id != request_id
            or result.retryable
            or result.status not in {
                "completed",
                "partial",
                "no_candidates",
            }
        ):
            return None
        try:
            for artifact in result.knowledge_artifacts:
                name = str(artifact.get("artifact_name") or "")
                if not name or Path(name).name != name:
                    return None
                path = (run_dir / "knowledge" / name).resolve()
                if run_dir.resolve() not in path.parents:
                    return None
                xml_text = path.read_text(encoding="utf-8")
                validate_knowledge_content(
                    xml_text, expected_sha256=str(artifact.get("sha256") or "")
                )
        except (OSError, UnicodeError, ValueError):
            return None
        result.resumed = True
        result.output_dir = str(run_dir)
        return result
