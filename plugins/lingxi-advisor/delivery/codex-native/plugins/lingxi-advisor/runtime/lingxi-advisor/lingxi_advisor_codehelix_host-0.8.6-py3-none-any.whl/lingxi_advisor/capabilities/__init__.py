"""Canonical LingxiAdvisor capability interfaces."""
