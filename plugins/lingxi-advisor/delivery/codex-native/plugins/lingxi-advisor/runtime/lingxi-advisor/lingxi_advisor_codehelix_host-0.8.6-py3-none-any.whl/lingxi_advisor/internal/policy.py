"""Core execution permissions, shared by CLI, MCP and batch callers."""
from dataclasses import dataclass

from .execution import ExecutionFailure


@dataclass(frozen=True)
class ExecutionPolicy:
    allow_live_search: bool = True
    allow_update_preretrieved: bool = True
    allow_refresh: bool = True
    allow_model_calls: bool = True

    def require(self, permission: str) -> None:
        if not getattr(self, permission):
            raise ExecutionFailure('policy_denied', f'LingxiAdvisor policy disallows {permission}')
