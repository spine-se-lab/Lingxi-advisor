"""Read-only worktree-grounded historical knowledge generation."""

from .contracts import (
    AgentCompletion,
    AgentToolCall,
    GroundedAnalysisConfig,
    GroundedAnalysisInput,
    GroundedAnalysisResult,
)
from .generator import GroundedKnowledgeGenerator
from .grounding_validation import (
    GroundingConsistencyError,
    GroundingConsistencyReport,
    GroundingConsistencyValidator,
)
from .service import GroundedAnalysisService
from .worktree_manager import (
    HistoricalWorktreeManager,
    WorktreeHandle,
    WorktreeGCResult,
    WorktreeUnavailableError,
    WorktreeValidationError,
)

__all__ = [
    "AgentCompletion",
    "AgentToolCall",
    "GroundedAnalysisConfig",
    "GroundedAnalysisInput",
    "GroundedAnalysisResult",
    "GroundedAnalysisService",
    "GroundedKnowledgeGenerator",
    "GroundingConsistencyError",
    "GroundingConsistencyReport",
    "GroundingConsistencyValidator",
    "HistoricalWorktreeManager",
    "WorktreeHandle",
    "WorktreeGCResult",
    "WorktreeUnavailableError",
    "WorktreeValidationError",
]
