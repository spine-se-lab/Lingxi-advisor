from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ..command_runner import RestrictedSubprocessRunner
from ..io_utils import safe_part
from .candidate_schema import candidate_repo, historical_fix_commit


@dataclass(frozen=True)
class GroundingPreflight:
    repo: str
    checkout_commit: str | None
    checkout_state: str
    repository_path: str | None
    local_repository_present: bool
    local_commit_present: bool
    clone_required: bool
    fetch_required: bool
    restorable: bool
    status: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


class GroundingPreflightService:
    """Read-only preflight for the future grounded-analysis stage."""

    def __init__(
        self,
        *,
        repository_root: Path,
        runner: RestrictedSubprocessRunner | None = None,
    ):
        self.repository_root = repository_root.expanduser().resolve()
        self._runner = runner

    def _command_runner(self) -> RestrictedSubprocessRunner:
        if self._runner is None:
            self._runner = RestrictedSubprocessRunner(
                allowed_executables=("git",),
                read_only=True,
                preserve_git_transport_config=False,
            )
        return self._runner

    def _repository_path(self, repo: str) -> Path | None:
        if not repo or "/" not in repo:
            return None
        owner, name = repo.split("/", 1)
        return self.repository_root / f"{safe_part(owner)}__{safe_part(name)}"

    def _local_commit_present(self, repository_path: Path, sha: str) -> bool:
        if not (repository_path / ".git").exists():
            return False
        try:
            proc = self._command_runner().run(
                [
                    "git",
                    "-C",
                    str(repository_path),
                    "cat-file",
                    "-e",
                    f"{sha}^{{commit}}",
                ],
                timeout_seconds=20,
            )
        except RuntimeError:
            return False
        return proc.returncode == 0

    def preflight(self, row: Mapping[str, Any]) -> GroundingPreflight:
        repo = candidate_repo(row)
        commit = historical_fix_commit(row)
        repository_path = self._repository_path(repo)
        local_repo = bool(repository_path and (repository_path / ".git").exists())
        local_commit = bool(
            repository_path
            and commit
            and self._local_commit_present(repository_path, commit)
        )
        if not repo:
            return GroundingPreflight(
                repo="",
                checkout_commit=commit,
                checkout_state="historical_fix_post_state",
                repository_path=str(repository_path) if repository_path else None,
                local_repository_present=local_repo,
                local_commit_present=local_commit,
                clone_required=False,
                fetch_required=False,
                restorable=False,
                status="unavailable",
                reason="Historical repository identity is missing.",
            )
        if commit is None:
            return GroundingPreflight(
                repo=repo,
                checkout_commit=None,
                checkout_state="historical_fix_post_state",
                repository_path=str(repository_path) if repository_path else None,
                local_repository_present=local_repo,
                local_commit_present=False,
                clone_required=not local_repo,
                fetch_required=False,
                restorable=False,
                status="unavailable",
                reason="No full 40-character historical fix commit is available.",
            )
        if local_commit:
            status = "local_ready"
            reason = (
                "Historical fix commit already exists in the local repository cache."
            )
        elif local_repo:
            status = "fetch_required"
            reason = "Repository cache exists, but the historical fix commit must be fetched."
        else:
            status = "clone_required"
            reason = (
                "Repository must be cloned before creating the historical worktree."
            )
        return GroundingPreflight(
            repo=repo,
            checkout_commit=commit,
            checkout_state="historical_fix_post_state",
            repository_path=str(repository_path) if repository_path else None,
            local_repository_present=local_repo,
            local_commit_present=local_commit,
            clone_required=not local_repo,
            fetch_required=local_repo and not local_commit,
            restorable=True,
            status=status,
            reason=reason,
        )
