from __future__ import annotations

from .execution import bounded_execution

from .policy import ExecutionPolicy
from .run_state import RunStatus
from .execution import ExecutionFailure, failure_details, checkpoint

import logging
from pathlib import Path
from typing import Any, Mapping, Sequence

from .generation_contracts import (
    GENERATION_SCHEMA_VERSION,
    GenerationManifestRow,
    GenerationRequest,
    GenerationResult,
    generation_request_id,
    knowledge_cache_key,
)
from .generation_dispatch import GenerationDispatcher
from .grounded_analysis.contracts import GroundedAnalysisConfig
from .grounded_analysis.grounding_validation import (
    GroundingConsistencyError,
)
from .grounded_analysis.llm import GroundedLLMClient
from .grounded_analysis.service import GroundedAnalysisService
from .io_utils import (
    read_jsonl,
    safe_part,
    write_json_atomic,
    write_jsonl_atomic,
)
from .knowledge_cache import KnowledgeCache
from .knowledge_template import template_version_for_mode
from .light_generation.contracts import (
    LightGeneratorConfig,
)
from .light_generation.generator import LLMClient
from .light_generation.service import LightGenerationService

logger = logging.getLogger(__name__)


class KnowledgeGenerationService:
    """Generate selected candidates; JSONL is only the CLI input adapter."""

    def __init__(
        self,
        *,
        light_config: LightGeneratorConfig | None = None,
        light_client: LLMClient | None = None,
        grounded_config: GroundedAnalysisConfig | None = None,
        grounded_client: GroundedLLMClient | None = None,
        policy: ExecutionPolicy | None = None,
    ) -> None:
        self.policy = policy or ExecutionPolicy()
        self.light_config = light_config
        self.light_client = light_client
        self.grounded_config = grounded_config
        self.grounded_client = grounded_client

    def _light_service_factory(self) -> LightGenerationService:
        self.policy.require("allow_model_calls")
        if self.light_config is None:
            raise RuntimeError("Light generator configuration is missing")
        if self.light_client is None and not self.light_config.api_key:
            raise RuntimeError(
                "No configured generator model and no Agent Host model "
                "backend is available for Light generation."
            )
        return LightGenerationService(
            self.light_config, client=self.light_client
        )

    def _grounded_service_factory(self) -> GroundedAnalysisService:
        self.policy.require("allow_model_calls")
        if self.grounded_config is None:
            raise RuntimeError(
                "Grounded analysis configuration is missing"
            )
        if self.grounded_client is None and not self.grounded_config.api_key:
            raise RuntimeError(
                "No configured generator model and no Agent Host model "
                "backend is available for Grounded generation."
            )
        return GroundedAnalysisService(
            self.grounded_config,
            client=self.grounded_client,
        )

    @staticmethod
    def _output_path(
        run_dir: Path,
        candidate: Mapping[str, Any],
        *,
        multiple_instances: bool,
    ) -> Path:
        instance_id = str(candidate.get("instance_id") or "unknown_instance")
        repo = str(candidate.get("repo") or "unknown_repository").strip()
        repo_part = safe_part(repo.replace("/", "__"))
        issue_number = candidate.get("historical_issue_number")
        if issue_number not in (None, ""):
            issue_part = safe_part(str(issue_number))
        else:
            fingerprint = str(
                candidate.get("historical_candidate_fingerprint")
                or "unknown_candidate"
            )
            issue_part = (
                "unknown__"
                + safe_part(fingerprint, max_len=32)
            )
        knowledge_root = run_dir / "knowledge"
        if multiple_instances:
            knowledge_root = knowledge_root / safe_part(instance_id)
        return knowledge_root / f"{repo_part}__issue_{issue_part}.xml"

    def run(self, request: GenerationRequest) -> GenerationResult:
        request.validate()
        assert request.input_jsonl is not None
        return self.run_candidates(request, read_jsonl(request.input_jsonl))

    @bounded_execution
    def run_candidates(
        self, request: GenerationRequest, candidates: Sequence[Mapping[str, Any]]
    ) -> GenerationResult:
        request.validate(require_input=False)
        candidates = [dict(candidate) for candidate in candidates]
        expected_template_version = template_version_for_mode(
            request.generation_mode
        )
        if request.generation_mode == "light":
            if self.light_config is None:
                raise ValueError("light_config is required for light mode")
            self.light_config.validate()
            if request.template_version != expected_template_version:
                raise ValueError(
                    "request template_version does not match the Light prompt "
                    f"implementation ({expected_template_version})"
                )
            if request.generator_model != self.light_config.model:
                raise ValueError(
                    "request generator_model does not match light_config.model"
                )
        elif (
            request.generation_mode == "grounded_analysis"
            and self.grounded_config is not None
        ):
            self.grounded_config.validate()
            if (
                request.template_version
                != expected_template_version
            ):
                raise ValueError(
                    "request template_version does not match the Grounded "
                    "prompt implementation "
                    f"({expected_template_version})"
                )
            if request.generator_model != self.grounded_config.model:
                raise ValueError(
                    "request generator_model does not match "
                    "grounded_config.model"
                )
            if request.allow_clone != self.grounded_config.allow_clone:
                raise ValueError(
                    "request allow_clone does not match grounded_config"
                )
            if request.allow_fetch != self.grounded_config.allow_fetch:
                raise ValueError(
                    "request allow_fetch does not match grounded_config"
                )
            if (
                request.repository_root is not None
                and request.repository_root.expanduser().resolve()
                != self.grounded_config.repository_root.expanduser().resolve()
            ):
                raise ValueError(
                    "request repository_root does not match grounded_config"
                )
            if (
                request.historical_worktree_root is not None
                and request.historical_worktree_root.expanduser().resolve()
                != self.grounded_config.worktree_root.expanduser().resolve()
            ):
                raise ValueError(
                    "request historical_worktree_root does not match "
                    "grounded_config"
                )
            if (
                request.runtime_options
                and dict(request.runtime_options)
                != self.grounded_config.public_dict()
            ):
                raise ValueError(
                    "request runtime_options do not match grounded_config"
                )

        request_id = generation_request_id(request, candidates)
        run_dir = (
            request.output_root.expanduser().resolve()
            / "generation_runs"
            / request_id
        )
        logger.info(
            "Knowledge generation started: request_id=%s mode=%s "
            "candidates=%d",
            request_id,
            request.generation_mode,
            len(candidates),
        )
        logger.debug(
            "Generation settings: model=%s template=%s "
            "target_conditioned=%s resume=%s allow_clone=%s "
            "allow_fetch=%s input=%s",
            request.generator_model,
            request.template_version,
            request.target_conditioned,
            request.resume,
            request.allow_clone,
            request.allow_fetch,
            request.input_jsonl,
        )
        logger.debug(
            "Generation paths: cache=%s run_dir=%s",
            request.knowledge_cache_dir,
            run_dir,
        )
        write_jsonl_atomic(
            run_dir / "selected_historical_issues.jsonl", candidates
        )
        cache = KnowledgeCache(request.knowledge_cache_dir)
        dispatcher = GenerationDispatcher(
            knowledge_cache=cache,
            generation_mode=request.generation_mode,
            template_version=request.template_version,
            generator_model=request.generator_model,
            target_conditioned=request.target_conditioned,
            light_service_factory=(
                self._light_service_factory
                if request.generation_mode == "light"
                else None
            ),
            grounded_service_factory=(
                self._grounded_service_factory
                if (
                    request.generation_mode == "grounded_analysis"
                    and self.grounded_config is not None
                )
                else None
            ),
        )
        instance_ids = {
            str(candidate.get("instance_id") or "")
            for candidate in candidates
        }
        multiple_instances = len(instance_ids) > 1
        manifest_rows: list[dict[str, Any]] = []

        if not candidates:
            logger.info(
                "No selected historical candidates; no cache lookup or model "
                "call is required."
            )

        for index, candidate in enumerate(candidates, start=1):
            checkpoint()
            instance_id = str(
                candidate.get("instance_id") or "unknown_instance"
            )
            fingerprint = str(
                candidate.get("historical_candidate_fingerprint")
                or "pending_validation"
            )
            repo = str(candidate.get("repo") or "unknown_repo")
            issue_number = candidate.get("historical_issue_number")
            issue_label = (
                f"#{issue_number}"
                if issue_number not in (None, "")
                else "unknown"
            )
            logger.debug(
                "[%d/%d] Processing candidate: instance=%s repo=%s "
                "historical_issue=%s candidate=%s",
                index,
                len(candidates),
                instance_id,
                repo,
                issue_label,
                fingerprint,
            )
            try:
                output_path = self._output_path(
                    run_dir,
                    candidate,
                    multiple_instances=multiple_instances,
                )
                row = dispatcher.dispatch(
                    candidate,
                    output_path=output_path,
                )
            except ExecutionFailure as exc:
                if exc.code in {"cancelled", "deadline_exceeded"}:
                    raise
                raise
            except Exception as exc:
                logger.error(
                    "Knowledge generation failed: stage=candidate_generation "
                    "candidate_index=%d candidate_count=%d reason=%s "
                    "can_continue=true",
                    index,
                    len(candidates),
                    type(exc).__name__,
                )
                logger.debug(
                    "Candidate failure traceback: instance=%s candidate=%s",
                    instance_id,
                    fingerprint,
                    exc_info=True,
                )
                cache_key = ""
                try:
                    cache_key = knowledge_cache_key(
                        candidate=candidate,
                        generation_mode=request.generation_mode,
                        template_version=request.template_version,
                        generator_model=request.generator_model,
                        target_conditioned=request.target_conditioned,
                    )
                except Exception:
                    pass
                grounding_validation = (
                    exc.report.to_dict()
                    if isinstance(exc, GroundingConsistencyError)
                    else None
                )
                row = GenerationManifestRow(
                    instance_id=str(candidate.get("instance_id") or ""),
                    historical_candidate_fingerprint=str(
                        candidate.get("historical_candidate_fingerprint") or ""
                    ),
                    generation_mode=request.generation_mode,
                    cache_hit=False,
                    generation_status="failed",
                    knowledge_cache_key=cache_key,
                    knowledge_path=None,
                    template_version=request.template_version,
                    generator_model=request.generator_model,
                    target_conditioned=request.target_conditioned,
                    repository_identity_verified=(
                        bool(
                            grounding_validation.get(
                                "repository_identity_verified"
                            )
                        )
                        if grounding_validation is not None
                        else None
                    ),
                    grounding_validation=grounding_validation,
                    error=f"{type(exc).__name__}: {exc}",
                    error_code=failure_details(exc)[0],
                    retryable=failure_details(exc)[1],
                )
            else:
                outcome = "cache_hit" if row.cache_hit else "generated"
                logger.debug(
                    "[%d/%d] Candidate completed: instance=%s candidate=%s "
                    "result=%s llm_latency=%.2fs output=%s",
                    index,
                    len(candidates),
                    row.instance_id,
                    row.historical_candidate_fingerprint,
                    outcome,
                    row.latency_seconds,
                    row.knowledge_path,
                )
            manifest_rows.append(row.to_dict())
            # Keep a valid resume checkpoint after every candidate.
            write_jsonl_atomic(
                run_dir / "generation_manifest.jsonl", manifest_rows
            )
            logger.debug(
                "[%d/%d] Generation checkpoint updated: %s",
                index,
                len(candidates),
                run_dir / "generation_manifest.jsonl",
            )

        selected_count = len(candidates)
        completed_count = sum(
            row["generation_status"] == "completed"
            for row in manifest_rows
        )
        cache_hit_count = sum(
            row["generation_status"] == "completed" and row["cache_hit"]
            for row in manifest_rows
        )
        generated_count = completed_count - cache_hit_count
        failed_count = selected_count - completed_count
        status = RunStatus.from_counts(selected=selected_count, completed=completed_count)

        result = GenerationResult(
            schema_version=GENERATION_SCHEMA_VERSION,
            request_id=request_id,
            status=status,
            generation_mode=request.generation_mode,
            selected_count=selected_count,
            completed_count=completed_count,
            cache_hit_count=cache_hit_count,
            generated_count=generated_count,
            failed_count=failed_count,
            manifest_rows=manifest_rows,
            output_dir=str(run_dir),
        )
        self._write_artifacts(run_dir, request, result)
        total_latency = sum(
            float(row.get("latency_seconds") or 0.0)
            for row in result.manifest_rows
        )
        total_cost = sum(
            float(row.get("cost_usd") or 0.0)
            for row in result.manifest_rows
        )
        worktree_reused_count = sum(
            row.get("worktree_reused") is True
            for row in result.manifest_rows
        )
        worktree_created_count = sum(
            row.get("worktree_reused") is False
            and bool(row.get("worktree_path"))
            for row in result.manifest_rows
        )
        worktree_gc_removed_count = sum(
            int(row.get("worktree_gc_removed_count") or 0)
            for row in result.manifest_rows
        )
        context_compaction_count = sum(
            int(
                (row.get("context_budget") or {}).get(
                    "compaction_count", 0
                )
            )
            for row in result.manifest_rows
        )
        logger.info(
            "Knowledge generation finished: status=%s selected=%d "
            "completed=%d generated=%d cache_hits=%d failed=%d "
            "worktrees_created=%d worktrees_reused=%d "
            "worktrees_gc_removed=%d context_compactions=%d "
            "llm_latency=%.2fs cost_usd=%.4f",
            result.status,
            result.selected_count,
            result.completed_count,
            result.generated_count,
            result.cache_hit_count,
            result.failed_count,
            worktree_created_count,
            worktree_reused_count,
            worktree_gc_removed_count,
            context_compaction_count,
            total_latency,
            total_cost,
        )
        logger.debug("Generation artifacts: %s", run_dir)
        return result

    @staticmethod
    def _write_artifacts(
        run_dir: Path,
        request: GenerationRequest,
        result: GenerationResult,
    ) -> None:
        write_json_atomic(run_dir / "request.json", request.to_dict())
        write_jsonl_atomic(
            run_dir / "generation_manifest.jsonl",
            result.manifest_rows,
        )
        write_json_atomic(
            run_dir / "summary.json",
            {
                "schema_version": result.schema_version,
                "request_id": result.request_id,
                "status": result.status,
                "generation_mode": result.generation_mode,
                "selected_count": result.selected_count,
                "completed_count": result.completed_count,
                "cache_hit_count": result.cache_hit_count,
                "generated_count": result.generated_count,
                "failed_count": result.failed_count,
                "worktree_reused_count": sum(
                    row.get("worktree_reused") is True
                    for row in result.manifest_rows
                ),
                "worktree_created_count": sum(
                    row.get("worktree_reused") is False
                    and bool(row.get("worktree_path"))
                    for row in result.manifest_rows
                ),
                "worktree_gc_removed_count": sum(
                    int(row.get("worktree_gc_removed_count") or 0)
                    for row in result.manifest_rows
                ),
                "worktree_post_verified_count": sum(
                    row.get("worktree_post_verified") is True
                    for row in result.manifest_rows
                ),
                "repository_identity_verified_count": sum(
                    row.get("repository_identity_verified") is True
                    for row in result.manifest_rows
                ),
                "context_compaction_count": sum(
                    int(
                        (row.get("context_budget") or {}).get(
                            "compaction_count", 0
                        )
                    )
                    for row in result.manifest_rows
                ),
                "latency_seconds": sum(
                    float(row.get("latency_seconds") or 0.0)
                    for row in result.manifest_rows
                ),
                "cost_usd": sum(
                    float(row.get("cost_usd") or 0.0)
                    for row in result.manifest_rows
                ),
            },
        )
        write_json_atomic(run_dir / "result.json", result.to_dict())
        write_json_atomic(
            run_dir / "manifest.json",
            {
                "schema_version": result.schema_version,
                "request_id": result.request_id,
                "status": result.status,
                "request": str(run_dir / "request.json"),
                "generation_manifest": str(
                    run_dir / "generation_manifest.jsonl"
                ),
                "selected_historical_issues": str(
                    run_dir / "selected_historical_issues.jsonl"
                ),
                "knowledge_dir": str(run_dir / "knowledge"),
                "summary": str(run_dir / "summary.json"),
                "result": str(run_dir / "result.json"),
            },
        )
