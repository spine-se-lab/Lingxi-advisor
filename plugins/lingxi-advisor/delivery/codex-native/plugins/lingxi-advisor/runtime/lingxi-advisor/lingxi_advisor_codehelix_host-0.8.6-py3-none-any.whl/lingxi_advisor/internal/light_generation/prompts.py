from string import Template

from ..knowledge_template import (
    GENERAL_SUMMARY_TAGS,
    LIGHT_FINE_GRAINED_1_TAGS,
    LIGHT_FINE_GRAINED_2_TAGS,
    LIGHT_TEMPLATE_VERSION,
    validate_template_instructions,
)

TEMPLATE_VERSION = LIGHT_TEMPLATE_VERSION

# Prompts_3
#
# Design:
# - Keep v2 tag names because they are better aligned with issue/fix knowledge retrieval.
# - Restore v1-style detailed instructions inside each tag.
# - Split fg1 and fg2 into complementary sections to avoid duplicated XML tags in step_analysis.
#
# Expected runner behavior:
#   step_analysis = fg1 + "\n\n" + fg2
#   step_summary  = g
#
# Therefore:
# - FINE_GRAINED_PROMPT_1 outputs only:
#     repository_hierarchy, dependency_analysis, call_trace
# - FINE_GRAINED_PROMPT_2 outputs only:
#     bug_category, usage_context, root_cause, behavior_comparison,
#     fix_logic, fix_steps, fix_checklist, test_case, conclusion
# - GENERAL_PROMPT_1 outputs general reusable knowledge with v2 summary tags.


FINE_GRAINED_PROMPT_1 = Template(
"""You are running the Light historical-knowledge generation mode. Analyze a historical issue/requirement report and its corresponding patch without reading or claiming to have read a repository worktree. Extract fine-grained, evidence-grounded structural knowledge for future retrieval and repair.

Your task in this first fine-grained pass is ONLY to identify the repository hierarchy, implementation dependencies, and call/logic flow that are supported by the report, patch, and changed files summary.

$TARGET_CONTEXT
$METADATA
$CHANGED_FILES_SUMMARY

Historical issue / requirement report:
\"\"\"
$REQUIREMENT_REPORT
\"\"\"

Corresponding patch:
\"\"\"
$PATCH
\"\"\"

Output ONLY XML with exactly the following top-level tags, in this order:

<repository_hierarchy>
    Describe where this issue/fix belongs in the repository architecture.

    Include:
    - The high-level subsystem, feature area, or capability involved.
    - The relevant component/module/file path(s) modified by the patch.
    - The relevant classes, methods, functions, config entries, data structures, or tests, but ONLY when they are explicitly supported by the patch or changed files summary.
    - The role of each identified file/function/component in the issue and fix.
    - A hierarchy-style description, for example:
      Repository → Subsystem → Component/Module → File → Class/Function → Responsibility.

    Constraints:
    - Do NOT invent architecture that is not visible from the report, patch, or changed files summary.
    - If only file-level information is supported, keep the hierarchy at file/component level.
    - If a class/function is not visible in the patch, do not name it.
</repository_hierarchy>

<dependency_analysis>
    Conduct a dependency analysis grounded in the patch.

    Include:
    - Direct imports added, removed, or changed by the patch.
    - Function, method, class, module, configuration, or data dependencies visible in the changed code.
    - Inheritance, interface, callback, hook, configuration lookup, event-flow, or utility-function dependencies, if explicitly supported.
    - For each dependency, explain:
        1. Dependency name and type, such as import, function call, method call, configuration dependency, data dependency, test dependency, or module dependency.
        2. Where it appears, using file/class/function identifiers only when supported.
        3. Why the dependency matters for the issue/fix.
        4. How the dependency participates in the corrected behavior.

    Constraints:
    - Do NOT infer hidden dependencies outside the patch.
    - Do NOT claim a dependency is called at runtime unless the patch or issue text supports that flow.
    - If the patch only shows a local helper or local condition, say the dependency scope is local.
</dependency_analysis>

<call_trace>
    Provide a numbered call trace or logic-flow trace for the issue and fix.

    Include:
    - A short overview of the relevant execution or decision flow.
    - A numbered sequence of key runtime or logical steps.
    - The pre-fix flow when it is useful for explaining the bug.
    - The post-fix flow showing where the new or changed logic alters behavior.
    - File/function identifiers ONLY when they are supported by the patch or changed files summary.
    - If the patch changes tests, include the test trigger or validation path as part of the trace.

    Suggested structure:
    1. Entry point or triggering condition.
    2. Existing lookup/check/processing path.
    3. Failure point or missing behavior.
    4. New or changed check/helper/branch introduced by the patch.
    5. Corrected outcome.
    6. Test or validation path, if supported.

    Constraints:
    - Keep the trace grounded in explicit patch evidence.
    - If an exact runtime call order is unknown, describe it as a logical flow instead of pretending it is a precise call stack.
</call_trace>

$SUFFIX
"""
)


FINE_GRAINED_PROMPT_2 = Template(
"""You are running the Light historical-knowledge generation mode. Analyze a historical issue/requirement report and its corresponding patch without reading or claiming to have read a repository worktree. Extract fine-grained, evidence-grounded bug/fix knowledge for future retrieval and repair.

Your task in this second fine-grained pass is ONLY to analyze the issue category, usage context, root cause, behavior difference, fix logic, implementation steps, checklist, tests, and conclusion.

Do NOT repeat the repository hierarchy, dependency analysis, or call trace sections. Those belong to the first fine-grained pass.

$TARGET_CONTEXT
$METADATA
$CHANGED_FILES_SUMMARY

Historical issue / requirement report:
\"\"\"
$REQUIREMENT_REPORT
\"\"\"

Corresponding patch:
\"\"\"
$PATCH
\"\"\"

Output ONLY XML with exactly the following top-level tags, in this order:

<bug_category>
    Classify the issue/fix using a concise but informative hierarchy.

    Include:
    - Primary category: the broad type of change, such as bug fix, feature enhancement, standards/protocol compliance, configuration behavior, API/interface behavior, validation fix, error handling fix, test coverage fix, performance fix, or refactor supporting a fix.
    - Secondary category: the affected system area, such as UI layer, network/request handling, parser, configuration layer, data layer, storage/cache, runtime behavior, integration layer, test infrastructure, or documentation.
    - Tertiary category: a repo-specific component or behavior, grounded in the patch.

    Explain briefly why this category fits.

    Constraints:
    - Use categories that reflect the actual patch.
    - Do NOT over-classify as security, performance, or protocol compliance unless the patch supports it.
</bug_category>

<usage_context>
    Describe when and how the issue appears from the user, developer, runtime, or system perspective.

    Include:
    - The triggering scenario or input condition described by the issue.
    - Relevant configuration, environment, feature flag, mode, protocol state, runtime state, or user action, if supported.
    - The affected user-visible behavior or developer-visible behavior.
    - Any important edge case, boundary condition, or special case handled by the patch.

    Constraints:
    - Do NOT invent reproduction steps.
    - If the issue report is sparse, derive only what is supported by the issue text and patch.
</usage_context>

<root_cause>
    Explain the underlying cause of the incorrect or missing behavior.

    Include:
    - The specific missing check, incorrect condition, wrong assumption, incomplete matching logic, missing state transition, unhandled edge case, incorrect dependency location, or insufficient validation.
    - The relevant code location(s), file(s), function(s), or changed logic, when supported.
    - Why the previous behavior failed for the reported scenario.
    - Whether the root cause is local to one function/file or spans multiple components.

    Constraints:
    - Ground the root cause in the diff.
    - Do NOT describe symptoms only; explain why the symptoms happened.
    - If root cause cannot be fully determined, state what is known and what remains unknown.
</root_cause>

<behavior_comparison>
    Compare the pre-fix behavior and the expected/post-fix behavior.

    Include:
    - Current/pre-fix behavior: what the code did before the patch.
    - Expected/post-fix behavior: what the code should do after the patch.
    - Behavior contrast: why the old behavior was wrong or incomplete, and how the new behavior changes the outcome.
    - Any changed precedence, guard condition, matching rule, fallback behavior, exception behavior, or state handling.

    Suggested substructure:
    <current_behavior>...</current_behavior>
    <expected_behavior>...</expected_behavior>
    <behavior_contrast>...</behavior_contrast>

    Constraints:
    - Avoid vague statements like "it fixes the issue" without explaining the behavior change.
    - Do NOT claim behavior not represented by the patch.
</behavior_comparison>

<fix_logic>
    Explain the implementation logic of the fix.

    Include:
    - Modified files and the responsibilities of the changed code.
    - Operations added, removed, or changed.
    - New guards, conditionals, helper functions, imports, data transformations, normalization rules, validation rules, fallback paths, or test assertions.
    - Why the change resolves the root cause.
    - Whether the fix is a minimal patch, refactor, relocation of helper logic, API/interface exposure, test-only update, or multi-step implementation.
    - Any assumptions or invariants that are updated by the patch.

    Constraints:
    - Use exact identifiers only when visible in the patch.
    - Distinguish functional changes from style/lint/test/doc changes.
</fix_logic>

<fix_steps>
    Provide concrete implementation steps that could guide a developer solving a similar issue.

    Include:
    - A concise summary of the fix strategy.
    - Numbered concrete steps.
    - For each step, include:
        1. The file/component/function involved, if supported.
        2. The code-level operation performed.
        3. The purpose of the operation.
        4. Why it is necessary for correctness.
    - Include test update steps if tests are modified by the patch.

    Constraints:
    - Steps should be reusable but still grounded in this patch.
    - Do NOT add steps that were not performed or clearly implied by the patch.
</fix_steps>

<fix_checklist>
    Provide a reusable checklist for developers facing similar issues.

    Include:
    - Conditions to inspect during debugging.
    - Code locations or component types to check.
    - Edge cases to validate.
    - Ordering or precedence rules to preserve.
    - Configuration, state, input-normalization, or dependency concerns to consider.
    - Testing requirements or regression checks.

    Constraints:
    - Make the checklist actionable.
    - Avoid generic advice that could apply to any bug.
</fix_checklist>

<test_case>
    Describe the test or validation logic associated with the fix.

    Include:
    - Tests added, removed, moved, or modified by the patch.
    - The behavior each test validates.
    - Important test input, setup, configuration, assertion, or expected output.
    - If no test is present in the patch, state that no explicit test change is visible and describe the minimal validation implied by the fix.

    Constraints:
    - Do NOT invent exact test names if not visible.
    - Separate observed tests from suggested validation.
</test_case>

<conclusion>
    Provide a concise final summary of the issue and fix.

    Include:
    - The issue category and affected feature/component.
    - The root cause.
    - The key behavior change.
    - The main files/functions/components changed, if supported.
    - The reusable lesson for future similar fixes.

    Constraints:
    - Keep it grounded and non-redundant.
    - Do NOT introduce new unsupported identifiers in the conclusion.
</conclusion>

$SUFFIX
"""
)


GENERAL_PROMPT_1 = Template(
"""You are running the Light historical-knowledge generation mode. Produce a general, reusable summary of a historical issue and fix without reading or claiming to have read a repository worktree. The input is a concise analysis context that may include the issue text and/or a call trace. Your goal is to abstract the fix knowledge so it can help solve the target issue when the evidence is genuinely transferable.

Stay general and transferable, but do not contradict the patch. Keep concrete identifiers only when they are important anchors and are explicitly supported by the patch.

$TARGET_CONTEXT
$METADATA
$CHANGED_FILES_SUMMARY

Analysis context:
\"\"\"
$REQUIREMENT_ANALYSIS
\"\"\"

Corresponding patch:
\"\"\"
$PATCH
\"\"\"

Output ONLY XML with exactly the following top-level tags, in this order:

<general_root_cause_analysis_steps>
    Provide a generalized diagnostic process for finding this type of issue.

    Include:
    - The kind of symptom or missing behavior to look for.
    - The relevant subsystem or component type to inspect.
    - The condition, edge case, state, configuration, input, or dependency relationship that tends to cause the issue.
    - How to compare current behavior against expected behavior.
    - How to localize the root cause using code, tests, or configuration.

    Constraints:
    - Abstract from this issue, but keep the reasoning compatible with the patch.
    - Do NOT include unsupported repository details.
</general_root_cause_analysis_steps>

<bug_categorization>
    Provide a generalized classification of the issue.

    Include:
    - Broad issue type, such as missing edge-case handling, incorrect matching/lookup, insufficient validation, wrong precedence, incomplete state handling, helper/API placement, configuration behavior, or regression test gap.
    - Affected system layer or architectural area.
    - Repo-specific category only if supported by the patch.

    Constraints:
    - Avoid over-specific labels that only restate one file name.
    - Avoid unsupported security/performance/protocol claims.
</bug_categorization>

<relevant_architecture>
    Describe the relevant architecture in reusable terms.

    Include:
    - The high-level subsystem or feature area.
    - The roles of the major involved components.
    - The flow between input, configuration/state lookup, processing logic, and output/decision.
    - Any helper/utility layer, validation layer, adapter layer, or test layer involved.

    Constraints:
    - Prefer component roles over excessive file/function details.
    - Mention exact files/functions only when they are essential and supported.
</relevant_architecture>

<involved_components>
    List and explain the involved components at a reusable level.

    Include:
    - Component name or role.
    - Responsibility in the issue/fix.
    - Whether the component is an entry point, decision point, helper, configuration source, data source, validation layer, or test component.
    - How components interact.

    Constraints:
    - Do NOT invent components.
    - If the patch only supports a small local change, keep this section local.
</involved_components>

<specific_involved_classes_functions_methods>
    Identify concrete classes, functions, methods, files, or tests that are important anchors for retrieval.

    Include:
    - Exact identifiers visible in the patch.
    - Their role in the issue/fix.
    - Why they matter for future similar issues.
    - If no class/function is visible, describe the file-level or component-level anchor instead.

    Constraints:
    - This is the only general-summary section where concrete identifiers are expected.
    - Do NOT add identifiers that are not supported by the patch or changed files summary.
</specific_involved_classes_functions_methods>

<feature_or_functionality_of_issue>
    Explain the feature or functionality affected by the issue.

    Include:
    - What capability the system was supposed to provide.
    - What user-visible, developer-visible, or system-visible behavior was incorrect or missing.
    - How the fix changes that capability.
    - What similar future issues might look like.

    Constraints:
    - Keep this about functionality, not just code mechanics.
</feature_or_functionality_of_issue>

<general_fix_pattern>
    Describe the generalizable fix pattern.

    Include:
    - The core strategy, such as adding a guard, widening a match, normalizing input, changing precedence, exposing/moving a helper, updating a state transition, validating configuration, handling an exception, or adding regression tests.
    - Why this strategy works.
    - When this pattern should be reused.
    - Risks or constraints when applying the pattern elsewhere.

    Constraints:
    - Do NOT claim the pattern applies universally.
    - Tie the pattern back to the evidence in this patch.
</general_fix_pattern>

<summary_of_fix_checklist>
    Provide a concise reusable checklist.

    Include:
    - What to inspect.
    - What edge cases to test.
    - What ordering, precedence, or invariants to preserve.
    - What files/components/tests are likely relevant in similar fixes.
    - What regression checks should be added or updated.

    Constraints:
    - Keep it actionable and not overly generic.
</summary_of_fix_checklist>

<design_patterns_and_coding_practices>
    Identify design practices demonstrated by the fix.

    Include:
    - Encapsulation, helper reuse, input normalization, explicit precedence, defensive checks, regression testing, small focused patches, separation of concerns, or API cleanup, when supported.
    - Why the practice matters for this class of issue.
    - Any maintainability or correctness principle shown by the patch.

    Constraints:
    - Mention only practices evidenced by the patch.
</design_patterns_and_coding_practices>

<additional_concepts>
    Add any additional reusable background concepts needed to understand or apply the fix.

    Include:
    - Domain concepts.
    - Configuration concepts.
    - Matching/lookup semantics.
    - Runtime-state concepts.
    - Testing concepts.
    - Any important caveats or unknowns.

    Constraints:
    - Keep this section useful for future retrieval.
    - Do NOT add broad unrelated background.
</additional_concepts>

$SUFFIX
"""
)


FINE_GRAINED_SUFFIX = """Verify:
- Output XML only; do not wrap the answer in Markdown.
- Use exactly the XML tags requested by the prompt and do not introduce additional top-level tags.
- Be comprehensive but grounded in the issue report, patch, and changed files summary.
- Do not introduce target-instance facts; this prompt contains historical evidence only.
- Do not claim repository/worktree inspection in Light mode.
- Avoid hallucinated file names, function names, classes, APIs, standards, protocols, or behaviors.
- When evidence is incomplete, state the uncertainty briefly inside the relevant tag.
- Prefer precise, developer-useful descriptions over generic statements.
"""


GENERAL_SUFFIX = """Verify:
- Output XML only; do not wrap the answer in Markdown.
- Use exactly the XML tags requested by the prompt and do not introduce additional top-level tags.
- Keep the summary general and transferable, but do not contradict the patch.
- Do not introduce target-instance facts; this prompt contains historical evidence only.
- Do not claim repository/worktree inspection in Light mode.
- Avoid hallucinated file names, function names, classes, APIs, standards, protocols, or behaviors.
- When concrete identifiers are used, they must be supported by the patch or changed files summary.
- Prefer reusable debugging and fix patterns over one-off narrative.
"""


validate_template_instructions(
    "Light fine-grained pass 1",
    FINE_GRAINED_PROMPT_1.template,
    LIGHT_FINE_GRAINED_1_TAGS,
)
validate_template_instructions(
    "Light fine-grained pass 2",
    FINE_GRAINED_PROMPT_2.template,
    LIGHT_FINE_GRAINED_2_TAGS,
)
validate_template_instructions(
    "Light general summary",
    GENERAL_PROMPT_1.template,
    GENERAL_SUMMARY_TAGS,
)
