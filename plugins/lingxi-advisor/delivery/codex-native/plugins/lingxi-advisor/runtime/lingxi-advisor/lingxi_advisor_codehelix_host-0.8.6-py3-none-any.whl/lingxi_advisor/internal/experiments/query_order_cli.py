"""Experimental wrapper around the production Search & Retrieval CLI."""

from __future__ import annotations

import argparse
import logging
import sys
from collections.abc import Sequence

from .query_order_profiles import (
    CONTROL_PROFILE,
    SUPPORTED_PROFILES,
    installed_query_order_profile,
    profile_description,
)

logger = logging.getLogger(__name__)


def _parse_experiment_args(argv: Sequence[str]) -> tuple[str, list[str]]:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument(
        "--query-order-profile",
        choices=SUPPORTED_PROFILES,
        default=CONTROL_PROFILE,
    )
    known, remaining = parser.parse_known_args(list(argv))
    return str(known.query_order_profile), remaining


def main() -> None:
    profile, production_args = _parse_experiment_args(sys.argv[1:])
    logger.warning(
        "query-order experiment profile=%s: %s",
        profile,
        profile_description(profile),
    )

    # The production parser must see only production arguments.  All retrieval,
    # safety, fix-discovery, caching, artifact, and gate behavior remains owned
    # by the existing CLI/service stack.
    original_argv = sys.argv
    sys.argv = [original_argv[0], *production_args]
    try:
        with installed_query_order_profile(profile):
            from ...adapters.cli.search import main as production_main

            production_main()
    finally:
        sys.argv = original_argv


if __name__ == "__main__":
    main()
