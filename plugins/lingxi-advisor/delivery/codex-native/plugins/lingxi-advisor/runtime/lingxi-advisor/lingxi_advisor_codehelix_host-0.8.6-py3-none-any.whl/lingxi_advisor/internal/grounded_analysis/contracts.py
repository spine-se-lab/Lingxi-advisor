from __future__ import annotations

import dataclasses
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from ..light_generation.contracts import (
    LightGenerationInput,
    ModelCallStats,
)

_SHA40_RE = re.compile(r"^[0-9a-f]{40}$")


@dataclass(frozen=True)
class GroundedAnalysisConfig:
    """Runtime and safety configuration for grounded historical analysis."""

    repository_root: Path
    worktree_root: Path
    model: str = "gpt-4.1-mini"
    base_url: str = "https://api.openai.com/v1"
    api_key: str | None = field(default=None, repr=False)
    timeout_seconds: float = 300.0
    max_attempts: int = 5
    retry_base_sleep_seconds: float = 2.0
    retry_max_sleep_seconds: float = 30.0
    max_output_tokens: int = 26_000
    temperature: float = 1.0
    verify_ssl: bool = True
    trust_env: bool = True
    allow_clone: bool = False
    allow_fetch: bool = False
    max_agent_turns: int = 24
    max_tool_calls: int = 20
    max_tool_output_chars: int = 16_000
    max_issue_chars: int = 32_000
    max_patch_chars: int = 96_000
    max_analysis_chars: int = 120_000
    max_context_chars: int = 480_000
    reserved_context_fraction: float = 0.15
    context_chars_per_token: int = 4
    max_compacted_tool_output_chars: int = 2_000
    max_file_bytes: int = 2_000_000
    max_search_results: int = 200
    max_glob_results: int = 500
    repository_host: str = "github.com"
    verify_repository_identity: bool = True
    grounding_consistency_policy: str = "strict"
    worktree_gc_max_count_per_repo: int = 0
    worktree_gc_max_age_days: float = 0.0
    worktree_gc_max_bytes_per_repo: int = 0

    def validate(self) -> None:
        if not self.model.strip():
            raise ValueError("grounded generator model cannot be empty")
        if not self.base_url.strip():
            raise ValueError("grounded generator base_url cannot be empty")
        if self.timeout_seconds <= 0:
            raise ValueError("grounded timeout_seconds must be positive")
        if self.max_attempts < 1:
            raise ValueError("grounded max_attempts must be positive")
        if self.retry_base_sleep_seconds < 0:
            raise ValueError(
                "grounded retry_base_sleep_seconds cannot be negative"
            )
        if self.retry_max_sleep_seconds < self.retry_base_sleep_seconds:
            raise ValueError(
                "grounded retry_max_sleep_seconds cannot be smaller than "
                "retry_base_sleep_seconds"
            )
        if self.max_output_tokens < 1:
            raise ValueError("grounded max_output_tokens must be positive")
        if not 0.0 <= self.temperature <= 2.0:
            raise ValueError("grounded temperature must be in [0, 2]")
        if self.max_agent_turns < 2:
            raise ValueError("max_agent_turns must be at least 2")
        if self.max_tool_calls < 1:
            raise ValueError("max_tool_calls must be positive")
        if self.max_tool_output_chars < 1_000:
            raise ValueError("max_tool_output_chars must be at least 1000")
        if self.max_context_chars < 16_000:
            raise ValueError("max_context_chars must be at least 16000")
        if not 0.0 <= self.reserved_context_fraction < 0.9:
            raise ValueError(
                "reserved_context_fraction must be in [0.0, 0.9)"
            )
        if self.context_chars_per_token < 1:
            raise ValueError("context_chars_per_token must be positive")
        reserved_context_chars = max(
            int(
                self.max_context_chars
                * self.reserved_context_fraction
            ),
            self.max_output_tokens * self.context_chars_per_token,
        )
        if self.max_context_chars - reserved_context_chars < 8_000:
            raise ValueError(
                "context settings leave less than 8000 request characters"
            )
        if self.max_compacted_tool_output_chars < 200:
            raise ValueError(
                "max_compacted_tool_output_chars must be at least 200"
            )
        if self.max_file_bytes < 1_000:
            raise ValueError("max_file_bytes must be at least 1000")
        if self.max_search_results < 1:
            raise ValueError("max_search_results must be positive")
        if self.max_glob_results < 1:
            raise ValueError("max_glob_results must be positive")
        if not self.repository_host.strip():
            raise ValueError("repository_host cannot be empty")
        if self.grounding_consistency_policy not in {"strict", "warn"}:
            raise ValueError(
                "grounding_consistency_policy must be strict or warn"
            )
        if self.worktree_gc_max_count_per_repo < 0:
            raise ValueError(
                "worktree_gc_max_count_per_repo cannot be negative"
            )
        if self.worktree_gc_max_age_days < 0:
            raise ValueError("worktree_gc_max_age_days cannot be negative")
        if self.worktree_gc_max_bytes_per_repo < 0:
            raise ValueError(
                "worktree_gc_max_bytes_per_repo cannot be negative"
            )
        for name, value in (
            ("max_issue_chars", self.max_issue_chars),
            ("max_patch_chars", self.max_patch_chars),
            ("max_analysis_chars", self.max_analysis_chars),
        ):
            if value < 1_000:
                raise ValueError(f"{name} must be at least 1000")

    def public_dict(self) -> dict[str, Any]:
        data = dataclasses.asdict(self)
        data.pop("api_key", None)
        data["repository_root"] = str(self.repository_root)
        data["worktree_root"] = str(self.worktree_root)
        return data


@dataclass(frozen=True)
class GroundedAnalysisInput:
    """Target-independent historical evidence for one grounded generation."""

    instance_id: str
    repo: str
    historical_issue_description: str
    historical_patch: str
    historical_candidate_fingerprint: str
    historical_patch_sha256: str
    historical_issue_number: int
    historical_issue_url: str
    historical_fix_commit: str
    changed_files: tuple[Mapping[str, Any], ...] = ()
    provenance: Mapping[str, Any] = field(default_factory=dict)
    grounding_preflight: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_candidate(
        cls, candidate: Mapping[str, Any]
    ) -> "GroundedAnalysisInput":
        base = LightGenerationInput.from_candidate(candidate)
        if base.historical_issue_number is None:
            raise ValueError(
                "grounded analysis requires historical_issue_number"
            )
        commit = str(base.historical_fix_commit or "").strip().lower()
        if not _SHA40_RE.fullmatch(commit):
            raise ValueError(
                "grounded analysis requires a full 40-character "
                "historical_fix_commit"
            )
        preflight = candidate.get("grounding_preflight")
        return cls(
            instance_id=base.instance_id,
            repo=base.repo,
            historical_issue_description=(
                base.historical_issue_description
            ),
            historical_patch=base.historical_patch,
            historical_candidate_fingerprint=(
                base.historical_candidate_fingerprint
            ),
            historical_patch_sha256=base.historical_patch_sha256,
            historical_issue_number=base.historical_issue_number,
            historical_issue_url=base.historical_issue_url,
            historical_fix_commit=commit,
            changed_files=base.changed_files,
            provenance=base.provenance,
            grounding_preflight=(
                dict(preflight) if isinstance(preflight, Mapping) else {}
            ),
        )


@dataclass(frozen=True)
class AgentToolCall:
    id: str
    name: str
    arguments: str

    def parsed_arguments(self) -> dict[str, Any]:
        try:
            value = json.loads(self.arguments or "{}")
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"tool arguments for {self.name!r} are not valid JSON"
            ) from exc
        if not isinstance(value, dict):
            raise ValueError(
                f"tool arguments for {self.name!r} must be a JSON object"
            )
        return value

    def to_openai_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": "function",
            "function": {
                "name": self.name,
                "arguments": self.arguments,
            },
        }


@dataclass(frozen=True)
class AgentCompletion:
    content: str
    model: str
    usage: Mapping[str, Any]
    tool_calls: tuple[AgentToolCall, ...] = ()


@dataclass(frozen=True)
class GroundedAnalysisResult:
    artifact_xml: str
    fine_grained_xml: str
    summary_xml: str
    calls: tuple[ModelCallStats, ...]
    worktree_path: str
    worktree_reused: bool
    grounding_validation: Mapping[str, Any] = field(default_factory=dict)
    worktree_post_verified: bool = False
    context_budget: Mapping[str, Any] = field(default_factory=dict)
    worktree_gc_removed_count: int = 0

    @property
    def total_latency_seconds(self) -> float:
        return sum(item.latency_seconds for item in self.calls)

    @property
    def total_cost_usd(self) -> float:
        return sum(item.cost_usd for item in self.calls)
