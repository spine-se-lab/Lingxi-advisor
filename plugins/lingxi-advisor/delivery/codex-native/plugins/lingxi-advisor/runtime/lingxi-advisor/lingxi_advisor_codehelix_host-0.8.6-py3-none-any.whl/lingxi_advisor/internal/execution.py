"""Request-scoped deadlines and cooperative cancellation across sync adapters."""
from __future__ import annotations

import asyncio
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from threading import Event
import time
from typing import Any, Callable, Iterator


class ExecutionFailure(RuntimeError):
    def __init__(self, code: str, message: str, *, retryable: bool = False):
        super().__init__(message)
        self.code = code
        self.retryable = retryable


@dataclass
class ExecutionBudget:
    deadline: float
    cancelled: Event = field(default_factory=Event)

    def check(self) -> float:
        if self.cancelled.is_set():
            raise ExecutionFailure('cancelled', 'LingxiAdvisor request was cancelled')
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise ExecutionFailure('deadline_exceeded', 'LingxiAdvisor request deadline exceeded', retryable=True)
        return remaining


_current: ContextVar[ExecutionBudget | None] = ContextVar('lingxi_advisor_execution', default=None)


@contextmanager
def execution_scope(timeout_seconds: float = 900.0, *, budget: ExecutionBudget | None = None) -> Iterator[ExecutionBudget]:
    if timeout_seconds <= 0:
        raise ValueError('execution timeout must be positive')
    parent = _current.get()
    value = budget or parent or ExecutionBudget(time.monotonic() + timeout_seconds)
    token = _current.set(value)
    try:
        value.check()
        yield value
    finally:
        _current.reset(token)


def checkpoint() -> None:
    value = _current.get()
    if value is not None:
        value.check()


def bounded_timeout(seconds: float) -> float:
    value = _current.get()
    return min(seconds, value.check()) if value is not None else seconds


def interruptible_sleep(seconds: float) -> None:
    value = _current.get()
    if value is None:
        time.sleep(seconds)
        return
    value.cancelled.wait(min(max(0, seconds), value.check()))
    value.check()


async def run_blocking(function: Callable[..., Any], *args: Any, timeout_seconds: float = 900.0, **kwargs: Any) -> Any:
    """Propagate cancellation to the worker; it may not publish after cancellation.

    A synchronous HTTP call already in flight exits at its bounded I/O timeout.
    Subsequent retries, lock waits and file publication observe the cancellation.
    """
    with execution_scope(timeout_seconds) as budget:
        task = asyncio.create_task(asyncio.to_thread(function, *args, **kwargs))
        try:
            done, _ = await asyncio.wait({task}, timeout=budget.check())
            if not done:
                raise ExecutionFailure('deadline_exceeded', 'LingxiAdvisor request deadline exceeded', retryable=True)
            return task.result()
        except (asyncio.CancelledError, ExecutionFailure):
            budget.cancelled.set()
            # Consume the worker's later failure without leaving an unobserved task.
            task.add_done_callback(lambda done: done.exception() if not done.cancelled() else None)
            raise


def failure_details(exc: BaseException) -> tuple[str, bool]:
    """Use typed failures/HTTP status, never classify by secret-bearing messages."""
    if isinstance(exc, ExecutionFailure):
        return exc.code, exc.retryable
    status = getattr(exc, 'status_code', None)
    if status in (401, 403):
        return 'authentication', False
    if status == 429:
        return 'rate_limited', True
    if isinstance(status, int):
        return ('remote_unavailable', True) if status >= 500 else ('invalid_request', False)
    import httpx
    if isinstance(exc, (TimeoutError, ConnectionError, httpx.TransportError)):
        return 'transport', True
    if isinstance(exc, (ValueError, TypeError, FileNotFoundError, PermissionError)):
        return 'invalid_input', False
    cause = exc.__cause__
    if cause is not None and cause is not exc:
        return failure_details(cause)
    return 'internal', False


@dataclass(frozen=True)
class FailureReport:
    code: str
    retryable: bool
    error: str

    @classmethod
    def from_exception(cls, exc: BaseException) -> "FailureReport":
        code, retryable = failure_details(exc)
        return cls(code, retryable, f"{type(exc).__name__} ({code})")


def bounded_execution(function: Callable[..., Any]) -> Callable[..., Any]:
    """Give direct synchronous callers the same default budget as MCP."""
    from functools import wraps
    @wraps(function)
    def run(*args: Any, **kwargs: Any) -> Any:
        with execution_scope():
            return function(*args, **kwargs)
    return run
