from __future__ import annotations

from .run_state import RunStatus

import dataclasses
import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Mapping, cast

GenerationMode = Literal["light", "grounded_analysis"]
GENERATION_MODES: tuple[GenerationMode, ...] = (
    "light",
    "grounded_analysis",
)
RESERVED_GENERATION_MODES = ("trajectory_analysis",)
GENERATION_SCHEMA_VERSION = 1


def _text(value: Any) -> str:
    return str(value or "").strip()


def validate_generation_mode(value: str) -> GenerationMode:
    mode = _text(value)
    if mode not in GENERATION_MODES:
        reserved_note = (
            f"; reserved for future use: {', '.join(RESERVED_GENERATION_MODES)}"
        )
        raise ValueError(
            "generation_mode must be one of: "
            + ", ".join(GENERATION_MODES)
            + reserved_note
        )
    return cast(GenerationMode, mode)


def knowledge_cache_key(
    *,
    candidate: Mapping[str, Any],
    generation_mode: str,
    template_version: str,
    generator_model: str,
    artifact_schema_version: int = GENERATION_SCHEMA_VERSION,
    target_conditioned: bool = False,
) -> str:
    """Return a readable, target-independent identity for a historical issue."""

    validate_generation_mode(generation_mode)
    repo = _text(candidate.get("repo") or candidate.get("instance_repo")).lower()
    issue_number = candidate.get("historical_issue_number")
    if not repo:
        raise ValueError("repository is required for reusable cache identity")
    if issue_number in (None, ""):
        raise ValueError(
            "historical_issue_number is required for reusable cache identity"
        )
    if not _text(template_version):
        raise ValueError("template_version is required")
    if not _text(generator_model):
        raise ValueError("generator_model is required")

    # Cache directories already isolate generation modes.  The artifact name
    # itself intentionally depends only on repository + historical issue ID so
    # later target instances selecting the same issue reuse the same file.
    del artifact_schema_version, target_conditioned
    repo_part = re.sub(r"[^a-z0-9._-]+", "__", repo).strip("._-")
    if not repo_part:
        raise ValueError("repository cannot be converted to a cache file name")
    return f"{repo_part}__issue_{int(issue_number)}"


@dataclass(frozen=True)
class GenerationRequest:
    input_jsonl: Path | None
    knowledge_cache_dir: Path
    output_root: Path
    generation_mode: GenerationMode
    template_version: str
    generator_model: str
    target_conditioned: bool = False
    resume: bool = True
    allow_clone: bool = False
    allow_fetch: bool = False
    repository_root: Path | None = None
    historical_worktree_root: Path | None = None
    runtime_options: Mapping[str, Any] = field(default_factory=dict)

    def validate(self, *, require_input: bool = True) -> None:
        validate_generation_mode(self.generation_mode)
        if self.target_conditioned:
            raise ValueError(
                "target-conditioned generation is disabled because the "
                "reusable cache identity is repository + historical issue"
            )
        if require_input and (self.input_jsonl is None or not self.input_jsonl.is_file()):
            raise FileNotFoundError(
                f"selected candidate JSONL does not exist: {self.input_jsonl}"
            )
        if not self.template_version.strip():
            raise ValueError("template_version cannot be empty")
        if not self.generator_model.strip():
            raise ValueError("generator_model cannot be empty")
        if not isinstance(self.runtime_options, Mapping):
            raise TypeError("runtime_options must be a mapping")

    def to_dict(self) -> dict[str, Any]:
        data = dataclasses.asdict(self)
        for key in (
            "input_jsonl",
            "knowledge_cache_dir",
            "output_root",
            "repository_root",
            "historical_worktree_root",
        ):
            if data[key] is None:
                continue
            data[key] = str(data[key])
        if not data["runtime_options"]:
            data.pop("runtime_options")
        return data


@dataclass
class GenerationManifestRow:
    instance_id: str
    historical_candidate_fingerprint: str
    generation_mode: str
    cache_hit: bool
    generation_status: str
    knowledge_cache_key: str
    knowledge_path: str | None
    cache_path: str | None = None
    knowledge_sha256: str | None = None
    template_version: str | None = None
    generator_model: str | None = None
    artifact_schema_version: int = GENERATION_SCHEMA_VERSION
    target_conditioned: bool = False
    worktree_path: str | None = None
    worktree_reused: bool | None = None
    repository_identity_verified: bool | None = None
    grounding_validation: dict[str, Any] | None = None
    worktree_post_verified: bool | None = None
    context_budget: dict[str, Any] = field(default_factory=dict)
    worktree_gc_removed_count: int = 0
    model_calls: list[dict[str, Any]] = field(default_factory=list)
    latency_seconds: float = 0.0
    cost_usd: float = 0.0
    error: str | None = None
    error_code: str | None = None
    retryable: bool = False

    def to_dict(self) -> dict[str, Any]:
        data = dataclasses.asdict(self)
        if self.generation_mode != "grounded_analysis":
            for key in (
                "repository_identity_verified",
                "grounding_validation",
                "worktree_post_verified",
                "context_budget",
                "worktree_gc_removed_count",
            ):
                data.pop(key, None)
        return data


@dataclass
class GenerationResult:
    schema_version: int
    request_id: str
    status: RunStatus | str
    generation_mode: str
    selected_count: int
    completed_count: int
    cache_hit_count: int
    generated_count: int
    failed_count: int
    manifest_rows: list[dict[str, Any]] = field(default_factory=list)
    output_dir: str | None = None
    error: str | None = None

    def __post_init__(self) -> None:
        self.status = RunStatus(self.status)

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


def generation_request_id(
    request: GenerationRequest, candidates: list[Mapping[str, Any]]
) -> str:
    payload = {
        "generation_mode": request.generation_mode,
        "template_version": request.template_version,
        "generator_model": request.generator_model,
        "artifact_schema_version": GENERATION_SCHEMA_VERSION,
        "target_conditioned": request.target_conditioned,
        "allow_clone": request.allow_clone,
        "allow_fetch": request.allow_fetch,
        "repository_root": (
            str(request.repository_root)
            if request.repository_root is not None
            else None
        ),
        "historical_worktree_root": (
            str(request.historical_worktree_root)
            if request.historical_worktree_root is not None
            else None
        ),
        "candidates": [
            {
                "instance_id": _text(row.get("instance_id")),
                "historical_candidate_fingerprint": _text(
                    row.get("historical_candidate_fingerprint")
                ),
                "historical_patch_sha256": _text(
                    row.get("historical_patch_sha256")
                ),
            }
            for row in candidates
        ],
    }
    if request.runtime_options:
        payload["runtime_options"] = dict(request.runtime_options)
    return hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()[:24]
