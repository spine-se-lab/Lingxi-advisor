from __future__ import annotations

import datetime as dt
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..command_runner import CommandResult, RestrictedSubprocessRunner
from ..io_utils import (
    read_json,
    safe_part,
    write_json_atomic,
    write_jsonl_atomic,
    read_jsonl,
)
from ..locking import FileLock
from .. import github as v4

logger = logging.getLogger(__name__)
DEFAULT_GIT_TIMEOUT_SECONDS = 1_800.0


def _require_git_success(result: CommandResult, *, operation: str) -> None:
    if result.returncode == 0:
        return
    detail = result.stderr_text().strip()
    if len(detail) > 2_000:
        detail = detail[:2_000] + "...[truncated]"
    suffix = f": {detail}" if detail else ""
    raise RuntimeError(f"{operation} failed with exit code {result.returncode}{suffix}")


@dataclass(frozen=True)
class CommitClosingMatch:
    sha: str
    commit_date: str
    message: str


class RepositoryProvider:
    """Server-owned clone cache used only for 02-style commit-message fallback."""

    def __init__(
        self,
        repository_root: Path,
        cache_root: Path,
        *,
        runner: RestrictedSubprocessRunner | None = None,
        git_timeout_seconds: float = DEFAULT_GIT_TIMEOUT_SECONDS,
    ):
        if git_timeout_seconds <= 0:
            raise ValueError("git_timeout_seconds must be positive")
        self.repository_root = repository_root
        self.cache_root = cache_root
        self.git_timeout_seconds = git_timeout_seconds
        self._runner = runner

    def _command_runner(self) -> RestrictedSubprocessRunner:
        if self._runner is None:
            self._runner = RestrictedSubprocessRunner(
                allowed_executables=("git",),
                read_only=False,
            )
        return self._runner

    def repo_path(self, repo: str) -> Path:
        owner, name = repo.split("/", 1)
        return self.repository_root / f"{safe_part(owner)}__{safe_part(name)}"

    def ensure_repository(self, repo: str, *, refresh: bool = False) -> Path:
        path = self.repo_path(repo)
        lock = self.repository_root / ".locks" / f"{safe_part(repo)}.lock"
        with FileLock(lock):
            if not (path / ".git").exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                url = f"https://github.com/{repo}.git"
                logger.info(
                    "Cloning repository metadata for commit-message fallback: %s", repo
                )
                result = self._command_runner().run(
                    [
                        "git",
                        "clone",
                        "--filter=blob:none",
                        "--no-checkout",
                        url,
                        str(path),
                    ],
                    timeout_seconds=self.git_timeout_seconds,
                )
                _require_git_success(
                    result,
                    operation=f"repository metadata clone for {repo}",
                )
            elif refresh:
                logger.info("Refreshing repository metadata for %s", repo)
                result = self._command_runner().run(
                    ["git", "-C", str(path), "fetch", "--all", "--prune"],
                    timeout_seconds=self.git_timeout_seconds,
                )
                _require_git_success(
                    result,
                    operation=f"repository metadata refresh for {repo}",
                )
        return path


class CommitClosingIndex:
    """One scan per repository, rather than one full git-log scan per issue."""

    SCHEMA_VERSION = 1

    def __init__(
        self,
        cache_root: Path,
        repository_provider: RepositoryProvider,
        *,
        runner: RestrictedSubprocessRunner | None = None,
        git_timeout_seconds: float = DEFAULT_GIT_TIMEOUT_SECONDS,
    ):
        if git_timeout_seconds <= 0:
            raise ValueError("git_timeout_seconds must be positive")
        self.cache_root = cache_root
        self.repository_provider = repository_provider
        self.git_timeout_seconds = git_timeout_seconds
        self._runner = runner

    def _command_runner(self) -> RestrictedSubprocessRunner:
        if self._runner is None:
            self._runner = RestrictedSubprocessRunner(
                allowed_executables=("git",),
                read_only=True,
                preserve_git_transport_config=False,
            )
        return self._runner

    def _repo_dir(self, repo: str) -> Path:
        owner, name = repo.split("/", 1)
        return (
            self.cache_root
            / "commit_closing_index"
            / f"{safe_part(owner)}__{safe_part(name)}"
        )

    def _head_fingerprint(self, repo_path: Path) -> str:
        result = self._command_runner().run(
            [
                "git",
                "-C",
                str(repo_path),
                "for-each-ref",
                "--format=%(refname):%(objectname)",
                "refs/remotes",
                "refs/heads",
                "refs/tags",
            ],
            timeout_seconds=self.git_timeout_seconds,
        )
        _require_git_success(result, operation="repository fingerprint")
        import hashlib

        return hashlib.sha256(result.stdout_text().encode("utf-8")).hexdigest()

    def _build(self, repo: str, repo_path: Path) -> tuple[list[dict[str, Any]], str]:
        delimiter_record = "\x1e"
        delimiter_field = "\x1f"
        fmt = "%H%x1f%cI%x1f%B%x1e"
        result = self._command_runner().run(
            [
                "git",
                "-C",
                str(repo_path),
                "log",
                "--all",
                "--date-order",
                f"--pretty=format:{fmt}",
            ],
            timeout_seconds=self.git_timeout_seconds,
        )
        _require_git_success(result, operation="commit closing-keyword index")
        rows: list[dict[str, Any]] = []
        for raw_record in result.stdout_text().split(delimiter_record):
            raw_record = raw_record.strip()
            if not raw_record:
                continue
            parts = raw_record.split(delimiter_field, 2)
            if len(parts) != 3:
                continue
            sha, commit_date, message = parts
            issue_numbers = sorted(v4.extract_closing_issue_numbers(message, repo=repo))
            if not issue_numbers:
                continue
            rows.append(
                {
                    "sha": sha.strip(),
                    "commit_date": commit_date.strip(),
                    "message": message.strip(),
                    "issue_numbers": issue_numbers,
                }
            )
        return rows, self._head_fingerprint(repo_path)

    def load_matches(
        self,
        repo: str,
        *,
        refresh_repository: bool = False,
    ) -> dict[int, list[CommitClosingMatch]]:
        repo_dir = self._repo_dir(repo)
        rows_path = repo_dir / "matches.jsonl"
        meta_path = repo_dir / "index_state.json"
        lock_path = repo_dir / ".index.lock"
        repo_dir.mkdir(parents=True, exist_ok=True)

        def read_published_cache() -> list[dict[str, Any]] | None:
            meta = read_json(meta_path)
            if (
                not rows_path.exists()
                or meta is None
                or meta.get("schema_version") != self.SCHEMA_VERSION
                or meta.get("repo") != repo
                or not meta.get("repository_fingerprint")
            ):
                return None
            return read_jsonl(rows_path)

        # RepositoryProvider owns this clone and mutates it only for an
        # explicit refresh. A published immutable index therefore needs no Git
        # fingerprint probe on the normal hot path. Besides avoiding needless
        # processes, this makes the first full-repository scan the only
        # expensive run for subsequent issues in the same repository.
        rows = None if refresh_repository else read_published_cache()
        if rows is None:
            repo_path = self.repository_provider.ensure_repository(
                repo,
                refresh=refresh_repository,
            )
            with FileLock(lock_path):
                # Another process may have published the same index while this
                # caller was ensuring the repository.
                if not refresh_repository:
                    rows = read_published_cache()
                if rows is not None:
                    current_fingerprint = None
                else:
                    current_fingerprint = self._head_fingerprint(repo_path)
                meta = read_json(meta_path)
                use_cache = (
                    rows is None
                    and rows_path.exists()
                    and meta is not None
                    and meta.get("schema_version") == self.SCHEMA_VERSION
                    and meta.get("repo") == repo
                    and meta.get("repository_fingerprint") == current_fingerprint
                )
                if use_cache:
                    rows = read_jsonl(rows_path)
                elif rows is None:
                    logger.info("Building commit closing-keyword index for %s", repo)
                    rows, fingerprint = self._build(repo, repo_path)
                    write_jsonl_atomic(rows_path, rows)
                    write_json_atomic(
                        meta_path,
                        {
                            "schema_version": self.SCHEMA_VERSION,
                            "repo": repo,
                            "repository_fingerprint": fingerprint,
                            "built_at": v4.isoformat_utc(
                                dt.datetime.now(dt.timezone.utc)
                            ),
                            "match_rows": len(rows),
                        },
                    )

        result: dict[int, list[CommitClosingMatch]] = {}
        for row in rows:
            sha = str(row.get("sha") or "").strip()
            if not sha:
                continue
            match = CommitClosingMatch(
                sha=sha,
                commit_date=str(row.get("commit_date") or ""),
                message=str(row.get("message") or ""),
            )
            for number in row.get("issue_numbers") or []:
                try:
                    issue_number = int(number)
                except (TypeError, ValueError):
                    continue
                result.setdefault(issue_number, []).append(match)
        return result
