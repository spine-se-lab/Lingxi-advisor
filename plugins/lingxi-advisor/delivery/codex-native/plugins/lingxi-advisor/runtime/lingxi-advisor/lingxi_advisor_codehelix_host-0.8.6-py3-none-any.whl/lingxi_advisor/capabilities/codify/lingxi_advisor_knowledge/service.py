from __future__ import annotations

from typing import Callable, Protocol, Sequence

from ....artifacts.interface import (
    KnowledgeArtifact,
    KnowledgeArtifactRef,
    KnowledgeArtifactStore,
)
from ....internal.generation_contracts import (
    GenerationMode,
    GenerationRequest,
    GenerationResult,
    knowledge_cache_key,
    validate_generation_mode,
)
from ....internal.light_generation.contracts import LightGenerationInput
from ....internal.preparation_contracts import (
    PreparationRequest,
    PreparationResult,
)
from .contracts import CodifyEnsureSettings, HistoricalCandidate


class PreparationRunner(Protocol):
    def run(self, request: PreparationRequest) -> PreparationResult: ...


class GenerationRunner(Protocol):
    def run_candidates(
        self, request: GenerationRequest, candidates: Sequence[HistoricalCandidate]
    ) -> GenerationResult: ...


GenerationRunnerFactory = Callable[[GenerationMode], GenerationRunner]


def artifact_ref_for_candidate(
    candidate: HistoricalCandidate,
    *,
    generation_mode: GenerationMode,
    template_version: str,
    generator_model: str,
) -> KnowledgeArtifactRef:
    """Derive the existing target-independent cache identity."""

    return KnowledgeArtifactRef(
        generation_mode=generation_mode,
        knowledge_cache_key=knowledge_cache_key(
            candidate=candidate,
            generation_mode=generation_mode,
            template_version=template_version,
            generator_model=generator_model,
            target_conditioned=False,
        ),
    )


class LingxiAdvisorCodify:
    """Canonical Codify capability over the existing preparation/generation."""

    def __init__(
        self,
        *,
        preparation_service: PreparationRunner | None,
        artifact_store: KnowledgeArtifactStore,
        generation_service_factory: GenerationRunnerFactory,
        ensure_settings: CodifyEnsureSettings,
    ) -> None:
        self._preparation_service = preparation_service
        self.artifact_store = artifact_store
        self._generation_service_factory = generation_service_factory
        self.ensure_settings = ensure_settings

    def prepare(
        self,
        request: PreparationRequest,
    ) -> PreparationResult:
        if self._preparation_service is None:
            raise RuntimeError("Codify preparation service is not configured")
        return self._preparation_service.run(request)

    def ref_for_candidate(
        self,
        candidate: HistoricalCandidate,
        *,
        generation_mode: GenerationMode,
    ) -> KnowledgeArtifactRef:
        mode = validate_generation_mode(generation_mode)
        return artifact_ref_for_candidate(
            candidate,
            generation_mode=mode,
            template_version=self.ensure_settings.template_version(mode),
            generator_model=self.ensure_settings.generator_model,
        )

    def artifact_is_current(
        self,
        candidate: HistoricalCandidate,
        artifact: KnowledgeArtifact,
        *,
        generation_mode: GenerationMode,
    ) -> bool:
        """Validate one cached artifact against current Codify provenance.

        The stable artifact ref intentionally remains repository + historical
        issue within a generation-mode directory so different target tasks can
        reuse it.  Reuse is allowed only when the selected historical evidence
        and the active generation configuration still match the manifest.
        """

        mode = validate_generation_mode(generation_mode)
        expected_ref = self.ref_for_candidate(
            candidate,
            generation_mode=mode,
        )
        generation_input = LightGenerationInput.from_candidate(candidate)
        return bool(
            artifact.ref == expected_ref
            and artifact.historical_candidate_fingerprint
            == generation_input.historical_candidate_fingerprint
            and artifact.historical_patch_sha256
            == generation_input.historical_patch_sha256
            and artifact.template_version
            == self.ensure_settings.template_version(mode)
            and artifact.generator_model
            == self.ensure_settings.generator_model
            and artifact.target_conditioned is False
        )

    def current_artifact_ref(
        self,
        candidate: HistoricalCandidate,
        *,
        generation_mode: GenerationMode,
    ) -> KnowledgeArtifactRef | None:
        """Return the ref only when its XML and full provenance are current."""

        ref = self.ref_for_candidate(
            candidate,
            generation_mode=generation_mode,
        )
        found = self.artifact_store.lookup(
            generation_mode=ref.generation_mode,
            knowledge_cache_key=ref.knowledge_cache_key,
        )
        if found is None:
            return None
        artifact = self.artifact_store.read(found)
        return (
            found
            if self.artifact_is_current(
                candidate,
                artifact,
                generation_mode=generation_mode,
            )
            else None
        )

    def ensure(
        self,
        candidates: Sequence[HistoricalCandidate],
        *,
        generation_mode: GenerationMode,
        resume: bool = True,
    ) -> Sequence[KnowledgeArtifactRef]:
        """Generate only missing artifacts for already-selected candidates."""

        mode = validate_generation_mode(generation_mode)
        ordered: list[
            tuple[KnowledgeArtifactRef, HistoricalCandidate]
        ] = []
        seen: set[tuple[str, str]] = set()
        for candidate in candidates:
            ref = self.ref_for_candidate(
                candidate,
                generation_mode=mode,
            )
            identity = (ref.generation_mode, ref.knowledge_cache_key)
            if identity in seen:
                continue
            seen.add(identity)
            ordered.append((ref, candidate))

        missing = [
            (ref, candidate)
            for ref, candidate in ordered
            if self.current_artifact_ref(
                candidate,
                generation_mode=mode,
            ) is None
        ]
        if missing:
            request = GenerationRequest(
                input_jsonl=None,
                knowledge_cache_dir=(
                    self.ensure_settings.knowledge_cache_dir
                ),
                output_root=self.ensure_settings.output_root,
                generation_mode=mode,
                template_version=(
                    self.ensure_settings.template_version(mode)
                ),
                generator_model=self.ensure_settings.generator_model,
                target_conditioned=False,
                resume=resume,
                allow_clone=(
                    self.ensure_settings.allow_clone
                    if mode == "grounded_analysis"
                    else False
                ),
                allow_fetch=(
                    self.ensure_settings.allow_fetch
                    if mode == "grounded_analysis"
                    else False
                ),
                repository_root=(
                    self.ensure_settings.repository_root
                    if mode == "grounded_analysis"
                    else None
                ),
                historical_worktree_root=(
                    self.ensure_settings.historical_worktree_root
                    if mode == "grounded_analysis"
                    else None
                ),
                runtime_options=dict(
                    self.ensure_settings.runtime_options.get(mode, {})
                ),
            )
            self._generation_service_factory(mode).run_candidates(
                request, [candidate for _ref, candidate in missing]
            )

        return [
            found
            for _ref, candidate in ordered
            if (
                found := self.current_artifact_ref(
                    candidate,
                    generation_mode=mode,
                )
            )
            is not None
        ]



__all__ = [
    "LingxiAdvisorCodify",
    "artifact_ref_for_candidate",
]
