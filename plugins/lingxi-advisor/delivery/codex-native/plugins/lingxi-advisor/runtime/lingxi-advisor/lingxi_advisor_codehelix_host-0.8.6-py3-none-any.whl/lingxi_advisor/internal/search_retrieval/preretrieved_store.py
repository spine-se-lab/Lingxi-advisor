from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from ..io_utils import read_jsonl, safe_part, write_json_atomic, write_jsonl_atomic
from ..locking import FileLock
from .candidate_schema import (
    canonical_candidate_row,
    candidate_fingerprint,
    candidate_repo,
    historical_issue_description,
    historical_patch,
    row_is_invalidated,
)
from .contracts import SWEbenchProInstance
from .. import github as v4

@dataclass(frozen=True)
class PreretrievedMatch:
    row: dict[str, Any]
    source_path: Path
    source_line: int


class PreretrievedStore:
    """Directory-backed pre-retrieved historical candidate store."""

    def __init__(self, root: Path):
        self.root = root.expanduser().resolve()

    def _jsonl_paths(self) -> list[Path]:
        if not self.root.exists():
            return []
        if self.root.is_file() and self.root.suffix == ".jsonl":
            return [self.root]
        paths = sorted(
            path
            for path in self.root.glob("*.jsonl")
            if path.is_file() and not path.name.startswith(".")
        )
        manifest_path = self.root / "manifest.json"
        if manifest_path.is_file():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                manifest = {}
            manifest_files = manifest.get("files")
            if isinstance(manifest_files, list):
                ordered: list[Path] = []
                seen: set[Path] = set()
                for item in manifest_files:
                    if not isinstance(item, str) or not item.strip():
                        continue
                    path = (self.root / item).resolve()
                    if path.is_file() and path.suffix == ".jsonl" and path not in seen:
                        ordered.append(path)
                        seen.add(path)
                for path in paths:
                    if path not in seen:
                        ordered.append(path)
                return ordered
        return paths

    def find(self, instance: SWEbenchProInstance) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        matches: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []
        for path in self._jsonl_paths():
            with path.open("r", encoding="utf-8") as handle:
                for line_no, raw_line in enumerate(handle, start=1):
                    line = raw_line.strip()
                    if not line:
                        continue
                    try:
                        raw = json.loads(line)
                    except json.JSONDecodeError as exc:
                        raise ValueError(
                            f"Invalid JSON in pre-retrieved store {path} at line {line_no}: {exc}"
                        ) from exc
                    if not isinstance(raw, dict):
                        rejected.append(
                            {
                                "retrieval_source": "preretrieved",
                                "source_path": str(path),
                                "source_line": line_no,
                                "reason": "row_is_not_json_object",
                            }
                        )
                        continue
                    if str(raw.get("instance_id") or "").strip() != instance.instance_id:
                        continue
                    reason = self._reject_reason(raw, instance)
                    if reason:
                        rejected.append(
                            {
                                "retrieval_source": "preretrieved",
                                "source_path": str(path),
                                "source_line": line_no,
                                "reason": reason,
                                "row": raw,
                            }
                        )
                        continue
                    matches.append(
                        canonical_candidate_row(
                            raw,
                            instance=instance,
                            retrieval_source="preretrieved",
                            retrieval_rank=len(matches) + 1,
                            source_path=str(path),
                        )
                    )
        return matches, rejected

    def find_portable(
        self,
        *,
        issue_description: str,
        context: Mapping[str, Any],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Find already-approved rows without requiring SWE-bench fields.

        This path never performs live retrieval or weak text similarity.  It
        requires an exact target identifier or exact normalized issue text and
        honors any repository supplied by the runtime context.
        """

        expected_issue = " ".join(str(issue_description or "").split())
        expected_instance = str(
            context.get("instance_id") or context.get("issue_id") or ""
        ).strip()
        expected_repo = str(context.get("repo") or "").strip().strip("/")
        matches: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []
        for path in self._jsonl_paths():
            with path.open("r", encoding="utf-8") as handle:
                for line_no, raw_line in enumerate(handle, start=1):
                    line = raw_line.strip()
                    if not line:
                        continue
                    try:
                        raw = json.loads(line)
                    except json.JSONDecodeError as exc:
                        raise ValueError(
                            f"Invalid JSON in pre-retrieved store {path} "
                            f"at line {line_no}: {exc}"
                        ) from exc
                    if not isinstance(raw, dict):
                        continue
                    row_instance = str(raw.get("instance_id") or "").strip()
                    row_issue = " ".join(
                        str(
                            raw.get("problem_statement")
                            or raw.get("issue_description")
                            or ""
                        ).split()
                    )
                    identity_matches = bool(
                        (expected_instance and row_instance == expected_instance)
                        or (expected_issue and row_issue == expected_issue)
                    )
                    if not identity_matches:
                        continue
                    row_repo = candidate_repo(raw)
                    if expected_repo and not v4.same_repository(
                        row_repo, expected_repo
                    ):
                        continue
                    decision = str(
                        raw.get("llm_gate_decision") or ""
                    ).strip().lower()
                    approved = bool(
                        raw.get("selected") is True
                        or decision
                        in {"selected", "llm_selected", "preselected"}
                        or raw.get("preretrieved_store_schema_version") == 1
                    )
                    if not approved:
                        rejected.append(
                            {
                                "retrieval_source": "preretrieved",
                                "source_path": str(path),
                                "source_line": line_no,
                                "reason": "candidate_not_approved",
                            }
                        )
                        continue
                    if row_is_invalidated(raw):
                        continue
                    if not historical_issue_description(raw) or not historical_patch(raw):
                        continue
                    payload = dict(raw)
                    payload.setdefault("retrieval_source", "preretrieved")
                    payload["preretrieved_source_path"] = str(path)
                    payload["preretrieved_source_line"] = line_no
                    matches.append(payload)
        return matches, rejected

    @staticmethod
    def _reject_reason(row: Mapping[str, Any], instance: SWEbenchProInstance) -> str | None:
        if row_is_invalidated(row):
            return "candidate_marked_invalid_or_superseded"
        repo = candidate_repo(row, instance)
        if not v4.same_repository(repo, instance.repo):
            return "historical_candidate_repo_mismatch"
        if not historical_issue_description(row):
            return "historical_issue_description_missing"
        if not historical_patch(row):
            return "historical_patch_missing"
        return None

    @staticmethod
    def _dedupe_key(row: Mapping[str, Any], instance: SWEbenchProInstance) -> str:
        return "|".join(
            [
                instance.instance_id,
                candidate_repo(row, instance),
                str(row.get("historical_issue_number") or ""),
                str(candidate_fingerprint(row, instance)),
            ]
        )

    def append_selected(
        self,
        *,
        instance: SWEbenchProInstance,
        rows: Iterable[Mapping[str, Any]],
        source_run_id: str,
        target_filename: str = "live_selected.jsonl",
    ) -> dict[str, Any]:
        self.root.mkdir(parents=True, exist_ok=True)
        target = self.root / target_filename
        lock_path = self.root / ".locks" / f"{safe_part(target_filename)}.lock"
        with FileLock(lock_path):
            existing = read_jsonl(target) if target.is_file() else []
            seen = {
                self._dedupe_key(row, instance)
                for row in existing
                if isinstance(row, Mapping)
            }
            appended: list[dict[str, Any]] = []
            now = dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")
            for row in rows:
                key = self._dedupe_key(row, instance)
                if key in seen:
                    continue
                payload = dict(row)
                payload["preretrieved_written_at"] = now
                payload["preretrieved_source_run_id"] = source_run_id
                payload["preretrieved_store_schema_version"] = 1
                appended.append(payload)
                seen.add(key)
            if appended:
                write_jsonl_atomic(target, [*existing, *appended])
            self._write_manifest()
        return {
            "target_path": str(target),
            "existing_rows": len(existing),
            "appended_rows": len(appended),
        }

    def _write_manifest(self) -> None:
        files = [path.name for path in self._jsonl_paths()]
        write_json_atomic(
            self.root / "manifest.json",
            {
                "schema_version": 1,
                "updated_at": dt.datetime.now(dt.timezone.utc)
                .isoformat()
                .replace("+00:00", "Z"),
                "files": files,
            },
        )
