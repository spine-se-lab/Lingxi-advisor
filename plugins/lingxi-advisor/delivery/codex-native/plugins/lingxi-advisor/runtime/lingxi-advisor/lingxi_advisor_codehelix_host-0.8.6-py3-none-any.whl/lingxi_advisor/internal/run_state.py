"""Validated terminal outcomes shared by generation and preparation runs."""
from enum import Enum


class RunStatus(str, Enum):
    COMPLETED = 'completed'
    PARTIAL = 'partial'
    NO_CANDIDATES = 'no_candidates'
    FAILED = 'failed'

    def __str__(self) -> str:
        return self.value

    @classmethod
    def from_counts(cls, *, selected: int, completed: int) -> 'RunStatus':
        if selected < 0 or not 0 <= completed <= selected:
            raise ValueError('invalid run completion counts')
        if selected == 0:
            return cls.NO_CANDIDATES
        if completed == selected:
            return cls.COMPLETED
        return cls.PARTIAL if completed else cls.FAILED
