from __future__ import annotations

import ssl
from typing import Any


def httpx_verify(verify_ssl: bool) -> Any:
    """Return an HTTPX verify value backed by the operating-system trust."""

    if not verify_ssl:
        return False
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = True
    context.verify_mode = ssl.CERT_REQUIRED
    context.load_default_certs()
    return context


__all__ = ["httpx_verify"]
