"""Validated item transitions; the batch manifest is the durable authority."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any, Mapping


class ItemStatus(str, Enum):
    PENDING = 'pending'
    RUNNING = 'running'
    COMPLETED = 'completed'
    PARTIAL = 'partial'
    NO_CANDIDATES = 'no_candidates'
    FAILED = 'failed'


FINAL_STATUSES = frozenset({ItemStatus.COMPLETED, ItemStatus.PARTIAL, ItemStatus.NO_CANDIDATES, ItemStatus.FAILED})


@dataclass(frozen=True)
class BatchItemState:
    status: ItemStatus
    attempts: int

    @classmethod
    def read(cls, item: Mapping[str, Any]) -> 'BatchItemState':
        state = cls(ItemStatus(item['status']), int(item.get('attempts') or 0))
        if state.attempts < 0:
            raise ValueError('batch attempts cannot be negative')
        return state

    def start(self) -> 'BatchItemState':
        if self.status not in {ItemStatus.PENDING, ItemStatus.FAILED}:
            raise ValueError(f'cannot start batch item in {self.status.value} state')
        return BatchItemState(ItemStatus.RUNNING, self.attempts + 1)

    def finish(self, status: str) -> 'BatchItemState':
        target = ItemStatus(status)
        if self.status != ItemStatus.RUNNING or target not in FINAL_STATUSES:
            raise ValueError('batch result requires a running item and a final status')
        return BatchItemState(target, self.attempts)

    def apply(self, item: dict[str, Any]) -> None:
        item.update(status=self.status.value, attempts=self.attempts)
