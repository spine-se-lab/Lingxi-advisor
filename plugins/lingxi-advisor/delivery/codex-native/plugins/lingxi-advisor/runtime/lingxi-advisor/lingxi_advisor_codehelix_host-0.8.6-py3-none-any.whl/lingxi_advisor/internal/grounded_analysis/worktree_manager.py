from __future__ import annotations

import dataclasses
import logging
import os
import re
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator
from urllib.parse import urlsplit

from ..io_utils import safe_part
from ..locking import FileLock
from .command_runner import RestrictedSubprocessRunner

logger = logging.getLogger(__name__)

_REPO_RE = re.compile(
    r"^[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,99})/"
    r"[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,99})$"
)
_SHA40_RE = re.compile(r"^[0-9a-f]{40}$")


class WorktreeUnavailableError(RuntimeError):
    pass


class WorktreeValidationError(RuntimeError):
    pass


@dataclass(frozen=True)
class WorktreeHandle:
    repo: str
    checkout_commit: str
    checkout_state: str
    repository_path: str
    worktree_path: str
    reused: bool
    repository_origin: str | None = None
    repository_identity_verified: bool = False

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass(frozen=True)
class WorktreeGCResult:
    removed_paths: tuple[str, ...] = ()
    reclaimed_bytes: int = 0
    skipped_busy_count: int = 0
    skipped_unsafe_count: int = 0

    @property
    def removed_count(self) -> int:
        return len(self.removed_paths)

    def to_dict(self) -> dict[str, Any]:
        data = dataclasses.asdict(self)
        data["removed_count"] = self.removed_count
        return data


@dataclass(frozen=True)
class _RegisteredWorktree:
    path: Path
    head: str | None


@dataclass(frozen=True)
class _GCItem:
    path: Path
    commit: str
    last_used: float
    size_bytes: int


class HistoricalWorktreeManager:
    """Restore, lease, verify, and optionally GC detached post-fix worktrees."""

    def __init__(
        self,
        *,
        repository_root: Path,
        worktree_root: Path,
        allow_clone: bool = False,
        allow_fetch: bool = False,
        git_timeout_seconds: float = 300.0,
        repository_host: str = "github.com",
        verify_repository_identity: bool = True,
        gc_max_count_per_repo: int = 0,
        gc_max_age_days: float = 0.0,
        gc_max_bytes_per_repo: int = 0,
        runner: RestrictedSubprocessRunner | None = None,
        read_runner: RestrictedSubprocessRunner | None = None,
    ) -> None:
        self.repository_root = self._prepare_root(repository_root)
        self.worktree_root = self._prepare_root(worktree_root)
        self.allow_clone = allow_clone
        self.allow_fetch = allow_fetch
        self.git_timeout_seconds = git_timeout_seconds
        self.repository_host = str(repository_host or "").strip().lower()
        self.verify_repository_identity = verify_repository_identity
        self.gc_max_count_per_repo = int(gc_max_count_per_repo)
        self.gc_max_age_days = float(gc_max_age_days)
        self.gc_max_bytes_per_repo = int(gc_max_bytes_per_repo)
        if not self.repository_host:
            raise ValueError("repository_host cannot be empty")
        if self.git_timeout_seconds <= 0:
            raise ValueError("git_timeout_seconds must be positive")
        if self.gc_max_count_per_repo < 0:
            raise ValueError("gc_max_count_per_repo cannot be negative")
        if self.gc_max_age_days < 0:
            raise ValueError("gc_max_age_days cannot be negative")
        if self.gc_max_bytes_per_repo < 0:
            raise ValueError("gc_max_bytes_per_repo cannot be negative")
        self._runner = runner or RestrictedSubprocessRunner(
            allowed_executables=("git",),
            read_only=False,
            allow_git_lazy_fetch=allow_fetch,
            preserve_git_transport_config=(allow_clone or allow_fetch),
        )
        self._read_runner = read_runner or RestrictedSubprocessRunner(
            allowed_executables=("git",),
            read_only=True,
            preserve_git_transport_config=False,
        )

    @staticmethod
    def _prepare_root(path: Path) -> Path:
        expanded = path.expanduser()
        if expanded.exists() and expanded.is_symlink():
            raise WorktreeValidationError(
                f"managed cache root cannot be a symlink: {expanded}"
            )
        expanded.mkdir(parents=True, exist_ok=True)
        resolved = expanded.resolve()
        if not resolved.is_dir():
            raise WorktreeValidationError(
                f"managed cache root is not a directory: {resolved}"
            )
        return resolved

    @staticmethod
    def _validate_repo(repo: str) -> str:
        normalized_repo = str(repo or "").strip().strip("/")
        if not _REPO_RE.fullmatch(normalized_repo):
            raise ValueError("repository must be a safe GitHub owner/name identifier")
        return normalized_repo

    @classmethod
    def _validate_identity(cls, repo: str, commit: str) -> tuple[str, str]:
        normalized_repo = cls._validate_repo(repo)
        normalized_commit = str(commit or "").strip().lower()
        if not _SHA40_RE.fullmatch(normalized_commit):
            raise ValueError("historical fix commit must be a 40-character SHA")
        return normalized_repo, normalized_commit

    @staticmethod
    def _validate_evidence_commits(
        commits: tuple[str, ...],
        *,
        checkout_commit: str,
    ) -> tuple[str, ...]:
        if len(commits) > 100:
            raise ValueError("at most 100 evidence commits may be prepared")
        normalized = tuple(str(item or "").strip().lower() for item in commits)
        if any(not _SHA40_RE.fullmatch(item) for item in normalized):
            raise ValueError("evidence commits must be full 40-character SHAs")
        return tuple(
            dict.fromkeys(item for item in normalized if item != checkout_commit)
        )

    @staticmethod
    def _repo_part(repo: str) -> str:
        owner, name = repo.split("/", 1)
        return f"{safe_part(owner)}__{safe_part(name)}"

    @staticmethod
    def _is_relative_to(path: Path, root: Path) -> bool:
        try:
            path.relative_to(root)
        except ValueError:
            return False
        return True

    def _safe_child(self, root: Path, *parts: str) -> Path:
        current = root
        for part in parts:
            if not part or part in {".", ".."} or "/" in part or "\\" in part:
                raise WorktreeValidationError(
                    f"unsafe managed path component: {part!r}"
                )
            current = current / part
            if current.is_symlink():
                raise WorktreeValidationError(
                    f"managed cache path contains a symlink: {current}"
                )
            if current.exists():
                resolved = current.resolve()
                if not self._is_relative_to(resolved, root):
                    raise WorktreeValidationError(
                        "managed cache path escapes its configured root"
                    )
        return current

    def _assert_managed_path(
        self,
        path: Path,
        *,
        root: Path,
        allow_missing: bool,
    ) -> Path:
        try:
            relative = path.relative_to(root)
        except ValueError as exc:
            raise WorktreeValidationError(
                f"managed path is outside configured root: {path}"
            ) from exc
        current = root
        for part in relative.parts:
            current = current / part
            if current.is_symlink():
                raise WorktreeValidationError(
                    f"managed path contains a symlink: {current}"
                )
            if not current.exists():
                if allow_missing:
                    continue
                raise WorktreeValidationError(f"managed path is missing: {current}")
            resolved = current.resolve()
            if not self._is_relative_to(resolved, root):
                raise WorktreeValidationError(
                    f"managed path escapes configured root: {current}"
                )
        return path

    def _safe_mkdir(self, path: Path, *, root: Path) -> None:
        self._assert_managed_path(path, root=root, allow_missing=True)
        path.mkdir(parents=True, exist_ok=True)
        self._assert_managed_path(path, root=root, allow_missing=False)

    def repository_path(self, repo: str) -> Path:
        return self._safe_child(
            self.repository_root, self._repo_part(self._validate_repo(repo))
        )

    def worktree_path(self, repo: str, commit: str) -> Path:
        normalized_repo, normalized_commit = self._validate_identity(repo, commit)
        return self._safe_child(
            self.worktree_root,
            self._repo_part(normalized_repo),
            normalized_commit,
        )

    def _repository_lock_path(self, repo: str) -> Path:
        return self._safe_child(
            self.repository_root,
            ".locks",
            f"{self._repo_part(repo)}.repository.lock",
        )

    def _registry_lock_path(self, repo: str) -> Path:
        return self._safe_child(
            self.repository_root,
            ".locks",
            f"{self._repo_part(repo)}.worktree-registry.lock",
        )

    def _commit_lock_path(self, repo: str, commit: str) -> Path:
        return self._safe_child(
            self.worktree_root,
            ".locks",
            self._repo_part(repo),
            f"{commit}.lock",
        )

    def _lock(self, path: Path, *, root: Path, blocking: bool = True) -> FileLock:
        self._safe_mkdir(path.parent, root=root)
        self._assert_managed_path(path, root=root, allow_missing=True)
        return FileLock(path, blocking=blocking)

    def _run(
        self,
        args: list[str],
        *,
        check: bool = True,
        read_only: bool = False,
    ):
        try:
            runner = self._read_runner if read_only else self._runner
            proc = runner.run(
                args,
                timeout_seconds=self.git_timeout_seconds,
            )
        except Exception as exc:
            raise WorktreeUnavailableError(
                f"Git command could not run: {args[0]}"
            ) from exc
        if check and proc.returncode != 0:
            detail = " ".join(proc.stderr_text().strip().split())
            if len(detail) > 800:
                detail = detail[:797] + "..."
            raise WorktreeUnavailableError(
                f"Git command failed ({proc.returncode}): "
                f"{' '.join(args[:6])}; {detail or 'no stderr'}"
            )
        return proc

    @staticmethod
    def _git_prefix() -> list[str]:
        return [
            "git",
            "-c",
            f"core.hooksPath={os.devnull}",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.longpaths=true",
        ]

    def _git_at(self, path: Path, *args: str) -> list[str]:
        return [*self._git_prefix(), "-C", str(path), *args]

    def _is_repository(self, path: Path) -> bool:
        self._assert_managed_path(path, root=self.repository_root, allow_missing=True)
        if not path.is_dir():
            return False
        proc = self._run(
            self._git_at(path, "rev-parse", "--git-dir"),
            check=False,
        )
        return proc.returncode == 0

    def _commit_present(self, repository_path: Path, commit: str) -> bool:
        proc = self._run(
            self._git_at(
                repository_path,
                "cat-file",
                "-e",
                f"{commit}^{{commit}}",
            ),
            check=False,
            read_only=True,
        )
        return proc.returncode == 0

    def _materialize_validation_objects(
        self,
        repository_path: Path,
        commit: str,
    ) -> None:
        """Explicitly hydrate the first-parent diff needed by Grounded.

        Blobless repositories materialize the post-fix worktree but can leave
        pre-fix blobs absent. Grounded validation and read-only tools need both
        sides of the historical diff. This preparation command is the only
        network-capable phase; later inspectors keep GIT_NO_LAZY_FETCH=1.
        """

        parents = (
            self._run(
                self._git_at(
                    repository_path,
                    "rev-list",
                    "--parents",
                    "-n",
                    "1",
                    commit,
                ),
                read_only=True,
            )
            .stdout_text()
            .strip()
            .split()
        )
        logger.info(
            "Grounded validation-object materialization started: commit=%s",
            commit,
        )
        if len(parents) > 1:
            command = self._git_at(
                repository_path,
                "diff",
                "--no-ext-diff",
                "--no-textconv",
                "--binary",
                "--full-index",
                f"--output={os.devnull}",
                parents[1],
                commit,
            )
        else:
            command = self._git_at(
                repository_path,
                "show",
                "--root",
                "--no-ext-diff",
                "--no-textconv",
                "--binary",
                "--full-index",
                "--format=",
                f"--output={os.devnull}",
                commit,
            )
        self._run(command)
        logger.info(
            "Grounded validation-object materialization completed: commit=%s",
            commit,
        )

    def _verify_repository_layout(self, repository_path: Path) -> None:
        dot_git = repository_path / ".git"
        if dot_git.is_symlink():
            raise WorktreeValidationError(
                "repository cache .git entry cannot be a symlink"
            )
        proc = self._run(
            self._git_at(
                repository_path,
                "rev-parse",
                "--absolute-git-dir",
            )
        )
        git_dir = Path(proc.stdout_text().strip()).expanduser().resolve()
        if not git_dir.is_relative_to(repository_path.resolve()):
            raise WorktreeValidationError(
                "repository cache Git directory escapes its managed path"
            )
        filters = self._run(
            self._git_at(
                repository_path,
                "config",
                "--local",
                "--get-regexp",
                r"^filter\..*\.(clean|smudge|process|required)$",
            ),
            check=False,
        )
        if filters.returncode not in {0, 1}:
            raise WorktreeValidationError(
                "repository cache filter configuration could not be audited"
            )
        if filters.returncode == 0 and filters.stdout_text().strip():
            raise WorktreeValidationError(
                "repository-local clean/smudge/process filters are not "
                "allowed for historical worktree checkout"
            )

    def _canonical_remote_repo(self, remote_url: str) -> str | None:
        value = str(remote_url or "").strip()
        if not value:
            return None
        host = ""
        path = ""
        scp_match = re.fullmatch(r"(?:[^@/\s]+@)?([^:/\s]+):(.+)", value)
        if scp_match and "://" not in value:
            host = scp_match.group(1).lower()
            path = scp_match.group(2)
        else:
            parsed = urlsplit(value)
            host = str(parsed.hostname or "").lower()
            path = parsed.path
        if host != self.repository_host:
            return None
        repo_path = path.strip("/")
        if repo_path.lower().endswith(".git"):
            repo_path = repo_path[:-4]
        if not _REPO_RE.fullmatch(repo_path):
            return None
        return repo_path.lower()

    def _verify_repository_origin(
        self, repository_path: Path, expected_repo: str
    ) -> str | None:
        if not self.verify_repository_identity:
            return None
        proc = self._run(
            self._git_at(repository_path, "remote", "get-url", "origin"),
            check=False,
        )
        canonical = (
            self._canonical_remote_repo(proc.stdout_text().strip())
            if proc.returncode == 0
            else None
        )
        if canonical != expected_repo.lower():
            raise WorktreeValidationError(
                "repository cache origin does not match candidate identity: "
                f"expected {self.repository_host}/{expected_repo}"
            )
        return f"{self.repository_host}/{canonical}"

    def _ensure_repository(
        self,
        repo: str,
        commit: str,
        evidence_commits: tuple[str, ...] = (),
    ) -> tuple[Path, str | None]:
        path = self.repository_path(repo)
        lock_path = self._repository_lock_path(repo)
        with self._lock(lock_path, root=self.repository_root):
            if not self._is_repository(path):
                if path.exists():
                    raise WorktreeUnavailableError(
                        "repository cache path exists but is not a Git "
                        f"repository: {path}"
                    )
                if not self.allow_clone:
                    raise WorktreeUnavailableError(
                        "repository cache is missing and --allow-clone is "
                        f"disabled: {path}"
                    )
                self._safe_mkdir(path.parent, root=self.repository_root)
                logger.info(
                    "Grounded repository clone started: repo=%s path=%s",
                    repo,
                    path,
                )
                self._run(
                    [
                        *self._git_prefix(),
                        "clone",
                        "--filter=blob:none",
                        "--no-checkout",
                        f"https://{self.repository_host}/{repo}.git",
                        str(path),
                    ]
                )
                self._assert_managed_path(
                    path,
                    root=self.repository_root,
                    allow_missing=False,
                )
                logger.info(
                    "Grounded repository clone completed: repo=%s",
                    repo,
                )

            self._verify_repository_layout(path)
            origin = self._verify_repository_origin(path, repo)
            if not self._commit_present(path, commit):
                if not self.allow_fetch:
                    raise WorktreeUnavailableError(
                        "historical fix commit is missing locally and "
                        f"--allow-fetch is disabled: {repo}@{commit}"
                    )
                logger.info(
                    "Grounded commit fetch started: repo=%s commit=%s",
                    repo,
                    commit,
                )
                self._run(
                    self._git_at(
                        path,
                        "fetch",
                        "--no-tags",
                        "origin",
                        commit,
                    )
                )
                if not self._commit_present(path, commit):
                    raise WorktreeUnavailableError(
                        "historical fix commit is still unavailable after "
                        f"fetch: {repo}@{commit}"
                    )
                logger.info(
                    "Grounded commit fetch completed: repo=%s commit=%s",
                    repo,
                    commit,
                )
            missing_evidence = tuple(
                item
                for item in evidence_commits
                if not self._commit_present(path, item)
            )
            if missing_evidence:
                if not self.allow_fetch:
                    raise WorktreeUnavailableError(
                        "historical evidence commits are missing locally and "
                        f"--allow-fetch is disabled: {repo}"
                    )
                logger.info(
                    "Grounded evidence commit fetch started: repo=%s commit_count=%d",
                    repo,
                    len(missing_evidence),
                )
                self._run(
                    self._git_at(
                        path,
                        "fetch",
                        "--no-tags",
                        "origin",
                        *missing_evidence,
                    )
                )
                if any(
                    not self._commit_present(path, item) for item in missing_evidence
                ):
                    raise WorktreeUnavailableError(
                        "historical evidence commits remain unavailable after "
                        f"fetch: {repo}"
                    )
                logger.info(
                    "Grounded evidence commit fetch completed: repo=%s commit_count=%d",
                    repo,
                    len(missing_evidence),
                )
            for evidence_commit in evidence_commits:
                self._materialize_validation_objects(path, evidence_commit)
            self._materialize_validation_objects(path, commit)
        return path, origin

    def _registered_worktrees(self, repository_path: Path) -> list[_RegisteredWorktree]:
        proc = self._run(
            self._git_at(repository_path, "worktree", "list", "--porcelain")
        )
        records: list[_RegisteredWorktree] = []
        current_path: Path | None = None
        current_head: str | None = None
        for line in [*proc.stdout_text().splitlines(), ""]:
            if not line:
                if current_path is not None:
                    records.append(
                        _RegisteredWorktree(
                            path=current_path,
                            head=current_head,
                        )
                    )
                current_path = None
                current_head = None
                continue
            key, _, value = line.partition(" ")
            if key == "worktree" and value:
                current_path = Path(value).expanduser().resolve()
            elif key == "HEAD" and value:
                current_head = value.strip().lower()
        return records

    def _verify_worktree(
        self,
        *,
        worktree_path: Path,
        expected_commit: str,
    ) -> None:
        self._assert_managed_path(
            worktree_path,
            root=self.worktree_root,
            allow_missing=False,
        )
        if not worktree_path.is_dir():
            raise WorktreeValidationError(
                f"historical worktree directory is missing: {worktree_path}"
            )
        root = (
            self._run(self._git_at(worktree_path, "rev-parse", "--show-toplevel"))
            .stdout_text()
            .strip()
        )
        if Path(root).expanduser().resolve() != worktree_path.resolve():
            raise WorktreeValidationError(
                "historical worktree root does not match the expected path"
            )
        head = (
            self._run(self._git_at(worktree_path, "rev-parse", "HEAD"))
            .stdout_text()
            .strip()
            .lower()
        )
        if head != expected_commit:
            raise WorktreeValidationError(
                f"historical worktree HEAD mismatch: {head} != {expected_commit}"
            )
        dirty = (
            self._run(
                self._git_at(
                    worktree_path,
                    "status",
                    "--porcelain",
                    "--untracked-files=all",
                )
            )
            .stdout_text()
            .strip()
        )
        if dirty:
            raise WorktreeValidationError("historical worktree is not clean")

    def _quarantine_invalid_path(
        self,
        repository_path: Path,
        worktree_path: Path,
    ) -> Path | None:
        self._assert_managed_path(
            worktree_path,
            root=self.worktree_root,
            allow_missing=True,
        )
        quarantined: Path | None = None
        if worktree_path.exists():
            if worktree_path.is_symlink():
                raise WorktreeValidationError(
                    "refusing to quarantine a symlinked worktree path"
                )
            stamp = time.strftime("%Y%m%dT%H%M%S", time.gmtime())
            quarantined = worktree_path.with_name(
                f"{worktree_path.name}.invalid-{stamp}-{os.getpid()}"
            )
            self._assert_managed_path(
                quarantined,
                root=self.worktree_root,
                allow_missing=True,
            )
            worktree_path.rename(quarantined)
            logger.warning(
                "Invalid historical worktree isolated: old=%s quarantine=%s",
                worktree_path,
                quarantined,
            )
        self._run(
            self._git_at(
                repository_path,
                "worktree",
                "prune",
                "--expire",
                "now",
            )
        )
        return quarantined

    def _prepare_locked(
        self,
        *,
        repo: str,
        commit: str,
        repository_path: Path,
        origin: str | None,
    ) -> WorktreeHandle:
        expected_path = self.worktree_path(repo, commit)
        registered = self._registered_worktrees(repository_path)
        expected_resolved = expected_path.resolve(strict=False)
        for item in registered:
            if item.head == commit and item.path == expected_resolved:
                try:
                    self._verify_worktree(
                        worktree_path=expected_path,
                        expected_commit=commit,
                    )
                except WorktreeValidationError:
                    self._quarantine_invalid_path(
                        repository_path,
                        expected_path,
                    )
                    break
                os.utime(expected_path, None)
                logger.info(
                    "Grounded worktree reused: repo=%s commit=%s path=%s",
                    repo,
                    commit,
                    expected_path,
                )
                return WorktreeHandle(
                    repo=repo,
                    checkout_commit=commit,
                    checkout_state="historical_fix_post_state",
                    repository_path=str(repository_path),
                    worktree_path=str(expected_path),
                    reused=True,
                    repository_origin=origin,
                    repository_identity_verified=(self.verify_repository_identity),
                )

        if expected_path.exists() or any(
            item.path == expected_resolved for item in registered
        ):
            self._quarantine_invalid_path(
                repository_path,
                expected_path,
            )

        self._safe_mkdir(expected_path.parent, root=self.worktree_root)
        self._assert_managed_path(
            expected_path,
            root=self.worktree_root,
            allow_missing=True,
        )
        logger.info(
            "Grounded worktree creation started: repo=%s commit=%s path=%s",
            repo,
            commit,
            expected_path,
        )
        self._run(
            self._git_at(
                repository_path,
                "worktree",
                "add",
                "--detach",
                str(expected_path),
                commit,
            )
        )
        try:
            self._verify_worktree(
                worktree_path=expected_path,
                expected_commit=commit,
            )
        except WorktreeValidationError:
            self._quarantine_invalid_path(
                repository_path,
                expected_path,
            )
            raise
        os.utime(expected_path, None)
        logger.info(
            "Grounded worktree created and verified: repo=%s commit=%s path=%s",
            repo,
            commit,
            expected_path,
        )
        return WorktreeHandle(
            repo=repo,
            checkout_commit=commit,
            checkout_state="historical_fix_post_state",
            repository_path=str(repository_path),
            worktree_path=str(expected_path),
            reused=False,
            repository_origin=origin,
            repository_identity_verified=self.verify_repository_identity,
        )

    def prepare(
        self,
        *,
        repo: str,
        commit: str,
        evidence_commits: tuple[str, ...] = (),
    ) -> WorktreeHandle:
        repo, commit = self._validate_identity(repo, commit)
        evidence_commits = self._validate_evidence_commits(
            evidence_commits,
            checkout_commit=commit,
        )
        repository_path, origin = self._ensure_repository(
            repo,
            commit,
            evidence_commits,
        )
        commit_lock = self._commit_lock_path(repo, commit)
        registry_lock = self._registry_lock_path(repo)
        with (
            self._lock(commit_lock, root=self.worktree_root),
            self._lock(registry_lock, root=self.repository_root),
        ):
            return self._prepare_locked(
                repo=repo,
                commit=commit,
                repository_path=repository_path,
                origin=origin,
            )

    @contextmanager
    def lease(
        self,
        *,
        repo: str,
        commit: str,
        evidence_commits: tuple[str, ...] = (),
    ) -> Iterator[WorktreeHandle]:
        """Hold the per-worktree lock through analysis and post-validation."""

        repo, commit = self._validate_identity(repo, commit)
        evidence_commits = self._validate_evidence_commits(
            evidence_commits,
            checkout_commit=commit,
        )
        repository_path, origin = self._ensure_repository(
            repo,
            commit,
            evidence_commits,
        )
        commit_lock = self._commit_lock_path(repo, commit)
        registry_lock = self._registry_lock_path(repo)
        with self._lock(commit_lock, root=self.worktree_root):
            with self._lock(registry_lock, root=self.repository_root):
                handle = self._prepare_locked(
                    repo=repo,
                    commit=commit,
                    repository_path=repository_path,
                    origin=origin,
                )
            try:
                yield handle
            except BaseException:
                try:
                    self._verify_worktree(
                        worktree_path=Path(handle.worktree_path),
                        expected_commit=handle.checkout_commit,
                    )
                except Exception:
                    logger.exception(
                        "Historical worktree changed while grounded analysis "
                        "was failing: repo=%s commit=%s",
                        repo,
                        commit,
                    )
                raise
            else:
                self._verify_worktree(
                    worktree_path=Path(handle.worktree_path),
                    expected_commit=handle.checkout_commit,
                )
                logger.info(
                    "Grounded worktree post-analysis verification passed: "
                    "repo=%s commit=%s",
                    repo,
                    commit,
                )

    def verify(self, handle: WorktreeHandle) -> None:
        repo, commit = self._validate_identity(handle.repo, handle.checkout_commit)
        expected = self.worktree_path(repo, commit)
        if Path(handle.worktree_path).resolve() != expected.resolve():
            raise WorktreeValidationError(
                "worktree handle path does not match managed identity"
            )
        lock = self._commit_lock_path(repo, commit)
        with self._lock(lock, root=self.worktree_root):
            self._verify_worktree(
                worktree_path=expected,
                expected_commit=commit,
            )

    @staticmethod
    def _directory_size(path: Path) -> int:
        total = 0
        for root, dirs, files in os.walk(path, followlinks=False):
            root_path = Path(root)
            dirs[:] = [item for item in dirs if not (root_path / item).is_symlink()]
            for name in files:
                item = root_path / name
                try:
                    total += item.lstat().st_size
                except OSError:
                    continue
        return total

    def _managed_gc_items(
        self,
        *,
        repo: str,
        repository_path: Path,
    ) -> list[_GCItem]:
        repo_root = self._safe_child(self.worktree_root, self._repo_part(repo))
        records = self._registered_worktrees(repository_path)
        items: list[_GCItem] = []
        for record in records:
            path = record.path
            if path.parent != repo_root or not _SHA40_RE.fullmatch(path.name):
                continue
            if record.head != path.name:
                continue
            try:
                self._verify_worktree(
                    worktree_path=path,
                    expected_commit=path.name,
                )
                stat = path.stat()
            except (OSError, WorktreeValidationError):
                continue
            items.append(
                _GCItem(
                    path=path,
                    commit=path.name,
                    last_used=stat.st_mtime,
                    size_bytes=self._directory_size(path),
                )
            )
        return items

    def _gc_enabled(self) -> bool:
        return bool(
            self.gc_max_count_per_repo
            or self.gc_max_age_days
            or self.gc_max_bytes_per_repo
        )

    def garbage_collect(
        self,
        *,
        repo: str,
        keep_commits: tuple[str, ...] = (),
    ) -> WorktreeGCResult:
        """Remove only clean, idle, managed worktrees under explicit quotas."""

        if not self._gc_enabled():
            return WorktreeGCResult()
        repo = self._validate_repo(repo)
        keep = {
            str(item).strip().lower()
            for item in keep_commits
            if _SHA40_RE.fullmatch(str(item).strip().lower())
        }
        repository_path = self.repository_path(repo)
        if not self._is_repository(repository_path):
            return WorktreeGCResult()
        registry_lock = self._registry_lock_path(repo)
        removed: list[str] = []
        reclaimed = 0
        skipped_busy = 0
        skipped_unsafe = 0
        with self._lock(registry_lock, root=self.repository_root):
            items = self._managed_gc_items(
                repo=repo,
                repository_path=repository_path,
            )
            now = time.time()
            selected: set[str] = set()
            candidates = sorted(
                (item for item in items if item.commit not in keep),
                key=lambda item: (item.last_used, item.commit),
            )
            if self.gc_max_age_days:
                max_age_seconds = self.gc_max_age_days * 86_400
                selected.update(
                    item.commit
                    for item in candidates
                    if now - item.last_used > max_age_seconds
                )

            remaining_count = len(items) - len(selected)
            remaining_bytes = sum(
                item.size_bytes for item in items if item.commit not in selected
            )
            for item in candidates:
                if item.commit in selected:
                    continue
                count_exceeded = (
                    self.gc_max_count_per_repo > 0
                    and remaining_count > self.gc_max_count_per_repo
                )
                bytes_exceeded = (
                    self.gc_max_bytes_per_repo > 0
                    and remaining_bytes > self.gc_max_bytes_per_repo
                )
                if not count_exceeded and not bytes_exceeded:
                    break
                selected.add(item.commit)
                remaining_count -= 1
                remaining_bytes -= item.size_bytes

            by_commit = {item.commit: item for item in candidates}
            for commit in sorted(
                selected,
                key=lambda value: (
                    by_commit[value].last_used,
                    value,
                ),
            ):
                item = by_commit[commit]
                commit_lock = self._commit_lock_path(repo, commit)
                try:
                    lock = self._lock(
                        commit_lock,
                        root=self.worktree_root,
                        blocking=False,
                    )
                    with lock:
                        try:
                            self._verify_worktree(
                                worktree_path=item.path,
                                expected_commit=commit,
                            )
                        except WorktreeValidationError:
                            skipped_unsafe += 1
                            continue
                        proc = self._run(
                            self._git_at(
                                repository_path,
                                "worktree",
                                "remove",
                                str(item.path),
                            ),
                            check=False,
                        )
                        if proc.returncode != 0:
                            skipped_unsafe += 1
                            logger.warning(
                                "Grounded worktree GC skipped a worktree Git "
                                "would not remove: repo=%s commit=%s",
                                repo,
                                commit,
                            )
                            continue
                        removed.append(str(item.path))
                        reclaimed += item.size_bytes
                        logger.info(
                            "Grounded worktree GC removed: repo=%s commit=%s bytes=%d",
                            repo,
                            commit,
                            item.size_bytes,
                        )
                except BlockingIOError:
                    skipped_busy += 1
                    logger.info(
                        "Grounded worktree GC skipped active lease: repo=%s commit=%s",
                        repo,
                        commit,
                    )
            if removed:
                self._run(
                    self._git_at(
                        repository_path,
                        "worktree",
                        "prune",
                        "--expire",
                        "now",
                    )
                )
        return WorktreeGCResult(
            removed_paths=tuple(removed),
            reclaimed_bytes=reclaimed,
            skipped_busy_count=skipped_busy,
            skipped_unsafe_count=skipped_unsafe,
        )
