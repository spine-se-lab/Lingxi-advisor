from __future__ import annotations

from typing import Any, Mapping

from .contracts import (
    LightGenerationInput,
    LightGenerationResult,
    LightGeneratorConfig,
)
from .generator import LLMClient, LightKnowledgeGenerator


class LightGenerationService:
    """Candidate-level facade for repository-free Light generation."""

    def __init__(
        self,
        config: LightGeneratorConfig,
        *,
        client: LLMClient | None = None,
    ) -> None:
        self.config = config
        self._client = client
        self._generator: LightKnowledgeGenerator | None = None

    def _get_generator(self) -> LightKnowledgeGenerator:
        if self._generator is None:
            self._generator = LightKnowledgeGenerator(
                self.config, client=self._client
            )
        return self._generator

    def generate(
        self, candidate: Mapping[str, Any]
    ) -> tuple[LightGenerationInput, LightGenerationResult]:
        value = LightGenerationInput.from_candidate(candidate)
        return value, self._get_generator().generate(value)
