from __future__ import annotations

import copy
import csv
import datetime as dt
import hashlib
import importlib.metadata
import json
import math
import re
import statistics
import subprocess
import sys
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from .. import github as v4


SearchPage = Callable[[dict[str, Any], int], Mapping[str, Any]]


@dataclass(frozen=True)
class SemanticCollectionResult:
    candidates: dict[str, dict[str, Any]]
    query_audit: list[dict[str, Any]]
    semantic_phases_planned: int
    semantic_phases_executed: int


@dataclass(frozen=True)
class SearchCollectionResult:
    candidates: dict[str, dict[str, Any]]
    query_audit: list[dict[str, Any]]
    phases_planned: int
    phases_executed: int


@dataclass(frozen=True)
class HistoricalFilterResult:
    candidates: dict[str, dict[str, Any]]
    rejection_counts: dict[str, int]
    filter_audit: list[dict[str, Any]]


@dataclass(frozen=True)
class CandidateEvaluationResult:
    candidates: dict[str, dict[str, Any]]
    arms: dict[str, list[dict[str, Any]]]
    minilm_telemetry: dict[str, Any]


class MiniLMEmbedder:
    """Thin CPU adapter around one pinned SentenceTransformer checkpoint."""

    DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
    DEFAULT_REVISION = "c9745ed1d9f207416be6d2e6f8de32d1f16199bf"

    def __init__(
        self,
        *,
        model_name: str = DEFAULT_MODEL,
        model_revision: str = DEFAULT_REVISION,
        model: Any = None,
        tokenizer: Any = None,
        batch_size: int = 32,
    ) -> None:
        if model is None:
            from sentence_transformers import SentenceTransformer

            model = SentenceTransformer(
                model_name,
                revision=model_revision,
                device="cpu",
            )
        self.model_name = model_name
        self.model_revision = model_revision
        self.model = model
        self.tokenizer = tokenizer or model.tokenizer
        self.max_seq_length = int(model.max_seq_length)
        self.batch_size = batch_size

    def encode(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        vectors = self.model.encode(
            texts,
            batch_size=self.batch_size,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return vectors.tolist() if hasattr(vectors, "tolist") else list(vectors)

    def token_lengths(self, texts: list[str]) -> list[int]:
        return [
            len(
                self.tokenizer(
                    text,
                    add_special_tokens=True,
                    truncation=False,
                )["input_ids"]
            )
            for text in texts
        ]


def select_semantic_phases(
    plan: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Return existing semantic intents without converting other search modes."""
    return [
        dict(phase)
        for phase in plan
        if str(phase.get("search_type") or "").casefold() == "semantic"
    ]


def select_search_phases(
    plan: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Keep every declared GitHub mode without converting query intent."""
    allowed = {"semantic", "hybrid", "lexical"}
    return [
        dict(phase)
        for phase in plan
        if str(phase.get("search_type") or "").casefold() in allowed
    ]


def _response_metadata(
    wrapped: Mapping[str, Any],
    requested_default: str,
) -> tuple[Mapping[str, Any], str, str, bool, str]:
    payload = wrapped.get("payload")
    if not isinstance(payload, Mapping):
        payload = {}
    requested = str(
        wrapped.get("requested_search_type") or requested_default
    ).casefold()
    # The shared wrapper historically synthesized a requested type when the
    # API omitted classification. Require the payload's explicit type here.
    actual = str(payload.get("search_type") or "").casefold()
    fallback = bool(
        wrapped.get("search_type_fallback")
        or wrapped.get("search_fallback_reason")
        or not actual
        or actual != requested
    )
    query_error = str(payload.get("query_error") or wrapped.get("error") or "")
    return payload, requested, actual, fallback, query_error


def collect_semantic_candidates(
    *,
    repo: str,
    phases: Sequence[Mapping[str, Any]],
    search_page: SearchPage,
    per_page: int = 100,
) -> SemanticCollectionResult:
    """Execute every semantic phase and aggregate duplicate hit provenance."""
    semantic_phases = select_semantic_phases(phases)
    candidates: dict[str, dict[str, Any]] = {}
    query_audit: list[dict[str, Any]] = []
    repo_key = v4.repo_identity_key(repo)

    for phase_index, raw_phase in enumerate(semantic_phases):
        phase = dict(raw_phase)
        phase_name = str(phase.get("phase") or f"semantic_{phase_index}")
        requested_default = str(phase.get("search_type") or "semantic")
        page_limit = max(1, int(phase.get("pages") or 1))

        for page in range(1, page_limit + 1):
            wrapped = search_page(phase, page)
            payload, requested, actual, fallback, query_error = _response_metadata(
                wrapped, requested_default
            )
            eligible = (
                requested == "semantic"
                and actual == "semantic"
                and not fallback
                and not query_error
            )
            raw_items = payload.get("items") or []
            items = [item for item in raw_items if isinstance(item, Mapping)]
            reported_total = (
                v4.safe_int(payload.get("total_count"), -1)
                if payload.get("total_count") is not None
                else -1
            )
            if query_error:
                status = "search_failed"
            elif not actual:
                status = "unclassified_search_type"
            elif not eligible:
                status = "nonsemantic_fallback"
            else:
                status = "ok"

            accepted_on_page = 0
            if eligible:
                for offset, raw_item in enumerate(items, start=1):
                    item = dict(raw_item)
                    item_repo = v4.normalize_repo(
                        str(item.get("repository_url") or "").split("/repos/")[-1]
                    )
                    if item_repo and v4.repo_identity_key(item_repo) != repo_key:
                        continue
                    if "pull_request" in item:
                        continue
                    number = v4.parse_issue_number_int(item.get("number"))
                    if not number:
                        continue
                    rank_in_query = (page - 1) * per_page + offset
                    key = f"{repo_key}#{number}"
                    candidate = candidates.setdefault(
                        key,
                        {
                            "candidate_key": key,
                            "repo": v4.normalize_repo(repo),
                            "issue_number": number,
                            "title": str(item.get("title") or ""),
                            "body": str(item.get("body") or ""),
                            "html_url": str(item.get("html_url") or ""),
                            "provenance": [],
                        },
                    )
                    candidate["provenance"].append(
                        {
                            "phase": phase_name,
                            "phase_index": phase_index,
                            "query_variant": str(phase.get("query_variant") or ""),
                            "query_text": str(phase.get("query_text") or ""),
                            "github_query": str(phase.get("github_query") or ""),
                            "page": page,
                            "rank_in_query": rank_in_query,
                            "requested_search_type": requested,
                            "actual_search_type": actual,
                            "search_type_fallback": fallback,
                            "response_status": status,
                            "query_error": query_error,
                        }
                    )
                    accepted_on_page += 1

            query_audit.append(
                {
                    "phase": phase_name,
                    "phase_index": phase_index,
                    "query_variant": str(phase.get("query_variant") or ""),
                    "query_text": str(phase.get("query_text") or ""),
                    "github_query": str(phase.get("github_query") or ""),
                    "page": page,
                    "requested_search_type": requested,
                    "actual_search_type": actual,
                    "search_type_fallback": fallback,
                    "eligible_semantic_response": eligible,
                    "status": status,
                    "query_error": query_error,
                    "raw_items": len(items),
                    "total_count": reported_total if reported_total >= 0 else "",
                    "accepted_items": accepted_on_page,
                    "cache_hit": bool(wrapped.get("cache_hit")),
                    "github_api_calls": (
                        0
                        if wrapped.get("cache_hit")
                        else max(1, int(wrapped.get("query_request_attempts") or 1))
                    ),
                }
            )
            exhausted = not items or (
                reported_total >= 0 and page * per_page >= reported_total
            )
            if not eligible or exhausted:
                break

    return SemanticCollectionResult(
        candidates=candidates,
        query_audit=query_audit,
        semantic_phases_planned=len(semantic_phases),
        semantic_phases_executed=len(semantic_phases),
    )


def collect_search_candidates(
    *,
    repo: str,
    phases: Sequence[Mapping[str, Any]],
    search_page: SearchPage,
    per_page: int = 100,
) -> SearchCollectionResult:
    """Execute all declared modes and accept results only when the API agrees."""
    selected = select_search_phases(phases)
    candidates: dict[str, dict[str, Any]] = {}
    query_audit: list[dict[str, Any]] = []
    repo_key = v4.repo_identity_key(repo)

    for phase_index, raw_phase in enumerate(selected):
        phase = dict(raw_phase)
        phase_name = str(phase.get("phase") or f"query_{phase_index}")
        requested_default = str(phase.get("search_type") or "").casefold()
        page_limit = max(1, int(phase.get("pages") or 1))

        for page in range(1, page_limit + 1):
            wrapped = search_page(phase, page)
            payload, requested, actual, fallback, query_error = _response_metadata(
                wrapped, requested_default
            )
            eligible = (
                requested in {"semantic", "hybrid", "lexical"}
                and actual == requested
                and not fallback
                and not query_error
            )
            raw_items = payload.get("items") or []
            items = [item for item in raw_items if isinstance(item, Mapping)]
            reported_total = (
                v4.safe_int(payload.get("total_count"), -1)
                if payload.get("total_count") is not None
                else -1
            )
            if query_error:
                status = "search_failed"
            elif not actual:
                status = "unclassified_search_type"
            elif not eligible:
                status = "search_type_mismatch"
            else:
                status = "ok"

            accepted_on_page = 0
            if eligible:
                for offset, raw_item in enumerate(items, start=1):
                    item = dict(raw_item)
                    item_repo = v4.normalize_repo(
                        str(item.get("repository_url") or "").split("/repos/")[-1]
                    )
                    if item_repo and v4.repo_identity_key(item_repo) != repo_key:
                        continue
                    if "pull_request" in item:
                        continue
                    number = v4.parse_issue_number_int(item.get("number"))
                    if not number:
                        continue
                    rank_in_query = (page - 1) * per_page + offset
                    key = f"{repo_key}#{number}"
                    candidate = candidates.setdefault(
                        key,
                        {
                            "candidate_key": key,
                            "repo": v4.normalize_repo(repo),
                            "issue_number": number,
                            "title": str(item.get("title") or ""),
                            "body": str(item.get("body") or ""),
                            "html_url": str(item.get("html_url") or ""),
                            "created_at": str(item.get("created_at") or ""),
                            "provenance": [],
                        },
                    )
                    candidate["provenance"].append(
                        {
                            "phase": phase_name,
                            "phase_index": phase_index,
                            "query_variant": str(phase.get("query_variant") or ""),
                            "query_text": str(phase.get("query_text") or ""),
                            "github_query": str(phase.get("github_query") or ""),
                            "page": page,
                            "rank_in_query": rank_in_query,
                            "requested_search_type": requested,
                            "actual_search_type": actual,
                            "search_type_fallback": fallback,
                            "response_status": status,
                            "query_error": query_error,
                        }
                    )
                    accepted_on_page += 1

            query_audit.append(
                {
                    "phase": phase_name,
                    "phase_index": phase_index,
                    "query_variant": str(phase.get("query_variant") or ""),
                    "query_text": str(phase.get("query_text") or ""),
                    "github_query": str(phase.get("github_query") or ""),
                    "page": page,
                    "requested_search_type": requested,
                    "actual_search_type": actual,
                    "search_type_fallback": fallback,
                    "eligible_search_response": eligible,
                    "eligible_semantic_response": eligible and requested == "semantic",
                    "status": status,
                    "query_error": query_error,
                    "raw_items": len(items),
                    "total_count": reported_total if reported_total >= 0 else "",
                    "accepted_items": accepted_on_page,
                    "cache_hit": bool(wrapped.get("cache_hit")),
                    "github_api_calls": (
                        0 if wrapped.get("cache_hit") else
                        max(1, int(wrapped.get("query_request_attempts") or 1))
                    ),
                }
            )
            exhausted = not items or (
                reported_total >= 0 and page * per_page >= reported_total
            )
            if not eligible or exhausted:
                break

    return SearchCollectionResult(
        candidates=candidates,
        query_audit=query_audit,
        phases_planned=len(selected),
        phases_executed=len(selected),
    )


def filter_historical_candidates(
    *,
    candidates: Mapping[str, Mapping[str, Any]],
    eligible_issues: Mapping[int, Mapping[str, Any]],
    discover_issue: Callable[[int, dict[str, Any]], tuple[dict[str, Any] | None, str]],
    validate_candidate: Callable[[dict[str, Any]], tuple[bool, str, dict[str, Any]]],
    require_patch: bool = True,
    target_issue_number: int | None = None,
) -> HistoricalFilterResult:
    """Apply deterministic pre-review filters before any local similarity score."""
    accepted: dict[str, dict[str, Any]] = {}
    rejection_counts: Counter[str] = Counter()
    audit: list[dict[str, Any]] = []

    for key, raw_candidate in candidates.items():
        candidate = copy.deepcopy(dict(raw_candidate))
        number = v4.parse_issue_number_int(candidate.get("issue_number"))
        issue = eligible_issues.get(number) if number is not None else None
        if issue is None:
            reason = (
                "current_issue"
                if number is not None and number == target_issue_number
                else "issue_not_in_eligible_closed_issue_universe"
            )
            rejection_counts[reason] += 1
            audit.append({"candidate_key": key, "accepted": False, "reason": reason})
            continue

        record, source = discover_issue(int(number), dict(issue))
        if record is None:
            reason = str(source or "no_canonical_fix_link")
            rejection_counts[reason] += 1
            audit.append({"candidate_key": key, "accepted": False, "reason": reason})
            continue
        patch = v4.safe_str(record.get("retrieved_issue_ground_truth_patch")) or v4.safe_str(
            record.get("retrieved_patch")
        )
        if require_patch and not patch:
            reason = "missing_historical_patch"
            rejection_counts[reason] += 1
            audit.append({"candidate_key": key, "accepted": False, "reason": reason})
            continue

        safe, reason, details = validate_candidate(record)
        if not safe:
            rejection_counts[reason] += 1
            audit.append(
                {"candidate_key": key, "accepted": False, "reason": reason, "details": details}
            )
            continue

        candidate["title"] = str(issue.get("title") or candidate.get("title") or "")
        candidate["body"] = str(issue.get("body") or candidate.get("body") or "")
        candidate["html_url"] = str(issue.get("html_url") or candidate.get("html_url") or "")
        candidate["filter_status"] = "safe"
        candidate["fix_discovery_source"] = source
        candidate["leakage_details"] = details
        accepted[key] = candidate
        audit.append({"candidate_key": key, "accepted": True, "reason": "safe", "source": source})

    return HistoricalFilterResult(
        candidates=accepted,
        rejection_counts=dict(rejection_counts),
        filter_audit=audit,
    )


def issue_text(title: object, body: object) -> str:
    return f"{str(title or '').strip()}\n\n{str(body or '').strip()}"


def query_rrf_scores(
    candidates: Mapping[str, Mapping[str, Any]],
    *,
    rrf_k: int = 60,
) -> dict[str, float]:
    scores: dict[str, float] = {}
    for key, candidate in candidates.items():
        best_by_phase: dict[str, int] = {}
        for row in candidate.get("provenance") or []:
            phase = str(row.get("phase") or "")
            rank = max(1, int(row.get("rank_in_query") or 1))
            if phase not in best_by_phase or rank < best_by_phase[phase]:
                best_by_phase[phase] = rank
        scores[key] = sum(1.0 / (rrf_k + rank) for rank in best_by_phase.values())
    return scores


_TOKEN_RE = re.compile(
    r"[A-Za-z][A-Za-z0-9_-]*(?:[./:][A-Za-z0-9_.-]+)+"
    r"|[A-Za-z_][A-Za-z0-9_]*|\d+"
)


def _tokens(text: object) -> list[str]:
    return [match.group(0).casefold() for match in _TOKEN_RE.finditer(str(text or ""))]


def bm25_scores(
    query: str,
    documents: Mapping[str, str],
    *,
    k1: float = 1.5,
    b: float = 0.75,
) -> dict[str, float]:
    """Small per-instance BM25 implementation with no external lexical service."""
    keys = list(documents)
    tokenized = {key: _tokens(documents[key]) for key in keys}
    query_terms = list(dict.fromkeys(_tokens(query)))
    if not keys or not query_terms:
        return {key: 0.0 for key in keys}
    average_length = sum(len(tokens) for tokens in tokenized.values()) / len(keys)
    average_length = average_length or 1.0
    document_frequency = {
        term: sum(term in set(tokens) for tokens in tokenized.values())
        for term in query_terms
    }
    scores: dict[str, float] = {}
    for key, tokens in tokenized.items():
        counts = Counter(tokens)
        length_norm = 1.0 - b + b * len(tokens) / average_length
        score = 0.0
        for term in query_terms:
            frequency = counts.get(term, 0)
            if not frequency:
                continue
            df = document_frequency[term]
            inverse_document_frequency = math.log(
                1.0 + (len(keys) - df + 0.5) / (df + 0.5)
            )
            score += inverse_document_frequency * (
                frequency * (k1 + 1.0)
                / (frequency + k1 * length_norm)
            )
        scores[key] = score
    return scores


_BACKTICK_RE = re.compile(r"`([^`\n]{2,120})`")
_TECHNICAL_IDENTIFIER_RE = re.compile(
    r"\b(?:"
    r"[A-Za-z][A-Za-z0-9_-]*(?:[./:][A-Za-z0-9_.-]+)+"
    r"|[A-Z][a-z]+(?:[A-Z][A-Za-z0-9]+)+"
    r"|[A-Z][A-Z0-9]+(?:_[A-Z0-9]+)+"
    r"|[a-z][a-z0-9]+(?:_[a-z0-9]+)+"
    r")\b"
)


def extract_exact_identifiers(text: str) -> list[str]:
    values = [*(_BACKTICK_RE.findall(text)), *(_TECHNICAL_IDENTIFIER_RE.findall(text))]
    seen: set[str] = set()
    result: list[str] = []
    for raw in values:
        value = raw.strip().strip("'\"")
        if not value or any(character.isspace() for character in value):
            continue
        key = value.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


def exact_identifier_scores(
    query: str,
    documents: Mapping[str, str],
) -> tuple[dict[str, float], dict[str, list[str]]]:
    identifiers = extract_exact_identifiers(query)
    matches: dict[str, list[str]] = {}
    scores: dict[str, float] = {}
    for key, document in documents.items():
        found: list[str] = []
        for identifier in identifiers:
            case_sensitive = any(character.isupper() for character in identifier)
            pattern = re.compile(
                rf"(?<![A-Za-z0-9_]){re.escape(identifier)}(?![A-Za-z0-9_])",
                0 if case_sensitive else re.IGNORECASE,
            )
            present = pattern.search(document) is not None
            if present:
                found.append(identifier)
        matches[key] = found
        scores[key] = float(len(found))
    return scores, matches


def _cosine(left: Sequence[float], right: Sequence[float]) -> float:
    numerator = sum(float(a) * float(b) for a, b in zip(left, right))
    left_norm = math.sqrt(sum(float(value) ** 2 for value in left))
    right_norm = math.sqrt(sum(float(value) ** 2 for value in right))
    if not left_norm or not right_norm:
        return 0.0
    return numerator / (left_norm * right_norm)


def score_minilm(
    current_text: str,
    candidates: Mapping[str, Mapping[str, Any]],
    embedder: Any,
) -> tuple[dict[str, float], dict[str, Any]]:
    keys = sorted(candidates)
    historical_texts = [
        issue_text(candidates[key].get("title"), candidates[key].get("body"))
        for key in keys
    ]
    embedding_started = time.perf_counter()
    current_vector = embedder.encode([current_text])[0]
    historical_vectors = embedder.encode(historical_texts) if historical_texts else []
    embedding_elapsed = time.perf_counter() - embedding_started
    scores = {
        key: _cosine(current_vector, historical_vectors[index])
        for index, key in enumerate(keys)
    }
    current_length = int(embedder.token_lengths([current_text])[0])
    historical_lengths = [int(value) for value in embedder.token_lengths(historical_texts)]
    maximum = int(embedder.max_seq_length)
    telemetry = {
        "model_name": str(getattr(embedder, "model_name", "")),
        "model_revision": str(getattr(embedder, "model_revision", "")),
        "max_seq_length": maximum,
        "current_token_length": current_length,
        "current_truncated": current_length > maximum,
        "historical_token_lengths": dict(zip(keys, historical_lengths)),
        "historical_truncated_count": sum(length > maximum for length in historical_lengths),
        "embedding_elapsed_seconds": embedding_elapsed,
    }
    return scores, telemetry


def _best_query_rank(candidate: Mapping[str, Any]) -> int:
    ranks = [
        int(row.get("rank_in_query") or 10**9)
        for row in candidate.get("provenance") or []
    ]
    return min(ranks, default=10**9)


def _ordered_keys(
    scores: Mapping[str, float],
    candidates: Mapping[str, Mapping[str, Any]],
    base_scores: Mapping[str, float],
    *,
    positive_only: bool = False,
) -> list[str]:
    keys = [
        key for key in candidates
        if not positive_only or float(scores.get(key, 0.0)) > 0.0
    ]
    return sorted(
        keys,
        key=lambda key: (
            -float(scores.get(key, 0.0)),
            -float(base_scores.get(key, 0.0)),
            _best_query_rank(candidates[key]),
            int(candidates[key].get("issue_number") or 10**9),
            key,
        ),
    )


def _fuse_component_orders(
    orders: Sequence[Sequence[str]],
    *,
    rrf_k: int,
) -> dict[str, float]:
    scores: dict[str, float] = {}
    for order in orders:
        for rank, key in enumerate(order, start=1):
            scores[key] = scores.get(key, 0.0) + 1.0 / (rrf_k + rank)
    return scores


def rank_experiment_arms(
    candidates: Mapping[str, Mapping[str, Any]],
    *,
    bm25: Mapping[str, float],
    exact: Mapping[str, float],
    minilm: Mapping[str, float],
    top_k: int = 10,
    rrf_k: int = 60,
) -> dict[str, list[dict[str, Any]]]:
    base_scores = query_rrf_scores(candidates, rrf_k=rrf_k)
    base_order = _ordered_keys(base_scores, candidates, base_scores)
    component_orders = {
        "bm25": _ordered_keys(bm25, candidates, base_scores),
        "exact": _ordered_keys(exact, candidates, base_scores, positive_only=True),
        "minilm": _ordered_keys(minilm, candidates, base_scores),
    }
    arm_orders: dict[str, tuple[list[str], dict[str, float]]] = {
        "rrf": (base_order, base_scores),
    }
    for arm, names in {
        "rrf_bm25_exact": ("bm25", "exact"),
        "rrf_minilm": ("minilm",),
        "rrf_minilm_bm25_exact": ("minilm", "bm25", "exact"),
    }.items():
        orders = [base_order, *(component_orders[name] for name in names)]
        fused = _fuse_component_orders(orders, rrf_k=rrf_k)
        arm_orders[arm] = (
            _ordered_keys(fused, candidates, base_scores),
            fused,
        )

    result: dict[str, list[dict[str, Any]]] = {}
    for arm, (order, fusion_scores) in arm_orders.items():
        result[arm] = [
            {
                "arm": arm,
                "rank": rank,
                "candidate_key": key,
                "fusion_score": float(fusion_scores.get(key, 0.0)),
                "query_rrf_score": float(base_scores.get(key, 0.0)),
                "bm25_score": float(bm25.get(key, 0.0)),
                "exact_identifier_score": float(exact.get(key, 0.0)),
                "minilm_cosine": float(minilm.get(key, 0.0)),
            }
            for rank, key in enumerate(order[: min(10, max(0, top_k))], start=1)
        ]
    return result


def evaluate_candidate_union(
    *,
    current_title: str,
    current_body: str,
    candidates: Mapping[str, Mapping[str, Any]],
    embedder: Any,
    top_k: int = 10,
    rrf_k: int = 60,
) -> CandidateEvaluationResult:
    evaluated = {
        key: copy.deepcopy(dict(candidate)) for key, candidate in candidates.items()
    }
    current = issue_text(current_title, current_body)
    documents = {
        key: issue_text(candidate.get("title"), candidate.get("body"))
        for key, candidate in evaluated.items()
    }
    lexical = bm25_scores(current, documents)
    exact, matches = exact_identifier_scores(current, documents)
    minilm, telemetry = score_minilm(current, evaluated, embedder)
    query_scores = query_rrf_scores(evaluated, rrf_k=rrf_k)

    for key, candidate in evaluated.items():
        candidate["query_rrf_score"] = float(query_scores.get(key, 0.0))
        candidate["bm25_score"] = float(lexical.get(key, 0.0))
        candidate["exact_identifier_score"] = float(exact.get(key, 0.0))
        candidate["matched_identifiers"] = list(matches.get(key, []))
        candidate["minilm_cosine"] = float(minilm.get(key, 0.0))
        candidate["minilm_token_length"] = int(
            telemetry.get("historical_token_lengths", {}).get(key, 0)
        )
        candidate["minilm_truncated"] = (
            candidate["minilm_token_length"] > int(telemetry["max_seq_length"])
        )

    arms = rank_experiment_arms(
        evaluated,
        bm25=lexical,
        exact=exact,
        minilm=minilm,
        top_k=top_k,
        rrf_k=rrf_k,
    )
    return CandidateEvaluationResult(
        candidates=evaluated,
        arms=arms,
        minilm_telemetry=telemetry,
    )


def shard_instances(
    instances: Sequence[Mapping[str, Any]],
    shard_index: int,
    shard_count: int,
) -> list[dict[str, Any]]:
    if shard_count < 1:
        raise ValueError("shard_count must be at least 1")
    if shard_index < 0 or shard_index >= shard_count:
        raise ValueError("shard_index must be between 0 and shard_count - 1")
    return [
        dict(instance)
        for index, instance in enumerate(instances)
        if index % shard_count == shard_index
    ]


def _write_tsv(path: Path, fieldnames: Sequence[str], rows: Sequence[Mapping[str, Any]]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fieldnames),
            delimiter="\t",
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def _provenance_text(rows: Sequence[Mapping[str, Any]]) -> str:
    return ";".join(
        f"{row.get('phase', '')}:{row.get('rank_in_query', '')}"
        for row in rows
    )


def _arm_jaccard(arms: Mapping[str, Any], left: str, right: str) -> float:
    left_keys = {str(row.get("candidate_key")) for row in arms.get(left, [])}
    right_keys = {str(row.get("candidate_key")) for row in arms.get(right, [])}
    union = left_keys | right_keys
    return len(left_keys & right_keys) / len(union) if union else 1.0


def _arm_rank_correlation(arms: Mapping[str, Any], left: str, right: str) -> float:
    """Spearman-style correlation over the union, with missing items ranked last."""
    left_rows = list(arms.get(left, []))
    right_rows = list(arms.get(right, []))
    left_ranks = {
        str(row.get("candidate_key")): int(row.get("rank") or index)
        for index, row in enumerate(left_rows, start=1)
    }
    right_ranks = {
        str(row.get("candidate_key")): int(row.get("rank") or index)
        for index, row in enumerate(right_rows, start=1)
    }
    keys = sorted(set(left_ranks) | set(right_ranks))
    if not keys:
        return 1.0
    missing_rank = max(len(left_rows), len(right_rows)) + 1
    left_values = [float(left_ranks.get(key, missing_rank)) for key in keys]
    right_values = [float(right_ranks.get(key, missing_rank)) for key in keys]
    left_mean = sum(left_values) / len(left_values)
    right_mean = sum(right_values) / len(right_values)
    numerator = sum(
        (left_value - left_mean) * (right_value - right_mean)
        for left_value, right_value in zip(left_values, right_values)
    )
    left_scale = math.sqrt(sum((value - left_mean) ** 2 for value in left_values))
    right_scale = math.sqrt(sum((value - right_mean) ** 2 for value in right_values))
    if not left_scale or not right_scale:
        return 1.0 if left_values == right_values else 0.0
    return numerator / (left_scale * right_scale)


def _score_summary(rows: Sequence[Mapping[str, Any]], field: str) -> str:
    values = [float(row.get(field) or 0.0) for row in rows]
    if not values:
        return "n=0"
    return (
        f"n={len(values)}, min={min(values):.4f}, "
        f"median={statistics.median(values):.4f}, "
        f"mean={statistics.fmean(values):.4f}, max={max(values):.4f}"
    )


def _numeric_summary(values: Sequence[float], prefix: str) -> dict[str, float]:
    if not values:
        return {
            f"{prefix}_min": 0.0,
            f"{prefix}_median": 0.0,
            f"{prefix}_mean": 0.0,
            f"{prefix}_max": 0.0,
        }
    return {
        f"{prefix}_min": min(values),
        f"{prefix}_median": statistics.median(values),
        f"{prefix}_mean": statistics.fmean(values),
        f"{prefix}_max": max(values),
    }


def build_run_metadata(
    repository_root: Path,
    *,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Capture reproducibility data without reading ignored files such as .env."""
    root = repository_root.resolve()

    def git(*arguments: str) -> bytes:
        completed = subprocess.run(
            ["git", *arguments],
            cwd=root,
            check=True,
            capture_output=True,
        )
        return completed.stdout

    source_commit = git("rev-parse", "HEAD").decode().strip()
    fingerprint = hashlib.sha256()
    fingerprint.update(git("diff", "--binary", "HEAD"))
    untracked = git("ls-files", "--others", "--exclude-standard", "-z")
    for raw_path in sorted(path for path in untracked.split(b"\0") if path):
        relative_path = raw_path.decode("utf-8", errors="surrogateescape")
        fingerprint.update(raw_path)
        fingerprint.update(b"\0")
        path = root / relative_path
        if path.is_file():
            fingerprint.update(path.read_bytes())

    metadata: dict[str, Any] = {
        "generated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "source_commit": source_commit,
        "working_tree_fingerprint_sha256": fingerprint.hexdigest(),
        "rrf_constant": 60,
    }
    for package in ("lingxi_advisor", "sentence-transformers", "torch"):
        try:
            metadata[f"dependency_{package}_version"] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            metadata[f"dependency_{package}_version"] = "not-installed"
    if extra:
        metadata.update(extra)
    return metadata


def build_experiment_identity(
    repository_root: Path,
    input_path: Path,
    *,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Fingerprint every input that can alter retrieval or ranking results."""
    root = repository_root.resolve()
    source_paths = [
        root / "src/lingxi_advisor/internal/experiments/semantic_reranking.py",
        root / "src/lingxi_advisor/internal/vendor/github_v4_backend.py",
        root / "scripts/run_semantic_reranking_experiment.py",
    ]

    def file_digest(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    normalized_config = {
        str(key): str(value) if isinstance(value, Path) else value
        for key, value in sorted(config.items())
    }
    identity: dict[str, Any] = {
        "checkpoint_schema_version": 2,
        "input_sha256": file_digest(input_path.resolve()),
        "lockfile_sha256": file_digest(root / "uv.lock"),
        "code_sha256": {
            str(path.relative_to(root)): file_digest(path) for path in source_paths
        },
        "runtime": {
            "python": sys.version,
            **{
                package: importlib.metadata.version(package)
                for package in (
                    "sentence-transformers",
                    "torch",
                    "transformers",
                    "tokenizers",
                )
            },
        },
        "config": normalized_config,
    }
    encoded = json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
    identity["identity_sha256"] = hashlib.sha256(encoded).hexdigest()
    return identity


def write_experiment_outputs(
    output_dir: Path,
    results: Sequence[Mapping[str, Any]],
    *,
    run_metadata: Mapping[str, Any] | None = None,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    ordered_results = sorted(
        results,
        key=lambda row: (str(row.get("repo") or ""), str(row.get("instance_id") or "")),
    )
    query_rows: list[dict[str, Any]] = []
    candidate_rows: list[dict[str, Any]] = []
    provenance_rows: list[dict[str, Any]] = []
    arm_rows: list[dict[str, Any]] = []
    instance_rows: list[dict[str, Any]] = []
    contribution_rows: list[dict[str, Any]] = []
    filter_rows: list[dict[str, Any]] = []
    quality_observations: list[dict[str, Any]] = []
    declared_query_groups: set[tuple[str, str, str]] = set()

    for result in ordered_results:
        instance_id = str(result.get("instance_id") or "")
        repo = str(result.get("repo") or "")
        candidates = result.get("candidates") or {}
        for audit in result.get("query_audit") or []:
            query_rows.append({"instance_id": instance_id, "repo": repo, **dict(audit)})
            declared_query_groups.add(
                (
                    repo,
                    str(audit.get("phase") or ""),
                    str(audit.get("requested_search_type") or ""),
                )
            )
        for audit in result.get("filter_audit") or []:
            row = dict(audit)
            if isinstance(row.get("details"), Mapping):
                row["details"] = json.dumps(row["details"], sort_keys=True)
            filter_rows.append({"instance_id": instance_id, "repo": repo, **row})
        for key, raw_candidate in sorted(candidates.items()):
            candidate = dict(raw_candidate)
            for provenance in candidate.get("provenance") or []:
                provenance_rows.append(
                    {
                        "instance_id": instance_id,
                        "repo": repo,
                        "candidate_key": key,
                        "issue_number": candidate.get("issue_number"),
                        **dict(provenance),
                    }
                )
            best_phase_rows: dict[str, Mapping[str, Any]] = {}
            for provenance in candidate.get("provenance") or []:
                phase = str(provenance.get("phase") or "")
                if not phase:
                    continue
                prior = best_phase_rows.get(phase)
                if prior is None or int(provenance.get("rank_in_query") or 10**9) < int(
                    prior.get("rank_in_query") or 10**9
                ):
                    best_phase_rows[phase] = provenance
            for phase, provenance in best_phase_rows.items():
                quality_observations.append(
                    {
                        "instance_id": instance_id,
                        "repo": repo,
                        "phase": phase,
                        "search_type": str(provenance.get("requested_search_type") or ""),
                        "rank_in_query": int(provenance.get("rank_in_query") or 0),
                        "bm25_score": float(candidate.get("bm25_score") or 0.0),
                        "exact_identifier_score": float(
                            candidate.get("exact_identifier_score") or 0.0
                        ),
                        "minilm_cosine": float(candidate.get("minilm_cosine") or 0.0),
                    }
                )
            candidate_rows.append(
                {
                    "instance_id": instance_id,
                    "repo": repo,
                    "candidate_key": key,
                    "issue_number": candidate.get("issue_number"),
                    "title": candidate.get("title"),
                    "html_url": candidate.get("html_url"),
                    "query_rrf_score": candidate.get("query_rrf_score"),
                    "bm25_score": candidate.get("bm25_score"),
                    "exact_identifier_score": candidate.get("exact_identifier_score"),
                    "matched_identifiers": ";".join(candidate.get("matched_identifiers") or []),
                    "minilm_cosine": candidate.get("minilm_cosine"),
                    "minilm_token_length": candidate.get("minilm_token_length"),
                    "minilm_truncated": candidate.get("minilm_truncated"),
                    "query_provenance": _provenance_text(candidate.get("provenance") or []),
                }
            )
        for arm, rankings in (result.get("arms") or {}).items():
            for raw_ranking in rankings:
                ranking = dict(raw_ranking)
                candidate = candidates.get(ranking.get("candidate_key"), {})
                arm_rows.append(
                    {
                        "instance_id": instance_id,
                        "repo": repo,
                        "arm": arm,
                        **ranking,
                        "issue_number": candidate.get("issue_number"),
                        "title": candidate.get("title"),
                        "html_url": candidate.get("html_url"),
                    }
                )
        telemetry = result.get("minilm_telemetry") or {}
        arms = result.get("arms") or {}
        phase_candidates: dict[str, set[str]] = defaultdict(set)
        candidate_phases: dict[str, set[str]] = {}
        for key, candidate in candidates.items():
            phases = {
                str(row.get("phase") or "")
                for row in candidate.get("provenance") or []
                if str(row.get("phase") or "")
            }
            candidate_phases[str(key)] = phases
            for phase in phases:
                phase_candidates[phase].add(str(key))
        audited_phases = {
            str(row.get("phase") or "")
            for row in result.get("query_audit") or []
            if str(row.get("phase") or "")
        }
        for phase in sorted(audited_phases | set(phase_candidates)):
            phase_keys = phase_candidates.get(phase, set())
            contribution_rows.append(
                {
                    "instance_id": instance_id,
                    "repo": repo,
                    "phase": phase,
                    "candidate_count": len(phase_keys),
                    "unique_candidate_count": sum(
                        candidate_phases.get(key) == {phase} for key in phase_keys
                    ),
                }
            )
        audits = list(result.get("query_audit") or [])
        instance_rows.append(
            {
                "instance_id": instance_id,
                "repo": repo,
                "status": result.get("status"),
                "semantic_phases_planned": result.get("semantic_phases_planned", 0),
                "semantic_phases_executed": result.get("semantic_phases_executed", 0),
                "phases_planned": result.get(
                    "phases_planned", result.get("semantic_phases_planned", 0)
                ),
                "phases_executed": result.get(
                    "phases_executed", result.get("semantic_phases_executed", 0)
                ),
                "raw_candidates": result.get("raw_candidate_count", len(candidates)),
                "filter_rejections": sum(
                    int(value)
                    for value in (result.get("filter_rejection_counts") or {}).values()
                ),
                "unique_candidates": len(candidates),
                "query_pages": len(audits),
                "github_api_calls": sum(
                    int(row.get("github_api_calls") or 0) for row in audits
                ),
                "cache_hits": sum(bool(row.get("cache_hit")) for row in audits),
                "query_failures": sum(
                    row.get("status") == "search_failed" for row in audits
                ),
                "search_type_fallbacks": sum(
                    row.get("status")
                    in {"nonsemantic_fallback", "search_type_mismatch", "unclassified_search_type"}
                    for row in audits
                ),
                "current_token_length": telemetry.get("current_token_length", 0),
                "current_truncated": telemetry.get("current_truncated", False),
                "historical_truncated_count": telemetry.get("historical_truncated_count", 0),
                "embedding_elapsed_seconds": telemetry.get("embedding_elapsed_seconds", 0),
                "duplicate_query_candidates": sum(
                    len(candidate.get("provenance") or []) > 1
                    for candidate in candidates.values()
                ),
                "unique_query_candidates": sum(
                    candidate_phases.get(key) == {phase}
                    for phase, phase_keys in phase_candidates.items()
                    for key in phase_keys
                ),
                "rrf_vs_bm25_exact_jaccard": _arm_jaccard(
                    arms, "rrf", "rrf_bm25_exact"
                ),
                "rrf_vs_minilm_jaccard": _arm_jaccard(
                    arms, "rrf", "rrf_minilm"
                ),
                "rrf_vs_minilm_rank_correlation": _arm_rank_correlation(
                    arms, "rrf", "rrf_minilm"
                ),
                "rrf_vs_bm25_exact_rank_correlation": _arm_rank_correlation(
                    arms, "rrf", "rrf_bm25_exact"
                ),
                "rrf_vs_all_rank_correlation": _arm_rank_correlation(
                    arms, "rrf", "rrf_minilm_bm25_exact"
                ),
                "rrf_vs_all_jaccard": _arm_jaccard(
                    arms, "rrf", "rrf_minilm_bm25_exact"
                ),
                "elapsed_seconds": result.get("elapsed_seconds", 0),
                "error": result.get("error", ""),
            }
        )

    def summarize_quality(
        scope: str,
        repository: str,
        phase: str,
        search_type: str,
        rows: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        def summary(field: str) -> tuple[float, float]:
            values = [float(row.get(field) or 0.0) for row in rows]
            return (
                statistics.fmean(values) if values else 0.0,
                statistics.median(values) if values else 0.0,
            )

        def instance_mean_summary(field: str) -> tuple[float, float]:
            grouped: dict[str, list[float]] = defaultdict(list)
            for row in rows:
                grouped[str(row.get("instance_id") or "")].append(
                    float(row.get(field) or 0.0)
                )
            means = [statistics.fmean(values) for values in grouped.values()]
            return (
                statistics.fmean(means) if means else 0.0,
                statistics.median(means) if means else 0.0,
            )

        bm25_mean, bm25_median = summary("bm25_score")
        exact_mean, exact_median = summary("exact_identifier_score")
        minilm_mean, minilm_median = summary("minilm_cosine")
        bm25_instance_mean_mean, bm25_instance_mean_median = instance_mean_summary(
            "bm25_score"
        )
        minilm_instance_mean_mean, minilm_instance_mean_median = instance_mean_summary(
            "minilm_cosine"
        )
        rank_mean, rank_median = summary("rank_in_query")
        return {
            "scope": scope,
            "repo": repository,
            "phase": phase,
            "search_type": search_type,
            "candidate_occurrences": len(rows),
            "instances_with_candidates": len(
                {str(row.get("instance_id") or "") for row in rows}
            ),
            "github_rank_mean": rank_mean,
            "github_rank_median": rank_median,
            "bm25_score_mean": bm25_mean,
            "bm25_score_median": bm25_median,
            "bm25_instance_mean_mean": bm25_instance_mean_mean,
            "bm25_instance_mean_median": bm25_instance_mean_median,
            "exact_identifier_score_mean": exact_mean,
            "exact_identifier_score_median": exact_median,
            "minilm_cosine_mean": minilm_mean,
            "minilm_cosine_median": minilm_median,
            "minilm_instance_mean_mean": minilm_instance_mean_mean,
            "minilm_instance_mean_median": minilm_instance_mean_median,
        }

    by_repo_phase: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    by_phase: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for observation in quality_observations:
        repo_phase_key = (
            str(observation["repo"]),
            str(observation["phase"]),
            str(observation["search_type"]),
        )
        by_repo_phase[repo_phase_key].append(observation)
        by_phase[(repo_phase_key[1], repo_phase_key[2])].append(observation)
    query_quality_rows = [
        summarize_quality("repository", repo, phase, mode, by_repo_phase.get((repo, phase, mode), []))
        for repo, phase, mode in sorted(declared_query_groups | set(by_repo_phase))
    ]
    for phase, mode in sorted(
        {(phase, mode) for _, phase, mode in declared_query_groups} | set(by_phase)
    ):
        query_quality_rows.append(
            summarize_quality("overall", "ALL", phase, mode, by_phase.get((phase, mode), []))
        )

    repository_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in instance_rows:
        repository_groups[str(row["repo"])].append(row)
    repository_rows = []
    for repo, rows in sorted(repository_groups.items()):
        repo_candidates = [row for row in candidate_rows if row["repo"] == repo]
        candidate_count = len(repo_candidates)
        current_lengths = [float(row["current_token_length"]) for row in rows]
        historical_lengths = [
            float(row.get("minilm_token_length") or 0) for row in repo_candidates
        ]
        repository_rows.append(
            {
                "repo": repo,
                "instances": len(rows),
                "completed": sum(row["status"] == "completed" for row in rows),
                "with_semantic_candidates": sum(int(row["unique_candidates"]) > 0 for row in rows),
                "unique_candidates": sum(int(row["unique_candidates"]) for row in rows),
                "semantic_phases_planned": sum(
                    int(row["semantic_phases_planned"]) for row in rows
                ),
                "semantic_phases_executed": sum(
                    int(row["semantic_phases_executed"]) for row in rows
                ),
                "query_failures": sum(int(row["query_failures"]) for row in rows),
                "search_type_fallbacks": sum(
                    int(row["search_type_fallbacks"]) for row in rows
                ),
                "github_api_calls": sum(int(row["github_api_calls"]) for row in rows),
                "cache_hits": sum(int(row["cache_hits"]) for row in rows),
                "elapsed_seconds": round(
                    sum(float(row["elapsed_seconds"]) for row in rows), 6
                ),
                "current_truncated": sum(bool(row["current_truncated"]) for row in rows),
                "historical_truncated": sum(int(row["historical_truncated_count"]) for row in rows),
                "current_truncation_rate": (
                    sum(bool(row["current_truncated"]) for row in rows) / len(rows)
                ),
                "historical_truncation_rate": (
                    sum(int(row["historical_truncated_count"]) for row in rows)
                    / candidate_count
                    if candidate_count
                    else 0.0
                ),
                "embedding_elapsed_seconds": round(
                    sum(float(row["embedding_elapsed_seconds"]) for row in rows), 6
                ),
                "duplicate_query_candidates": sum(
                    int(row["duplicate_query_candidates"]) for row in rows
                ),
                "unique_query_candidates": sum(
                    int(row["unique_query_candidates"]) for row in rows
                ),
                "mean_rrf_vs_minilm_jaccard": round(
                    sum(float(row["rrf_vs_minilm_jaccard"]) for row in rows) / len(rows), 6
                ),
                "mean_rrf_vs_bm25_exact_jaccard": statistics.fmean(
                    float(row["rrf_vs_bm25_exact_jaccard"]) for row in rows
                ),
                "mean_rrf_vs_all_jaccard": statistics.fmean(
                    float(row["rrf_vs_all_jaccard"]) for row in rows
                ),
                "mean_rrf_vs_minilm_rank_correlation": round(
                    sum(float(row["rrf_vs_minilm_rank_correlation"]) for row in rows)
                    / len(rows),
                    6,
                ),
                "mean_rrf_vs_bm25_exact_rank_correlation": statistics.fmean(
                    float(row["rrf_vs_bm25_exact_rank_correlation"]) for row in rows
                ),
                "mean_rrf_vs_all_rank_correlation": statistics.fmean(
                    float(row["rrf_vs_all_rank_correlation"]) for row in rows
                ),
                "phase_mismatch_instances": sum(
                    int(row["semantic_phases_planned"]) != int(row["semantic_phases_executed"])
                    for row in rows
                ),
                **_numeric_summary(current_lengths, "current_tokens"),
                **_numeric_summary(historical_lengths, "historical_tokens"),
                **_numeric_summary(
                    [float(row.get("query_rrf_score") or 0) for row in repo_candidates],
                    "query_rrf",
                ),
                **_numeric_summary(
                    [float(row.get("bm25_score") or 0) for row in repo_candidates],
                    "bm25",
                ),
                **_numeric_summary(
                    [float(row.get("exact_identifier_score") or 0) for row in repo_candidates],
                    "exact_identifier",
                ),
                **_numeric_summary(
                    [float(row.get("minilm_cosine") or 0) for row in repo_candidates],
                    "minilm_cosine",
                ),
            }
        )

    _write_tsv(
        output_dir / "run_metadata.tsv",
        ["key", "value"],
        [
            {"key": key, "value": value}
            for key, value in sorted((run_metadata or {}).items())
        ],
    )
    _write_tsv(
        output_dir / "query_audit.tsv",
        [
            "instance_id", "repo", "phase", "phase_index", "query_variant",
            "query_text", "github_query", "page", "requested_search_type",
            "actual_search_type", "search_type_fallback", "eligible_search_response",
            "eligible_semantic_response",
            "status", "query_error", "raw_items", "total_count", "accepted_items", "cache_hit",
            "github_api_calls",
        ],
        query_rows,
    )
    _write_tsv(
        output_dir / "filter_audit.tsv",
        ["instance_id", "repo", "candidate_key", "accepted", "reason", "source", "details"],
        filter_rows,
    )
    _write_tsv(
        output_dir / "query_quality.tsv",
        [
            "scope", "repo", "phase", "search_type", "candidate_occurrences",
            "instances_with_candidates", "github_rank_mean", "github_rank_median",
            "bm25_score_mean", "bm25_score_median", "exact_identifier_score_mean",
            "exact_identifier_score_median", "minilm_cosine_mean", "minilm_cosine_median",
            "bm25_instance_mean_mean", "bm25_instance_mean_median",
            "minilm_instance_mean_mean", "minilm_instance_mean_median",
        ],
        query_quality_rows,
    )
    _write_tsv(
        output_dir / "query_contributions.tsv",
        ["instance_id", "repo", "phase", "candidate_count", "unique_candidate_count"],
        contribution_rows,
    )
    _write_tsv(
        output_dir / "candidate_provenance.tsv",
        [
            "instance_id", "repo", "candidate_key", "issue_number", "phase",
            "phase_index", "query_variant", "query_text", "github_query", "page",
            "rank_in_query", "requested_search_type", "actual_search_type",
            "search_type_fallback", "response_status", "query_error",
        ],
        provenance_rows,
    )
    _write_tsv(
        output_dir / "candidate_scores.tsv",
        [
            "instance_id", "repo", "candidate_key", "issue_number", "title", "html_url",
            "query_rrf_score", "bm25_score", "exact_identifier_score", "matched_identifiers",
            "minilm_cosine", "minilm_token_length", "minilm_truncated", "query_provenance",
        ],
        candidate_rows,
    )
    _write_tsv(
        output_dir / "arm_rankings.tsv",
        [
            "instance_id", "repo", "arm", "rank", "candidate_key", "issue_number", "title",
            "html_url", "fusion_score", "query_rrf_score", "bm25_score",
            "exact_identifier_score", "minilm_cosine",
        ],
        arm_rows,
    )
    _write_tsv(
        output_dir / "instances.tsv",
        [
            "instance_id", "repo", "status", "semantic_phases_planned",
            "semantic_phases_executed", "phases_planned", "phases_executed",
            "raw_candidates", "filter_rejections", "unique_candidates", "query_pages",
            "github_api_calls", "cache_hits", "query_failures", "search_type_fallbacks",
            "current_token_length", "current_truncated", "historical_truncated_count",
            "embedding_elapsed_seconds", "duplicate_query_candidates", "unique_query_candidates",
            "rrf_vs_bm25_exact_jaccard", "rrf_vs_minilm_jaccard", "rrf_vs_all_jaccard",
            "rrf_vs_minilm_rank_correlation", "rrf_vs_bm25_exact_rank_correlation",
            "rrf_vs_all_rank_correlation",
            "elapsed_seconds", "error",
        ],
        instance_rows,
    )
    _write_tsv(
        output_dir / "repositories.tsv",
        [
            "repo", "instances", "completed", "with_semantic_candidates", "unique_candidates",
            "semantic_phases_planned", "semantic_phases_executed", "query_failures",
            "search_type_fallbacks", "github_api_calls", "cache_hits", "elapsed_seconds",
            "current_truncated", "historical_truncated", "current_truncation_rate",
            "historical_truncation_rate", "phase_mismatch_instances",
            "embedding_elapsed_seconds", "duplicate_query_candidates", "unique_query_candidates",
            "mean_rrf_vs_minilm_jaccard", "mean_rrf_vs_bm25_exact_jaccard",
            "mean_rrf_vs_all_jaccard", "mean_rrf_vs_minilm_rank_correlation",
            "mean_rrf_vs_bm25_exact_rank_correlation", "mean_rrf_vs_all_rank_correlation",
            "current_tokens_min", "current_tokens_median", "current_tokens_mean", "current_tokens_max",
            "historical_tokens_min", "historical_tokens_median", "historical_tokens_mean", "historical_tokens_max",
            "query_rrf_min", "query_rrf_median", "query_rrf_mean", "query_rrf_max",
            "bm25_min", "bm25_median", "bm25_mean", "bm25_max",
            "exact_identifier_min", "exact_identifier_median", "exact_identifier_mean", "exact_identifier_max",
            "minilm_cosine_min", "minilm_cosine_median", "minilm_cosine_mean", "minilm_cosine_max",
        ],
        repository_rows,
    )

    completed = sum(row["status"] == "completed" for row in instance_rows)
    with_candidates = sum(int(row["unique_candidates"]) > 0 for row in instance_rows)
    mean_rrf_minilm_overlap = (
        sum(float(row["rrf_vs_minilm_jaccard"]) for row in instance_rows)
        / len(instance_rows)
        if instance_rows
        else 0.0
    )
    total_api_calls = sum(int(row["github_api_calls"]) for row in instance_rows)
    total_cache_hits = sum(int(row["cache_hits"]) for row in instance_rows)
    total_query_failures = sum(int(row["query_failures"]) for row in instance_rows)
    total_fallbacks = sum(int(row["search_type_fallbacks"]) for row in instance_rows)
    highlighted_repos = {
        "element-hq/element-web",
        "flipt-io/flipt",
        "navidrome/navidrome",
        "protonmail/webclients",
    }
    highlighted_lines = [
        "| Repository | Instances | With candidates | Candidates | Fallbacks |",
        "| --- | ---: | ---: | ---: | ---: |",
        *(
            f"| {row['repo']} | {row['instances']} | "
            f"{row['with_semantic_candidates']} | {row['unique_candidates']} | "
            f"{row['search_type_fallbacks']} |"
            for row in repository_rows
            if str(row["repo"]).casefold() in highlighted_repos
        ),
    ]
    report = "\n".join(
        [
            "# Semantic Reranking Experiment",
            "",
            "## Reproducibility",
            "",
            *(
                f"- {key}: {value}"
                for key, value in sorted((run_metadata or {}).items())
            ),
            "",
            "## Run integrity",
            "",
            f"- Instances recorded: {len(instance_rows)}",
            f"- Completed: {completed}",
            f"- With at least one filtered historical candidate: {with_candidates}",
            f"- Query audit rows: {len(query_rows)}",
            f"- GitHub API request attempts: {total_api_calls}",
            f"- Search cache hits: {total_cache_hits}",
            f"- Query failures: {total_query_failures}",
            f"- Search-type fallbacks or unclassified responses: {total_fallbacks}",
            f"- Unique instance-candidate rows: {len(candidate_rows)}",
            "",
            "## Arm overlap",
            "",
            f"- Mean RRF versus RRF+MiniLM top-k Jaccard: {mean_rrf_minilm_overlap:.4f}",
            "",
            "## Previously poor repositories",
            "",
            *highlighted_lines,
            "",
            "## Raw score distributions",
            "",
            f"- Query RRF: {_score_summary(candidate_rows, 'query_rrf_score')}",
            f"- BM25: {_score_summary(candidate_rows, 'bm25_score')}",
            f"- Exact identifiers: {_score_summary(candidate_rows, 'exact_identifier_score')}",
            f"- MiniLM cosine: {_score_summary(candidate_rows, 'minilm_cosine')}",
            "",
            "## Scope limitation",
            "",
            "This experiment applies deterministic pre-review filters but does not run the LLM review gate; it therefore cannot establish review-gate improvement.",
            "",
        ]
    )
    (output_dir / "semantic_reranking_experiment_report.md").write_text(
        report,
        encoding="utf-8",
    )
