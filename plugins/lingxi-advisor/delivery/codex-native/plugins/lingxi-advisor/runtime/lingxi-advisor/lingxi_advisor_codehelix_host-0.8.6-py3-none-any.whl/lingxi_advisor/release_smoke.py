from __future__ import annotations

import argparse
import asyncio
import importlib.metadata
import json
import subprocess
import sys
import tempfile
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Mapping

from . import __version__
from .adapters.mcp.gateway import MCPServerPolicy
from .adapters.mcp.operator_tools import OPERATOR_TOOLS
from .adapters.mcp.server import create_mcp_server
from .adapters.mcp.runtime_tools import RUNTIME_TOOLS, _register_runtime_tools
from .artifacts import (
    FilesystemKnowledgeArtifactStore,
    KnowledgeArtifact,
    KnowledgeArtifactRef,
)
from .capabilities.activate.lingxi_advisor_apply import LingxiAdvisorActivationApply
from .capabilities.activate.lingxi_advisor_search import KnowledgeMatch
from .config import ServerSettings
from .internal.generation_contracts import (
    GenerationMode,
    validate_generation_mode,
)
from .internal.grounded_analysis.analyst import ANALYST_TAGS
from .internal.grounded_analysis.summarizer import SUMMARY_TAGS
from .internal.io_utils import write_jsonl_atomic
from .internal.search_retrieval.contracts import SWEbenchProInstance


class ReleaseSmokeError(RuntimeError):
    pass


def _real_progress(message: str) -> None:
    print(f'[real-acceptance] {message}', file=sys.stderr, flush=True)


_FORBIDDEN_REAL_INSTANCE_FIELDS = frozenset(
    {
        "patch",
        "target_patch",
        "test_patch",
        "gold_patch",
        "hidden_tests",
        "api_key",
        "credentials",
        "server_path",
    }
)


class _StaticActivation:
    def __init__(self, match: KnowledgeMatch) -> None:
        self._match = match

    def search(self, request: Any) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "status": "completed",
            "instance_id": request.instance_id,
            "generation_mode": request.generation_mode,
            "prepare_if_missing": True,
            "retrieval_status": "completed",
            "retrieval_source": "release_smoke",
            "selected_count": 1,
            "rejected_count": 0,
            "completed_count": 1,
            "cache_hit_count": 1,
            "generated_count": 0,
            "missing_count": 0,
            "failed_count": 0,
            "knowledge_matches": [self._match.to_dict()],
            "unresolved_knowledge": [],
            "error": None,
        }


def _mcp_sdk() -> tuple[Any, Any]:
    try:
        from mcp.server.fastmcp import FastMCP
        from mcp.server.fastmcp.server import Settings as FastMCPSettings
        from mcp.shared.memory import create_connected_server_and_client_session
    except ImportError as exc:  # pragma: no cover - release installs [mcp]
        raise ReleaseSmokeError(
            "release validation requires the official MCP Python SDK; "
            "install the lingxi_advisor[mcp] extra"
        ) from exc
    try:
        FastMCPSettings.model_rebuild()
    except (AttributeError, NameError, TypeError):
        pass
    return FastMCP, create_connected_server_and_client_session


@asynccontextmanager
async def _connect_sampling_tools_host(
    host: Any,
    *,
    sampling_callback: Any,
    raise_exceptions: bool,
) -> AsyncIterator[Any]:
    try:
        import anyio
        from mcp import types
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
    except ImportError as exc:  # pragma: no cover - release installs [mcp]
        raise ReleaseSmokeError(
            'host sampling acceptance requires the lingxi_advisor[mcp] extra'
        ) from exc

    server = getattr(host, '_mcp_server', host)
    async with create_client_server_memory_streams() as (
        client_streams,
        server_streams,
    ):
        client_read, client_write = client_streams
        server_read, server_write = server_streams
        async with anyio.create_task_group() as task_group:
            task_group.start_soon(
                lambda: server.run(
                    server_read,
                    server_write,
                    server.create_initialization_options(),
                    raise_exceptions=raise_exceptions,
                )
            )
            try:
                async with ClientSession(
                    read_stream=client_read,
                    write_stream=client_write,
                    sampling_callback=sampling_callback,
                    sampling_capabilities=types.SamplingCapability(
                        tools=types.SamplingToolsCapability()
                    ),
                ) as session:
                    await session.initialize()
                    yield session
            finally:
                task_group.cancel_scope.cancel()


@asynccontextmanager
async def _connect_stdio_tools_host(
    *,
    args: list[str],
    cwd: Path,
) -> AsyncIterator[Any]:
    try:
        from mcp.client.session import ClientSession
        from mcp.client.stdio import StdioServerParameters, stdio_client
    except ImportError as exc:  # pragma: no cover - release installs [mcp]
        raise ReleaseSmokeError(
            'stdio acceptance requires the lingxi_advisor[mcp] extra'
        ) from exc

    parameters = StdioServerParameters(
        command=sys.executable,
        args=args,
        cwd=cwd,
    )
    async with stdio_client(parameters) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            yield session


def _structured_content(result: Any, *, tool_name: str) -> dict[str, Any]:
    if bool(getattr(result, "isError", False)):
        raise ReleaseSmokeError(f"{tool_name} returned an MCP error")
    value = getattr(result, "structuredContent", None)
    if not isinstance(value, Mapping):
        raise ReleaseSmokeError(
            f"{tool_name} did not return structured MCP content"
        )
    return dict(value)


def _runtime_host(
    *,
    activation: Any,
    apply_capability: Any,
    policy: MCPServerPolicy,
    settings: ServerSettings | None = None,
) -> Any:
    FastMCP, _ = _mcp_sdk()
    host = FastMCP("LingxiAdvisor release acceptance")
    _register_runtime_tools(
        host,
        activation=activation,
        apply_capability=apply_capability,
        policy=policy,
        settings=settings,
    )
    return host


async def _list_runtime_tools(session: Any) -> list[str]:
    response = await session.list_tools()
    names = [item.name for item in response.tools]
    if set(names) != set(RUNTIME_TOOLS) or len(names) != len(RUNTIME_TOOLS):
        raise ReleaseSmokeError(
            "mounted Runtime Tool Set differs from the extension contract: "
            + ", ".join(names)
        )
    return list(RUNTIME_TOOLS)


async def _list_operator_tools(session: Any) -> list[str]:
    response = await session.list_tools()
    names = [item.name for item in response.tools]
    if set(names) != set(OPERATOR_TOOLS) or len(names) != len(OPERATOR_TOOLS):
        raise ReleaseSmokeError(
            'mounted Operator Tool Set differs from the extension contract: '
            + ', '.join(names)
        )
    return list(OPERATOR_TOOLS)


def _string_content(result: Any, *, tool_name: str) -> str:
    if bool(getattr(result, 'isError', False)):
        raise ReleaseSmokeError(f'{tool_name} returned an MCP error')
    structured = getattr(result, 'structuredContent', None)
    if isinstance(structured, Mapping):
        for key in ('result', 'content', 'value'):
            value = structured.get(key)
            if isinstance(value, str):
                return value
    for block in getattr(result, 'content', ()) or ():
        value = getattr(block, 'text', None)
        if isinstance(value, str):
            return value
    raise ReleaseSmokeError(f'{tool_name} did not return string content')


def run_release_smoke(bundle_root: str | Path) -> dict[str, Any]:
    """Validate the installed package, descriptors, MCP mount, Search, and Apply."""

    distribution = importlib.metadata.distribution("lingxi_advisor")
    packaged_paths = {
        str(item).replace("\\", "/") for item in (distribution.files or ())
    }
    if any(
        path.startswith("historical_knowledge_gate/")
        for path in packaged_paths
    ):
        raise ReleaseSmokeError(
            "the lingxi_advisor wheel contains the removed legacy package"
        )

    with tempfile.TemporaryDirectory(prefix="lingxi_advisor-release-smoke-") as raw:
        temp = Path(raw)
        store = FilesystemKnowledgeArtifactStore(temp / "artifacts")
        ref = KnowledgeArtifactRef(
            generation_mode="light",
            knowledge_cache_key="release-smoke-issue-1",
        )
        artifact = KnowledgeArtifact(
            ref=ref,
            knowledge_xml=(
                "<historical_knowledge>"
                "<fine_grained_analysis>"
                "<root_cause>validated release smoke evidence</root_cause>"
                "</fine_grained_analysis>"
                "<general_summary>"
                "<general_fix_pattern>verify the current code</general_fix_pattern>"
                "</general_summary>"
                "</historical_knowledge>"
            ),
            historical_candidate_fingerprint="release-smoke-candidate",
            historical_patch_sha256="1" * 64,
            template_version="release-smoke-v1",
            generator_model="release-smoke",
        )
        store.store(artifact)
        match = KnowledgeMatch(
            artifact_ref=ref,
            knowledge_xml=artifact.knowledge_xml,
            artifact_sha256=str(artifact.artifact_sha256),
            repo="lingxi_advisor/release-smoke",
            historical_issue_number=1,
            historical_issue_url=(
                "https://github.com/lingxi_advisor/release-smoke/issues/1"
            ),
            historical_issue_title="Release smoke issue",
            historical_candidate_fingerprint=(
                artifact.historical_candidate_fingerprint
            ),
            cache_hit=True,
        )
        host = _runtime_host(
            activation=_StaticActivation(match),
            apply_capability=LingxiAdvisorActivationApply(
                artifact_store=store,
                assembly_root=temp / "assembly",
            ),
            policy=MCPServerPolicy(),
        )
        _, connect = _mcp_sdk()

        async def exercise() -> tuple[list[str], dict[str, Any], dict[str, Any]]:
            async with connect(host, raise_exceptions=True) as session:
                tools = await _list_runtime_tools(session)
                search_call = await session.call_tool(
                    "lingxi.advisor.search",
                    {"issue_description": "Release smoke current issue"},
                )
                search = _structured_content(
                    search_call,
                    tool_name="lingxi.advisor.search",
                )
                apply_call = await session.call_tool(
                    "lingxi.advisor.apply",
                    {
                        "issue_description": "Release smoke current issue",
                        "knowledge_matches": search["knowledge_matches"],
                    },
                )
                apply = _structured_content(
                    apply_call,
                    tool_name="lingxi.advisor.apply",
                )
                return tools, search, apply

        runtime_tools, search_result, apply_result = asyncio.run(exercise())
        if search_result.get("status") != "completed":
            raise ReleaseSmokeError("minimal lingxi.advisor.search failed")
        if apply_result.get("status") != "completed":
            raise ReleaseSmokeError("minimal lingxi.advisor.apply failed")
        if apply_result.get("source_artifact_refs") != [ref.to_dict()]:
            raise ReleaseSmokeError(
                "Apply did not preserve the source Artifact Ref"
            )

    return {
        "status": "completed",
        "version": __version__,
        "runtime_tools": runtime_tools,
        "search_status": search_result["status"],
        "apply_status": apply_result["status"],
        "source_artifact_refs": apply_result["source_artifact_refs"],
    }


def _real_acceptance_settings(project_root: Any) -> ServerSettings:
    root = Path(project_root).expanduser().resolve()
    settings = ServerSettings(
        project_root=root,
        cache_root=root / "cache",
        output_root=root / "outputs",
        batch_input_path=root / "examples" / "instances.jsonl",
    ).resolved()
    missing = []
    if not settings.github_tokens:
        missing.append("GITHUB_TOKEN")
    if not settings.judge_api_key:
        missing.append("LINGXI_ADVISOR_JUDGE_API_KEY")
    if not settings.judge_base_url:
        missing.append("LINGXI_ADVISOR_JUDGE_BASE_URL")
    if not settings.judge_model:
        missing.append("LINGXI_ADVISOR_JUDGE_MODEL")
    if not settings.generator_api_key:
        missing.append("LINGXI_ADVISOR_GENERATOR_API_KEY")
    if not settings.generator_base_url:
        missing.append("LINGXI_ADVISOR_GENERATOR_BASE_URL")
    if not settings.generator_model:
        missing.append("LINGXI_ADVISOR_GENERATOR_MODEL")
    if missing:
        raise ReleaseSmokeError(
            "missing real acceptance configuration: " + ", ".join(missing)
        )
    return settings


def _require_real_search(result: Mapping[str, Any], *, first: bool) -> None:
    ordinal = "first" if first else "second"
    status = str(result.get("status") or "")
    if status not in {"completed", "partial"}:
        raise ReleaseSmokeError(
            f"{ordinal} real search did not complete: "
            + str(result.get("error") or status)
        )
    matches = result.get("knowledge_matches")
    if not isinstance(matches, list) or not matches:
        raise ReleaseSmokeError(
            f"{ordinal} real search returned no sourced Artifact"
        )
    generated = int(result.get("generated_count") or 0)
    cache_hits = int(result.get("cache_hit_count") or 0)
    if first and (generated < 1 or cache_hits != 0):
        raise ReleaseSmokeError(
            "first real search did not generate a fresh sourced Artifact"
        )
    if not first and (generated != 0 or cache_hits < 1):
        raise ReleaseSmokeError(
            "second real search did not reuse the first-call Artifact"
        )


def _match_identity(match: Mapping[str, Any]) -> tuple[Any, Any, Any]:
    return (
        match.get("artifact_ref"),
        match.get("artifact_sha256"),
        match.get("knowledge_xml"),
    )


async def _call_real_apply(
    session: Any,
    *,
    instance: SWEbenchProInstance,
    result: Mapping[str, Any],
) -> dict[str, Any]:
    matches = result.get("knowledge_matches")
    if not isinstance(matches, list):
        raise ReleaseSmokeError("real search knowledge_matches is not a list")
    call = await session.call_tool(
        "lingxi.advisor.apply",
        {
            "issue_description": instance.problem_statement,
            "knowledge_matches": matches,
        },
    )
    applied = _structured_content(call, tool_name="lingxi.advisor.apply")
    if str(applied.get("status") or "") not in {"completed", "partial"}:
        raise ReleaseSmokeError(
            "real Apply did not complete: "
            + str(applied.get("error") or applied.get("status"))
        )
    refs = applied.get("source_artifact_refs")
    if not isinstance(refs, list) or not refs:
        raise ReleaseSmokeError("real Apply did not retain Artifact refs")
    return applied


def run_real_release_acceptance(
    bundle_root: str | Path,
    instance: Mapping[str, Any],
    *,
    project_root: str | Path,
    generation_mode: str = "light",
) -> dict[str, Any]:
    """Exercise the real two-call flow through installed Runtime MCP tools."""

    run_release_smoke(bundle_root)
    mode: GenerationMode = validate_generation_mode(generation_mode)
    forbidden = sorted(
        str(key)
        for key in instance
        if str(key).strip().lower() in _FORBIDDEN_REAL_INSTANCE_FIELDS
    )
    if forbidden:
        raise ReleaseSmokeError(
            "real release acceptance requires public-only input; remove: "
            + ", ".join(forbidden)
        )
    normalized = SWEbenchProInstance.from_mapping(instance)
    settings = _real_acceptance_settings(project_root)
    root = settings.project_root
    policy = MCPServerPolicy(
        allow_live_search=True,
        allow_update_preretrieved=True,
        allow_clone=mode == "grounded_analysis",
        allow_fetch=mode == "grounded_analysis",
    )
    preretrieved_dir = root / "preretrieved"
    knowledge_cache_dir = root / "knowledge"
    write_jsonl_atomic(
        root / "examples" / "instances.jsonl",
        [normalized.public_dict()],
    )
    host = create_mcp_server(
        profile="runtime",
        settings=settings,
        policy=policy,
        preretrieved_dir=preretrieved_dir,
        knowledge_cache_dir=knowledge_cache_dir,
    )
    _, connect = _mcp_sdk()
    assert settings.cache_root is not None
    assert settings.output_root is not None
    assert settings.repository_root is not None
    assert settings.historical_worktree_root is not None
    assert settings.batch_input_path is not None
    operator_args = [
        '-m',
        'lingxi_advisor.adapters.mcp.server',
        '--profile',
        'operator',
        '--transport',
        'stdio',
        '--project-root',
        str(root),
        '--preretrieved-dir',
        str(preretrieved_dir),
        '--knowledge-cache-dir',
        str(knowledge_cache_dir),
        '--cache-root',
        str(settings.cache_root),
        '--output-root',
        str(settings.output_root),
        '--repository-root',
        str(settings.repository_root),
        '--historical-worktree-root',
        str(settings.historical_worktree_root),
        '--batch-input',
        str(settings.batch_input_path),
        '--allow-update-preretrieved',
    ]
    if mode == 'grounded_analysis':
        operator_args.extend(('--allow-clone', '--allow-fetch'))
    if not settings.verify_ssl:
        operator_args.append('--disable-ssl-verify')
    if not settings.trust_env:
        operator_args.append('--no-trust-env')
    search_arguments = {
        "issue_description": normalized.problem_statement,
        "context": normalized.public_dict(),
        "generation_mode": mode,
        "search_candidate_count": 3,
        "final_top_k": 1,
        "update_preretrieved": True,
    }

    async def exercise() -> dict[str, Any]:
        async with connect(host, raise_exceptions=True) as session:
            runtime_tools = await _list_runtime_tools(session)
            _real_progress(f'{mode}: Runtime first Search started')
            first_call = await session.call_tool(
                "lingxi.advisor.search",
                search_arguments,
            )
            first = _structured_content(
                first_call,
                tool_name="lingxi.advisor.search",
            )
            _require_real_search(first, first=True)
            first_apply = await _call_real_apply(
                session,
                instance=normalized,
                result=first,
            )
            _real_progress(f'{mode}: Runtime first Search/Apply completed')

            second_arguments = {
                **search_arguments,
                "update_preretrieved": False,
            }
            _real_progress(f'{mode}: Runtime cache-only Search started')
            second_call = await session.call_tool(
                "lingxi.advisor.search",
                second_arguments,
            )
            second = _structured_content(
                second_call,
                tool_name="lingxi.advisor.search",
            )
            _require_real_search(second, first=False)
            first_match = first["knowledge_matches"][0]
            second_match = second["knowledge_matches"][0]
            if not isinstance(first_match, Mapping) or not isinstance(
                second_match, Mapping
            ):
                raise ReleaseSmokeError(
                    "real search returned an invalid knowledge match"
                )
            if _match_identity(second_match) != _match_identity(first_match):
                raise ReleaseSmokeError(
                    "second real search returned a different Artifact"
                )
            second_apply = await _call_real_apply(
                session,
                instance=normalized,
                result=second,
            )
            if second_apply["source_artifact_refs"] != first_apply[
                "source_artifact_refs"
            ]:
                raise ReleaseSmokeError(
                    "second real Apply did not retain the same Artifact refs"
                )
            _real_progress(f'{mode}: Runtime cache reuse completed')
            runtime_result = {
                "runtime_tools": runtime_tools,
                "first": first,
                "second": second,
                "second_apply": second_apply,
            }

        terminal_statuses = {
            "completed",
            "completed_with_failures",
            "stopped",
            "failed",
        }
        _real_progress(f'{mode}: Operator batch started')
        async with _connect_stdio_tools_host(
            args=operator_args,
            cwd=root,
        ) as session:
            operator_tools = await _list_operator_tools(session)
            start_call = await session.call_tool(
                "lingxi.advisor.start_preparation_batch",
                {
                    "generation_mode": mode,
                    "search_candidate_count": 3,
                    "final_top_k": 1,
                    "resume": True,
                    "continue_on_error": False,
                },
            )
            batch = _structured_content(
                start_call,
                tool_name="lingxi.advisor.start_preparation_batch",
            )
            batch_id = str(batch.get("batch_id") or "")
            if not batch_id:
                raise ReleaseSmokeError(
                    "real Operator batch returned no batch_id"
                )
            observed_statuses = [str(batch.get("status") or "")]
            _real_progress(
                f'{mode}: Operator batch_id={batch_id} status='
                + observed_statuses[-1]
            )
            deadline = asyncio.get_running_loop().time() + 900
            while str(batch.get("status") or "") not in terminal_statuses:
                if asyncio.get_running_loop().time() >= deadline:
                    raise ReleaseSmokeError(
                        "real Operator batch did not reach a terminal status"
                    )
                await asyncio.sleep(0.1)
                batch_call = await session.call_tool(
                    "lingxi.advisor.get_preparation_batch",
                    {"batch_id": batch_id, "offset": 0, "limit": 50},
                )
                batch = _structured_content(
                    batch_call,
                    tool_name="lingxi.advisor.get_preparation_batch",
                )
                current = str(batch.get("status") or "")
                if not observed_statuses or current != observed_statuses[-1]:
                    observed_statuses.append(current)
            if batch.get("status") != "completed":
                raise ReleaseSmokeError(
                    "real Operator batch failed: "
                    + str(batch.get("error") or batch.get("status"))
                )
            if "running" not in observed_statuses:
                raise ReleaseSmokeError(
                    "real Operator batch never exposed running status"
                )
            _real_progress(
                f'{mode}: Operator batch terminal status='
                + str(batch.get("status"))
            )
            items = batch.get("items")
            if not isinstance(items, list) or len(items) != 1:
                raise ReleaseSmokeError(
                    "real Operator batch did not return exactly one item"
                )
            request_id = str(items[0].get("request_id") or "")
            if not request_id:
                raise ReleaseSmokeError(
                    "real Operator batch item returned no request_id"
                )
            result_call = await session.call_tool(
                "lingxi.advisor.get_preparation_result",
                {"request_id": request_id},
            )
            prepared = _structured_content(
                result_call,
                tool_name="lingxi.advisor.get_preparation_result",
            )
            if str(prepared.get("status") or "") not in {
                "completed",
                "partial",
            }:
                raise ReleaseSmokeError(
                    "real Operator result did not complete: "
                    + str(prepared.get("error") or prepared.get("status"))
                )
            artifacts = prepared.get("knowledge_artifacts")
            if not isinstance(artifacts, list) or not artifacts:
                raise ReleaseSmokeError(
                    "real Operator result published no Artifact"
                )
            artifact_name = str(artifacts[0].get("artifact_name") or "")
            read_call = await session.call_tool(
                "lingxi.advisor.read_prepared_knowledge",
                {
                    "request_id": request_id,
                    "artifact_name": artifact_name,
                },
            )
            knowledge_xml = _string_content(
                read_call,
                tool_name="lingxi.advisor.read_prepared_knowledge",
            )
            if "<historical_knowledge>" not in knowledge_xml:
                raise ReleaseSmokeError(
                    "real Operator read returned invalid knowledge XML"
                )
            _real_progress(f'{mode}: Operator result/read completed')

        return {
            **runtime_result,
            "operator": {
                "tools": operator_tools,
                "batch_id": batch_id,
                "observed_statuses": observed_statuses,
                "request_id": request_id,
                "result_status": prepared["status"],
                "artifact_name": artifact_name,
                "knowledge_xml_chars": len(knowledge_xml),
            },
        }

    result = asyncio.run(exercise())
    first = result["first"]
    second = result["second"]
    second_apply = result["second_apply"]
    return {
        "status": "completed",
        "version": __version__,
        "generation_mode": mode,
        "runtime_tools": result["runtime_tools"],
        "first_generated_count": int(first.get("generated_count") or 0),
        "first_cache_hit_count": int(first.get("cache_hit_count") or 0),
        "second_generated_count": int(second.get("generated_count") or 0),
        "second_cache_hit_count": int(second.get("cache_hit_count") or 0),
        "source_artifact_refs": second_apply["source_artifact_refs"],
        "operator": result["operator"],
    }


def _run_fixture_git(repository: Path, *args: str) -> str:
    result = subprocess.run(
        ['git', *args],
        cwd=repository,
        check=True,
        capture_output=True,
        text=True,
        encoding='utf-8',
    )
    return result.stdout.strip()


def _write_grounded_repository(project_root: Path) -> tuple[str, str]:
    repository = (
        project_root
        / 'repositories'
        / 'lingxi_advisor__host-sampling-fixture'
    )
    repository.mkdir(parents=True)
    _run_fixture_git(repository, 'init')
    _run_fixture_git(
        repository,
        'config',
        'user.email',
        'release-smoke@example.com',
    )
    _run_fixture_git(
        repository,
        'config',
        'user.name',
        'LingxiAdvisor Release Smoke',
    )
    _run_fixture_git(
        repository,
        'remote',
        'add',
        'origin',
        'https://github.com/lingxi_advisor/host-sampling-fixture.git',
    )
    source = repository / 'src' / 'dispatcher.py'
    source.parent.mkdir()
    source.write_text(
        'def dispatch(handler, request):\n'
        '    return handler(request)\n',
        encoding='utf-8',
    )
    _run_fixture_git(repository, 'add', 'src/dispatcher.py')
    _run_fixture_git(repository, 'commit', '-m', 'initial dispatcher')
    source.write_text(
        'def dispatch(handler, request):\n'
        '    if handler is None:\n'
        '        raise LookupError(\'handler is required\')\n'
        '    return handler(request)\n',
        encoding='utf-8',
    )
    _run_fixture_git(repository, 'add', 'src/dispatcher.py')
    _run_fixture_git(repository, 'commit', '-m', 'Guard missing handler')
    commit = _run_fixture_git(repository, 'rev-parse', 'HEAD')
    historical_patch = _run_fixture_git(
        repository,
        'show',
        '--format=',
        '--patch',
        'HEAD',
    )
    return commit, historical_patch


def _write_host_sampling_fixture(
    project_root: Path,
    *,
    generation_mode: GenerationMode,
) -> SWEbenchProInstance:
    '''Write public historical evidence that still exercises the real gate.'''

    instance = SWEbenchProInstance.from_mapping(
        {
            'repo': 'lingxi_advisor/host-sampling-fixture',
            'instance_id': 'host-sampling-runtime-1',
            'base_commit': '1' * 40,
            'problem_statement': (
                'The dispatcher crashes instead of returning a clear error '
                'when a required handler is missing.'
            ),
        }
    )
    historical_patch = (
        'diff --git a/src/dispatcher.py b/src/dispatcher.py\n'
        '--- a/src/dispatcher.py\n'
        '+++ b/src/dispatcher.py\n'
        '@@ -1,2 +1,4 @@\n'
        '+if handler is None:\n'
        '+    raise LookupError(\'handler is required\')\n'
        ' return handler(request)\n'
    )
    historical_commit = '2' * 40
    if generation_mode == 'grounded_analysis':
        historical_commit, historical_patch = _write_grounded_repository(
            project_root
        )
    candidate = {
        'instance_id': instance.instance_id,
        'repo': instance.repo,
        'retrieved_repo': instance.repo,
        'retrieved_issue_number': 17,
        'retrieved_issue_url': (
            'https://github.com/lingxi_advisor/host-sampling-fixture/issues/17'
        ),
        'retrieved_issue_title': 'Guard a missing dispatcher handler',
        'retrieved_issue_desc': (
            'Dispatch raised an opaque attribute error when the configured '
            'handler was absent.'
        ),
        'retrieved_issue_created_at': '2024-01-01T00:00:00Z',
        'retrieved_patch': historical_patch,
        'retrieved_issue_ground_truth_patch': historical_patch,
        'retrieved_commit_id': historical_commit,
        'retrieved_commit_ids': [historical_commit],
        'retrieved_metadata': {
            'repo': instance.repo,
            'issue_number': 17,
            'retrieved_commit_id': historical_commit,
            'retrieved_max_commit_created_at': '2024-02-01T00:00:00Z',
        },
        'leakage_rejection_passed': True,
        'leakage_decision': 'safe',
        'leakage_boundary_iso': '2025-01-01T00:00:00Z',
        'leakage_boundary_source': 'release_host_sampling_fixture',
        'retrieval_tier': 0,
        'github_rank_in_query': 1,
    }
    preretrieved = project_root / 'preretrieved'
    preretrieved.mkdir(parents=True, exist_ok=True)
    (preretrieved / 'host_sampling.jsonl').write_text(
        json.dumps(candidate, ensure_ascii=False) + '\n',
        encoding='utf-8',
    )
    return instance


def _light_host_sampling_responses() -> tuple[tuple[str, str], ...]:
    return (
        (
            'judge',
            json.dumps(
                {
                    'selected': True,
                    'similarity_score': 3,
                    'misleading_risk': 0,
                    'match_basis': [
                        'same_failure_mode',
                        'same_validation_strategy',
                    ],
                    'failure_mode_evidence': (
                        'Both issues fail when dispatch configuration omits '
                        'a required handler.'
                    ),
                    'repair_transfer_evidence': (
                        'Validate the missing handler before dereferencing it.'
                    ),
                    'localization_help': 'Inspect dispatcher handler lookup.',
                    'reason': 'The historical guard is directly transferable.',
                    'main_risk': 'Preserve the existing dispatch contract.',
                }
            ),
        ),
        (
            'light_fg1',
            (
                '<repository_hierarchy>dispatcher module</repository_hierarchy>'
                '<dependency_analysis>handler lookup precedes dispatch</dependency_analysis>'
                '<call_trace>dispatch -&gt; handler lookup -&gt; invoke</call_trace>'
            ),
        ),
        (
            'light_fg2',
            (
                '<bug_category>missing configuration guard</bug_category>'
                '<usage_context>request dispatch</usage_context>'
                '<root_cause>an absent handler was dereferenced</root_cause>'
                '<behavior_comparison>opaque crash became an explicit error</behavior_comparison>'
                '<fix_logic>validate before invocation</fix_logic>'
                '<fix_steps>add a null guard</fix_steps>'
                '<fix_checklist>preserve valid dispatch behavior</fix_checklist>'
                '<test_case>exercise missing and configured handlers</test_case>'
                '<conclusion>guard configuration boundaries</conclusion>'
            ),
        ),
        (
            'light_summary',
            (
                '<general_root_cause_analysis_steps>trace configuration lookup</general_root_cause_analysis_steps>'
                '<bug_categorization>missing dependency validation</bug_categorization>'
                '<relevant_architecture>dispatcher boundary</relevant_architecture>'
                '<involved_components>handler registry and dispatcher</involved_components>'
                '<specific_involved_classes_functions_methods>dispatch</specific_involved_classes_functions_methods>'
                '<feature_or_functionality_of_issue>request dispatch</feature_or_functionality_of_issue>'
                '<general_fix_pattern>validate dependencies before use</general_fix_pattern>'
                '<summary_of_fix_checklist>cover missing and valid configuration</summary_of_fix_checklist>'
                '<design_patterns_and_coding_practices>fail fast at boundaries</design_patterns_and_coding_practices>'
                '<additional_concepts>retain explicit provenance</additional_concepts>'
            ),
        ),
    )


def _host_knowledge_fragment(tags: tuple[str, ...]) -> str:
    return ''.join(
        f'<{tag}>Grounded evidence for {tag}.</{tag}>'
        for tag in tags
    )


def _host_sampling_responses(
    generation_mode: GenerationMode,
) -> tuple[tuple[str, str], ...]:
    light = _light_host_sampling_responses()
    if generation_mode == 'light':
        return light
    return (
        light[0],
        ('grounded_tool', ''),
        ('grounded_analysis', _host_knowledge_fragment(ANALYST_TAGS)),
        ('grounded_summary', _host_knowledge_fragment(SUMMARY_TAGS)),
    )


def run_host_sampling_release_acceptance(
    bundle_root: str | Path,
    *,
    project_root: str | Path,
    generation_mode: str = 'light',
) -> dict[str, Any]:
    '''Prove unconfigured Activation through real MCP host sampling.'''

    mode: GenerationMode = validate_generation_mode(generation_mode)
    Path(bundle_root).expanduser().resolve()
    root = Path(project_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    instance = _write_host_sampling_fixture(
        root,
        generation_mode=mode,
    )
    settings = ServerSettings(
        project_root=root,
        cache_root=root / 'cache',
        output_root=root / 'outputs',
        repository_root=root / 'repositories',
        historical_worktree_root=root / 'historical_worktrees',
        generator_max_attempts=1,
        generator_retry_base_sleep_seconds=0,
        generator_retry_max_sleep_seconds=0,
    ).resolved()
    if settings.judge_model_configured or settings.generator_model_configured:
        raise ReleaseSmokeError(
            'host sampling acceptance requires Judge and Generator model '
            'configuration to be absent'
        )

    knowledge_root = root / 'knowledge'
    host = create_mcp_server(
        profile='runtime',
        settings=settings,
        policy=MCPServerPolicy(allow_live_search=False),
        preretrieved_dir=root / 'preretrieved',
        knowledge_cache_dir=knowledge_root,
    )
    _, connect = _mcp_sdk()
    try:
        from mcp import types
    except ImportError as exc:  # pragma: no cover - release installs [mcp]
        raise ReleaseSmokeError(
            'host sampling acceptance requires the lingxi_advisor[mcp] extra'
        ) from exc

    sampling_kinds: list[str] = []
    sampling_responses = _host_sampling_responses(mode)

    async def sampling_callback(_context: Any, _params: Any) -> Any:
        index = len(sampling_kinds)
        if index >= len(sampling_responses):
            raise ReleaseSmokeError(
                'the cache-hit search unexpectedly requested more Host sampling'
            )
        kind, content = sampling_responses[index]
        sampling_kinds.append(kind)
        if kind == 'grounded_tool':
            return types.CreateMessageResultWithTools(
                role='assistant',
                content=[
                    types.ToolUseContent(
                        type='tool_use',
                        id='read-dispatcher',
                        name='read_file',
                        input={
                            'path': 'src/dispatcher.py',
                            'start_line': 1,
                            'end_line': 20,
                        },
                    )
                ],
                model='agent-host',
                stopReason='toolUse',
            )
        return types.CreateMessageResult(
            role='assistant',
            content=types.TextContent(type='text', text=content),
            model='agent-host',
            stopReason='endTurn',
        )

    search_arguments = {
        'issue_description': instance.problem_statement,
        'context': instance.public_dict(),
        'generation_mode': mode,
        'search_candidate_count': 1,
        'final_top_k': 1,
        'run_gate_for_preretrieved': True,
    }

    async def exercise() -> dict[str, Any]:
        connection = (
            _connect_sampling_tools_host
            if mode == 'grounded_analysis'
            else connect
        )
        async with connection(
            host,
            sampling_callback=sampling_callback,
            raise_exceptions=True,
        ) as session:
            runtime_tools = await _list_runtime_tools(session)
            first_call = await session.call_tool(
                'lingxi.advisor.search',
                search_arguments,
            )
            first = _structured_content(
                first_call,
                tool_name='lingxi.advisor.search',
            )
            _require_real_search(first, first=True)
            first_apply = await _call_real_apply(
                session,
                instance=instance,
                result=first,
            )
            second_arguments = {
                **search_arguments,
                'run_gate_for_preretrieved': False,
            }
            second_call = await session.call_tool(
                'lingxi.advisor.search',
                second_arguments,
            )
            second = _structured_content(
                second_call,
                tool_name='lingxi.advisor.search',
            )
            _require_real_search(second, first=False)
            first_match = first['knowledge_matches'][0]
            second_match = second['knowledge_matches'][0]
            if (
                not isinstance(first_match, Mapping)
                or not isinstance(second_match, Mapping)
                or _match_identity(first_match) != _match_identity(second_match)
            ):
                raise ReleaseSmokeError(
                    'the host-backed cache-hit search changed the Artifact'
                )
            second_apply = await _call_real_apply(
                session,
                instance=instance,
                result=second,
            )
            if second_apply['source_artifact_refs'] != first_apply[
                'source_artifact_refs'
            ]:
                raise ReleaseSmokeError(
                    'host-backed Apply did not preserve cached Artifact refs'
                )
            return {
                'runtime_tools': runtime_tools,
                'first': first,
                'second': second,
                'second_apply': second_apply,
            }

    result = asyncio.run(exercise())
    first = result['first']
    second = result['second']
    second_apply = result['second_apply']
    refs = second_apply['source_artifact_refs']
    artifact_ref = KnowledgeArtifactRef.from_mapping(refs[0])
    artifact = FilesystemKnowledgeArtifactStore(knowledge_root).read(
        artifact_ref
    )
    if sampling_kinds != [item[0] for item in sampling_responses]:
        raise ReleaseSmokeError(
            'host sampling did not run Judge and every Generation stage once'
        )
    if artifact.generator_model != 'agent-host':
        raise ReleaseSmokeError(
            'generated Artifact lacks Agent Host model provenance'
        )
    return {
        'status': 'completed',
        'version': __version__,
        'generation_mode': mode,
        'runtime_tools': result['runtime_tools'],
        'sampling_kinds': sampling_kinds,
        'sampling_count': len(sampling_kinds),
        'generator_model': artifact.generator_model,
        'first_generated_count': int(first.get('generated_count') or 0),
        'first_cache_hit_count': int(first.get('cache_hit_count') or 0),
        'second_generated_count': int(second.get('generated_count') or 0),
        'second_cache_hit_count': int(second.get('cache_hit_count') or 0),
        'source_artifact_refs': refs,
    }


def _load_real_instance(path: Path) -> dict[str, Any]:
    value = json.loads(path.expanduser().read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ReleaseSmokeError("--real-instance must contain one JSON object")
    return value


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Validate an installed LingxiAdvisor extension bundle."
    )
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument(
        "--real-instance",
        type=Path,
        help="Run opt-in real GitHub/model acceptance with this public JSON.",
    )
    parser.add_argument(
        "--real-project-root",
        type=Path,
        help="Isolated runtime directory for --real-instance.",
    )
    parser.add_argument(
        "--real-generation-mode",
        default="light",
        choices=("light", "grounded_analysis"),
        help="Generation mode for --real-instance acceptance.",
    )
    parser.add_argument(
        '--host-sampling-project-root',
        type=Path,
        help=(
            'Run deterministic real MCP sampling acceptance with no '
            'preconfigured Judge or Generator.'
        ),
    )
    parser.add_argument(
        '--host-sampling-generation-mode',
        default='light',
        choices=('light', 'grounded_analysis'),
        help='Generation mode for Agent Host sampling acceptance.',
    )
    args = parser.parse_args()
    result = run_release_smoke(args.bundle_root)
    if args.host_sampling_project_root is not None:
        result['host_sampling_acceptance'] = (
            run_host_sampling_release_acceptance(
                args.bundle_root,
                project_root=args.host_sampling_project_root,
                generation_mode=args.host_sampling_generation_mode,
            )
        )
    if args.real_instance is not None:
        if args.real_project_root is None:
            parser.error("--real-project-root is required with --real-instance")
        result["real_acceptance"] = run_real_release_acceptance(
            args.bundle_root,
            _load_real_instance(args.real_instance),
            project_root=args.real_project_root,
            generation_mode=args.real_generation_mode,
        )
    print(
        json.dumps(
            result,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()


__all__ = [
    'run_host_sampling_release_acceptance',
    "ReleaseSmokeError",
    "run_real_release_acceptance",
    "run_release_smoke",
]
