from __future__ import annotations

import dataclasses
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Mapping

from ..search_retrieval.candidate_schema import (
    historical_fix_commit,
    historical_issue_description,
    historical_issue_number,
    historical_issue_url,
)


def _text(value: Any) -> str:
    return str(value or "").strip()


def _historical_patch_only(candidate: Mapping[str, Any]) -> str:
    """Select historical evidence without ever falling back to target gold."""

    for key in (
        "historical_patch",
        "retrieved_issue_ground_truth_patch",
        "retrieved_patch",
        "pr_patch",
        "merge_commit_patch",
    ):
        value = _text(candidate.get(key))
        if value:
            return value
    return ""


def _candidate_fingerprint(
    candidate: Mapping[str, Any],
    *,
    repo: str,
    patch_sha256: str,
    issue_number: int | None,
    issue_url: str,
    fix_commit: str | None,
) -> str:
    supplied = _text(candidate.get("historical_candidate_fingerprint"))
    if supplied:
        return supplied
    payload = {
        "repo": repo,
        "historical_issue_number": issue_number,
        "historical_issue_url": issue_url,
        "historical_fix_commit": fix_commit,
        "patch_sha256": patch_sha256,
    }
    return hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()[:24]


@dataclass(frozen=True)
class LightGeneratorConfig:
    """Runtime configuration for an OpenAI-compatible Light generator."""

    model: str = "gpt-4.1-mini"
    base_url: str = "https://api.openai.com/v1"
    api_key: str | None = field(default=None, repr=False)
    timeout_seconds: float = 300.0
    max_attempts: int = 5
    retry_base_sleep_seconds: float = 2.0
    retry_max_sleep_seconds: float = 30.0
    max_output_tokens: int = 26_000
    temperature: float = 1.0
    verify_ssl: bool = True
    trust_env: bool = True
    aspect_mode: str = "g_from_issue_plus_fg_calltrace"

    def validate(self) -> None:
        if not self.model.strip():
            raise ValueError("generator model cannot be empty")
        if not self.base_url.strip():
            raise ValueError("generator base_url cannot be empty")
        if self.timeout_seconds <= 0:
            raise ValueError("generator timeout_seconds must be positive")
        if self.max_attempts < 1:
            raise ValueError("generator max_attempts must be positive")
        if self.retry_base_sleep_seconds < 0:
            raise ValueError("retry_base_sleep_seconds cannot be negative")
        if self.retry_max_sleep_seconds < self.retry_base_sleep_seconds:
            raise ValueError(
                "retry_max_sleep_seconds cannot be smaller than retry_base_sleep_seconds"
            )
        if self.max_output_tokens < 1:
            raise ValueError("max_output_tokens must be positive")
        if not 0.0 <= self.temperature <= 2.0:
            raise ValueError("temperature must be in [0, 2]")
        if self.aspect_mode not in {
            "base_split",
            "g_from_issue_plus_fg_calltrace",
        }:
            raise ValueError(
                "aspect_mode must be base_split or g_from_issue_plus_fg_calltrace"
            )

    def public_dict(self) -> dict[str, Any]:
        data = dataclasses.asdict(self)
        data.pop("api_key", None)
        return data


@dataclass(frozen=True)
class LightGenerationInput:
    """Canonical Light input built from one selected retrieval candidate."""

    instance_id: str
    repo: str
    problem_statement: str
    requirements: str
    historical_issue_description: str
    historical_patch: str
    historical_candidate_fingerprint: str
    historical_patch_sha256: str
    historical_issue_number: int | None = None
    historical_issue_url: str = ""
    historical_fix_commit: str | None = None
    changed_files: tuple[Mapping[str, Any], ...] = ()
    provenance: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_candidate(
        cls, candidate: Mapping[str, Any]
    ) -> "LightGenerationInput":
        if not isinstance(candidate, Mapping):
            raise TypeError("selected candidate must be a mapping")

        instance_id = _text(candidate.get("instance_id"))
        repo = _text(candidate.get("repo") or candidate.get("instance_repo"))
        issue_description = historical_issue_description(candidate)
        patch = _historical_patch_only(candidate)
        patch_sha256 = hashlib.sha256(
            patch.encode("utf-8", errors="replace")
        ).hexdigest()
        supplied_patch_sha256 = _text(candidate.get("historical_patch_sha256"))
        issue_number = historical_issue_number(candidate)
        issue_url = historical_issue_url(candidate, repo, issue_number)
        fix_commit = historical_fix_commit(candidate)
        fingerprint = _candidate_fingerprint(
            candidate,
            repo=repo,
            patch_sha256=patch_sha256,
            issue_number=issue_number,
            issue_url=issue_url,
            fix_commit=fix_commit,
        )

        missing = [
            name
            for name, value in (
                ("instance_id", instance_id),
                ("repo", repo),
                ("historical_issue_description", issue_description),
                ("historical_patch", patch),
                ("historical_candidate_fingerprint", fingerprint),
            )
            if not value
        ]
        if missing:
            raise ValueError(
                "selected candidate is missing required generation field(s): "
                + ", ".join(missing)
            )
        if supplied_patch_sha256 and supplied_patch_sha256 != patch_sha256:
            raise ValueError(
                "historical_patch_sha256 does not match historical_patch"
            )

        changed_files_raw = candidate.get("changed_files")
        changed_files = tuple(
            item
            for item in (
                changed_files_raw if isinstance(changed_files_raw, list) else []
            )
            if isinstance(item, Mapping)
        )
        provenance_keys = (
            "schema_version",
            "retrieval_source",
            "retrieval_rank",
            "candidate_position",
            "final_selected_position",
            "llm_gate_decision",
            "llm_gate_reason",
            "llm_similarity_score",
            "llm_misleading_risk",
            "ranking_source",
            "preretrieved_source_path",
            "retrieved_commit_ids",
            "retrieved_grounding_commit_id",
            "retrieved_grounding_commit_source",
        )
        provenance = {
            key: candidate[key]
            for key in provenance_keys
            if key in candidate and candidate[key] is not None
        }
        return cls(
            instance_id=instance_id,
            repo=repo,
            problem_statement=_text(candidate.get("problem_statement")),
            requirements=_text(candidate.get("requirements")),
            historical_issue_description=issue_description,
            historical_patch=patch,
            historical_candidate_fingerprint=fingerprint,
            historical_patch_sha256=patch_sha256,
            historical_issue_number=issue_number,
            historical_issue_url=issue_url,
            historical_fix_commit=fix_commit,
            changed_files=changed_files,
            provenance=provenance,
        )


@dataclass(frozen=True)
class ModelCallStats:
    tag: str
    model: str
    attempt: int
    latency_seconds: float
    attempt_count: int = 1
    failed_attempt_latency_seconds: float = 0.0
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None
    cost_usd: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass(frozen=True)
class LightGenerationResult:
    artifact_xml: str
    fine_grained_xml: str
    summary_xml: str
    calls: tuple[ModelCallStats, ...]

    @property
    def total_latency_seconds(self) -> float:
        return sum(item.latency_seconds for item in self.calls)

    @property
    def total_cost_usd(self) -> float:
        return sum(item.cost_usd for item in self.calls)
