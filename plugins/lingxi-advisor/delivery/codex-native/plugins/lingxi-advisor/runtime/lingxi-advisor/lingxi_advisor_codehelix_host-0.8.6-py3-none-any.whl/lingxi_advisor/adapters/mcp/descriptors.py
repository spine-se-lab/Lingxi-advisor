from __future__ import annotations

from typing import Any, Mapping

from .operator_tools import OPERATOR_TOOLS
from .runtime_tools import RUNTIME_TOOLS

PROFILE_TOOLS = {
    'runtime': RUNTIME_TOOLS,
    'operator': OPERATOR_TOOLS,
}

def server_descriptor(profile: str) -> dict[str, Any]:
    if profile not in PROFILE_TOOLS:
        raise ValueError('profile must be runtime or operator')
    return {
        'schema_version': 1,
        'profile': profile,
        'command': 'lingxi-advisor-mcp',
        'args': ['--profile', profile, '--transport', 'stdio'],
        'tools': list(PROFILE_TOOLS[profile]),
    }

def validate_server_descriptor(
    value: Mapping[str, Any],
    *,
    profile: str,
 ) -> None:
    expected = server_descriptor(profile)
    for key in ('schema_version', 'profile', 'command', 'args', 'tools'):
        if value.get(key) != expected[key]:
            raise ValueError(f'{profile} descriptor mismatch: {key}')

__all__ = [
    'PROFILE_TOOLS',
    'server_descriptor',
    'validate_server_descriptor',
]
