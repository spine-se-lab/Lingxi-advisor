from __future__ import annotations

from ..execution import checkpoint, bounded_timeout, failure_details, interruptible_sleep, ExecutionFailure

import dataclasses
import json
import logging
from dataclasses import dataclass
from typing import Any, Mapping, Protocol

from ..tls import httpx_verify

from .candidate_schema import (
    candidate_fingerprint,
    historical_issue_description,
    historical_issue_number,
    historical_patch,
)
from .contracts import SWEbenchProInstance, SimilarityGateOptions
from .safety import PostRetrievalSafetyDecision

logger = logging.getLogger(__name__)

SIMILARITY_GATE_PROMPT_VERSION = "search_retrieval_repair_utility_gate_v3"
SIMILARITY_GATE_POLICY_VERSION = "tiered_transferability_risk_policy_v2"

STRONG_TRANSFERABILITY_SCORE = 3
WEAK_TRANSFERABILITY_SCORE = 2
STRONG_MAXIMUM_MISLEADING_RISK = 2
WEAK_MAXIMUM_MISLEADING_RISK = 1

ALLOWED_MATCH_BASES = frozenset(
    {
        "same_module",
        "same_subsystem",
        "same_engineering_aspect",
        "same_failure_mode",
        "same_patch_operation",
        "same_validation_strategy",
        "same_localization_area",
        "generic_theme",
        "unrelated",
    }
)

TRANSFERABLE_MATCH_BASES = frozenset(
    {
        "same_module",
        "same_subsystem",
        "same_engineering_aspect",
        "same_failure_mode",
        "same_patch_operation",
        "same_validation_strategy",
        "same_localization_area",
    }
)

SYSTEM_PROMPT = """\
You judge whether one historical GitHub issue and its patch can provide useful,
transferable historical knowledge for solving a current SWE-bench Pro issue.

The candidate has already passed repository, temporal, patch, and leakage-safety
checks. Judge repair transferability, not keyword overlap or surface similarity.

Use the current problem statement as the target. Use the historical issue
description and historical patch as evidence. Do not require the same exact bug,
file, symbol, root cause, or directly applicable patch.

A candidate may be useful through at least one concrete connection:
- the same module, subsystem, or localization area;
- the same engineering aspect or failure mode;
- a transferable patch operation or implementation pattern; or
- a reusable testing or validation strategy.

Broad topical overlap alone is not sufficient. For example, merely involving
validation, caching, error handling, a UI, or the same programming language is
not useful unless the historical issue or patch provides a concrete clue for
the current repair.

Interpret similarity_score as a repair-transferability score:
- 5: nearly the same problem or repair mechanism;
- 4: strongly related module and repair mechanism;
- 3: clearly transferable failure mode, patch operation, localization clue, or
  validation strategy;
- 2: a weak but usable connection through the same module or engineering
  aspect, with at least one concrete localization, repair, or testing clue;
- 1: only broad or generic topical overlap, without a concrete clue;
- 0: unrelated or contradictory.

Interpret misleading_risk as:
- 0: the historical repair can be safely abstracted;
- 1: minor differences require adaptation but are unlikely to mislead;
- 2: important differences exist, but the useful parts can still be separated;
- 3: the candidate could plausibly lead the repair in the wrong direction;
- 4-5: substantially conflicting or misleading.

Set selected=true only when at least one transferable match_basis and at least
one concrete evidence field are present, and either:
- similarity_score is 3-5 and misleading_risk is 0-2; or
- similarity_score is 2 and misleading_risk is 0-1.

Set selected=false for score 0-1, risk 3-5, generic overlap without a concrete
clue, or an unrelated/contradictory repair. The server independently enforces
this policy, so keep selected, scores, match_basis, and evidence consistent.

Return exactly one JSON object:
{
  "selected": true,
  "similarity_score": 2,
  "misleading_risk": 1,
  "match_basis": ["same_module", "same_validation_strategy"],
  "failure_mode_evidence": "",
  "repair_transfer_evidence": "",
  "localization_help": "",
  "main_risk": "",
  "reason": ""
}

similarity_score and misleading_risk must be integers from 0 to 5. match_basis
must contain only values from: same_module, same_subsystem,
same_engineering_aspect, same_failure_mode, same_patch_operation,
same_validation_strategy, same_localization_area, generic_theme, unrelated.
For selected=true, populate at least one of failure_mode_evidence,
repair_transfer_evidence, or localization_help with a concrete clue. Keep each
text field concise, preferably one sentence. Output JSON only.
"""

USER_PROMPT = """\
Current issue:
<problem_statement>
{problem_statement}
</problem_statement>

Historical issue #{historical_issue_number}:
<historical_issue>
{historical_issue}
</historical_issue>

Historical patch:
<historical_patch>
{patch}
</historical_patch>

Decide whether this historical repair should be selected for Knowledge Generation.
Return JSON only.
"""


class JudgeClient(Protocol):
    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        ...


class OpenAICompatibleJudgeClient:
    """Synchronous OpenAI-compatible client with server-owned credentials."""

    def __init__(
        self,
        *,
        api_key: str,
        model: str,
        base_url: str | None,
        timeout_seconds: float,
        max_retries: int,
        max_output_tokens: int,
        verify_ssl: bool,
        trust_env: bool,
    ) -> None:
        if not api_key.strip():
            raise ValueError("Similarity judge API key is empty")
        if not model.strip():
            raise ValueError("Similarity judge model is empty")
        try:
            import httpx
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError(
                "Search & Retrieval LLM gate requires the 'openai' and 'httpx' packages"
            ) from exc

        http_client = httpx.Client(
            timeout=timeout_seconds,
            verify=httpx_verify(verify_ssl),
            trust_env=trust_env,
        )
        kwargs: dict[str, Any] = {
            "api_key": api_key,
            "timeout": timeout_seconds,
            "max_retries": 0,
            "http_client": http_client,
        }
        if base_url:
            kwargs["base_url"] = base_url
        self._client = OpenAI(**kwargs)
        self._max_retries = max_retries
        self._model = model
        self._max_output_tokens = max_output_tokens
        self._http_client = http_client

    def close(self) -> None:
        try:
            self._client.close()
        finally:
            self._http_client.close()

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        for attempt in range(self._max_retries + 1):
            try:
                checkpoint()
                response = self._client.chat.completions.create(
                    timeout=bounded_timeout(self._client.timeout),
                    model=self._model,
                    temperature=0.0,
                    max_tokens=self._max_output_tokens,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt},
                    ],
                )
                break
            except Exception as exc:
                if not failure_details(exc)[1] or attempt >= self._max_retries:
                    raise
                interruptible_sleep(min(10, 2 ** attempt))
        if not response.choices:
            raise ExecutionFailure("model_empty_response", "Similarity judge returned no choices")
        choice = response.choices[0]
        if choice.finish_reason == "length":
            raise ExecutionFailure(
                "model_output_limit",
                "Similarity judge exhausted its output token budget; "
                "increase LINGXI_ADVISOR_JUDGE_MAX_OUTPUT_TOKENS",
            )
        content = choice.message.content or ""
        if not content.strip():
            raise ExecutionFailure("model_empty_response", "Similarity judge returned no text")
        return content


def _text(value: Any, limit: int | None = None) -> str:
    text = str(value or "").strip()
    return text[:limit] if limit is not None else text


def _truncate_middle(text: str, limit: int, label: str) -> str:
    value = str(text or "")
    if limit <= 0 or len(value) <= limit:
        return value[:limit] if limit > 0 else ""
    marker = f"\n\n[... {label} truncated: original_chars={len(value)} ...]\n\n"
    if limit <= len(marker) + 200:
        return value[:limit]
    remaining = limit - len(marker)
    head = int(remaining * 0.65)
    tail = remaining - head
    return value[:head] + marker + value[-tail:]


def _extract_json_object(text: str) -> dict[str, Any] | None:
    stripped = str(text or "").strip()
    if not stripped:
        return None
    try:
        value = json.loads(stripped)
    except json.JSONDecodeError:
        start = stripped.find("{")
        end = stripped.rfind("}")
        if start < 0 or end <= start:
            return None
        try:
            value = json.loads(stripped[start : end + 1])
        except json.JSONDecodeError:
            return None
    return value if isinstance(value, dict) else None


def _parse_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and not isinstance(value, bool) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "yes", "1"}:
            return True
        if normalized in {"false", "no", "0"}:
            return False
    return None


def _parse_score(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not number.is_integer():
        return None
    parsed = int(number)
    return parsed if 0 <= parsed <= 5 else None


def _parse_match_basis(value: Any) -> list[str] | None:
    if isinstance(value, str):
        raw_values: list[Any] = [value]
    elif isinstance(value, list):
        raw_values = value
    else:
        return None

    parsed: list[str] = []
    for item in raw_values:
        if not isinstance(item, str):
            return None
        normalized = item.strip().lower()
        if not normalized or normalized not in ALLOWED_MATCH_BASES:
            return None
        if normalized not in parsed:
            parsed.append(normalized)
    return parsed or None


@dataclass
class SimilarityGateDecision:
    instance_id: str
    candidate_key: str
    candidate_position: int | None
    selected: bool
    similarity_score: int | None
    misleading_risk: int | None
    decision_source: str
    judge_ran: bool
    model_selected: bool | None = None
    match_basis: list[str] = dataclasses.field(default_factory=list)
    selection_tier: str | None = None
    policy_reasons: list[str] = dataclasses.field(default_factory=list)
    reason: str | None = None
    error: str | None = None
    raw_response: str | None = None
    failure_mode_evidence: str | None = None
    repair_transfer_evidence: str | None = None
    localization_help: str | None = None
    main_risk: str | None = None
    prompt_version: str = SIMILARITY_GATE_PROMPT_VERSION
    policy_version: str = SIMILARITY_GATE_POLICY_VERSION

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


class SimilarityGate:
    def __init__(self, *, client: JudgeClient, options: SimilarityGateOptions) -> None:
        options.validate()
        self.client = client
        self.options = options

    def _reject(
        self,
        *,
        row: Mapping[str, Any],
        instance: SWEbenchProInstance,
        position: int | None,
        decision_source: str,
        judge_ran: bool,
        reason: str,
        error: str | None = None,
        raw_response: str | None = None,
    ) -> SimilarityGateDecision:
        return SimilarityGateDecision(
            instance_id=instance.instance_id,
            candidate_key=candidate_fingerprint(row, instance),
            candidate_position=position,
            selected=False,
            similarity_score=None,
            misleading_risk=None,
            decision_source=decision_source,
            judge_ran=judge_ran,
            reason=reason,
            error=error,
            raw_response=raw_response,
        )

    def evaluate(
        self,
        *,
        row: Mapping[str, Any],
        instance: SWEbenchProInstance,
        safety: PostRetrievalSafetyDecision,
        candidate_position: int,
    ) -> SimilarityGateDecision:
        if not safety.passed:
            return self._reject(
                row=row,
                instance=instance,
                position=candidate_position,
                decision_source="safety_reject",
                judge_ran=False,
                reason="Post-retrieval safety integrity recheck failed.",
                error="; ".join(safety.reasons),
            )

        historical_issue = historical_issue_description(row)
        patch = historical_patch(row)
        missing: list[str] = []
        if not instance.problem_statement:
            missing.append("problem_statement")
        if not historical_issue:
            missing.append("historical_issue_description")
        if not patch:
            missing.append("historical_patch")
        if missing:
            return self._reject(
                row=row,
                instance=instance,
                position=candidate_position,
                decision_source="missing_gate_evidence",
                judge_ran=False,
                reason=f"Missing {', '.join(missing)}; rejected fail-closed.",
                error="missing_gate_evidence",
            )

        user_prompt = USER_PROMPT.format(
            problem_statement=_truncate_middle(
                instance.problem_statement,
                self.options.max_current_issue_chars,
                "problem_statement",
            ),
            historical_issue_number=historical_issue_number(row) or "",
            historical_issue=_truncate_middle(
                historical_issue,
                self.options.max_historical_issue_chars,
                "historical_issue",
            ),
            patch=_truncate_middle(patch, self.options.max_patch_chars, "historical_patch"),
        )

        try:
            raw_response = self.client.complete(
                system_prompt=SYSTEM_PROMPT,
                user_prompt=user_prompt,
            )
        except Exception as exc:
            logger.warning(
                "Similarity gate failed for %s candidate=%s: %s",
                instance.instance_id,
                candidate_fingerprint(row, instance),
                exc,
            )
            return self._reject(
                row=row,
                instance=instance,
                position=candidate_position,
                decision_source="judge_call_error",
                judge_ran=True,
                reason="Similarity judge call failed; rejected fail-closed.",
                error=str(exc),
            )

        data = _extract_json_object(raw_response)
        if data is None:
            return self._reject(
                row=row,
                instance=instance,
                position=candidate_position,
                decision_source="judge_invalid_json",
                judge_ran=True,
                reason="Similarity judge returned invalid JSON; rejected fail-closed.",
                error="invalid_json",
                raw_response=str(raw_response)[:4000],
            )

        model_selected = _parse_bool(data.get("selected"))
        similarity_score = _parse_score(data.get("similarity_score"))
        misleading_risk = _parse_score(data.get("misleading_risk"))
        match_basis = _parse_match_basis(data.get("match_basis"))
        failure_mode_evidence = _text(data.get("failure_mode_evidence"), 2000) or None
        repair_transfer_evidence = (
            _text(data.get("repair_transfer_evidence"), 2000) or None
        )
        localization_help = _text(data.get("localization_help"), 2000) or None

        validation_errors: list[str] = []
        if similarity_score is None:
            validation_errors.append("similarity_score is missing or invalid")
        if misleading_risk is None:
            validation_errors.append("misleading_risk is missing or invalid")
        if match_basis is None:
            validation_errors.append("match_basis is missing or invalid")

        if validation_errors:
            selected = False
            decision_source = "judge_schema_reject"
            selection_tier = None
            policy_reasons = list(validation_errors)
        else:
            assert similarity_score is not None
            assert misleading_risk is not None
            assert match_basis is not None

            has_transferable_basis = bool(
                TRANSFERABLE_MATCH_BASES.intersection(match_basis)
            )
            has_concrete_evidence = bool(
                failure_mode_evidence
                or repair_transfer_evidence
                or localization_help
            )
            within_configured_bounds = bool(
                similarity_score >= self.options.minimum_similarity_score
                and misleading_risk <= self.options.maximum_misleading_risk
            )

            strong_match = bool(
                within_configured_bounds
                and similarity_score >= STRONG_TRANSFERABILITY_SCORE
                and misleading_risk <= STRONG_MAXIMUM_MISLEADING_RISK
                and has_transferable_basis
                and has_concrete_evidence
            )
            weak_match = bool(
                within_configured_bounds
                and similarity_score == WEAK_TRANSFERABILITY_SCORE
                and misleading_risk <= WEAK_MAXIMUM_MISLEADING_RISK
                and has_transferable_basis
                and has_concrete_evidence
            )

            selected = strong_match or weak_match
            selection_tier = (
                "strong" if strong_match else "fallback" if weak_match else None
            )

            policy_reasons = []
            if similarity_score < self.options.minimum_similarity_score:
                policy_reasons.append("below_configured_similarity_threshold")
            if misleading_risk > self.options.maximum_misleading_risk:
                policy_reasons.append("above_configured_risk_threshold")
            if not has_transferable_basis:
                policy_reasons.append("no_transferable_match_basis")
            if not has_concrete_evidence:
                policy_reasons.append("no_concrete_transfer_evidence")
            if (
                similarity_score == WEAK_TRANSFERABILITY_SCORE
                and misleading_risk > WEAK_MAXIMUM_MISLEADING_RISK
            ):
                policy_reasons.append("weak_match_risk_too_high")
            if similarity_score < WEAK_TRANSFERABILITY_SCORE:
                policy_reasons.append("transferability_too_low")

            # The model's boolean is retained for auditing, but the explicit,
            # reproducible score/risk/evidence policy makes the final decision.
            if model_selected is not None and model_selected != selected:
                policy_reasons.append("model_policy_disagreement")

            decision_source = "llm_selected" if selected else "llm_rejected"

        return SimilarityGateDecision(
            instance_id=instance.instance_id,
            candidate_key=candidate_fingerprint(row, instance),
            candidate_position=candidate_position,
            selected=selected,
            similarity_score=similarity_score,
            misleading_risk=misleading_risk,
            decision_source=decision_source,
            judge_ran=True,
            model_selected=model_selected,
            match_basis=match_basis or [],
            selection_tier=selection_tier,
            policy_reasons=policy_reasons,
            reason=_text(data.get("reason"), 2000)
            or "; ".join(validation_errors)
            or None,
            error="; ".join(validation_errors) if validation_errors else None,
            raw_response=str(raw_response)[:4000],
            failure_mode_evidence=failure_mode_evidence,
            repair_transfer_evidence=repair_transfer_evidence,
            localization_help=localization_help,
            main_risk=_text(data.get("main_risk"), 2000) or None,
        )
