"""Historical fix discovery and strict repository/temporal validation."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import random
import re
import subprocess
import time
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .common import (
    commit_exists_locally,
    commit_time_cache_path,
    content_hash,
    datetime_to_ts,
    extract_sha_set,
    format_patch_from_local_git,
    get_commit_time_from_git,
    infer_target_commit_from_instance,
    instance_identifier,
    is_blobless_partial_clone,
    isoformat_utc,
    logger,
    normalize_repo,
    parse_datetime_to_utc,
    parse_issue_number_int,
    read_json,
    read_jsonl,
    repo_identity_key,
    repo_name_from_repo,
    run_git,
    safe_filename_part,
    safe_float,
    safe_int,
    safe_str,
    write_json_atomic,
)
from .query import (
    search_cache_path,
)
from .transport import (
    GithubClient,
)


def historical_lookup_key(repo: str, issue_number: int) -> str:
    return f"{normalize_repo(repo)}#{int(issue_number)}"


def load_historical_lookup(path: Path) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Any]]:
    rows = read_jsonl(path)
    lookup: Dict[str, Dict[str, Any]] = {}
    duplicate_keys: Counter[str] = Counter()
    closing_sources: Counter[str] = Counter()
    repos: Counter[str] = Counter()
    for row in rows:
        repo = normalize_repo(row.get("repo"))
        issue_number = parse_issue_number_int(row.get("issue_number"))
        if not repo or not issue_number:
            continue
        key = historical_lookup_key(repo, issue_number)
        closing_sources[safe_str(row.get("closing_source")) or "unknown"] += 1
        repos[repo] += 1
        if key in lookup:
            duplicate_keys[key] += 1
            continue
        lookup[key] = row
    stats = {
        "historical_rows_loaded": len(rows),
        "historical_lookup_keys": len(lookup),
        "duplicate_lookup_keys": sum(duplicate_keys.values()),
        "closing_sources": dict(closing_sources),
        "repos": dict(repos),
    }
    return lookup, stats


def compact_pr_file(file_obj: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "filename": file_obj.get("filename"),
        "status": file_obj.get("status"),
        "additions": file_obj.get("additions"),
        "deletions": file_obj.get("deletions"),
        "changes": file_obj.get("changes"),
        "previous_filename": file_obj.get("previous_filename"),
        "blob_url": file_obj.get("blob_url"),
        "raw_url": file_obj.get("raw_url"),
        "contents_url": file_obj.get("contents_url"),
        "patch": file_obj.get("patch"),
    }


def compact_commit(commit_obj: Dict[str, Any]) -> Dict[str, Any]:
    commit = commit_obj.get("commit") or {}
    author = commit.get("author") or {}
    committer = commit.get("committer") or {}
    return {
        "sha": commit_obj.get("sha"),
        "html_url": commit_obj.get("html_url"),
        "message": commit.get("message"),
        "author_name": author.get("name"),
        "author_email": author.get("email"),
        "author_date": author.get("date"),
        "committer_name": committer.get("name"),
        "committer_email": committer.get("email"),
        "committer_date": committer.get("date"),
        "parents": [p.get("sha") for p in commit_obj.get("parents", []) if isinstance(p, dict)],
    }


def preferred_commit_created_at(commit_record: Dict[str, Any]) -> Optional[str]:
    for key in ("committer_date", "author_date", "commit_date"):
        value = commit_record.get(key)
        if value:
            return str(value)
    return None


def max_commit_created_at(commit_records: Iterable[Dict[str, Any]]) -> Optional[str]:
    best_value: Optional[str] = None
    best_ts = 0.0
    for record in commit_records:
        if not isinstance(record, dict):
            continue
        value = preferred_commit_created_at(record)
        parsed = parse_datetime_to_utc(value)
        ts = datetime_to_ts(parsed)
        if value and ts > best_ts:
            best_value = value
            best_ts = ts
    return best_value


def issue_from_search_or_api(repo: str, client: GithubClient, issue_number: int, search_item: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if search_item and search_item.get("number"):
        body = safe_str(search_item.get("body"))
        if body or search_item.get("title"):
            return {
                "id": search_item.get("id"),
                "node_id": search_item.get("node_id"),
                "number": search_item.get("number"),
                "title": search_item.get("title"),
                "body": search_item.get("body") or "",
                "state": search_item.get("state"),
                "state_reason": search_item.get("state_reason"),
                "html_url": search_item.get("html_url"),
                "created_at": search_item.get("created_at"),
                "updated_at": search_item.get("updated_at"),
                "closed_at": search_item.get("closed_at"),
                "labels": search_item.get("labels") or [],
                "user": search_item.get("user") or {},
            }
    return client.get_issue(repo, issue_number)


def collect_patch_for_commit(
    *,
    repo: str,
    repo_path: Optional[Path],
    client: GithubClient,
    sha: str,
    patch_path: Path,
) -> Tuple[str, str]:
    if patch_path.exists():
        return patch_path.read_text(encoding="utf-8", errors="replace"), "existing_file"
    patch_path.parent.mkdir(parents=True, exist_ok=True)
    use_local_git = False
    if repo_path is not None and not is_blobless_partial_clone(repo_path):
        try:
            use_local_git = commit_exists_locally(repo_path, sha)
        except (OSError, subprocess.SubprocessError) as exc:
            logger.warning(
                "Local Git commit probe failed for %s; using GitHub patch: %s",
                sha,
                exc,
            )
    if use_local_git:
        try:
            patch = format_patch_from_local_git(repo_path, sha)
        except (OSError, subprocess.SubprocessError) as exc:
            logger.warning(
                "Local Git patch materialization failed for %s; using GitHub patch: %s",
                sha,
                exc,
            )
        else:
            patch_path.write_text(patch, encoding="utf-8")
            return patch, "local_git"
    patch = client.get_commit_patch(repo, sha)
    patch_path.write_text(patch, encoding="utf-8")
    return patch, "github_commit_patch"


def build_pr_record(
    *,
    repo: str,
    issue: Dict[str, Any],
    candidate_source: str,
    client: GithubClient,
    repo_checkout: Optional[Path],
    patch_dir: Path,
    pr: Dict[str, Any],
    close_event: Optional[Dict[str, Any]] = None,
    include_patch_text: bool = True,
) -> Dict[str, Any]:
    issue_number = int(issue.get("number"))
    pr_number = int(pr.get("number"))
    if not pr.get("merged"):
        raise ValueError(f"PR #{pr_number} is not merged")

    close_event = close_event or {}
    closer = close_event.get("closer") or {}

    pr_files: List[Dict[str, Any]] = []
    try:
        pr_files = [compact_pr_file(obj) for obj in client.get_pr_files(repo, pr_number)]
    except Exception as exc:
        logger.warning("Failed to fetch PR files for %s#%s: %s", repo, pr_number, exc)

    pr_commits_raw = client.get_pr_commits(repo, pr_number)
    pr_commits = [compact_commit(obj) for obj in pr_commits_raw]
    commit_ids = [safe_str(c.get("sha")) for c in pr_commits if c.get("sha")]

    pr_patch_text = ""
    pr_patch_path = patch_dir / f"pr_{pr_number}" / f"PR_{pr_number}.patch"
    try:
        if pr_patch_path.exists():
            pr_patch_text = pr_patch_path.read_text(encoding="utf-8", errors="replace")
        else:
            pr_patch_path.parent.mkdir(parents=True, exist_ok=True)
            pr_patch_text = client.get_pr_patch(repo, pr_number)
            pr_patch_path.write_text(pr_patch_text, encoding="utf-8")
    except Exception as exc:
        logger.warning("Failed to collect aggregate PR patch for %s PR #%s: %s", repo, pr_number, exc)

    commit_patch_records: List[Dict[str, Any]] = []
    aggregate_commit_patches: List[str] = []
    last_patch_bearing_commit_sha: Optional[str] = None
    for commit_obj in pr_commits:
        sha = safe_str(commit_obj.get("sha"))
        if not sha:
            continue

        # The aggregate PR patch is the canonical historical patch consumed by
        # safety, review, and generation. Re-materializing every commit patch
        # is redundant and can turn one large historical PR into hundreds of
        # sequential Git commands. This is especially expensive for the
        # blob-less repository used by commit-message fallback because each
        # format-patch may trigger a lazy object fetch.
        if pr_patch_text:
            if len(commit_obj.get("parents") or ()) <= 1:
                last_patch_bearing_commit_sha = sha
            patch_record = {
                **commit_obj,
                "patch_path": None,
                "patch_source": "aggregate_pr_patch",
            }
            if include_patch_text:
                patch_record["patch"] = ""
            commit_patch_records.append(patch_record)
            continue

        # Preserve the original per-commit recovery path when GitHub cannot
        # provide an aggregate PR patch.
        commit_patch_path = patch_dir / f"pr_{pr_number}" / f"{sha}.patch"
        try:
            patch_text, patch_source = collect_patch_for_commit(
                repo=repo,
                repo_path=repo_checkout,
                client=client,
                sha=sha,
                patch_path=commit_patch_path,
            )
        except Exception as exc:
            logger.warning("Failed to collect patch for commit %s in %s PR #%s: %s", sha, repo, pr_number, exc)
            patch_text = ""
            patch_source = "missing"
        aggregate_commit_patches.append(patch_text)
        if (
            patch_text.strip()
            and len(commit_obj.get("parents") or ()) <= 1
        ):
            last_patch_bearing_commit_sha = sha
        patch_record = {**commit_obj, "patch_path": str(commit_patch_path), "patch_source": patch_source}
        if include_patch_text:
            patch_record["patch"] = patch_text
        commit_patch_records.append(patch_record)

    merge_commit_sha = pr.get("merge_commit_sha") or (closer.get("mergeCommit") or {}).get("oid")
    merge_commit_patch_text = ""
    merge_commit_patch_path: Optional[Path] = None
    merge_commit_api_verified = False
    fix_commit_records_for_time: List[Dict[str, Any]] = list(pr_commits)
    if merge_commit_sha and merge_commit_sha not in set(commit_ids):
        if not pr_patch_text:
            merge_commit_patch_path = patch_dir / f"pr_{pr_number}" / f"merge_{merge_commit_sha}.patch"
            try:
                merge_commit_patch_text, _ = collect_patch_for_commit(
                    repo=repo,
                    repo_path=repo_checkout,
                    client=client,
                    sha=str(merge_commit_sha),
                    patch_path=merge_commit_patch_path,
                )
                merge_commit_api_verified = True
            except Exception as exc:
                logger.warning("Failed to collect merge/squash/rebase patch %s for %s PR #%s: %s", merge_commit_sha, repo, pr_number, exc)
        merge_commit_record: Optional[Dict[str, Any]] = None
        try:
            commit_payload = client.get_commit(repo, str(merge_commit_sha))
            if commit_payload:
                merge_commit_record = compact_commit(commit_payload)
                merge_commit_api_verified = True
        except Exception as exc:
            logger.warning("Failed to fetch merge commit metadata %s for %s PR #%s: %s", merge_commit_sha, repo, pr_number, exc)
        if merge_commit_record is None and pr.get("merged_at"):
            merge_commit_record = {"sha": merge_commit_sha, "author_date": pr.get("merged_at"), "committer_date": pr.get("merged_at")}
        if merge_commit_record is not None:
            fix_commit_records_for_time.append(merge_commit_record)

    retrieved_max_commit_created_at = max_commit_created_at(fix_commit_records_for_time)
    retrieved_patch = pr_patch_text
    if not retrieved_patch:
        retrieved_patch = "\n\n".join(p for p in aggregate_commit_patches if p)
    if not retrieved_patch and merge_commit_patch_text:
        retrieved_patch = merge_commit_patch_text

    if merge_commit_sha and merge_commit_api_verified:
        grounding_commit_id = str(merge_commit_sha)
        grounding_commit_source = "verified_merge_commit"
    elif last_patch_bearing_commit_sha:
        grounding_commit_id = last_patch_bearing_commit_sha
        grounding_commit_source = "last_patch_bearing_pr_commit"
    elif commit_ids:
        grounding_commit_id = commit_ids[-1]
        grounding_commit_source = "last_pr_commit"
    else:
        grounding_commit_id = merge_commit_sha
        grounding_commit_source = "unverified_merge_commit"

    labels = issue.get("labels") or []
    return {
        "repo": repo,
        "issue_number": issue_number,
        "issue_id": issue.get("id"),
        "issue_url": issue.get("html_url"),
        "issue_title": issue.get("title"),
        "issue_body": issue.get("body") or "",
        "issue_state": issue.get("state"),
        "issue_created_at": issue.get("created_at"),
        "issue_updated_at": issue.get("updated_at"),
        "issue_closed_at": issue.get("closed_at"),
        "issue_state_reason": issue.get("state_reason"),
        "issue_labels": [label.get("name") for label in labels if isinstance(label, dict)],
        "closing_event_created_at": close_event.get("createdAt"),
        "closing_event_actor": (close_event.get("actor") or {}).get("login"),
        "closing_source": candidate_source,
        "dynamic_fix_discovery": candidate_source.startswith("dynamic_"),
        "pr_number": pr_number,
        "pr_id": pr.get("id"),
        "pr_url": pr.get("html_url") or closer.get("url"),
        "pr_title": pr.get("title") or closer.get("title"),
        "pr_body": pr.get("body") or "",
        "pr_state": pr.get("state"),
        "pr_merged": pr.get("merged"),
        "pr_created_at": pr.get("created_at"),
        "pr_updated_at": pr.get("updated_at"),
        "pr_closed_at": pr.get("closed_at"),
        "pr_merged_at": pr.get("merged_at"),
        "merge_commit_sha": merge_commit_sha,
        "base_ref": (pr.get("base") or {}).get("ref") or closer.get("baseRefName"),
        "base_sha": (pr.get("base") or {}).get("sha") or closer.get("baseRefOid"),
        "head_ref": (pr.get("head") or {}).get("ref") or closer.get("headRefName"),
        "head_sha": (pr.get("head") or {}).get("sha") or closer.get("headRefOid"),
        "additions": pr.get("additions"),
        "deletions": pr.get("deletions"),
        "changed_files_count": pr.get("changed_files"),
        "changed_files": pr_files,
        "retrieved_issue_desc": f"{issue.get('title') or ''}\n\n{issue.get('body') or ''}".strip(),
        "retrieved_commit_id": merge_commit_sha or (commit_ids[-1] if commit_ids else None),
        "retrieved_grounding_commit_id": grounding_commit_id,
        "retrieved_grounding_commit_source": grounding_commit_source,
        "retrieved_commit_ids": commit_ids,
        "retrieved_max_commit_created_at": retrieved_max_commit_created_at,
        "retrieved_commit_created_at": retrieved_max_commit_created_at,
        "retrieved_patch": retrieved_patch,
        "retrieved_issue_ground_truth_patch": pr_patch_text or merge_commit_patch_text or retrieved_patch,
        "pr_patch_path": str(pr_patch_path) if pr_patch_text else None,
        "pr_patch": pr_patch_text if include_patch_text else None,
        "merge_commit_patch_path": str(merge_commit_patch_path) if merge_commit_patch_path else None,
        "merge_commit_patch": merge_commit_patch_text if include_patch_text else None,
        "patches": commit_patch_records,
        "patch_paths": [p.get("patch_path") for p in commit_patch_records if p.get("patch_path")],
    }


def build_pr_only_record(
    *,
    repo: str,
    pr: Dict[str, Any],
    client: GithubClient,
    repo_checkout: Optional[Path],
    patch_dir: Path,
    candidate_source: str,
    include_patch_text: bool = True,
) -> Dict[str, Any]:
    issue_like = {
        "number": None,
        "id": f"pr:{pr.get('id')}",
        "html_url": pr.get("html_url"),
        "title": pr.get("title"),
        "body": pr.get("body") or "",
        "state": pr.get("state"),
        "state_reason": "pull_request_fallback",
        "created_at": pr.get("created_at"),
        "updated_at": pr.get("updated_at"),
        "closed_at": pr.get("closed_at") or pr.get("merged_at"),
        "labels": [],
    }
    record = build_pr_record(
        repo=repo,
        issue={**issue_like, "number": int(pr.get("number"))},
        candidate_source=candidate_source,
        client=client,
        repo_checkout=repo_checkout,
        patch_dir=patch_dir,
        pr=pr,
        close_event=None,
        include_patch_text=include_patch_text,
    )
    record["doc_type"] = "historical_pull_request_fallback"
    record["issue_number"] = None
    record["retrieved_issue_number"] = None
    record["retrieved_doc_id"] = f"github_pr::{repo}#{pr.get('number')}"
    record["retrieved_issue_desc"] = f"{pr.get('title') or ''}\n\n{pr.get('body') or ''}".strip()
    return record


CLOSING_KEYWORD_RE = re.compile(r"\b(?:fix(?:e[sd]|es)?|close[sd]?|resolve[sd]?)\b", flags=re.IGNORECASE)


ISSUE_REFERENCE_RE = re.compile(
    r"(?:https://github\.com/(?P<url_owner>[A-Za-z0-9_.-]+)/(?P<url_repo>[A-Za-z0-9_.-]+)/(?:issues|pull)/(?P<url_num>\d+))"
    r"|(?:(?P<qualified_owner>[A-Za-z0-9_.-]+)/(?P<qualified_repo>[A-Za-z0-9_.-]+)#(?P<qualified_num>\d+))"
    r"|(?:#(?P<plain_num>\d+))",
    flags=re.IGNORECASE,
)


def extract_closing_issue_numbers(text: str, *, repo: str, keyword_tail_chars: int = 300) -> set[int]:
    if not text:
        return set()
    owner, name = GithubClient.split_repo(repo)
    found: set[int] = set()
    for keyword_match in CLOSING_KEYWORD_RE.finditer(text):
        tail = text[keyword_match.end(): keyword_match.end() + keyword_tail_chars]
        tail = re.split(r"[\n\r;]", tail, maxsplit=1)[0]
        sentence_cut = re.search(r"\.(?:\s|$)", tail)
        if sentence_cut:
            tail = tail[:sentence_cut.start()]
        for ref_match in ISSUE_REFERENCE_RE.finditer(tail):
            ref_owner = ref_match.group("url_owner") or ref_match.group("qualified_owner")
            ref_repo = ref_match.group("url_repo") or ref_match.group("qualified_repo")
            if ref_owner and ref_repo:
                if ref_owner.lower() != owner.lower() or ref_repo.lower() != name.lower():
                    continue
            raw_num = ref_match.group("url_num") or ref_match.group("qualified_num") or ref_match.group("plain_num")
            if raw_num:
                found.add(int(raw_num))
    return found


def dynamic_cache_key(repo: str, issue_number: Optional[int] = None, pr_number: Optional[int] = None) -> str:
    if issue_number is not None:
        return f"issue::{normalize_repo(repo)}#{int(issue_number)}"
    if pr_number is not None:
        return f"pr::{normalize_repo(repo)}#{int(pr_number)}"
    raise ValueError("dynamic_cache_key requires issue_number or pr_number")


def dynamic_cache_path(cache_dir: Path, key: str) -> Path:
    digest = hashlib.md5(key.encode("utf-8")).hexdigest()
    return cache_dir / f"{safe_filename_part(key, max_len=80)}-{digest[:12]}.json"


def read_dynamic_cache(cache_dir: Path, key: str) -> Optional[Dict[str, Any]]:
    obj = read_json(dynamic_cache_path(cache_dir, key))
    return obj if isinstance(obj, dict) else None


def write_dynamic_cache(cache_dir: Path, key: str, payload: Dict[str, Any]) -> None:
    payload = dict(payload)
    payload["cached_at"] = isoformat_utc(dt.datetime.now(dt.timezone.utc))
    write_json_atomic(dynamic_cache_path(cache_dir, key), payload)


def discover_issue_fix_record(
    *,
    repo: str,
    issue_number: int,
    search_item: Optional[Dict[str, Any]],
    client: GithubClient,
    repo_checkout: Optional[Path],
    patch_dir: Path,
    dynamic_cache_dir: Path,
    include_patch_text: bool,
) -> Tuple[Optional[Dict[str, Any]], str]:
    key = dynamic_cache_key(repo, issue_number=issue_number)
    cached = read_dynamic_cache(dynamic_cache_dir, key)
    if cached:
        if cached.get("status") == "found" and isinstance(cached.get("record"), dict):
            return cached["record"], safe_str(cached.get("source")) or "dynamic_cache"
        if cached.get("status") == "not_found":
            return None, safe_str(cached.get("source")) or "dynamic_cache_not_found"

    issue = issue_from_search_or_api(repo, client, issue_number, search_item)
    if not issue:
        write_dynamic_cache(dynamic_cache_dir, key, {"status": "not_found", "source": "dynamic_issue_not_found"})
        return None, "dynamic_issue_not_found"

    # Source 1: GraphQL ClosedEvent PR closer from full closed-event timeline.
    try:
        close_event = client.get_issue_latest_pr_closer_event_graphql(repo, issue_number)
    except Exception as exc:
        logger.warning("Dynamic GraphQL closer discovery failed for %s#%s: %s", repo, issue_number, exc)
        close_event = None
    if close_event is not None:
        closer = close_event.get("closer") or {}
        pr_number = closer.get("number")
        if pr_number is not None:
            pr = client.get_pr(repo, int(pr_number))
            if pr and pr.get("merged"):
                try:
                    record = build_pr_record(
                        repo=repo,
                        issue=issue,
                        candidate_source="dynamic_graphql_closed_event_closer_pull_request",
                        client=client,
                        repo_checkout=repo_checkout,
                        patch_dir=patch_dir,
                        pr=pr,
                        close_event=close_event,
                        include_patch_text=include_patch_text,
                    )
                    write_dynamic_cache(dynamic_cache_dir, key, {"status": "found", "source": record["closing_source"], "record": record})
                    return record, record["closing_source"]
                except Exception as exc:
                    logger.warning("Dynamic PR record build failed for %s#%s PR #%s: %s", repo, issue_number, pr_number, exc)

    # Source 2: Search merged PRs that mention this issue with closing keywords.
    pr_search_queries = [
        f"repo:{repo} is:pr is:merged \"#{issue_number}\"",
        f"repo:{repo} is:pr is:merged \"fixes #{issue_number}\"",
        f"repo:{repo} is:pr is:merged \"closes #{issue_number}\"",
        f"repo:{repo} is:pr is:merged \"resolves #{issue_number}\"",
    ]
    for query in pr_search_queries:
        payload = client.search_issues_or_prs(query=query, search_type="hybrid", per_page=20, page=1, text_match=False)
        for item in payload.get("items") or []:
            if not isinstance(item, dict) or "pull_request" not in item:
                continue
            pr_num = parse_issue_number_int(item.get("number"))
            if not pr_num:
                continue
            pr = client.get_pr(repo, pr_num)
            if not pr or not pr.get("merged"):
                continue
            text = f"{pr.get('title') or ''}\n\n{pr.get('body') or ''}"
            if issue_number not in extract_closing_issue_numbers(text, repo=repo):
                continue
            try:
                record = build_pr_record(
                    repo=repo,
                    issue=issue,
                    candidate_source="dynamic_pr_body_closing_keyword",
                    client=client,
                    repo_checkout=repo_checkout,
                    patch_dir=patch_dir,
                    pr=pr,
                    include_patch_text=include_patch_text,
                )
                write_dynamic_cache(dynamic_cache_dir, key, {"status": "found", "source": record["closing_source"], "record": record})
                return record, record["closing_source"]
            except Exception as exc:
                logger.warning("Dynamic PR-body record build failed for %s#%s PR #%s: %s", repo, issue_number, pr_num, exc)

    # Source 3: local commit-message closing keyword fallback, mapped to associated PR if possible.
    if repo_checkout is not None and (repo_checkout / ".git").exists():
        try:
            commit_ids = run_git(repo_checkout, "log", "--all", "--date-order", "--pretty=format:%H").splitlines()
        except Exception as exc:
            logger.warning("Failed to scan local commits for %s dynamic issue #%s: %s", repo, issue_number, exc)
            commit_ids = []
        first_commit_only: Optional[Dict[str, Any]] = None
        for sha in commit_ids:
            sha = sha.strip()
            if not sha:
                continue
            try:
                message = run_git(repo_checkout, "show", "-s", "--format=%B", sha)
                commit_date = run_git(repo_checkout, "show", "-s", "--format=%cI", sha)
            except Exception:
                continue
            if issue_number not in extract_closing_issue_numbers(message, repo=repo):
                continue
            if first_commit_only is None:
                first_commit_only = {"commit_sha": sha, "commit_date": commit_date, "message": message}
            try:
                associated_prs = client.get_commit_associated_prs(repo, sha)
            except Exception:
                associated_prs = []
            for pr_preview in associated_prs:
                pr_num = pr_preview.get("number")
                if pr_num is None:
                    continue
                pr = client.get_pr(repo, int(pr_num))
                if not pr or not pr.get("merged"):
                    continue
                try:
                    record = build_pr_record(
                        repo=repo,
                        issue=issue,
                        candidate_source="dynamic_commit_message_closing_keyword_mapped_to_pr",
                        client=client,
                        repo_checkout=repo_checkout,
                        patch_dir=patch_dir,
                        pr=pr,
                        include_patch_text=include_patch_text,
                    )
                    record["dynamic_commit_message_match_sha"] = sha
                    record["dynamic_commit_message_match_date"] = commit_date
                    write_dynamic_cache(dynamic_cache_dir, key, {"status": "found", "source": record["closing_source"], "record": record})
                    return record, record["closing_source"]
                except Exception as exc:
                    logger.warning("Dynamic commit-to-PR record build failed for %s#%s commit %s: %s", repo, issue_number, sha, exc)

            if first_commit_only is not None:
                # Continue scanning briefly for a PR-mapped version before falling back to commit-only.
                break

        if first_commit_only is not None:
            record = build_commit_only_record(
                repo=repo,
                issue=issue,
                candidate_source="dynamic_commit_message_closing_keyword",
                client=client,
                repo_checkout=repo_checkout,
                patch_dir=patch_dir,
                sha=first_commit_only["commit_sha"],
                commit_date=first_commit_only.get("commit_date"),
                include_patch_text=include_patch_text,
            )
            write_dynamic_cache(dynamic_cache_dir, key, {"status": "found", "source": record["closing_source"], "record": record})
            return record, record["closing_source"]

    write_dynamic_cache(dynamic_cache_dir, key, {"status": "not_found", "source": "dynamic_no_canonical_fix_link"})
    return None, "dynamic_no_canonical_fix_link"


def build_commit_only_record(
    *,
    repo: str,
    issue: Dict[str, Any],
    candidate_source: str,
    client: GithubClient,
    repo_checkout: Optional[Path],
    patch_dir: Path,
    sha: str,
    commit_date: Optional[str],
    include_patch_text: bool,
) -> Dict[str, Any]:
    commit_patch_path = patch_dir / "commit_only" / f"{sha}.patch"
    try:
        patch_text, patch_source = collect_patch_for_commit(
            repo=repo,
            repo_path=repo_checkout,
            client=client,
            sha=sha,
            patch_path=commit_patch_path,
        )
    except Exception as exc:
        logger.warning("Failed to collect patch for dynamic commit-only %s@%s: %s", repo, sha, exc)
        patch_text = ""
        patch_source = "missing"
    commit_raw = client.get_commit(repo, sha) or {"sha": sha, "commit": {}}
    commit_record = compact_commit(commit_raw)
    if commit_date and not commit_record.get("committer_date") and not commit_record.get("author_date"):
        commit_record["committer_date"] = commit_date
        commit_record["author_date"] = commit_date
    commit_record["patch_path"] = str(commit_patch_path)
    commit_record["patch_source"] = patch_source
    if include_patch_text:
        commit_record["patch"] = patch_text
    retrieved_max_commit_created_at = max_commit_created_at([commit_record])
    files = commit_raw.get("files") if isinstance(commit_raw, dict) else []
    changed_files = [compact_pr_file(obj) for obj in (files or []) if isinstance(obj, dict)]
    additions = sum(int(f.get("additions") or 0) for f in changed_files)
    deletions = sum(int(f.get("deletions") or 0) for f in changed_files)
    labels = issue.get("labels") or []
    return {
        "repo": repo,
        "issue_number": issue.get("number"),
        "issue_id": issue.get("id"),
        "issue_url": issue.get("html_url"),
        "issue_title": issue.get("title"),
        "issue_body": issue.get("body") or "",
        "issue_state": issue.get("state"),
        "issue_created_at": issue.get("created_at"),
        "issue_updated_at": issue.get("updated_at"),
        "issue_closed_at": issue.get("closed_at"),
        "issue_state_reason": issue.get("state_reason"),
        "issue_labels": [label.get("name") for label in labels if isinstance(label, dict)],
        "closing_event_created_at": None,
        "closing_event_actor": None,
        "closing_source": candidate_source,
        "dynamic_fix_discovery": True,
        "pr_number": None,
        "pr_id": None,
        "pr_url": None,
        "pr_title": None,
        "pr_body": "",
        "pr_state": None,
        "pr_merged": None,
        "pr_created_at": None,
        "pr_updated_at": None,
        "pr_closed_at": None,
        "pr_merged_at": None,
        "merge_commit_sha": None,
        "base_ref": None,
        "base_sha": None,
        "head_ref": None,
        "head_sha": None,
        "additions": additions,
        "deletions": deletions,
        "changed_files_count": len(changed_files),
        "changed_files": changed_files,
        "retrieved_issue_desc": f"{issue.get('title') or ''}\n\n{issue.get('body') or ''}".strip(),
        "retrieved_commit_id": sha,
        "retrieved_commit_ids": [sha],
        "retrieved_max_commit_created_at": retrieved_max_commit_created_at,
        "retrieved_commit_created_at": retrieved_max_commit_created_at,
        "retrieved_patch": patch_text,
        "retrieved_issue_ground_truth_patch": patch_text,
        "pr_patch_path": None,
        "pr_patch": None,
        "merge_commit_patch_path": None,
        "merge_commit_patch": None,
        "patches": [commit_record],
        "patch_paths": [str(commit_patch_path)],
    }


def discover_pr_records(
    *,
    repo: str,
    pr_number: int,
    pr_search_item: Optional[Dict[str, Any]],
    client: GithubClient,
    repo_checkout: Optional[Path],
    patch_dir: Path,
    dynamic_cache_dir: Path,
    include_patch_text: bool,
) -> Tuple[List[Dict[str, Any]], str]:
    key = dynamic_cache_key(repo, pr_number=pr_number)
    cached = read_dynamic_cache(dynamic_cache_dir, key)
    if cached:
        if cached.get("status") == "found" and isinstance(cached.get("records"), list):
            return [r for r in cached["records"] if isinstance(r, dict)], safe_str(cached.get("source")) or "dynamic_pr_cache"
        if cached.get("status") == "not_found":
            return [], safe_str(cached.get("source")) or "dynamic_pr_cache_not_found"

    pr = client.get_pr(repo, pr_number)
    if not pr or not pr.get("merged"):
        write_dynamic_cache(dynamic_cache_dir, key, {"status": "not_found", "source": "dynamic_pr_not_found_or_unmerged"})
        return [], "dynamic_pr_not_found_or_unmerged"

    records: List[Dict[str, Any]] = []

    # Source 1: GraphQL closingIssuesReferences from PR to issues.
    closing_issues: List[Dict[str, Any]] = []
    try:
        closing_issues = client.get_pr_closing_issues_graphql(repo, pr_number)
    except Exception as exc:
        logger.warning("Dynamic PR closingIssuesReferences failed for %s PR #%s: %s", repo, pr_number, exc)
    for issue in closing_issues:
        if not issue.get("number"):
            continue
        try:
            records.append(build_pr_record(
                repo=repo,
                issue=issue,
                candidate_source="dynamic_pr_closing_issues_references",
                client=client,
                repo_checkout=repo_checkout,
                patch_dir=patch_dir,
                pr=pr,
                include_patch_text=include_patch_text,
            ))
        except Exception as exc:
            logger.warning("Failed to build PR closing issue record %s PR #%s issue #%s: %s", repo, pr_number, issue.get("number"), exc)

    # Source 2: PR body closing keyword references.
    if not records:
        referenced_numbers = extract_closing_issue_numbers(f"{pr.get('title') or ''}\n\n{pr.get('body') or ''}", repo=repo)
        for issue_number in sorted(referenced_numbers):
            issue = client.get_issue(repo, int(issue_number))
            if not issue or "pull_request" in issue:
                continue
            try:
                records.append(build_pr_record(
                    repo=repo,
                    issue=issue,
                    candidate_source="dynamic_pr_body_closing_keyword_reverse",
                    client=client,
                    repo_checkout=repo_checkout,
                    patch_dir=patch_dir,
                    pr=pr,
                    include_patch_text=include_patch_text,
                ))
            except Exception as exc:
                logger.warning("Failed to build reverse PR-body issue record %s PR #%s issue #%s: %s", repo, pr_number, issue_number, exc)

    # Source 3: PR-only fallback. This is last-resort and still strict on PR creation/fix time.
    if not records:
        try:
            records.append(build_pr_only_record(
                repo=repo,
                pr=pr,
                client=client,
                repo_checkout=repo_checkout,
                patch_dir=patch_dir,
                candidate_source="dynamic_pr_only_fallback",
                include_patch_text=include_patch_text,
            ))
        except Exception as exc:
            logger.warning("Failed to build PR-only fallback record %s PR #%s: %s", repo, pr_number, exc)

    if records:
        source = safe_str(records[0].get("closing_source")) or "dynamic_pr_records"
        write_dynamic_cache(dynamic_cache_dir, key, {"status": "found", "source": source, "records": records})
        return records, source
    write_dynamic_cache(dynamic_cache_dir, key, {"status": "not_found", "source": "dynamic_pr_no_usable_records"})
    return [], "dynamic_pr_no_usable_records"


def historical_fix_commit_datetimes(record: Dict[str, Any]) -> List[dt.datetime]:
    values: List[Any] = []
    for key in ("retrieved_max_commit_created_at", "retrieved_commit_created_at", "merge_commit_created_at", "commit_created_at"):
        value = record.get(key)
        if value:
            values.append(value)
    patches = record.get("patches")
    if isinstance(patches, list):
        for patch_record in patches:
            if not isinstance(patch_record, dict):
                continue
            for key in ("committer_date", "author_date", "commit_date", "created_at"):
                value = patch_record.get(key)
                if value:
                    values.append(value)
    parsed: List[dt.datetime] = []
    for value in values:
        parsed_value = parse_datetime_to_utc(value)
        if parsed_value is not None:
            parsed.append(parsed_value)
    return parsed


def historical_max_fix_commit_datetime(record: Dict[str, Any]) -> Optional[dt.datetime]:
    dates = historical_fix_commit_datetimes(record)
    return max(dates) if dates else None


def candidate_commit_shas(record: Dict[str, Any]) -> set[str]:
    keys = (
        "retrieved_commit_id",
        "retrieved_commit_ids",
        "merge_commit_sha",
        "commit_id",
        "commit_ids",
        "commit_sha",
        "commit_shas",
        "patches",
        "retrieved_patch",
        "retrieved_issue_ground_truth_patch",
        "pr_patch",
        "merge_commit_patch",
        "patch_paths",
    )
    result: set[str] = set()
    for key in keys:
        result.update(extract_sha_set(record.get(key)))
    return result


def historical_record_contains_any_sha(record: Dict[str, Any], shas: set[str]) -> set[str]:
    if not shas:
        return set()
    text = json.dumps(record, ensure_ascii=False, sort_keys=True).lower()
    return {sha for sha in shas if sha and sha in text}


def compute_boundary(instance: Dict[str, Any], base_time: Optional[dt.datetime]) -> Tuple[float, str, str]:
    new_issue_boundary = parse_datetime_to_utc(
        instance.get("new_issue_search_boundary_at")
    )
    new_issue_boundary_ts = datetime_to_ts(new_issue_boundary)
    if new_issue_boundary_ts > 0.0:
        return (
            new_issue_boundary_ts,
            isoformat_utc(new_issue_boundary),
            "new_issue_search_boundary_at",
        )
    base_ts = datetime_to_ts(base_time)
    if base_ts <= 0.0:
        return 0.0, "", "missing_base_commit_time"
    boundary_ts = base_ts
    source = "base_commit_ts"
    instance_create_at = parse_datetime_to_utc(instance.get("instance_create_at"))
    instance_create_ts = datetime_to_ts(instance_create_at)
    if instance_create_ts > 0.0 and instance_create_ts < boundary_ts:
        boundary_ts = instance_create_ts
        source = "instance_create_at"
    boundary_iso = isoformat_utc(dt.datetime.fromtimestamp(boundary_ts, tz=dt.timezone.utc))
    return boundary_ts, boundary_iso, source


def validate_candidate(
    *,
    instance: Dict[str, Any],
    record: Dict[str, Any],
    base_time: Optional[dt.datetime],
    all_target_commits: set[str],
    enable_issue_number_guard: bool,
    enable_target_leakage_check: bool = True,
) -> Tuple[bool, str, Dict[str, Any]]:
    if enable_target_leakage_check:
        boundary_ts, boundary_iso, boundary_source = compute_boundary(
            instance, base_time
        )
    else:
        boundary_ts, boundary_iso = 0.0, ""
        boundary_source = "target_specific_leakage_check_disabled"
    details: Dict[str, Any] = {
        "boundary_ts": boundary_ts,
        "boundary_iso": boundary_iso,
        "boundary_source": boundary_source,
    }
    if enable_target_leakage_check and boundary_ts <= 0.0:
        return False, "missing_base_commit_time", details

    instance_repo = normalize_repo(instance.get("repo"))
    candidate_repo = normalize_repo(record.get("repo"))
    if repo_identity_key(candidate_repo) != repo_identity_key(instance_repo):
        return False, "repo_mismatch", details

    instance_issue_number = parse_issue_number_int(instance.get("instance_issue_number"))
    candidate_issue_number = parse_issue_number_int(record.get("issue_number"))
    details["instance_issue_number"] = instance_issue_number
    details["candidate_issue_number"] = candidate_issue_number
    details["target_leakage_check"] = enable_target_leakage_check
    if (
        enable_target_leakage_check
        and enable_issue_number_guard
        and instance_issue_number
        and candidate_issue_number
    ):
        if candidate_issue_number >= instance_issue_number:
            return False, "candidate_issue_number_not_older", details

    # For issue-linked records, this is issue_created_at. For PR-only fallback records,
    # build_pr_only_record intentionally sets issue_created_at to PR created_at.
    issue_created_at = parse_datetime_to_utc(record.get("issue_created_at"))
    issue_ts = datetime_to_ts(issue_created_at)
    details["retrieved_issue_created_at"] = isoformat_utc(issue_created_at)
    details["retrieved_issue_created_at_ts"] = issue_ts
    if enable_target_leakage_check and (
        issue_ts <= 0.0 or issue_ts >= boundary_ts
    ):
        return False, "retrieved_issue_time_missing_or_not_before_boundary", details

    fix_dt = historical_max_fix_commit_datetime(record)
    fix_ts = datetime_to_ts(fix_dt)
    details["retrieved_max_fix_commit_created_at"] = isoformat_utc(fix_dt)
    details["retrieved_max_fix_commit_created_at_ts"] = fix_ts
    if enable_target_leakage_check and (
        fix_ts <= 0.0 or fix_ts >= boundary_ts
    ):
        return False, "retrieved_fix_time_missing_or_not_before_boundary", details

    target_commit = (
        infer_target_commit_from_instance(instance)
        if enable_target_leakage_check
        else ""
    )
    shas = candidate_commit_shas(record)
    details["candidate_commit_shas"] = sorted(shas)

    if target_commit and target_commit in shas:
        details["matched_target_commits"] = [target_commit]
        return False, "candidate_uses_current_target_commit", details

    global_hits = shas & all_target_commits
    if global_hits:
        details["matched_target_commits"] = sorted(global_hits)
        return False, "candidate_uses_global_swebench_target_commit", details

    text_hits = historical_record_contains_any_sha(record, all_target_commits)
    if text_hits:
        details["matched_target_commits"] = sorted(text_hits)
        return False, "candidate_text_mentions_global_swebench_target_commit", details

    return True, "safe", details


def run_search_with_cache(
    *,
    client: GithubClient,
    query: str,
    search_type: str,
    per_page: int,
    page: int,
    text_match: bool,
    cache_dir: Path,
    refresh_cache: bool,
    sleep_seconds: float,
) -> Dict[str, Any]:
    path = search_cache_path(cache_dir, query, search_type, per_page, page)
    if path.exists() and not refresh_cache:
        cached = read_json(path)
        if cached and isinstance(cached.get("payload"), dict):
            cached = dict(cached)
            cached["cache_hit"] = True
            return cached
    if sleep_seconds > 0:
        time.sleep(
            sleep_seconds + random.random() * min(1.0, sleep_seconds)
        )
    payload = client.search_issues_or_prs(
        query=query,
        search_type=search_type,
        per_page=per_page,
        page=page,
        text_match=text_match,
    )
    effective_query = (
        safe_str(payload.get("_search_query_effective")) or query
    )
    effective_query_text = safe_str(
        payload.get("_search_query_effective_text")
    )
    actual_search_type = safe_str(payload.get("search_type")) or search_type
    fallback_reason = (
        payload.get("fallback_reason")
        or payload.get("search_fallback_reason")
        or payload.get("search_type_fallback_reason")
        or payload.get("lexical_fallback_reason")
    )
    wrapped = {
        "query": query,
        "effective_query": effective_query,
        "effective_query_text": effective_query_text,
        "query_failed": bool(payload.get("_search_query_failed")),
        "query_error": payload.get("query_error"),
        "query_auto_truncated": bool(
            payload.get("_search_query_auto_truncated")
        ),
        "query_original_chars": safe_int(
            payload.get("_search_query_original_chars"),
            len(query),
        ),
        "query_effective_chars": safe_int(
            payload.get("_search_query_effective_chars"),
            len(effective_query),
        ),
        "query_request_attempts": safe_int(
            payload.get("_search_query_request_attempts"),
            1,
        ),
        "query_original_422_error": payload.get(
            "_search_query_original_422_error"
        ),
        "problem_original_chars": payload.get(
            "_search_problem_original_chars"
        ),
        "problem_effective_chars": payload.get(
            "_search_problem_effective_chars"
        ),
        "requirements_original_chars": payload.get(
            "_search_requirements_original_chars"
        ),
        "requirements_effective_chars": payload.get(
            "_search_requirements_effective_chars"
        ),
        "search_type": search_type,
        "requested_search_type": search_type,
        "actual_search_type": actual_search_type,
        "search_type_fallback": bool(
            actual_search_type != search_type or fallback_reason
        ),
        "search_fallback_reason": fallback_reason,
        "search_response_metadata": {
            key: value
            for key, value in payload.items()
            if key not in {"items", "total_count"}
        },
        "per_page": per_page,
        "page": page,
        "payload": payload,
        "cache_hit": False,
        "cached_at": isoformat_utc(dt.datetime.now(dt.timezone.utc)),
    }
    # Validation failures can be transient (for example abuse protection), so
    # preserve them in the run audit but do not persist them as reusable search
    # cache entries.
    if not wrapped["query_failed"]:
        write_json_atomic(path, wrapped)
    return wrapped


def resolve_base_commit_time(
    *,
    instance: Dict[str, Any],
    repo_checkout: Optional[Path],
    client: GithubClient,
    cache_dir: Path,
) -> Tuple[Optional[dt.datetime], str]:
    for field in ("base_commit_ts", "base_commit_created_at"):
        parsed = parse_datetime_to_utc(instance.get(field))
        if parsed is not None:
            return parsed, f"instance_field:{field}"
    parsed_created_at = parse_datetime_to_utc(instance.get("created_at"))
    if parsed_created_at is not None:
        return parsed_created_at, "instance_field:created_at_last_resort"

    repo = normalize_repo(instance.get("repo"))
    sha = safe_str(instance.get("base_commit"))
    if not repo or not sha:
        return None, "missing_repo_or_base_commit"

    cache_path = commit_time_cache_path(cache_dir, repo, sha)
    cached = read_json(cache_path)
    if cached:
        parsed = parse_datetime_to_utc(cached.get("commit_time"))
        if parsed is not None:
            return parsed, "commit_cache"

    if repo_checkout is not None:
        parsed = get_commit_time_from_git(repo_checkout, sha)
        if parsed is not None:
            write_json_atomic(cache_path, {
                "repo": repo,
                "sha": sha,
                "commit_time": isoformat_utc(parsed),
                "source": "git",
                "cached_at": isoformat_utc(dt.datetime.now(dt.timezone.utc)),
            })
            return parsed, "git"

    try:
        payload = client.get_commit(repo, sha)
        if payload:
            commit = payload.get("commit") or {}
            committer = commit.get("committer") or {}
            author = commit.get("author") or {}
            parsed = parse_datetime_to_utc(committer.get("date")) or parse_datetime_to_utc(author.get("date"))
            if parsed is not None:
                write_json_atomic(cache_path, {
                    "repo": repo,
                    "sha": sha,
                    "commit_time": isoformat_utc(parsed),
                    "source": "github_commit_api",
                    "cached_at": isoformat_utc(dt.datetime.now(dt.timezone.utc)),
                })
                return parsed, "github_commit_api"
    except Exception as exc:
        logger.warning("Failed to query base commit time for %s@%s: %s", repo, sha, exc)
    return None, "unresolved"


def make_output_record(
    *,
    instance: Dict[str, Any],
    historical_record: Dict[str, Any],
    github_hit: Dict[str, Any],
    query_text: str,
    github_query: str,
    search_phase: str,
    search_kind: str,
    search_type: str,
    search_rank: int,
    safe_position: int,
    base_time: Optional[dt.datetime],
    base_time_source: str,
    leakage_details: Dict[str, Any],
    record_origin: str,
) -> Dict[str, Any]:
    instance_id = instance_identifier(instance)
    repo = normalize_repo(instance.get("repo"))
    issue_number = parse_issue_number_int(historical_record.get("issue_number"))
    issue_desc = safe_str(historical_record.get("retrieved_issue_desc")) or (
        f"{historical_record.get('issue_title') or ''}\n\n{historical_record.get('issue_body') or ''}".strip()
    )
    github_score = safe_float(github_hit.get("score"), default=0.0)
    retrieved_doc_id = f"github_api_v4::{repo}#issue-{issue_number}" if issue_number else f"github_api_v4::{repo}#pr-{historical_record.get('pr_number')}"

    return {
        "instance_id": instance_id,
        "instance_repo": repo,
        "instance_repo_name": repo_name_from_repo(repo),
        "instance_issue_number": parse_issue_number_int(instance.get("instance_issue_number")),
        "instance_create_at": safe_str(instance.get("instance_create_at")) or None,
        "instance_create_at_ts": datetime_to_ts(parse_datetime_to_utc(instance.get("instance_create_at"))) or None,
        "instance_base_commit": safe_str(instance.get("base_commit")),
        "instance_base_commit_created_at": isoformat_utc(base_time),
        "instance_base_commit_created_at_ts": datetime_to_ts(base_time),
        "instance_base_commit_time_source": base_time_source,
        "target_commit": infer_target_commit_from_instance(instance),
        "problem_statement": safe_str(instance.get("problem_statement")),
        "requirements": safe_str(instance.get("requirements")),
        "problem_statement_summary": query_text,

        "retrieval_source": "github_api_v4_boundary_dynamic_fix_discovery",
        "retrieval_filter_source": "strict_issue_or_pr_time_and_fix_commit_cutoff_local_validation",
        "ranking_source": f"github_{search_type}_search_boundary_query_planning",
        "qwen_reranked": False,

        "retrieval_rank": search_rank,
        "retrieval_distance": None,
        "retrieval_similarity_estimate": None,
        "candidate_pool_position": safe_position,
        "reranked_position": safe_position,
        "relevance_score": None,
        "reranker_model": None,
        "reranking_error": None,

        "github_search_type": search_type,
        "github_search_kind": search_kind,
        "github_search_phase": search_phase,
        "search_phase": search_phase,
        "github_search_query": github_query,
        "github_search_query_text": query_text,
        "github_search_rank": search_rank,
        "github_search_safe_position": safe_position,
        "github_search_score": github_score,
        "github_search_item_url": github_hit.get("html_url"),
        "github_search_text_matches": github_hit.get("text_matches"),

        "record_origin": record_origin,
        "dynamic_fix_discovery": bool(historical_record.get("dynamic_fix_discovery")),
        "leakage_boundary_ts": leakage_details.get("boundary_ts"),
        "leakage_boundary_iso": leakage_details.get("boundary_iso"),
        "leakage_boundary_source": leakage_details.get("boundary_source"),
        "leakage_rejection_passed": True,
        "leakage_decision": "safe",
        "issue_number_guard_enabled": False,

        "retrieved_doc_id": retrieved_doc_id,
        "retrieved_issue_desc": issue_desc,
        "retrieved_metadata": {
            "doc_type": historical_record.get("doc_type") or "historical_issue",
            "repo": repo,
            "repo_name": repo_name_from_repo(repo),
            "historical_row_key": f"{repo}#{issue_number}" if issue_number else None,
            "issue_number": issue_number,
            "issue_number_int": issue_number or 0,
            "issue_id": historical_record.get("issue_id"),
            "issue_url": historical_record.get("issue_url"),
            "issue_created_at": historical_record.get("issue_created_at"),
            "issue_created_at_ts": leakage_details.get("retrieved_issue_created_at_ts"),
            "retrieved_max_commit_created_at": leakage_details.get("retrieved_max_fix_commit_created_at"),
            "retrieved_max_commit_created_at_ts": leakage_details.get("retrieved_max_fix_commit_created_at_ts"),
            "retrieved_commit_id": historical_record.get("retrieved_commit_id"),
            "retrieved_grounding_commit_id": historical_record.get(
                "retrieved_grounding_commit_id"
            ),
            "retrieved_grounding_commit_source": historical_record.get(
                "retrieved_grounding_commit_source"
            ),
            "merge_commit_sha": historical_record.get("merge_commit_sha"),
            "pr_number": historical_record.get("pr_number"),
            "pr_url": historical_record.get("pr_url"),
            "closing_source": historical_record.get("closing_source"),
            "record_origin": record_origin,
        },

        "retrieved_issue_number": issue_number,
        "retrieved_issue_id": historical_record.get("issue_id"),
        "retrieved_issue_url": historical_record.get("issue_url"),
        "retrieved_issue_title": historical_record.get("issue_title"),
        "retrieved_issue_body": historical_record.get("issue_body"),
        "retrieved_issue_created_at": historical_record.get("issue_created_at"),
        "retrieved_issue_closed_at": historical_record.get("issue_closed_at"),
        "retrieved_pr_number": historical_record.get("pr_number"),
        "retrieved_pr_url": historical_record.get("pr_url"),
        "retrieved_commit_id": historical_record.get("retrieved_commit_id"),
        "retrieved_grounding_commit_id": historical_record.get(
            "retrieved_grounding_commit_id"
        ),
        "retrieved_grounding_commit_source": historical_record.get(
            "retrieved_grounding_commit_source"
        ),
        "retrieved_commit_ids": historical_record.get("retrieved_commit_ids"),
        "retrieved_patch": historical_record.get("retrieved_patch"),
        "retrieved_issue_ground_truth_patch": historical_record.get("retrieved_issue_ground_truth_patch"),
        "pr_patch_path": historical_record.get("pr_patch_path"),
        "merge_commit_patch_path": historical_record.get("merge_commit_patch_path"),
        "patch_paths": historical_record.get("patch_paths"),
        "closing_source": historical_record.get("closing_source"),
    }


def instance_checkpoint_path(checkpoint_dir: Path, instance_id: str) -> Path:
    return checkpoint_dir / f"{safe_filename_part(instance_id)}.json"


def early_hit_time_rejects(hit: Dict[str, Any], boundary_ts: float) -> Optional[str]:
    created_at = parse_datetime_to_utc(hit.get("created_at"))
    created_ts = datetime_to_ts(created_at)
    if created_ts > 0.0 and created_ts >= boundary_ts:
        return "github_hit_created_at_not_before_boundary"
    return None


def record_unique_key(record: Dict[str, Any]) -> str:
    repo = normalize_repo(record.get("repo"))
    issue_number = parse_issue_number_int(record.get("issue_number"))
    if issue_number:
        return f"issue::{repo}#{issue_number}"
    pr_number = parse_issue_number_int(record.get("pr_number"))
    if pr_number:
        return f"pr::{repo}#{pr_number}"
    return f"record::{repo}::{content_hash(json.dumps(record, ensure_ascii=False, sort_keys=True))}"
