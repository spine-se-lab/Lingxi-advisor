from __future__ import annotations

from ...internal.execution import run_blocking

import asyncio
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

try:
    from mcp.server.fastmcp import Context
except ImportError:
    Context = Any  # type: ignore[misc,assignment]

from ...capabilities.activate.lingxi_advisor_apply import LingxiAdvisorApplyRequest
from ...capabilities.activate.lingxi_advisor_search import (
    TargetIssue,
    LingxiAdvisorSearchRequest,
)
from ...config import ServerSettings
from ...internal.search_retrieval.contracts import (
    SearchRetrievalOptions,
    SimilarityGateOptions,
)
from ...internal.search_retrieval.preretrieved_store import PreretrievedStore
from .gateway import MCPServerPolicy
from .host_sampling import HostSamplingBridge

RUNTIME_TOOLS = ('lingxi.advisor.search', 'lingxi.advisor.apply')


@dataclass(frozen=True)
class RuntimeSearchContext:
    repo: str | None = None
    base_commit: str | None = None
    instance_id: str | None = None
    issue_number: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            key: value
            for key, value in (
                ('repo', self.repo),
                ('base_commit', self.base_commit),
                ('instance_id', self.instance_id),
                ('issue_number', self.issue_number),
            )
            if value not in (None, '')
        }


@dataclass(frozen=True)
class RuntimeTargetIssue:
    instance_id: str | None = None
    issue_number: int | None = None
    created_at: str | None = None

    def to_target_issue(self) -> TargetIssue:
        return TargetIssue.from_mapping(
            {
                key: value
                for key, value in (
                    ('instance_id', self.instance_id),
                    ('issue_number', self.issue_number),
                    ('created_at', self.created_at),
                )
                if value not in (None, '')
            }
        )


def _register_runtime_tools(
    mcp: Any,
    *,
    activation: Any,
    apply_capability: Any,
    policy: MCPServerPolicy,
    settings: ServerSettings | None = None,
    host_capabilities_factory: Callable[[HostSamplingBridge], Any] | None = None,
    path_redactor: Callable[[str], str] | None = None,
) -> None:
    policy.validate()
    approved_matches: dict[tuple[str, str], dict[str, Any]] = {}

    @mcp.tool(
        name='lingxi.advisor.search',
        description=(
            'Search safe same-repository historical issue knowledge. '
            'Provide issue_description, or provide repo plus a positive '
            'issue_number so bounded Search can load the public issue text. '
            'Prefer repo, instance_id, and base_commit when the host provides '
            'a SWE-bench style identity. Normal bounded Search treats repo '
            'plus issue_number as a new issue. Evaluation Search preserves '
            'benchmark target identity and target-specific leakage behavior. The '
            'existing Artifact lifecycle '
            'reuses valid knowledge or prepares missing or invalid knowledge.'
        ),
    )
    async def lingxi_advisor_search_tool(
        issue_description: str = '',
        context: RuntimeSearchContext | None = None,
        target_issue: RuntimeTargetIssue | None = None,
        generation_mode: str = 'light',
        search_candidate_count: int = 5,
        final_top_k: int = 3,
        update_preretrieved: bool | None = None,
        run_gate_for_preretrieved: bool = False,
        search_type: str = 'semantic',
        fallback_search_type: str = 'hybrid',
        minimum_similarity_score: int = 2,
        maximum_misleading_risk: int = 3,
        resume: bool = True,
        refresh_instance_metadata: bool = False,
        refresh_search_cache: bool = False,
        ctx: Context = None,  # type: ignore[assignment]
    ) -> dict[str, Any]:
        retrieval_strategy = os.environ.get(
            'LINGXI_ADVISOR_RETRIEVAL_STRATEGY', 'bounded'
        ).strip().lower()
        if retrieval_strategy not in {'bounded', 'evaluation'}:
            raise RuntimeError(
                'LINGXI_ADVISOR_RETRIEVAL_STRATEGY must be bounded or evaluation.'
            )
        effective_update_preretrieved = (
            policy.allow_update_preretrieved
            if update_preretrieved is None
            else update_preretrieved
        )
        _validate_request_policy(
            policy,
            generation_mode=generation_mode,
            search_candidate_count=search_candidate_count,
            final_top_k=final_top_k,
            update_preretrieved=effective_update_preretrieved,
            refresh_requested=(
                refresh_instance_metadata or refresh_search_cache
            ),
        )
        request = LingxiAdvisorSearchRequest(
            issue_description=issue_description,
            context=context.to_dict() if context is not None else {},
            target_issue=(
                target_issue.to_target_issue()
                if target_issue is not None
                else None
            ),
            generation_mode=generation_mode,  # type: ignore[arg-type]
            search_options=SearchRetrievalOptions(
                search_candidate_count=search_candidate_count,
                final_top_k=final_top_k,
                retrieval_strategy=retrieval_strategy,  # type: ignore[arg-type]
                update_preretrieved=effective_update_preretrieved,
                run_gate_for_preretrieved=run_gate_for_preretrieved,
                search_type=search_type,
                fallback_search_type=fallback_search_type,
                per_page=100 if retrieval_strategy == 'evaluation' else 25,
                search_pages=3 if retrieval_strategy == 'evaluation' else 1,
                fallback_search_pages=(
                    2 if retrieval_strategy == 'evaluation' else 1
                ),
                max_search_hits_to_resolve=(
                    300 if retrieval_strategy == 'evaluation' else 40
                ),
                max_phases=None if retrieval_strategy == 'evaluation' else 4,
                enable_commit_message_fallback=(
                    retrieval_strategy == 'evaluation'
                ),
                refresh_search_cache=refresh_search_cache,
            ),
            gate_options=SimilarityGateOptions(
                minimum_similarity_score=minimum_similarity_score,
                maximum_misleading_risk=maximum_misleading_risk,
            ),
            resume=resume,
            refresh_instance_metadata=refresh_instance_metadata,
        )
        request.validate()
        _validate_live_search_policy(activation, policy=policy, request=request)
        call_activation: Any = activation
        resolved = settings.resolved() if settings is not None else None
        needs_host = bool(
            host_capabilities_factory is not None
            and resolved is not None
            and (
                not resolved.judge_model_configured
                or not resolved.generator_model_configured
            )
        )
        if needs_host:
            if ctx is None:
                raise RuntimeError(
                    'No model is configured and no Host sampling context exists.'
                )
            bridge = HostSamplingBridge(
                session=ctx.session,
                event_loop=asyncio.get_running_loop(),
                related_request_id=getattr(ctx, 'request_id', None),
                timeout_seconds=max(
                    resolved.judge_timeout_seconds,
                    resolved.generator_timeout_seconds,
                ),
            )
            assert host_capabilities_factory is not None
            call_activation = host_capabilities_factory(bridge).activation
        result = await run_blocking(call_activation.search, request)
        value = _result_mapping(result)
        _validate_knowledge_size(value, policy.max_knowledge_chars)
        redactor = path_redactor or getattr(
            activation,
            '_redact_server_paths',
            None,
        )
        if callable(redactor):
            _redact_result_errors(value, redactor)
        for item in value.get('knowledge_matches', []):
            if not isinstance(item, Mapping):
                continue
            key = _artifact_ref_key(item.get('artifact_ref'))
            if key is not None:
                approved_matches[key] = dict(item)
        return value

    @mcp.tool(
        name='lingxi.advisor.apply',
        description=(
            'Turn Search-approved knowledge into bounded source-attributed '
            'guidance for the current public issue. Pass the unchanged '
            'knowledge_matches when possible; if the host truncates large '
            'tool results, each match artifact_ref is sufficient for this '
            'server process to restore and verify the approved match.'
        ),
    )
    async def lingxi_advisor_apply_tool(
        issue_description: str,
        knowledge_matches: list[dict[str, Any]],
    ) -> dict[str, Any]:
        restored_matches: list[dict[str, Any]] = []
        for item in knowledge_matches:
            if not isinstance(item, Mapping):
                restored_matches.append(item)
                continue
            key = _artifact_ref_key(item.get('artifact_ref'))
            approved = approved_matches.get(key) if key is not None else None
            restored_matches.append(dict(approved or item))
        request = LingxiAdvisorApplyRequest.from_mapping(
            {
                'issue_description': issue_description,
                'knowledge_matches': restored_matches,
            }
        )
        result = await run_blocking(apply_capability.apply, request)
        value = _result_mapping(result)
        return {
            'status': value.get('status'),
            'content': value.get('content') or '',
            'source_artifact_refs': value.get('source_artifact_refs') or [],
            'error': value.get('error'),
        }


def _artifact_ref_key(value: Any) -> tuple[str, str] | None:
    if not isinstance(value, Mapping):
        return None
    generation_mode = str(value.get('generation_mode') or '').strip()
    cache_key = str(value.get('knowledge_cache_key') or '').strip()
    if not generation_mode or not cache_key:
        return None
    return generation_mode, cache_key

def _validate_request_policy(
    policy: MCPServerPolicy,
    *,
    generation_mode: str,
    search_candidate_count: int,
    final_top_k: int,
    update_preretrieved: bool,
    refresh_requested: bool,
) -> None:
    if generation_mode not in policy.allowed_generation_modes:
        raise PermissionError(f'generation mode is disabled: {generation_mode}')
    if search_candidate_count > policy.max_search_candidate_count:
        raise ValueError('search_candidate_count exceeds the server limit')
    if final_top_k > policy.max_final_top_k:
        raise ValueError('final_top_k exceeds the server limit')
    if final_top_k > search_candidate_count:
        raise ValueError('final_top_k cannot exceed search_candidate_count')
    if update_preretrieved and not policy.allow_update_preretrieved:
        raise PermissionError('Pre-retrieved writes are disabled.')
    if refresh_requested and not policy.allow_refresh:
        raise PermissionError('Refresh operations are disabled.')

def _validate_live_search_policy(
    activation: Any,
    *,
    policy: MCPServerPolicy,
    request: LingxiAdvisorSearchRequest,
) -> None:
    if policy.allow_live_search:
        return
    directory = getattr(activation, 'preretrieved_dir_for_activation', None)
    if directory is None:
        directory = getattr(activation, 'preretrieved_dir', None)
    if directory is None:
        raise PermissionError('Live search is disabled without a cache.')
    instance = request.internal_instance()
    store = PreretrievedStore(Path(directory))
    if instance is not None:
        rows, _rejected = store.find(instance)
    else:
        rows, _rejected = store.find_portable(
            issue_description=request.issue_description,
            context=request.context,
        )
    if not rows:
        raise PermissionError('Live search is disabled and no candidate exists.')

def _result_mapping(result: Any) -> dict[str, Any]:
    if isinstance(result, Mapping):
        return dict(result)
    converter = getattr(result, 'to_dict', None)
    if not callable(converter):
        raise TypeError('Capability result must be a mapping')
    value = converter()
    if not isinstance(value, Mapping):
        raise TypeError('Capability to_dict result must be a mapping')
    return dict(value)

def _validate_knowledge_size(
    result: Mapping[str, Any],
    max_knowledge_chars: int,
) -> None:
    for item in result.get('knowledge_matches', []):
        if not isinstance(item, Mapping):
            continue
        if len(str(item.get('knowledge_xml') or '')) > max_knowledge_chars:
            raise ValueError('knowledge artifact exceeds the response limit')

def _redact_result_errors(
    value: dict[str, Any],
    redactor: Callable[[str], str],
) -> None:
    error = str(value.get('error') or '').strip()
    if error:
        value['error'] = redactor(error)
    for item in value.get('unresolved_knowledge', []):
        if isinstance(item, dict) and item.get('reason'):
            item['reason'] = redactor(str(item['reason']))

__all__ = ['RUNTIME_TOOLS']
