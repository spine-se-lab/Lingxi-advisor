from __future__ import annotations

import datetime as dt
import logging
from pathlib import Path
from typing import Any

from .closed_pulls import ClosedPullBodyIndex
from ..io_utils import read_json, safe_part, write_json_atomic
from .repository import CommitClosingIndex, RepositoryProvider
from .. import github as v4

logger = logging.getLogger(__name__)


class FixDiscoveryService:
    """02/05 canonical fix discovery behind a reusable service boundary.

    Priority for issue hits:
      1. full GraphQL ClosedEvent timeline -> merged PR closer;
      2. GraphQL issue -> closing pull-request relation;
      3. merged PR body with an explicit closing keyword;
      4. local commit-message closing keyword, mapped to a merged PR when possible;
      5. commit-only fallback.

    Priority for PR hits:
      1. GraphQL closingIssuesReferences;
      2. explicit closing keyword references in PR title/body.

    PR-only records are intentionally excluded because this stage promises a
    pool of closed *issues*, not arbitrary similar PRs.
    """

    CACHE_SCHEMA_VERSION = 4

    def __init__(
        self,
        *,
        cache_root: Path,
        patch_root: Path,
        repository_provider: RepositoryProvider,
        commit_index: CommitClosingIndex,
        pr_body_index: ClosedPullBodyIndex,
    ) -> None:
        self.cache_root = cache_root
        self.patch_root = patch_root
        self.repository_provider = repository_provider
        self.commit_index = commit_index
        self.pr_body_index = pr_body_index
        self._commit_matches: dict[str, dict[int, list[Any]]] = {}

    def _cache_path(self, repo: str, kind: str, number: int) -> Path:
        owner, name = repo.split("/", 1)
        return (
            self.cache_root
            / "fix_discovery"
            / f"{safe_part(owner)}__{safe_part(name)}"
            / f"{kind}_{int(number)}.json"
        )

    def _profile(
        self,
        *,
        enable_commit_message_fallback: bool,
        include_patch_text: bool,
        allow_exhaustive_fallbacks: bool = True,
    ) -> dict[str, Any]:
        return {
            "schema_version": self.CACHE_SCHEMA_VERSION,
            "enable_commit_message_fallback": enable_commit_message_fallback,
            "include_patch_text": include_patch_text,
            "allow_exhaustive_fallbacks": allow_exhaustive_fallbacks,
        }

    def _read_cached(self, path: Path, profile: dict[str, Any]) -> dict[str, Any] | None:
        cached = read_json(path)
        if not cached or cached.get("profile") != profile:
            return None
        return cached

    def _write_cached(self, path: Path, profile: dict[str, Any], payload: dict[str, Any]) -> None:
        write_json_atomic(
            path,
            {
                "profile": profile,
                "cached_at": v4.isoformat_utc(dt.datetime.now(dt.timezone.utc)),
                **payload,
            },
        )

    def _patch_dir(self, repo: str) -> Path:
        owner, name = repo.split("/", 1)
        return self.patch_root / f"{safe_part(owner)}__{safe_part(name)}"

    def _build_pr_record(
        self,
        *,
        repo: str,
        issue: dict[str, Any],
        pr: dict[str, Any],
        source: str,
        client: v4.GithubClient,
        include_patch_text: bool,
        close_event: dict[str, Any] | None = None,
        repo_checkout: Path | None = None,
    ) -> dict[str, Any]:
        return v4.build_pr_record(
            repo=repo,
            issue=issue,
            candidate_source=source,
            client=client,
            repo_checkout=repo_checkout,
            patch_dir=self._patch_dir(repo),
            pr=pr,
            close_event=close_event,
            include_patch_text=include_patch_text,
        )

    def _load_commit_matches(self, repo: str, *, refresh_repository: bool) -> dict[int, list[Any]]:
        if repo not in self._commit_matches or refresh_repository:
            self._commit_matches[repo] = self.commit_index.load_matches(
                repo,
                refresh_repository=refresh_repository,
            )
        return self._commit_matches[repo]

    def discover_issue(
        self,
        *,
        repo: str,
        issue_number: int,
        issue: dict[str, Any],
        client: v4.GithubClient,
        include_patch_text: bool,
        enable_commit_message_fallback: bool,
        refresh_repository: bool,
        closed_pulls_ttl_seconds: int,
        refresh_closed_pulls: bool,
        allow_exhaustive_fallbacks: bool = True,
    ) -> tuple[dict[str, Any] | None, str]:
        profile = self._profile(
            enable_commit_message_fallback=enable_commit_message_fallback,
            include_patch_text=include_patch_text,
            allow_exhaustive_fallbacks=allow_exhaustive_fallbacks,
        )
        cache_path = self._cache_path(repo, "issue", issue_number)
        cached = self._read_cached(cache_path, profile)
        if cached:
            if cached.get("status") == "found" and isinstance(cached.get("record"), dict):
                return cached["record"], str(cached.get("source") or "fix_cache")
            if cached.get("status") == "not_found":
                return None, str(cached.get("source") or "fix_cache_not_found")

        # Source 1: full ClosedEvent timeline, latest PR closer.
        try:
            close_event = client.get_issue_latest_pr_closer_event_graphql(repo, issue_number)
        except Exception as exc:
            logger.warning("GraphQL closer discovery failed for %s#%s: %s", repo, issue_number, exc)
            close_event = None
        if close_event is not None:
            closer = close_event.get("closer") or {}
            pr_number = v4.parse_issue_number_int(closer.get("number"))
            if pr_number is not None:
                pr = client.get_pr(repo, pr_number)
                if pr and pr.get("merged"):
                    try:
                        record = self._build_pr_record(
                            repo=repo,
                            issue=issue,
                            pr=pr,
                            source="graphql_closed_event_closer_pull_request",
                            client=client,
                            include_patch_text=include_patch_text,
                            close_event=close_event,
                        )
                        self._write_cached(cache_path, profile, {
                            "status": "found",
                            "source": record.get("closing_source"),
                            "record": record,
                        })
                        return record, str(record.get("closing_source"))
                    except Exception as exc:
                        logger.warning("Failed to build closer PR record for %s#%s: %s", repo, issue_number, exc)

        # Source 2: canonical issue-side pull-request relations. This captures
        # linked fixes even when a repository does not repeat a close keyword
        # in the PR body and the PR was not the final ClosedEvent actor.
        try:
            closing_prs = client.get_issue_closing_prs_graphql(repo, issue_number)
        except Exception as exc:
            logger.warning(
                "GraphQL issue closing-PR discovery failed for %s#%s: %s",
                repo,
                issue_number,
                exc,
            )
            closing_prs = []
        for pr_preview in closing_prs:
            pr_number = v4.parse_issue_number_int(pr_preview.get("number"))
            if pr_number is None:
                continue
            try:
                pr = client.get_pr(repo, pr_number)
            except Exception as exc:
                logger.warning(
                    "Failed to fetch issue-linked PR for %s#%s via PR #%s: %s",
                    repo,
                    issue_number,
                    pr_number,
                    exc,
                )
                continue
            if not pr or not pr.get("merged"):
                continue
            try:
                record = self._build_pr_record(
                    repo=repo,
                    issue=issue,
                    pr=pr,
                    source="graphql_issue_closing_pull_request_relation",
                    client=client,
                    include_patch_text=include_patch_text,
                )
                self._write_cached(cache_path, profile, {
                    "status": "found",
                    "source": record.get("closing_source"),
                    "record": record,
                })
                return record, str(record.get("closing_source"))
            except Exception as exc:
                logger.warning(
                    "Failed to build issue-linked PR record for %s#%s via PR #%s: %s",
                    repo,
                    issue_number,
                    pr_number,
                    exc,
                )

        # Source 3: exhaustive closed-PR body index, matching 02_git_utils.
        # The list endpoint is scanned once per repository and cached server-side.
        pr_numbers: list[int] = []
        if allow_exhaustive_fallbacks:
            try:
                pr_numbers = self.pr_body_index.load_matches(
                    repo=repo,
                    client=client,
                    ttl_seconds=closed_pulls_ttl_seconds,
                    refresh=refresh_closed_pulls,
                ).get(issue_number, [])
            except Exception as exc:
                logger.warning(
                    "Exhaustive PR-body index unavailable for %s#%s: %s",
                    repo,
                    issue_number,
                    exc,
                )

        for pr_number in pr_numbers:
            pr = client.get_pr(repo, pr_number)
            if not pr or not pr.get("merged"):
                continue
            text = f"{pr.get('title') or ''}\n\n{pr.get('body') or ''}"
            if issue_number not in v4.extract_closing_issue_numbers(text, repo=repo):
                continue
            try:
                record = self._build_pr_record(
                    repo=repo,
                    issue=issue,
                    pr=pr,
                    source="pr_body_closing_keyword",
                    client=client,
                    include_patch_text=include_patch_text,
                )
                record["pr_body_discovery_mode"] = "exhaustive_closed_pr_index"
                self._write_cached(cache_path, profile, {
                    "status": "found",
                    "source": record.get("closing_source"),
                    "record": record,
                })
                return record, str(record.get("closing_source"))
            except Exception as exc:
                logger.warning(
                    "Failed to build exhaustive PR-body record for %s#%s via PR #%s: %s",
                    repo,
                    issue_number,
                    pr_number,
                    exc,
                )

        # Sources 3/4: repository commit-message index.
        if allow_exhaustive_fallbacks and enable_commit_message_fallback:
            try:
                matches = self._load_commit_matches(repo, refresh_repository=refresh_repository).get(issue_number, [])
                repo_checkout = self.repository_provider.repo_path(repo)
            except Exception as exc:
                logger.warning("Commit-message index unavailable for %s: %s", repo, exc)
                matches = []
                repo_checkout = None

            first_commit_only: Any | None = matches[0] if matches else None
            for match in matches:
                try:
                    associated_prs = client.get_commit_associated_prs(repo, match.sha)
                except Exception:
                    associated_prs = []
                for pr_preview in associated_prs:
                    pr_number = v4.parse_issue_number_int(pr_preview.get("number"))
                    if pr_number is None:
                        continue
                    pr = client.get_pr(repo, pr_number)
                    if not pr or not pr.get("merged"):
                        continue
                    try:
                        record = self._build_pr_record(
                            repo=repo,
                            issue=issue,
                            pr=pr,
                            source="commit_message_closing_keyword_mapped_to_pr",
                            client=client,
                            include_patch_text=include_patch_text,
                            repo_checkout=repo_checkout,
                        )
                        record["dynamic_commit_message_match_sha"] = match.sha
                        record["dynamic_commit_message_match_date"] = match.commit_date
                        self._write_cached(cache_path, profile, {
                            "status": "found",
                            "source": record.get("closing_source"),
                            "record": record,
                        })
                        return record, str(record.get("closing_source"))
                    except Exception as exc:
                        logger.warning("Failed to build commit-to-PR record for %s#%s: %s", repo, issue_number, exc)

            if first_commit_only is not None:
                try:
                    record = v4.build_commit_only_record(
                        repo=repo,
                        issue=issue,
                        candidate_source="commit_message_closing_keyword",
                        client=client,
                        repo_checkout=repo_checkout,
                        patch_dir=self._patch_dir(repo),
                        sha=first_commit_only.sha,
                        commit_date=first_commit_only.commit_date,
                        include_patch_text=include_patch_text,
                    )
                    self._write_cached(cache_path, profile, {
                        "status": "found",
                        "source": record.get("closing_source"),
                        "record": record,
                    })
                    return record, str(record.get("closing_source"))
                except Exception as exc:
                    logger.warning("Failed to build commit-only record for %s#%s: %s", repo, issue_number, exc)

        source = "no_canonical_fix_link"
        self._write_cached(cache_path, profile, {"status": "not_found", "source": source})
        return None, source

    def discover_pr(
        self,
        *,
        repo: str,
        pr_number: int,
        eligible_issues: dict[int, dict[str, Any]] | None,
        client: v4.GithubClient,
        include_patch_text: bool,
    ) -> tuple[list[dict[str, Any]], str]:
        profile = self._profile(enable_commit_message_fallback=False, include_patch_text=include_patch_text)
        cache_path = self._cache_path(repo, "pr", pr_number)
        cached = self._read_cached(cache_path, profile)
        if cached and cached.get("status") == "found" and isinstance(cached.get("records"), list):
            records = [record for record in cached["records"] if isinstance(record, dict)]
            return records, str(cached.get("source") or "pr_fix_cache")
        if cached and cached.get("status") == "not_found":
            return [], str(cached.get("source") or "pr_fix_cache_not_found")

        pr = client.get_pr(repo, pr_number)
        if not pr or not pr.get("merged"):
            source = "pr_not_found_or_unmerged"
            self._write_cached(cache_path, profile, {"status": "not_found", "source": source})
            return [], source

        issue_numbers: list[int] = []
        try:
            closing_issues = client.get_pr_closing_issues_graphql(repo, pr_number)
        except Exception as exc:
            logger.warning("PR closingIssuesReferences failed for %s#%s: %s", repo, pr_number, exc)
            closing_issues = []
        for issue in closing_issues:
            number = v4.parse_issue_number_int(issue.get("number"))
            if (
                number is not None
                and (eligible_issues is None or number in eligible_issues)
                and number not in issue_numbers
            ):
                issue_numbers.append(number)

        if not issue_numbers:
            references = v4.extract_closing_issue_numbers(
                f"{pr.get('title') or ''}\n\n{pr.get('body') or ''}",
                repo=repo,
            )
            issue_numbers = sorted(
                number
                for number in references
                if eligible_issues is None or number in eligible_issues
            )

        records: list[dict[str, Any]] = []
        source = "pr_no_closed_issue_relation"
        for issue_number in issue_numbers:
            issue = (
                eligible_issues.get(issue_number)
                if eligible_issues is not None
                else client.get_issue(repo, issue_number)
            )
            if not issue or str(issue.get("state") or "").lower() != "closed":
                continue
            try:
                record = self._build_pr_record(
                    repo=repo,
                    issue=issue,
                    pr=pr,
                    source="pr_closing_issue_relation",
                    client=client,
                    include_patch_text=include_patch_text,
                )
                records.append(record)
                source = str(record.get("closing_source") or "pr_closing_issue_relation")
            except Exception as exc:
                logger.warning("Failed to build reverse PR record for %s PR #%s issue #%s: %s", repo, pr_number, issue_number, exc)

        if records:
            self._write_cached(cache_path, profile, {
                "status": "found",
                "source": source,
                "records": records,
            })
            return records, source
        self._write_cached(cache_path, profile, {"status": "not_found", "source": source})
        return [], source
