from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from .generation_contracts import GenerationMode


@dataclass(frozen=True)
class CodifyEnsureOptions:
    """Server-owned settings used when ensure must fill cache misses."""

    knowledge_cache_dir: Path
    output_root: Path
    template_versions: Mapping[GenerationMode, str]
    generator_model: str
    allow_clone: bool = False
    allow_fetch: bool = False
    repository_root: Path | None = None
    historical_worktree_root: Path | None = None
    generation_runtime_options: Mapping[str, Any] = field(default_factory=dict)

    def template_version(self, mode: GenerationMode) -> str:
        value = str(self.template_versions.get(mode) or "").strip()
        if not value:
            raise ValueError(f"no template version configured for {mode}")
        return value


class ConfiguredCandidateSearch:
    """Bind server-owned retrieval paths outside the Activation interface."""

    def __init__(
        self,
        search_service: Any,
        preretrieved_dir: Path,
        *,
        allow_live_search: bool = True,
    ) -> None:
        self.search_service = search_service
        self.preretrieved_dir = preretrieved_dir
        self.allow_live_search = allow_live_search

    def run(
        self,
        instance: Mapping[str, Any],
        options: Any,
        gate_options: Any,
        *,
        refresh_instance_metadata: bool = False,
    ) -> Any:
        if not self.allow_live_search:
            from .search_retrieval.contracts import SWEbenchProInstance
            from .search_retrieval.preretrieved_store import PreretrievedStore

            normalized = SWEbenchProInstance.from_mapping(instance)
            rows, _rejected = PreretrievedStore(
                self.preretrieved_dir
            ).find(normalized)
            if not rows:
                raise PermissionError(
                    "live search is disabled and no pre-retrieved candidate "
                    "exists for this instance"
                )
        return self.search_service.run(
            instance,
            options,
            gate_options,
            preretrieved_dir=self.preretrieved_dir,
            write_artifacts=False,
            refresh_instance_metadata=refresh_instance_metadata,
            use_test_patch_for_metadata=False,
        )
