from __future__ import annotations

import dataclasses
import hashlib
import json
import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping, Protocol
from .. import github as v4

SHA40_RE = re.compile(r"\b[0-9a-fA-F]{40}\b")
SAFETY_RECHECK_VERSION = "post_retrieval_integrity_recheck_v1"


def _text(value: Any) -> str:
    return str(value or "").strip()


def _int(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _float(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def _parse_time(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            number = float(value)
            if number > 10_000_000_000:
                number /= 1000.0
            return datetime.fromtimestamp(number, tz=timezone.utc)
        except Exception:
            return None
    text = _text(value)
    if not text:
        return None
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        try:
            number = float(text)
            if number > 10_000_000_000:
                number /= 1000.0
            return datetime.fromtimestamp(number, tz=timezone.utc)
        except Exception:
            return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    for candidate in (text, text.replace(" ", "T")):
        try:
            parsed = datetime.fromisoformat(candidate)
        except ValueError:
            continue
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    return None


def _iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _metadata(row: Mapping[str, Any]) -> Mapping[str, Any]:
    value = row.get("retrieved_metadata")
    return value if isinstance(value, Mapping) else {}


def _candidate_patch(row: Mapping[str, Any]) -> str:
    return _text(
        row.get("retrieved_issue_ground_truth_patch")
        or row.get("retrieved_patch")
    )


def _target_commit(instance: Mapping[str, Any], row: Mapping[str, Any]) -> str:
    explicit = _text(row.get("target_commit") or instance.get("target_commit")).lower()
    if re.fullmatch(r"[0-9a-f]{40}", explicit):
        return explicit
    base_commit = _text(instance.get("base_commit")).lower()
    instance_id = _text(instance.get("instance_id"))
    shas = [match.group(0).lower() for match in SHA40_RE.finditer(instance_id)]
    for sha in shas:
        if sha != base_commit:
            return sha
    return shas[0] if shas else ""


def candidate_identity(row: Mapping[str, Any]) -> str:
    metadata = _metadata(row)
    payload = {
        "instance_id": _text(row.get("instance_id")),
        "retrieved_doc_id": _text(row.get("retrieved_doc_id")),
        "repo": _text(
            row.get("retrieved_repo")
            or metadata.get("repo")
            or row.get("instance_repo")
        ),
        "issue_number": _int(
            row.get("retrieved_issue_number")
            or metadata.get("issue_number")
        ),
        "pr_number": _int(row.get("retrieved_pr_number") or metadata.get("pr_number")),
        "commit_id": _text(
            row.get("retrieved_commit_id") or metadata.get("retrieved_commit_id")
        ),
        "patch_sha256": hashlib.sha256(
            _candidate_patch(row).encode("utf-8", errors="replace")
        ).hexdigest(),
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
    ).hexdigest()[:24]


@dataclass
class PostRetrievalSafetyDecision:
    instance_id: str
    candidate_key: str
    candidate_position: int | None
    passed: bool
    reasons: list[str] = field(default_factory=list)
    boundary_iso: str | None = None
    issue_created_at: str | None = None
    max_fix_created_at: str | None = None
    target_commit: str | None = None
    evidence_scope: str = "post_retrieval_integrity_recheck"
    safety_version: str = SAFETY_RECHECK_VERSION

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


class LeakageDetector(Protocol):
    """Replaceable detector used after historical candidate retrieval."""

    def evaluate(
        self,
        *,
        row: Mapping[str, Any],
        source_instance: Mapping[str, Any],
        source_boundary: Mapping[str, Any],
        target_leakage_check: bool = True,
    ) -> PostRetrievalSafetyDecision: ...


class PostRetrievalSafetyGate:
    """Fail-closed integrity recheck over Stage-1 safety provenance.

    This does not repeat GitHub fix discovery. It verifies that the retrieval
    handoff still contains the safe decision and enough immutable
    evidence to prevent corrupted or mismatched rows from entering the LLM gate.
    """
    def evaluate(
        self,
        *,
        row: Mapping[str, Any],
        source_instance: Mapping[str, Any],
        source_boundary: Mapping[str, Any],
        target_leakage_check: bool = True,
    ) -> PostRetrievalSafetyDecision:
        reasons: list[str] = []
        instance_id = _text(source_instance.get("instance_id"))
        row_instance_id = _text(row.get("instance_id"))
        candidate_key = candidate_identity(row)
        candidate_position_raw = (
            row.get("candidate_position")
            if row.get("candidate_position") not in (None, "")
            else row.get("reranked_position")
        )
        try:
            candidate_position = int(candidate_position_raw)
        except (TypeError, ValueError):
            candidate_position = None
            reasons.append("missing_or_invalid_candidate_position")

        if not instance_id:
            reasons.append("source_instance_id_missing")
        elif row_instance_id != instance_id:
            reasons.append("instance_id_mismatch")

        source_repo = _text(source_instance.get("repo"))
        row_repo = _text(row.get("instance_repo") or row.get("repo"))
        metadata = _metadata(row)
        historical_repo = _text(
            row.get("retrieved_repo") or metadata.get("repo") or row_repo
        )
        if not source_repo:
            reasons.append("source_repo_missing")
        if not v4.same_repository(row_repo, source_repo):
            reasons.append("instance_repo_mismatch")
        if not v4.same_repository(historical_repo, source_repo):
            reasons.append("historical_repo_mismatch")

        if row.get("leakage_rejection_passed") is not True:
            reasons.append("stage1_leakage_rejection_passed_not_true")
        if _text(row.get("leakage_decision")).lower() != "safe":
            reasons.append("stage1_leakage_decision_not_safe")

        boundary = None
        if target_leakage_check:
            source_boundary_time = _parse_time(
                source_boundary.get("iso") or source_boundary.get("timestamp")
            )
            row_boundary_time = _parse_time(
                row.get("leakage_boundary_iso") or row.get("leakage_boundary_ts")
            )
            if source_boundary_time is None:
                reasons.append("source_boundary_missing")
            if row_boundary_time is None:
                reasons.append("row_boundary_missing")
            if (
                source_boundary_time is not None
                and row_boundary_time is not None
                and source_boundary_time != row_boundary_time
            ):
                reasons.append("boundary_mismatch")
            boundary = source_boundary_time or row_boundary_time

        issue_time = _parse_time(
            row.get("retrieved_issue_created_at")
            or metadata.get("issue_created_at")
            or metadata.get("issue_created_at_ts")
        )
        if target_leakage_check:
            if issue_time is None:
                reasons.append("historical_issue_time_missing")
            elif boundary is not None and issue_time >= boundary:
                reasons.append("historical_issue_not_before_boundary")

        fix_time = _parse_time(
            metadata.get("retrieved_max_commit_created_at")
            or metadata.get("retrieved_max_commit_created_at_ts")
            or row.get("retrieved_max_commit_created_at")
            or row.get("retrieved_max_commit_created_at_ts")
        )
        if target_leakage_check:
            if fix_time is None:
                reasons.append("historical_fix_time_missing")
            elif boundary is not None and fix_time >= boundary:
                reasons.append("historical_fix_not_before_boundary")

        target_issue_number = _int(source_instance.get("instance_issue_number"))
        historical_issue_number = _int(
            row.get("retrieved_issue_number") or metadata.get("issue_number")
        )
        if (
            target_leakage_check
            and target_issue_number is not None
            and historical_issue_number is not None
            and target_issue_number == historical_issue_number
        ):
            reasons.append("historical_issue_is_current_issue")

        patch = _candidate_patch(row)
        if not patch:
            reasons.append("historical_patch_missing")

        current_target_commit = (
            _target_commit(source_instance, row)
            if target_leakage_check
            else ""
        )
        retrieved_commit = _text(
            row.get("retrieved_commit_id") or metadata.get("retrieved_commit_id")
        ).lower()
        retrieved_commits = row.get("retrieved_commit_ids")
        serialized_commits = json.dumps(
            retrieved_commits, ensure_ascii=False, sort_keys=True
        ).lower()
        if current_target_commit:
            if retrieved_commit == current_target_commit:
                reasons.append("candidate_uses_current_target_commit")
            if current_target_commit in serialized_commits:
                reasons.append("candidate_commit_list_uses_current_target_commit")
            # Search only the historical evidence, never the current-instance fields.
            historical_serialized = json.dumps(
                {
                    "retrieved_issue_desc": row.get("retrieved_issue_desc"),
                    "retrieved_issue_title": row.get("retrieved_issue_title"),
                    "retrieved_issue_body": row.get("retrieved_issue_body"),
                    "retrieved_patch": row.get("retrieved_patch"),
                    "retrieved_issue_ground_truth_patch": row.get(
                        "retrieved_issue_ground_truth_patch"
                    ),
                    "retrieved_metadata": metadata,
                },
                ensure_ascii=False,
                sort_keys=True,
            ).lower()
            if current_target_commit in historical_serialized:
                reasons.append("historical_evidence_mentions_current_target_commit")

        return PostRetrievalSafetyDecision(
            instance_id=instance_id or row_instance_id,
            candidate_key=candidate_key,
            candidate_position=candidate_position,
            passed=not reasons,
            reasons=reasons,
            boundary_iso=_iso(boundary),
            issue_created_at=_iso(issue_time),
            max_fix_created_at=_iso(fix_time),
            target_commit=current_target_commit or None,
        )
