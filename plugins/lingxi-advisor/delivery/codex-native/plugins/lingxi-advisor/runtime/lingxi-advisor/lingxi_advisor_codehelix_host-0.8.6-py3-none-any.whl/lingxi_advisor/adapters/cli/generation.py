from __future__ import annotations

import argparse
import dataclasses
import json
import logging
from pathlib import Path

from ...config import DEFAULT_PROJECT_ROOT, ServerSettings
from ...internal.generation_contracts import (
    GenerationRequest,
    validate_generation_mode,
)
from ...internal.generation_service import KnowledgeGenerationService
from ...internal.grounded_analysis.contracts import GroundedAnalysisConfig
from ...internal.knowledge_template import template_version_for_mode
from ...internal.light_generation.contracts import LightGeneratorConfig

logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate historical XML knowledge from retrieval's "
            "selected_historical_issues.jsonl. The user selects one global "
            "generation mode; the knowledge cache is checked before routing."
        )
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--input-jsonl", type=Path)
    source.add_argument(
        "--candidate-run-dir",
        type=Path,
        help=(
            "Search & Retrieval run directory containing "
            "selected_historical_issues.jsonl"
        ),
    )
    parser.add_argument(
        "--generation-mode",
        required=True,
        choices=["light", "grounded_analysis"],
    )
    parser.add_argument("--project-root", type=Path, default=DEFAULT_PROJECT_ROOT)
    parser.add_argument("--env-file", type=Path, default=None)
    parser.add_argument("--knowledge-cache-dir", type=Path, default=None)
    parser.add_argument("--output-root", type=Path, default=None)
    parser.add_argument(
        "--repository-root",
        type=Path,
        default=None,
        help=(
            "Shared Git repository cache used by grounded analysis. "
            "Defaults to <project-root>/cache/repositories."
        ),
    )
    parser.add_argument(
        "--historical-worktree-root",
        type=Path,
        default=None,
        help=(
            "Persistent detached worktree cache. Defaults to "
            "<project-root>/cache/historical_worktrees."
        ),
    )
    parser.add_argument(
        "--allow-clone",
        action="store_true",
        help="Allow grounded analysis to create a missing repository cache.",
    )
    parser.add_argument(
        "--allow-fetch",
        action="store_true",
        help="Allow grounded analysis to fetch a missing historical commit.",
    )
    parser.add_argument("--template-version", type=str, default=None)
    parser.add_argument("--generator-model", type=str, default=None)
    parser.add_argument("--generator-base-url", type=str, default=None)
    parser.add_argument("--generator-api-key", type=str, default=None)
    parser.add_argument("--generator-timeout-seconds", type=float, default=300.0)
    parser.add_argument("--generator-max-attempts", type=int, default=5)
    parser.add_argument(
        "--generator-retry-base-sleep-seconds", type=float, default=2.0
    )
    parser.add_argument(
        "--generator-retry-max-sleep-seconds", type=float, default=30.0
    )
    parser.add_argument(
        "--generator-max-output-tokens", type=int, default=26_000
    )
    parser.add_argument("--generator-temperature", type=float, default=1.0)
    parser.add_argument(
        "--aspect-mode",
        choices=["base_split", "g_from_issue_plus_fg_calltrace"],
        default="g_from_issue_plus_fg_calltrace",
    )
    parser.add_argument(
        "--grounded-max-agent-turns",
        type=int,
        default=24,
    )
    parser.add_argument(
        "--grounded-max-tool-calls",
        type=int,
        default=20,
    )
    parser.add_argument(
        "--grounded-max-tool-output-chars",
        type=int,
        default=16_000,
    )
    parser.add_argument(
        "--grounded-max-context-chars",
        type=int,
        default=480_000,
        help=(
            "Approximate total model context capacity in characters. "
            "Requests reserve output capacity and the profile's 15%% margin."
        ),
    )
    parser.add_argument(
        "--grounded-reserved-context-fraction",
        type=float,
        default=0.15,
    )
    parser.add_argument(
        "--grounded-context-chars-per-token",
        type=int,
        default=4,
    )
    parser.add_argument(
        "--grounded-max-compacted-tool-output-chars",
        type=int,
        default=2_000,
    )
    parser.add_argument(
        "--grounded-max-file-bytes",
        type=int,
        default=2_000_000,
    )
    parser.add_argument(
        "--grounded-max-search-results",
        type=int,
        default=200,
    )
    parser.add_argument(
        "--grounded-max-glob-results",
        type=int,
        default=500,
    )
    parser.add_argument(
        "--grounded-repository-host",
        type=str,
        default="github.com",
    )
    parser.add_argument(
        "--grounded-verify-repository-identity",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Require the repository cache origin to match "
            "<repository-host>/<owner>/<repo>."
        ),
    )
    parser.add_argument(
        "--grounded-consistency-policy",
        choices=["strict", "warn"],
        default="strict",
        help=(
            "How patch/commit/changed-files/preflight mismatches are handled."
        ),
    )
    parser.add_argument(
        "--grounded-worktree-gc-max-count-per-repo",
        type=int,
        default=0,
        help="Opt-in per-repository worktree count quota; 0 disables it.",
    )
    parser.add_argument(
        "--grounded-worktree-gc-max-age-days",
        type=float,
        default=0.0,
        help="Opt-in age-based worktree GC; 0 disables it.",
    )
    parser.add_argument(
        "--grounded-worktree-gc-max-bytes-per-repo",
        type=int,
        default=0,
        help="Opt-in per-repository worktree byte quota; 0 disables it.",
    )
    parser.add_argument(
        "--resume",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Reuse completed cache/checkpoint artifacts. Knowledge cache "
            "lookup remains mandatory in either setting."
        ),
    )
    parser.add_argument("--disable-generator-ssl-verify", action="store_true")
    parser.add_argument("--no-generator-trust-env", action="store_true")
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Shortcut for --log-level DEBUG.",
    )
    return parser.parse_args()


def _load_dotenv(path: Path) -> bool:
    if not path.exists():
        logger.info(
            "Environment file not found; using process environment only: %s",
            path,
        )
        return False
    try:
        from dotenv import load_dotenv
    except ImportError:
        logger.warning(
            "Environment file exists but python-dotenv is unavailable: %s",
            path,
        )
        return False
    loaded = bool(load_dotenv(path, override=False))
    logger.info(
        "Environment file loaded: path=%s variables_found=%s",
        path,
        "yes" if loaded else "no",
    )
    return loaded


def _selected_jsonl(args: argparse.Namespace) -> Path:
    if args.input_jsonl is not None:
        return args.input_jsonl.expanduser().resolve()
    assert args.candidate_run_dir is not None
    return (
        args.candidate_run_dir.expanduser().resolve()
        / "selected_historical_issues.jsonl"
    )


def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    project_root = args.project_root.expanduser().resolve()
    env_file = (args.env_file or project_root / ".env").expanduser().resolve()
    _load_dotenv(env_file)
    settings = ServerSettings(
        project_root=project_root,
        output_root=args.output_root,
        repository_root=args.repository_root,
        historical_worktree_root=args.historical_worktree_root,
        generator_base_url=args.generator_base_url,
        generator_api_key=args.generator_api_key,
        generator_model=args.generator_model,
        generator_timeout_seconds=args.generator_timeout_seconds,
        generator_max_attempts=args.generator_max_attempts,
        generator_retry_base_sleep_seconds=(
            args.generator_retry_base_sleep_seconds
        ),
        generator_retry_max_sleep_seconds=(
            args.generator_retry_max_sleep_seconds
        ),
        generator_max_output_tokens=args.generator_max_output_tokens,
        generator_temperature=args.generator_temperature,
        generator_verify_ssl=not args.disable_generator_ssl_verify,
        generator_trust_env=not args.no_generator_trust_env,
    ).resolved()
    mode = validate_generation_mode(args.generation_mode)
    model = settings.generator_model or "gpt-4.1-mini"
    template_version = args.template_version or template_version_for_mode(mode)
    output_root = (
        args.output_root.expanduser().resolve()
        if args.output_root is not None
        else settings.output_root or project_root / "outputs"
    )
    cache_root = (
        args.knowledge_cache_dir.expanduser().resolve()
        if args.knowledge_cache_dir is not None
        else project_root / "knowl_cache"
    )
    selected_jsonl = _selected_jsonl(args)
    logger.info(
        "Generation CLI: mode=%s input=%s cache=%s output_root=%s",
        mode,
        selected_jsonl,
        cache_root,
        output_root,
    )
    logger.info(
        "Generator connection: model=%s base_url=%s api_key_configured=%s "
        "timeout=%.1fs max_attempts=%d",
        model,
        settings.generator_base_url,
        "yes" if settings.generator_api_key else "no",
        settings.generator_timeout_seconds,
        settings.generator_max_attempts,
    )
    if mode == "grounded_analysis":
        logger.info(
            "Grounded paths and permissions: repositories=%s worktrees=%s "
            "allow_clone=%s allow_fetch=%s max_agent_turns=%d "
            "max_tool_calls=%d",
            settings.repository_root,
            settings.historical_worktree_root,
            args.allow_clone,
            args.allow_fetch,
            args.grounded_max_agent_turns,
            args.grounded_max_tool_calls,
        )
        logger.info(
            "Grounded validation and limits: repository_host=%s "
            "verify_repository_identity=%s consistency_policy=%s "
            "max_context_chars=%d reserved_context_fraction=%.2f "
            "max_file_bytes=%d search_results=%d glob_results=%d "
            "gc_count=%d gc_age_days=%.2f gc_bytes=%d",
            args.grounded_repository_host,
            args.grounded_verify_repository_identity,
            args.grounded_consistency_policy,
            args.grounded_max_context_chars,
            args.grounded_reserved_context_fraction,
            args.grounded_max_file_bytes,
            args.grounded_max_search_results,
            args.grounded_max_glob_results,
            args.grounded_worktree_gc_max_count_per_repo,
            args.grounded_worktree_gc_max_age_days,
            args.grounded_worktree_gc_max_bytes_per_repo,
        )
    if not settings.generator_api_key:
        logger.warning(
            "No generator API key was resolved. Set "
            "LINGXI_ADVISOR_GENERATOR_API_KEY or pass "
            "--generator-api-key. A cache hit can still complete without a "
            "model call."
        )
    request = GenerationRequest(
        input_jsonl=selected_jsonl,
        knowledge_cache_dir=cache_root,
        output_root=output_root,
        generation_mode=mode,
        template_version=template_version,
        generator_model=model,
        target_conditioned=False,
        resume=args.resume,
        allow_clone=args.allow_clone,
        allow_fetch=args.allow_fetch,
        repository_root=(
            settings.repository_root
            if mode == "grounded_analysis"
            else None
        ),
        historical_worktree_root=(
            settings.historical_worktree_root
            if mode == "grounded_analysis"
            else None
        ),
    )
    light_config = (
        LightGeneratorConfig(
            model=model,
            base_url=(
                settings.generator_base_url
                or "https://api.openai.com/v1"
            ),
            api_key=settings.generator_api_key,
            timeout_seconds=settings.generator_timeout_seconds,
            max_attempts=settings.generator_max_attempts,
            retry_base_sleep_seconds=(
                settings.generator_retry_base_sleep_seconds
            ),
            retry_max_sleep_seconds=(
                settings.generator_retry_max_sleep_seconds
            ),
            max_output_tokens=settings.generator_max_output_tokens,
            temperature=settings.generator_temperature,
            verify_ssl=settings.generator_verify_ssl,
            trust_env=settings.generator_trust_env,
            aspect_mode=args.aspect_mode,
        )
        if mode == "light"
        else None
    )
    grounded_config = (
        GroundedAnalysisConfig(
            repository_root=(
                settings.repository_root
                or project_root / "cache" / "repositories"
            ),
            worktree_root=(
                settings.historical_worktree_root
                or project_root / "cache" / "historical_worktrees"
            ),
            model=model,
            base_url=(
                settings.generator_base_url
                or "https://api.openai.com/v1"
            ),
            api_key=settings.generator_api_key,
            timeout_seconds=settings.generator_timeout_seconds,
            max_attempts=settings.generator_max_attempts,
            retry_base_sleep_seconds=(
                settings.generator_retry_base_sleep_seconds
            ),
            retry_max_sleep_seconds=(
                settings.generator_retry_max_sleep_seconds
            ),
            max_output_tokens=settings.generator_max_output_tokens,
            temperature=settings.generator_temperature,
            verify_ssl=settings.generator_verify_ssl,
            trust_env=settings.generator_trust_env,
            allow_clone=args.allow_clone,
            allow_fetch=args.allow_fetch,
            max_agent_turns=args.grounded_max_agent_turns,
            max_tool_calls=args.grounded_max_tool_calls,
            max_tool_output_chars=(
                args.grounded_max_tool_output_chars
            ),
            max_context_chars=args.grounded_max_context_chars,
            reserved_context_fraction=(
                args.grounded_reserved_context_fraction
            ),
            context_chars_per_token=(
                args.grounded_context_chars_per_token
            ),
            max_compacted_tool_output_chars=(
                args.grounded_max_compacted_tool_output_chars
            ),
            max_file_bytes=args.grounded_max_file_bytes,
            max_search_results=args.grounded_max_search_results,
            max_glob_results=args.grounded_max_glob_results,
            repository_host=args.grounded_repository_host,
            verify_repository_identity=(
                args.grounded_verify_repository_identity
            ),
            grounding_consistency_policy=(
                args.grounded_consistency_policy
            ),
            worktree_gc_max_count_per_repo=(
                args.grounded_worktree_gc_max_count_per_repo
            ),
            worktree_gc_max_age_days=(
                args.grounded_worktree_gc_max_age_days
            ),
            worktree_gc_max_bytes_per_repo=(
                args.grounded_worktree_gc_max_bytes_per_repo
            ),
        )
        if mode == "grounded_analysis"
        else None
    )
    if grounded_config is not None:
        request = dataclasses.replace(
            request,
            runtime_options=grounded_config.public_dict(),
        )
    result = KnowledgeGenerationService(
        light_config=light_config,
        grounded_config=grounded_config,
    ).run(request)
    print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    if result.status == "failed":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
