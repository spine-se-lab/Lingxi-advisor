"""Canonical LingxiAdvisor knowledge-template structure and versions."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from types import MappingProxyType
from typing import Iterable, Mapping


KNOWLEDGE_ROOT_TAG = "historical_knowledge"
FINE_GRAINED_SECTION_TAG = "fine_grained_analysis"
GENERAL_SUMMARY_SECTION_TAG = "general_summary"
KNOWLEDGE_SECTION_TAGS = (
    FINE_GRAINED_SECTION_TAG,
    GENERAL_SUMMARY_SECTION_TAG,
)

FINE_GRAINED_TAGS = (
    "repository_hierarchy",
    "dependency_analysis",
    "call_trace",
    "bug_category",
    "usage_context",
    "root_cause",
    "behavior_comparison",
    "fix_logic",
    "fix_steps",
    "fix_checklist",
    "test_case",
    "conclusion",
)
LIGHT_FINE_GRAINED_1_TAGS = FINE_GRAINED_TAGS[:3]
LIGHT_FINE_GRAINED_2_TAGS = FINE_GRAINED_TAGS[3:]
GENERAL_SUMMARY_TAGS = (
    "general_root_cause_analysis_steps",
    "bug_categorization",
    "relevant_architecture",
    "involved_components",
    "specific_involved_classes_functions_methods",
    "feature_or_functionality_of_issue",
    "general_fix_pattern",
    "summary_of_fix_checklist",
    "design_patterns_and_coding_practices",
    "additional_concepts",
)

# These values remain part of Artifact/cache identity. Change one only when
# the corresponding generation instructions or knowledge semantics change.
LIGHT_TEMPLATE_VERSION = "light_fg_split_v1"
GROUNDED_TEMPLATE_VERSION = (
    "lingxi_grounded_analyst_b011c0de0021_"
    "summarizer_b011c0de0022_v2_hardened"
)
DEFAULT_TEMPLATE_VERSIONS: Mapping[str, str] = MappingProxyType(
    {
        "light": LIGHT_TEMPLATE_VERSION,
        "grounded_analysis": GROUNDED_TEMPLATE_VERSION,
    }
)

_DECLARED_TAG_RE = re.compile(r"^\s*<([a-z][a-z0-9_]*)>\s*$", re.MULTILINE)


def template_version_for_mode(generation_mode: str) -> str:
    try:
        return DEFAULT_TEMPLATE_VERSIONS[generation_mode]
    except KeyError as exc:
        raise ValueError(
            f"unsupported generation mode: {generation_mode}"
        ) from exc


def declared_xml_tags(instructions: str) -> tuple[str, ...]:
    """Return standalone opening tags declared by one prompt/profile."""

    return tuple(_DECLARED_TAG_RE.findall(str(instructions or "")))


def validate_template_instructions(
    name: str,
    instructions: str,
    expected_tags: tuple[str, ...],
) -> None:
    actual = declared_xml_tags(instructions)
    if actual != expected_tags:
        raise RuntimeError(
            f"{name} XML sections must be {expected_tags}, got {actual}"
        )


def assemble_knowledge_xml(
    *,
    fine_grained_children: Iterable[ET.Element],
    general_summary_children: Iterable[ET.Element],
) -> str:
    """Assemble the stable outer XML document used by every generator."""

    root = ET.Element(KNOWLEDGE_ROOT_TAG)
    fine_grained = ET.SubElement(root, FINE_GRAINED_SECTION_TAG)
    fine_grained.extend(fine_grained_children)
    general_summary = ET.SubElement(root, GENERAL_SUMMARY_SECTION_TAG)
    general_summary.extend(general_summary_children)
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="unicode")

