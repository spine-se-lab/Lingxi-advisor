from __future__ import annotations

from .internal.execution import run_blocking

import dataclasses
from pathlib import Path
from typing import Any, Mapping

from .artifacts import FilesystemKnowledgeArtifactStore
from .capabilities.activate.lingxi_advisor_apply import (
    LingxiAdvisorActivationApply,
    LingxiAdvisorApplyRequest,
)
from .capabilities.activate.lingxi_advisor_search import (
    TargetIssue,
    LingxiAdvisorSearchRequest,
)
from .config import ServerSettings
from .internal.generation_contracts import (
    GenerationRequest,
    validate_generation_mode,
)
from .internal.generation_service import KnowledgeGenerationService
from .internal.knowledge_template import template_version_for_mode
from .internal.preparation_contracts import PreparationRequest
from .internal.search_retrieval.contracts import (
    SWEbenchProInstance,
    SearchRetrievalOptions,
    SimilarityGateOptions,
)
from .internal.search_retrieval.service import SearchRetrievalService


from .composition import (
    LingxiAdvisorCapabilities,  # noqa: F401 - compatibility import
    build_lingxi_advisor_capabilities,
    _compose_capabilities,
    _configured_generator_model,
    _grounded_config,
    _light_config,
)


def search_historical_issues(
    instance: Mapping[str, Any],
    options: Mapping[str, Any] | SearchRetrievalOptions | None = None,
    gate_options: Mapping[str, Any] | SimilarityGateOptions | None = None,
    *,
    settings: ServerSettings | None = None,
    preretrieved_dir: str | None = None,
    write_artifacts: bool = True,
    refresh_instance_metadata: bool = False,
    use_test_patch_for_metadata: bool = False,
) -> dict[str, Any]:
    """Run the current Search & Retrieval stage and return a serializable result."""

    result = SearchRetrievalService(settings=settings).run(
        instance,
        options,
        gate_options,
        preretrieved_dir=preretrieved_dir,
        write_artifacts=write_artifacts,
        refresh_instance_metadata=refresh_instance_metadata,
        use_test_patch_for_metadata=use_test_patch_for_metadata,
    )
    return result.to_dict()


async def search_historical_issues_async(
    instance: Mapping[str, Any],
    options: Mapping[str, Any] | SearchRetrievalOptions | None = None,
    gate_options: Mapping[str, Any] | SimilarityGateOptions | None = None,
    *,
    settings: ServerSettings | None = None,
    preretrieved_dir: str | None = None,
    write_artifacts: bool = True,
    refresh_instance_metadata: bool = False,
    use_test_patch_for_metadata: bool = False,
) -> dict[str, Any]:
    return await run_blocking(
        search_historical_issues,
        instance,
        options,
        gate_options,
        settings=settings,
        preretrieved_dir=preretrieved_dir,
        write_artifacts=write_artifacts,
        refresh_instance_metadata=refresh_instance_metadata,
        use_test_patch_for_metadata=use_test_patch_for_metadata,
    )


def apply_lingxi_advisors(
    issue_description: str,
    knowledge_matches: list[Mapping[str, Any]],
    *,
    context: Mapping[str, Any] | None = None,
    artifact_refs: list[Mapping[str, Any]] | None = None,
    sections: list[str] | None = None,
    max_content_chars: int = 160_000,
    settings: ServerSettings | None = None,
    knowledge_cache_dir: str | Path | None = None,
    assembly_root: str | Path | None = None,
) -> dict[str, Any]:
    """Run Apply Assembly and scoped Consumption without model calls."""

    paths = settings or ServerSettings()
    root = paths.project_root.expanduser().resolve()
    apply_capability = LingxiAdvisorActivationApply(
        artifact_store=FilesystemKnowledgeArtifactStore(
            Path(knowledge_cache_dir).expanduser().resolve()
            if knowledge_cache_dir is not None else root / "knowl_cache"
        ),
        assembly_root=(Path(assembly_root).expanduser().resolve()
                       if assembly_root is not None else root / "lingxi_advisor_store"),
    )
    request = LingxiAdvisorApplyRequest.from_mapping(
        {
            "issue_description": issue_description,
            "knowledge_matches": knowledge_matches,
            "context": context or {},
            "artifact_refs": artifact_refs or [],
            "sections": sections or [],
            "max_content_chars": max_content_chars,
        }
    )
    return apply_capability.apply(request).to_dict()


async def apply_lingxi_advisors_async(
    issue_description: str,
    knowledge_matches: list[Mapping[str, Any]],
    **kwargs: Any,
) -> dict[str, Any]:
    return await run_blocking(
        apply_lingxi_advisors,
        issue_description,
        knowledge_matches,
        **kwargs,
    )


def search_lingxi_advisors(
    issue_description: str,
    *,
    context: Mapping[str, Any] | None = None,
    target_issue: Mapping[str, Any] | TargetIssue | None = None,
    generation_mode: str = "light",
    search_options: Mapping[str, Any] | SearchRetrievalOptions | None = None,
    gate_options: Mapping[str, Any] | SimilarityGateOptions | None = None,
    resume: bool = True,
    refresh_instance_metadata: bool = False,
    settings: ServerSettings | None = None,
    preretrieved_dir: str | Path | None = None,
    knowledge_cache_dir: str | Path | None = None,
    output_root: str | Path | None = None,
    repository_root: str | Path | None = None,
    historical_worktree_root: str | Path | None = None,
    allow_clone: bool = False,
    allow_fetch: bool = False,
    light_aspect_mode: str = "g_from_issue_plus_fg_calltrace",
) -> dict[str, Any]:
    """Run Activation search and return knowledge content in one call."""

    normalized_search_options = (
        search_options
        if isinstance(search_options, SearchRetrievalOptions)
        else SearchRetrievalOptions.from_mapping(search_options)
    )
    normalized_gate_options = (
        gate_options
        if isinstance(gate_options, SimilarityGateOptions)
        else SimilarityGateOptions.from_mapping(gate_options)
    )
    request = LingxiAdvisorSearchRequest(
        issue_description=issue_description,
        context=dict(context or {}),
        target_issue=(
            target_issue
            if isinstance(target_issue, TargetIssue)
            else TargetIssue.from_mapping(target_issue)
            if target_issue is not None
            else None
        ),
        generation_mode=validate_generation_mode(generation_mode),
        search_options=normalized_search_options,
        gate_options=normalized_gate_options,
        resume=resume,
        refresh_instance_metadata=refresh_instance_metadata,
    )
    capabilities = build_lingxi_advisor_capabilities(
        settings=settings,
        preretrieved_dir=preretrieved_dir,
        knowledge_cache_dir=knowledge_cache_dir,
        output_root=output_root,
        repository_root=repository_root,
        historical_worktree_root=historical_worktree_root,
        allow_clone=allow_clone,
        allow_fetch=allow_fetch,
        light_aspect_mode=light_aspect_mode,
    )
    return capabilities.activation.search(request).to_dict()


async def search_lingxi_advisors_async(
    issue_description: str,
    **kwargs: Any,
) -> dict[str, Any]:
    return await run_blocking(
        search_lingxi_advisors,
        issue_description,
        **kwargs,
    )


def generate_historical_knowledge(
    selected_candidates_jsonl: str | Path,
    *,
    generation_mode: str,
    knowledge_cache_dir: str | Path | None = None,
    output_root: str | Path | None = None,
    settings: ServerSettings | None = None,
    template_version: str | None = None,
    target_conditioned: bool = False,
    resume: bool = True,
    repository_root: str | Path | None = None,
    historical_worktree_root: str | Path | None = None,
    allow_clone: bool = False,
    allow_fetch: bool = False,
    grounded_max_agent_turns: int = 24,
    grounded_max_tool_calls: int = 20,
    grounded_max_tool_output_chars: int = 16_000,
    grounded_max_context_chars: int = 480_000,
    grounded_reserved_context_fraction: float = 0.15,
    grounded_context_chars_per_token: int = 4,
    grounded_max_compacted_tool_output_chars: int = 2_000,
    grounded_max_file_bytes: int = 2_000_000,
    grounded_max_search_results: int = 200,
    grounded_max_glob_results: int = 500,
    grounded_repository_host: str = "github.com",
    grounded_verify_repository_identity: bool = True,
    grounded_consistency_policy: str = "strict",
    grounded_worktree_gc_max_count_per_repo: int = 0,
    grounded_worktree_gc_max_age_days: float = 0.0,
    grounded_worktree_gc_max_bytes_per_repo: int = 0,
) -> dict[str, Any]:
    """Generate XML from the standard Search & Retrieval selected JSONL."""

    resolved = (settings or ServerSettings()).resolved()
    mode = validate_generation_mode(generation_mode)
    model = _configured_generator_model(resolved)
    version = template_version or template_version_for_mode(mode)
    grounded_configuration = (
        _grounded_config(
            resolved,
            allow_clone=allow_clone,
            allow_fetch=allow_fetch,
            repository_root=repository_root,
            historical_worktree_root=historical_worktree_root,
            max_agent_turns=grounded_max_agent_turns,
            max_tool_calls=grounded_max_tool_calls,
            max_tool_output_chars=grounded_max_tool_output_chars,
            max_context_chars=grounded_max_context_chars,
            reserved_context_fraction=(
                grounded_reserved_context_fraction
            ),
            context_chars_per_token=(
                grounded_context_chars_per_token
            ),
            max_compacted_tool_output_chars=(
                grounded_max_compacted_tool_output_chars
            ),
            max_file_bytes=grounded_max_file_bytes,
            max_search_results=grounded_max_search_results,
            max_glob_results=grounded_max_glob_results,
            repository_host=grounded_repository_host,
            verify_repository_identity=(
                grounded_verify_repository_identity
            ),
            grounding_consistency_policy=(
                grounded_consistency_policy
            ),
            worktree_gc_max_count_per_repo=(
                grounded_worktree_gc_max_count_per_repo
            ),
            worktree_gc_max_age_days=(
                grounded_worktree_gc_max_age_days
            ),
            worktree_gc_max_bytes_per_repo=(
                grounded_worktree_gc_max_bytes_per_repo
            ),
        )
        if mode == "grounded_analysis"
        else None
    )
    request = GenerationRequest(
        input_jsonl=Path(selected_candidates_jsonl).expanduser().resolve(),
        knowledge_cache_dir=(
            Path(knowledge_cache_dir).expanduser().resolve()
            if knowledge_cache_dir is not None
            else resolved.project_root / "knowl_cache"
        ),
        output_root=(
            Path(output_root).expanduser().resolve()
            if output_root is not None
            else resolved.output_root or resolved.project_root / "outputs"
        ),
        generation_mode=mode,
        template_version=version,
        generator_model=model,
        target_conditioned=target_conditioned,
        resume=resume,
        allow_clone=allow_clone,
        allow_fetch=allow_fetch,
        repository_root=(
            Path(repository_root).expanduser().resolve()
            if repository_root is not None
            else (
                resolved.repository_root
                if mode == "grounded_analysis"
                else None
            )
        ),
        historical_worktree_root=(
            Path(historical_worktree_root).expanduser().resolve()
            if historical_worktree_root is not None
            else (
                resolved.historical_worktree_root
                if mode == "grounded_analysis"
                else None
            )
        ),
        runtime_options=(
            grounded_configuration.public_dict()
            if grounded_configuration is not None
            else {}
        ),
    )
    result = KnowledgeGenerationService(
        light_config=_light_config(resolved) if mode == "light" else None,
        grounded_config=grounded_configuration,
    ).run(request)
    return result.to_dict()


async def generate_historical_knowledge_async(
    selected_candidates_jsonl: str | Path,
    *,
    generation_mode: str,
    knowledge_cache_dir: str | Path | None = None,
    output_root: str | Path | None = None,
    settings: ServerSettings | None = None,
    template_version: str | None = None,
    target_conditioned: bool = False,
    resume: bool = True,
    repository_root: str | Path | None = None,
    historical_worktree_root: str | Path | None = None,
    allow_clone: bool = False,
    allow_fetch: bool = False,
    grounded_max_agent_turns: int = 24,
    grounded_max_tool_calls: int = 20,
    grounded_max_tool_output_chars: int = 16_000,
    grounded_max_context_chars: int = 480_000,
    grounded_reserved_context_fraction: float = 0.15,
    grounded_context_chars_per_token: int = 4,
    grounded_max_compacted_tool_output_chars: int = 2_000,
    grounded_max_file_bytes: int = 2_000_000,
    grounded_max_search_results: int = 200,
    grounded_max_glob_results: int = 500,
    grounded_repository_host: str = "github.com",
    grounded_verify_repository_identity: bool = True,
    grounded_consistency_policy: str = "strict",
    grounded_worktree_gc_max_count_per_repo: int = 0,
    grounded_worktree_gc_max_age_days: float = 0.0,
    grounded_worktree_gc_max_bytes_per_repo: int = 0,
) -> dict[str, Any]:
    return await run_blocking(
        generate_historical_knowledge,
        selected_candidates_jsonl,
        generation_mode=generation_mode,
        knowledge_cache_dir=knowledge_cache_dir,
        output_root=output_root,
        settings=settings,
        template_version=template_version,
        target_conditioned=target_conditioned,
        resume=resume,
        repository_root=repository_root,
        historical_worktree_root=historical_worktree_root,
        allow_clone=allow_clone,
        allow_fetch=allow_fetch,
        grounded_max_agent_turns=grounded_max_agent_turns,
        grounded_max_tool_calls=grounded_max_tool_calls,
        grounded_max_tool_output_chars=(
            grounded_max_tool_output_chars
        ),
        grounded_max_context_chars=grounded_max_context_chars,
        grounded_reserved_context_fraction=(
            grounded_reserved_context_fraction
        ),
        grounded_context_chars_per_token=(
            grounded_context_chars_per_token
        ),
        grounded_max_compacted_tool_output_chars=(
            grounded_max_compacted_tool_output_chars
        ),
        grounded_max_file_bytes=grounded_max_file_bytes,
        grounded_max_search_results=grounded_max_search_results,
        grounded_max_glob_results=grounded_max_glob_results,
        grounded_repository_host=grounded_repository_host,
        grounded_verify_repository_identity=(
            grounded_verify_repository_identity
        ),
        grounded_consistency_policy=grounded_consistency_policy,
        grounded_worktree_gc_max_count_per_repo=(
            grounded_worktree_gc_max_count_per_repo
        ),
        grounded_worktree_gc_max_age_days=(
            grounded_worktree_gc_max_age_days
        ),
        grounded_worktree_gc_max_bytes_per_repo=(
            grounded_worktree_gc_max_bytes_per_repo
        ),
    )


def prepare_historical_knowledge(
    instance: Mapping[str, Any],
    *,
    generation_mode: str,
    search_options: Mapping[str, Any] | SearchRetrievalOptions | None = None,
    gate_options: Mapping[str, Any] | SimilarityGateOptions | None = None,
    settings: ServerSettings | None = None,
    preretrieved_dir: str | None = None,
    knowledge_cache_dir: str | Path | None = None,
    output_root: str | Path | None = None,
    template_version: str | None = None,
    resume: bool = True,
    refresh_instance_metadata: bool = False,
    use_test_patch_for_metadata: bool = False,
    repository_root: str | Path | None = None,
    historical_worktree_root: str | Path | None = None,
    allow_clone: bool = False,
    allow_fetch: bool = False,
    grounded_max_agent_turns: int = 24,
    grounded_max_tool_calls: int = 20,
    grounded_max_tool_output_chars: int = 16_000,
    grounded_max_context_chars: int = 480_000,
    grounded_reserved_context_fraction: float = 0.15,
    grounded_context_chars_per_token: int = 4,
    grounded_max_compacted_tool_output_chars: int = 2_000,
    grounded_max_file_bytes: int = 2_000_000,
    grounded_max_search_results: int = 200,
    grounded_max_glob_results: int = 500,
    grounded_repository_host: str = "github.com",
    grounded_verify_repository_identity: bool = True,
    grounded_consistency_policy: str = "strict",
    grounded_worktree_gc_max_count_per_repo: int = 0,
    grounded_worktree_gc_max_age_days: float = 0.0,
    grounded_worktree_gc_max_bytes_per_repo: int = 0,
    light_aspect_mode: str = "g_from_issue_plus_fg_calltrace",
) -> dict[str, Any]:
    """Run the complete, artifact-producing Knowledge Preparation pipeline."""

    if use_test_patch_for_metadata:
        raise ValueError(
            "The unified production interface does not allow target test "
            "patches to participate in metadata recovery."
        )
    resolved = (settings or ServerSettings()).resolved()
    normalized_instance = SWEbenchProInstance.from_mapping(instance)
    normalized_search_options = (
        search_options
        if isinstance(search_options, SearchRetrievalOptions)
        else SearchRetrievalOptions.from_mapping(search_options)
    )
    normalized_gate_options = (
        gate_options
        if isinstance(gate_options, SimilarityGateOptions)
        else SimilarityGateOptions.from_mapping(gate_options)
    )
    mode = validate_generation_mode(generation_mode)
    model = _configured_generator_model(resolved)
    version = template_version or template_version_for_mode(mode)
    resolved_output_root = (
        Path(output_root).expanduser().resolve()
        if output_root is not None
        else resolved.output_root or resolved.project_root / "outputs"
    )
    resolved_cache_dir = (
        Path(knowledge_cache_dir).expanduser().resolve()
        if knowledge_cache_dir is not None
        else resolved.project_root / "knowl_cache"
    )
    resolved_preretrieved_dir = (
        Path(preretrieved_dir).expanduser().resolve()
        if preretrieved_dir is not None
        else resolved.project_root / "preretrieved_issues"
    )
    grounded_configuration = (
        _grounded_config(
            resolved,
            allow_clone=allow_clone,
            allow_fetch=allow_fetch,
            repository_root=repository_root,
            historical_worktree_root=historical_worktree_root,
            max_agent_turns=grounded_max_agent_turns,
            max_tool_calls=grounded_max_tool_calls,
            max_tool_output_chars=grounded_max_tool_output_chars,
            max_context_chars=grounded_max_context_chars,
            reserved_context_fraction=(
                grounded_reserved_context_fraction
            ),
            context_chars_per_token=grounded_context_chars_per_token,
            max_compacted_tool_output_chars=(
                grounded_max_compacted_tool_output_chars
            ),
            max_file_bytes=grounded_max_file_bytes,
            max_search_results=grounded_max_search_results,
            max_glob_results=grounded_max_glob_results,
            repository_host=grounded_repository_host,
            verify_repository_identity=(
                grounded_verify_repository_identity
            ),
            grounding_consistency_policy=(
                grounded_consistency_policy
            ),
            worktree_gc_max_count_per_repo=(
                grounded_worktree_gc_max_count_per_repo
            ),
            worktree_gc_max_age_days=(
                grounded_worktree_gc_max_age_days
            ),
            worktree_gc_max_bytes_per_repo=(
                grounded_worktree_gc_max_bytes_per_repo
            ),
        )
        if mode == "grounded_analysis"
        else None
    )
    light_configuration = (
        _light_config(resolved, aspect_mode=light_aspect_mode)
        if mode == "light"
        else None
    )
    runtime_settings = dataclasses.replace(
        resolved,
        output_root=resolved_output_root,
        repository_root=(
            grounded_configuration.repository_root
            if grounded_configuration is not None
            else resolved.repository_root
        ),
        historical_worktree_root=(
            grounded_configuration.worktree_root
            if grounded_configuration is not None
            else resolved.historical_worktree_root
        ),
    )
    request = PreparationRequest(
        instance=normalized_instance,
        search_options=normalized_search_options,
        gate_options=normalized_gate_options,
        generation_mode=mode,
        preretrieved_dir=resolved_preretrieved_dir,
        knowledge_cache_dir=resolved_cache_dir,
        output_root=resolved_output_root,
        template_version=version,
        generator_model=model,
        resume=resume,
        refresh_instance_metadata=refresh_instance_metadata,
        allow_clone=allow_clone,
        allow_fetch=allow_fetch,
        repository_root=(
            grounded_configuration.repository_root
            if grounded_configuration is not None
            else None
        ),
        historical_worktree_root=(
            grounded_configuration.worktree_root
            if grounded_configuration is not None
            else None
        ),
        generation_runtime_options=(
            grounded_configuration.public_dict()
            if grounded_configuration is not None
            else {}
        ),
    )
    capabilities = _compose_capabilities(
        resolved=runtime_settings,
        resolved_output_root=resolved_output_root,
        resolved_cache_dir=resolved_cache_dir,
        resolved_preretrieved_dir=resolved_preretrieved_dir,
        light_configuration=light_configuration,
        grounded_configuration=grounded_configuration,
        allow_clone=allow_clone, allow_fetch=allow_fetch,
    )
    result = capabilities.codify.prepare(request)
    return result.to_dict()


async def prepare_historical_knowledge_async(
    instance: Mapping[str, Any],
    **kwargs: Any,
) -> dict[str, Any]:
    """Async wrapper for MCP servers and other event-loop based callers."""

    return await run_blocking(
        prepare_historical_knowledge,
        instance,
        **kwargs,
    )
