"""Query-plan order profiles for the mk-v2 fallback-order experiment.

This module deliberately delegates query construction to the production
``github_v4_backend.build_search_plan`` implementation.  The experimental
arm changes only the order of already-built phase dictionaries; query text,
search type, page budget, leakage boundaries, fix discovery, global hit
deduplication, and the 10-candidate stop remain production behavior.
"""

from __future__ import annotations

import collections
import contextlib
import json
from collections.abc import Iterator, Mapping, Sequence
from typing import Any

CONTROL_PROFILE = "mk_v2_control"
TITLE_EARLY_PROFILE = "title_early"
SUPPORTED_PROFILES = (CONTROL_PROFILE, TITLE_EARLY_PROFILE)

TITLE_EARLY_PHASES = (
    "semantic_title_only",
    "hybrid_title_and_extracted_keywords",
)


def _phase_name(phase: Mapping[str, Any]) -> str:
    return str(phase.get("phase") or "")


def _phase_fingerprint(phase: Mapping[str, Any]) -> str:
    """Return an exact, order-independent fingerprint for one phase."""
    return json.dumps(dict(phase), ensure_ascii=False, sort_keys=True, default=str)


def assert_exact_permutation(
    original: Sequence[Mapping[str, Any]],
    reordered: Sequence[Mapping[str, Any]],
) -> None:
    """Fail if an experimental profile changes anything except list order."""
    original_counts = collections.Counter(_phase_fingerprint(row) for row in original)
    reordered_counts = collections.Counter(_phase_fingerprint(row) for row in reordered)
    if original_counts != reordered_counts:
        missing = list((original_counts - reordered_counts).elements())
        added = list((reordered_counts - original_counts).elements())
        raise AssertionError(
            "query-order profile changed phase content; "
            f"missing={len(missing)} added={len(added)}"
        )


def reorder_search_plan(
    phases: Sequence[Mapping[str, Any]],
    profile: str,
) -> list[dict[str, Any]]:
    """Apply one named order profile without mutating the caller's phases.

    ``mk_v2_control`` preserves the production order exactly.

    ``title_early`` keeps the primary query first, then moves
    ``semantic_title_only`` and ``hybrid_title_and_extracted_keywords``
    immediately after it, in that order.  Every remaining phase retains its
    original relative order.  If a title-derived phase was not built for a
    particular instance, the available phases are moved and no phase is
    invented.
    """
    if profile not in SUPPORTED_PROFILES:
        raise ValueError(
            f"unsupported query-order profile {profile!r}; "
            f"choose one of {', '.join(SUPPORTED_PROFILES)}"
        )

    copied = [dict(phase) for phase in phases]
    if profile == CONTROL_PROFILE or len(copied) <= 1:
        return copied

    primary = copied[0]
    remaining = copied[1:]
    moved: list[dict[str, Any]] = []
    for wanted_name in TITLE_EARLY_PHASES:
        for index, phase in enumerate(remaining):
            if _phase_name(phase) == wanted_name:
                moved.append(remaining.pop(index))
                break

    result = [primary, *moved, *remaining]
    assert_exact_permutation(copied, result)
    return result


def profile_description(profile: str) -> str:
    if profile == CONTROL_PROFILE:
        return "Unmodified mk-v2 production query order."
    if profile == TITLE_EARLY_PROFILE:
        return (
            "Primary query, then semantic_title_only, then "
            "hybrid_title_and_extracted_keywords, followed by the remaining "
            "mk-v2 phases in their original relative order."
        )
    raise ValueError(f"unsupported query-order profile: {profile}")


@contextlib.contextmanager
def installed_query_order_profile(profile: str) -> Iterator[None]:
    """Temporarily apply a profile to the production plan builder.

    The experiment CLI runs one profile per process, so this narrowly scoped
    patch cannot leak between arms.  The original functions are restored even
    when retrieval raises.
    """
    if profile not in SUPPORTED_PROFILES:
        raise ValueError(f"unsupported query-order profile: {profile}")

    from .. import github as v4

    original_build_search_plan = v4.build_search_plan
    original_search_policy_name = v4.search_policy_name

    def profiled_build_search_plan(
        instance: dict[str, Any],
        boundary_ts: float,
        args: Any,
    ) -> list[dict[str, Any]]:
        production_plan = original_build_search_plan(instance, boundary_ts, args)
        return reorder_search_plan(production_plan, profile)

    def profiled_search_policy_name(*args: Any, **kwargs: Any) -> str:
        base_name = original_search_policy_name(*args, **kwargs)
        return f"{base_name}__query_order_{profile}"

    v4.build_search_plan = profiled_build_search_plan
    v4.search_policy_name = profiled_search_policy_name
    try:
        yield
    finally:
        v4.build_search_plan = original_build_search_plan
        v4.search_policy_name = original_search_policy_name
