"""Replaceable target-issue resolution for LingxiAdvisor activation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol


def _positive_int(value: Any) -> int | None:
    if value in (None, "") or isinstance(value, bool):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


@dataclass(frozen=True)
class TargetIssue:
    """Identity facts proving that the current request targets an existing issue."""

    instance_id: str = ""
    issue_number: int | None = None
    created_at: str | None = None

    def validate(self) -> None:
        if not self.instance_id.strip() and self.issue_number is None:
            raise ValueError(
                "target_issue requires instance_id/issue_id or issue_number"
            )
        if self.issue_number is not None and self.issue_number < 1:
            raise ValueError("target_issue.issue_number must be positive")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "TargetIssue":
        if not isinstance(value, Mapping):
            raise TypeError("target_issue must be a mapping")
        allowed = {
            "id",
            "issue_id",
            "instance_id",
            "number",
            "issue_number",
            "created_at",
            "instance_create_at",
        }
        unknown = sorted(str(key) for key in value if key not in allowed)
        if unknown:
            raise ValueError(
                "unknown target_issue field(s): " + ", ".join(unknown)
            )
        raw_number = value.get("issue_number", value.get("number"))
        issue_number = _positive_int(raw_number)
        if raw_number not in (None, "") and issue_number is None:
            raise ValueError("target_issue.issue_number must be positive")
        target = cls(
            instance_id=str(
                value.get("instance_id")
                or value.get("issue_id")
                or value.get("id")
                or ""
            ).strip(),
            issue_number=issue_number,
            created_at=(
                str(
                    value.get("created_at")
                    or value.get("instance_create_at")
                    or ""
                ).strip()
                or None
            ),
        )
        target.validate()
        return target

    def to_dict(self) -> dict[str, Any]:
        value: dict[str, Any] = {}
        if self.instance_id:
            value["instance_id"] = self.instance_id
        if self.issue_number is not None:
            value["issue_number"] = self.issue_number
        if self.created_at:
            value["created_at"] = self.created_at
        return value


class TargetIssueResolver(Protocol):
    """Internal extension point that resolves identity facts into a target."""

    def resolve(
        self,
        *,
        explicit_target: TargetIssue | None,
        context: Mapping[str, Any],
    ) -> TargetIssue | None: ...


class DefaultTargetIssueResolver:
    """Resolve explicit identity plus legacy benchmark context deterministically."""

    def resolve(
        self,
        *,
        explicit_target: TargetIssue | None,
        context: Mapping[str, Any],
    ) -> TargetIssue | None:
        legacy = self._legacy_target(context)
        if explicit_target is None:
            return legacy
        explicit_target.validate()
        if legacy is None:
            return explicit_target
        if (
            explicit_target.instance_id
            and legacy.instance_id
            and explicit_target.instance_id != legacy.instance_id
        ):
            raise ValueError(
                "target_issue.instance_id conflicts with context identity"
            )
        if (
            explicit_target.issue_number is not None
            and legacy.issue_number is not None
            and explicit_target.issue_number != legacy.issue_number
        ):
            raise ValueError("target_issue.issue_number conflicts with context")
        return TargetIssue(
            instance_id=explicit_target.instance_id or legacy.instance_id,
            issue_number=(
                explicit_target.issue_number
                if explicit_target.issue_number is not None
                else legacy.issue_number
            ),
            created_at=explicit_target.created_at or legacy.created_at,
        )

    @staticmethod
    def _legacy_target(context: Mapping[str, Any]) -> TargetIssue | None:
        instance_id = str(
            context.get("instance_id") or context.get("issue_id") or ""
        ).strip()
        issue_number = _positive_int(context.get("issue_number"))
        if not instance_id and issue_number is None:
            return None
        return TargetIssue(
            instance_id=instance_id,
            issue_number=issue_number,
            created_at=(
                str(context.get("instance_create_at") or "").strip() or None
            ),
        )


__all__ = [
    "DefaultTargetIssueResolver",
    "TargetIssue",
    "TargetIssueResolver",
]
