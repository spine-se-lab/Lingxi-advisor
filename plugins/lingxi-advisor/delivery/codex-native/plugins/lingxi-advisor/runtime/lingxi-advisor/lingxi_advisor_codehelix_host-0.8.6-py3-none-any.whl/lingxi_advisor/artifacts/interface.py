from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol, runtime_checkable

from ..internal.knowledge_validation import validate_knowledge_content
from ..internal.generation_contracts import (
    GENERATION_SCHEMA_VERSION,
    GenerationMode,
    validate_generation_mode,
)


def _validate_cache_key(value: str) -> str:
    cache_key = str(value or "").strip()
    if (
        not cache_key
        or Path(cache_key).name != cache_key
        or "/" in cache_key
        or "\\" in cache_key
    ):
        raise ValueError("knowledge_cache_key must be one safe basename")
    return cache_key


@dataclass(frozen=True)
class KnowledgeArtifactRef:
    """Stable, path-free identity of one reusable knowledge artifact."""

    generation_mode: GenerationMode
    knowledge_cache_key: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "generation_mode",
            validate_generation_mode(self.generation_mode),
        )
        object.__setattr__(
            self,
            "knowledge_cache_key",
            _validate_cache_key(self.knowledge_cache_key),
        )

    def to_dict(self) -> dict[str, str]:
        return dataclasses.asdict(self)

    @classmethod
    def from_mapping(
        cls, value: Mapping[str, Any]
    ) -> "KnowledgeArtifactRef":
        return cls(
            generation_mode=str(value.get("generation_mode") or ""),  # type: ignore[arg-type]
            knowledge_cache_key=str(
                value.get("knowledge_cache_key") or ""
            ),
        )


@dataclass(frozen=True)
class KnowledgeArtifact:
    """Validated XML content and provenance behind an artifact reference."""

    ref: KnowledgeArtifactRef
    knowledge_xml: str
    historical_candidate_fingerprint: str
    historical_patch_sha256: str
    template_version: str
    generator_model: str
    target_conditioned: bool = False
    instance_id: str = ""
    artifact_schema_version: int = GENERATION_SCHEMA_VERSION
    artifact_sha256: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        xml_text = str(self.knowledge_xml or "")
        if not xml_text.strip():
            raise ValueError("knowledge_xml cannot be empty")
        if self.target_conditioned:
            raise ValueError(
                "LingxiAdvisor knowledge artifacts must be target-independent"
            )
        if self.artifact_schema_version != GENERATION_SCHEMA_VERSION:
            raise ValueError("unsupported artifact_schema_version")
        digest = validate_knowledge_content(
            xml_text, expected_sha256=self.artifact_sha256
        )
        object.__setattr__(self, "knowledge_xml", xml_text)
        object.__setattr__(self, "artifact_sha256", digest)

    def to_dict(self, *, include_content: bool = True) -> dict[str, Any]:
        value: dict[str, Any] = {
            "artifact_ref": self.ref.to_dict(),
            "artifact_sha256": self.artifact_sha256,
            "artifact_schema_version": self.artifact_schema_version,
            "historical_candidate_fingerprint": (
                self.historical_candidate_fingerprint
            ),
            "historical_patch_sha256": self.historical_patch_sha256,
            "template_version": self.template_version,
            "generator_model": self.generator_model,
            "target_conditioned": self.target_conditioned,
            "instance_id": self.instance_id,
            "metadata": dict(self.metadata),
        }
        if include_content:
            value["knowledge_xml"] = self.knowledge_xml
        return value


@runtime_checkable
class KnowledgeArtifactStore(Protocol):
    """Canonical storage seam used by Codify and Activation."""

    def lookup(
        self,
        *,
        generation_mode: GenerationMode,
        knowledge_cache_key: str,
    ) -> KnowledgeArtifactRef | None: ...

    def read(
        self,
        artifact_ref: KnowledgeArtifactRef,
    ) -> KnowledgeArtifact: ...

    def store(
        self,
        artifact: KnowledgeArtifact,
    ) -> KnowledgeArtifactRef: ...

