"""Legacy dataset orchestration; runtime capabilities do not import this module."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import logging
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .common import (
    SCRIPT_VERSION,
    infer_target_commit_from_instance,
    instance_identifier,
    isoformat_utc,
    load_instance_filter,
    logger,
    normalize_repo,
    parse_issue_number_int,
    read_json,
    read_jsonl,
    repo_identity_key,
    repo_local_name,
    resolve_repo_checkout,
    safe_filename_part,
    safe_int,
    safe_str,
    write_json_atomic,
    write_jsonl_atomic,
)
from .discovery import (
    compute_boundary,
    discover_issue_fix_record,
    discover_pr_records,
    early_hit_time_rejects,
    historical_lookup_key,
    instance_checkpoint_path,
    load_historical_lookup,
    make_output_record,
    record_unique_key,
    resolve_base_commit_time,
    run_search_with_cache,
    validate_candidate,
)
from .query import (
    build_search_plan,
    search_policy_name,
)
from .transport import (
    GithubClient,
    GithubTokenRotator,
    load_github_tokens_from_env,
)

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None


def process_instance(
    *,
    instance: Dict[str, Any],
    client: GithubClient,
    historical_lookup: Dict[str, Dict[str, Any]],
    repo_checkout_root: Path,
    checkpoint_dir: Path,
    instance_output_dir: Path,
    search_cache_dir: Path,
    commit_time_cache_dir: Path,
    dynamic_cache_dir: Path,
    dynamic_patch_dir: Path,
    all_target_commits: set[str],
    args: argparse.Namespace,
) -> Dict[str, Any]:
    instance_id = instance_identifier(instance)
    repo = normalize_repo(instance.get("repo"))
    checkpoint_path = instance_checkpoint_path(checkpoint_dir, instance_id)
    output_path = instance_output_dir / f"{safe_filename_part(instance_id)}.jsonl"

    if args.resume and checkpoint_path.exists() and output_path.exists() and not args.refresh_instance:
        checkpoint = read_json(checkpoint_path) or {}
        if checkpoint.get("status") == "done" and checkpoint.get("script_version") == SCRIPT_VERSION:
            logger.info("Skipping completed instance %s", instance_id)
            return checkpoint

    repo_checkout = resolve_repo_checkout(repo, repo_checkout_root)
    base_time, base_time_source = resolve_base_commit_time(
        instance=instance,
        repo_checkout=repo_checkout,
        client=client,
        cache_dir=commit_time_cache_dir,
    )
    boundary_ts, boundary_iso, boundary_source = compute_boundary(instance, base_time)
    if boundary_ts <= 0.0:
        checkpoint = {
            "script_version": SCRIPT_VERSION,
            "instance_id": instance_id,
            "repo": repo,
            "status": "skipped",
            "reason": f"base_commit_time_unresolved:{base_time_source}",
            "records_written": 0,
            "output_file": str(output_path),
            "finished_at": isoformat_utc(dt.datetime.now(dt.timezone.utc)),
        }
        write_jsonl_atomic(output_path, [])
        write_json_atomic(checkpoint_path, checkpoint)
        return checkpoint

    search_plan = build_search_plan(instance, boundary_ts, args)
    primary_query = search_plan[0]["github_query"] if search_plan else ""
    search_pages: List[Dict[str, Any]] = []
    search_phase_stats: List[Dict[str, Any]] = []
    output_rows: List[Dict[str, Any]] = []
    rejection_reasons: Counter[str] = Counter()
    discovery_sources: Counter[str] = Counter()
    unique_search_hit_keys: set[str] = set()
    emitted_record_keys: set[str] = set()
    raw_pr_pseudo_hits = 0
    raw_repo_mismatch_hits = 0
    duplicate_hit_count = 0
    precollected_fix_hits = 0
    precollected_fix_missing = 0
    dynamic_fix_attempts = 0
    dynamic_fix_found = 0
    dynamic_fix_missing = 0

    for phase_item in search_plan:
        if len(output_rows) >= args.max_candidates_per_instance:
            break
        phase_name = safe_str(phase_item["phase"])
        retrieval_tier = safe_int(phase_item.get("tier"), 0)
        search_kind = safe_str(phase_item["kind"])
        phase_search_type = (
            safe_str(phase_item.get("search_type"))
            or safe_str(args.search_type)
        )
        query_variant = safe_str(phase_item.get("query_variant"))
        query_text = safe_str(phase_item.get("query_text"))
        github_query = safe_str(phase_item["github_query"])
        phase_page_limit = safe_int(phase_item.get("pages"), args.search_pages)
        phase_pages: List[Dict[str, Any]] = []
        phase_rejections: Counter[str] = Counter()
        phase_records_before = len(output_rows)
        phase_raw_unique_hits = 0
        phase_precollected_hits = 0
        phase_precollected_missing = 0
        phase_dynamic_attempts = 0
        phase_dynamic_found = 0
        phase_dynamic_missing = 0
        ranked_hits: List[Dict[str, Any]] = []
        phase_effective_query = github_query
        phase_effective_query_text = query_text
        phase_query_auto_truncated = False
        phase_query_original_chars = len(github_query)
        phase_query_effective_chars = len(github_query)
        phase_query_request_attempts = 1
        phase_problem_effective_chars: Optional[int] = None
        phase_requirements_effective_chars: Optional[int] = None

        for page in range(1, phase_page_limit + 1):
            try:
                wrapped = run_search_with_cache(
                    client=client,
                    query=github_query,
                    search_type=phase_search_type,
                    per_page=args.per_page,
                    page=page,
                    text_match=args.text_match,
                    cache_dir=search_cache_dir,
                    refresh_cache=args.refresh_search_cache,
                    sleep_seconds=args.search_sleep_seconds,
                )
            except Exception as exc:
                page_stat = {"phase": phase_name, "page": page, "status": "error", "error": safe_str(exc)}
                phase_pages.append(page_stat)
                search_pages.append(page_stat)
                logger.warning("GitHub search failed for %s phase=%s page=%s: %s", instance_id, phase_name, page, exc)
                continue
            payload = wrapped.get("payload") or {}
            effective_github_query = (
                safe_str(wrapped.get("effective_query")) or github_query
            )
            effective_query_text = (
                safe_str(wrapped.get("effective_query_text"))
                or query_text
            )
            phase_effective_query = effective_github_query
            phase_effective_query_text = effective_query_text
            phase_query_auto_truncated = bool(
                wrapped.get("query_auto_truncated")
            )
            phase_query_original_chars = safe_int(
                wrapped.get("query_original_chars"),
                len(github_query),
            )
            phase_query_effective_chars = safe_int(
                wrapped.get("query_effective_chars"),
                len(effective_github_query),
            )
            phase_query_request_attempts = safe_int(
                wrapped.get("query_request_attempts"),
                1,
            )
            phase_problem_effective_chars = wrapped.get(
                "problem_effective_chars"
            )
            phase_requirements_effective_chars = wrapped.get(
                "requirements_effective_chars"
            )
            requested_search_type = (
                safe_str(wrapped.get("requested_search_type"))
                or phase_search_type
            )
            actual_search_type = (
                safe_str(wrapped.get("actual_search_type"))
                or safe_str(payload.get("search_type"))
                or requested_search_type
            )
            search_fallback_reason = wrapped.get(
                "search_fallback_reason"
            )
            search_type_fallback = bool(
                wrapped.get("search_type_fallback")
                or actual_search_type != requested_search_type
                or search_fallback_reason
            )
            items = payload.get("items") or []
            query_error = safe_str(payload.get("query_error"))
            page_stat = {
                "phase": phase_name,
                "kind": search_kind,
                "page": page,
                "requested_search_type": requested_search_type,
                "actual_search_type": actual_search_type,
                "search_type_fallback": search_type_fallback,
                "search_fallback_reason": search_fallback_reason,
                "status": "search_failed" if query_error else "ok",
                "total_count": payload.get("total_count"),
                "incomplete_results": payload.get("incomplete_results"),
                "items_returned": len(items),
                "query_error": query_error or None,
                "original_github_query": github_query,
                "effective_github_query": effective_github_query,
                "query_auto_truncated": phase_query_auto_truncated,
                "query_original_chars": phase_query_original_chars,
                "query_effective_chars": phase_query_effective_chars,
                "query_request_attempts": phase_query_request_attempts,
                "problem_effective_chars": (
                    phase_problem_effective_chars
                ),
                "requirements_effective_chars": (
                    phase_requirements_effective_chars
                ),
            }
            phase_pages.append(page_stat)
            search_pages.append(page_stat)
            if not items:
                break
            for idx, item in enumerate(items, start=1):
                if not isinstance(item, dict):
                    continue
                global_rank = (page - 1) * args.per_page + idx
                item_repo = normalize_repo((item.get("repository_url") or "").split("/repos/")[-1])
                if item_repo and repo_identity_key(item_repo) != repo_identity_key(repo):
                    raw_repo_mismatch_hits += 1
                    continue
                is_pr_hit = "pull_request" in item
                if search_kind == "issue" and is_pr_hit:
                    raw_pr_pseudo_hits += 1
                    continue
                if search_kind == "pr" and not is_pr_hit:
                    continue
                num = parse_issue_number_int(item.get("number"))
                if not num:
                    continue
                hit_key = f"{search_kind}:{repo}#{num}"
                if hit_key in unique_search_hit_keys:
                    duplicate_hit_count += 1
                    continue
                unique_search_hit_keys.add(hit_key)
                early_reject = early_hit_time_rejects(item, boundary_ts)
                if early_reject:
                    rejection_reasons[early_reject] += 1
                    phase_rejections[early_reject] += 1
                    continue
                phase_raw_unique_hits += 1
                hit = dict(item)
                hit["_github_rank_in_query"] = global_rank
                hit["_github_global_rank"] = global_rank
                hit["_retrieval_tier"] = retrieval_tier
                hit["_phase_search_type"] = phase_search_type
                hit["_github_requested_search_type"] = (
                    requested_search_type
                )
                hit["_github_actual_search_type"] = actual_search_type
                hit["_github_search_type_fallback"] = (
                    search_type_fallback
                )
                hit["_github_search_fallback_reason"] = (
                    search_fallback_reason
                )
                hit["_github_search_phase"] = phase_name
                hit["_github_query_text"] = effective_query_text
                hit["_github_query"] = effective_github_query
                hit["_github_original_query"] = github_query
                hit["_github_query_auto_truncated"] = (
                    phase_query_auto_truncated
                )
                hit["_github_query_original_chars"] = (
                    phase_query_original_chars
                )
                hit["_github_query_effective_chars"] = (
                    phase_query_effective_chars
                )
                hit["_github_query_request_attempts"] = (
                    phase_query_request_attempts
                )
                hit["_github_problem_effective_chars"] = (
                    phase_problem_effective_chars
                )
                hit["_github_requirements_effective_chars"] = (
                    phase_requirements_effective_chars
                )
                ranked_hits.append(hit)

        # GitHub semantic/hybrid relevance is represented by result order.
        # The response score is commonly constant and is not a tie-breaker.
        ranked_hits.sort(
            key=lambda h: safe_int(
                h.get("_github_rank_in_query"),
                10**9,
            )
        )

        for hit in ranked_hits[: args.max_search_hits_to_resolve]:
            if len(output_rows) >= args.max_candidates_per_instance:
                break
            number = parse_issue_number_int(hit.get("number"))
            if not number:
                rejection_reasons["missing_issue_or_pr_number"] += 1
                phase_rejections["missing_issue_or_pr_number"] += 1
                continue

            candidate_records: List[Tuple[Dict[str, Any], str]] = []
            if search_kind == "issue":
                lookup_key = historical_lookup_key(repo, number)
                record = historical_lookup.get(lookup_key)
                if record is not None:
                    precollected_fix_hits += 1
                    phase_precollected_hits += 1
                    candidate_records.append((record, "precollected_02_output"))
                else:
                    precollected_fix_missing += 1
                    phase_precollected_missing += 1
                    dynamic_fix_attempts += 1
                    phase_dynamic_attempts += 1
                    record, source = discover_issue_fix_record(
                        repo=repo,
                        issue_number=number,
                        search_item=hit,
                        client=client,
                        repo_checkout=repo_checkout,
                        patch_dir=dynamic_patch_dir / repo_local_name(repo),
                        dynamic_cache_dir=dynamic_cache_dir,
                        include_patch_text=not args.no_patch_text,
                    )
                    discovery_sources[source] += 1
                    if record is not None:
                        dynamic_fix_found += 1
                        phase_dynamic_found += 1
                        candidate_records.append((record, source))
                    else:
                        dynamic_fix_missing += 1
                        phase_dynamic_missing += 1
                        rejection_reasons[source] += 1
                        phase_rejections[source] += 1
                        continue
            else:
                dynamic_fix_attempts += 1
                phase_dynamic_attempts += 1
                records, source = discover_pr_records(
                    repo=repo,
                    pr_number=number,
                    pr_search_item=hit,
                    client=client,
                    repo_checkout=repo_checkout,
                    patch_dir=dynamic_patch_dir / repo_local_name(repo),
                    dynamic_cache_dir=dynamic_cache_dir,
                    include_patch_text=not args.no_patch_text,
                )
                discovery_sources[source] += 1
                if records:
                    dynamic_fix_found += len(records)
                    phase_dynamic_found += len(records)
                    candidate_records.extend((record, source) for record in records)
                else:
                    dynamic_fix_missing += 1
                    phase_dynamic_missing += 1
                    rejection_reasons[source] += 1
                    phase_rejections[source] += 1
                    continue

            for record, origin in candidate_records:
                if len(output_rows) >= args.max_candidates_per_instance:
                    break
                rkey = record_unique_key(record)
                if rkey in emitted_record_keys:
                    duplicate_hit_count += 1
                    continue
                safe, reason, details = validate_candidate(
                    instance=instance,
                    record=record,
                    base_time=base_time,
                    all_target_commits=all_target_commits,
                    enable_issue_number_guard=args.enable_issue_number_guard,
                )
                if not safe:
                    rejection_reasons[reason] += 1
                    phase_rejections[reason] += 1
                    continue
                row = make_output_record(
                    instance=instance,
                    historical_record=record,
                    github_hit=hit,
                    query_text=safe_str(hit.get("_github_query_text")),
                    github_query=safe_str(hit.get("_github_query")),
                    search_phase=phase_name,
                    search_kind=search_kind,
                    search_type=phase_search_type,
                    search_rank=safe_int(
                        hit.get("_github_rank_in_query"),
                        0,
                    ),
                    safe_position=len(output_rows),
                    base_time=base_time,
                    base_time_source=base_time_source,
                    leakage_details=details,
                    record_origin=origin,
                )
                row["issue_number_guard_enabled"] = bool(
                    args.enable_issue_number_guard
                )
                row["retrieval_tier"] = retrieval_tier
                row["query_variant"] = query_variant
                row["github_rank_in_query"] = safe_int(
                    hit.get("_github_rank_in_query"),
                    0,
                )
                row["problem_statement_original_chars"] = safe_int(
                    phase_item.get("problem_statement_original_chars"),
                    len(safe_str(instance.get("problem_statement"))),
                )
                row["requirements_original_chars"] = safe_int(
                    phase_item.get("requirements_original_chars"),
                    len(safe_str(instance.get("requirements"))),
                )
                row["problem_statement_sent_chars"] = safe_int(
                    hit.get("_github_problem_effective_chars"),
                    safe_int(
                        phase_item.get("problem_statement_planned_chars"),
                        len(safe_str(instance.get("problem_statement"))),
                    ),
                )
                row["requirements_sent_chars"] = safe_int(
                    hit.get("_github_requirements_effective_chars"),
                    safe_int(
                        phase_item.get("requirements_planned_chars"),
                        0,
                    ),
                )
                row["query_text_sent_chars"] = len(
                    safe_str(hit.get("_github_query_text"))
                )
                row["query_text_truncated"] = bool(
                    phase_item.get("query_text_truncated")
                    or hit.get("_github_query_auto_truncated")
                )
                row["github_query_hard_truncated"] = bool(
                    phase_item.get("github_query_hard_truncated")
                    or hit.get("_github_query_auto_truncated")
                )
                row["extracted_keyword_count"] = safe_int(
                    phase_item.get("extracted_keyword_count"),
                    0,
                )
                row["extracted_keywords_used"] = list(
                    phase_item.get("extracted_keywords_used") or []
                )
                row["derived_issue_title"] = safe_str(
                    phase_item.get("derived_issue_title")
                )
                row["github_search_original_query"] = safe_str(
                    hit.get("_github_original_query")
                )
                row["github_search_effective_query"] = safe_str(
                    hit.get("_github_query")
                )
                row["github_search_query_auto_truncated"] = bool(
                    hit.get("_github_query_auto_truncated")
                )
                row["github_search_query_original_chars"] = safe_int(
                    hit.get("_github_query_original_chars"),
                    len(github_query),
                )
                row["github_search_query_effective_chars"] = safe_int(
                    hit.get("_github_query_effective_chars"),
                    len(safe_str(hit.get("_github_query"))),
                )
                row["github_search_query_request_attempts"] = safe_int(
                    hit.get("_github_query_request_attempts"),
                    1,
                )
                row["github_requested_search_type"] = hit.get(
                    "_github_requested_search_type"
                )
                row["github_actual_search_type"] = hit.get(
                    "_github_actual_search_type"
                )
                row["github_search_type_fallback"] = bool(
                    hit.get("_github_search_type_fallback")
                )
                row["github_search_fallback_reason"] = hit.get(
                    "_github_search_fallback_reason"
                )
                output_rows.append(row)
                emitted_record_keys.add(rkey)

        search_phase_stats.append({
            "phase": phase_name,
            "retrieval_tier": retrieval_tier,
            "kind": search_kind,
            "search_type": phase_search_type,
            "query_variant": query_variant,
            "query_text": query_text,
            "effective_query_text": phase_effective_query_text,
            "github_query": github_query,
            "effective_github_query": phase_effective_query,
            "extracted_keyword_count": safe_int(
                phase_item.get("extracted_keyword_count"),
                0,
            ),
            "extracted_keywords_used": list(
                phase_item.get("extracted_keywords_used") or []
            ),
            "derived_issue_title": safe_str(
                phase_item.get("derived_issue_title")
            ),
            "query_auto_truncated": phase_query_auto_truncated,
            "query_original_chars": phase_query_original_chars,
            "query_effective_chars": phase_query_effective_chars,
            "query_request_attempts": phase_query_request_attempts,
            "problem_effective_chars": phase_problem_effective_chars,
            "requirements_effective_chars": (
                phase_requirements_effective_chars
            ),
            "pages": phase_pages,
            "raw_unique_hits": phase_raw_unique_hits,
            "precollected_fix_hits": phase_precollected_hits,
            "precollected_fix_missing": phase_precollected_missing,
            "dynamic_fix_attempts": phase_dynamic_attempts,
            "dynamic_fix_found": phase_dynamic_found,
            "dynamic_fix_missing": phase_dynamic_missing,
            "records_written": len(output_rows) - phase_records_before,
            "rejection_reasons": dict(phase_rejections),
        })

    write_jsonl_atomic(output_path, output_rows)
    search_failure_count = sum(
        1
        for page_stat in search_pages
        if page_stat.get("status") in {"error", "search_failed"}
    )
    checkpoint = {
        "script_version": SCRIPT_VERSION,
        "instance_id": instance_id,
        "repo": repo,
        "status": (
            "failed"
            if search_failure_count and not output_rows
            else "done"
        ),
        "error": (
            f"{search_failure_count} GitHub search page(s) failed."
            if search_failure_count and not output_rows
            else None
        ),
        "base_commit_time": isoformat_utc(base_time),
        "base_commit_time_source": base_time_source,
        "boundary_ts": boundary_ts,
        "boundary_iso": boundary_iso,
        "boundary_source": boundary_source,
        "search_type": args.search_type,
        "fallback_search_type": args.fallback_search_type,
        "search_policy": (
            search_policy_name(
                args.search_type,
                args.fallback_search_type,
            )
        ),
        "search_query": primary_query,
        "search_plan": search_plan,
        "search_pages": search_pages,
        "search_phases": search_phase_stats,
        "search_failure_count": search_failure_count,
        "boundary_aware_query_planning_enabled": True,
        "dynamic_fix_discovery_enabled": True,
        "raw_unique_search_hits": len(unique_search_hit_keys),
        "raw_pr_pseudo_hits": raw_pr_pseudo_hits,
        "raw_repo_mismatch_hits": raw_repo_mismatch_hits,
        "duplicate_hit_count": duplicate_hit_count,
        "precollected_fix_hits": precollected_fix_hits,
        "precollected_fix_missing": precollected_fix_missing,
        "dynamic_fix_attempts": dynamic_fix_attempts,
        "dynamic_fix_found": dynamic_fix_found,
        "dynamic_fix_missing": dynamic_fix_missing,
        "dynamic_discovery_sources": dict(discovery_sources),
        "records_written": len(output_rows),
        "rejection_reasons": dict(rejection_reasons),
        "issue_number_guard_enabled": bool(args.enable_issue_number_guard),
        "output_file": str(output_path),
        "finished_at": isoformat_utc(dt.datetime.now(dt.timezone.utc)),
    }
    write_json_atomic(checkpoint_path, checkpoint)
    return checkpoint


def merge_instance_outputs(instance_output_dir: Path, output_path: Path) -> int:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = output_path.with_name(output_path.name + ".tmp")
    rows = 0
    with tmp.open("w", encoding="utf-8") as out_handle:
        for path in sorted(instance_output_dir.glob("*.jsonl")):
            with path.open("r", encoding="utf-8") as in_handle:
                for line in in_handle:
                    if line.strip():
                        out_handle.write(line if line.endswith("\n") else line + "\n")
                        rows += 1
    tmp.replace(output_path)
    return rows


def infer_project_root() -> Path:
    cwd = Path.cwd().resolve()
    if (cwd / "data").exists() or (cwd / "src").exists() or (cwd / ".env").exists():
        return cwd
    current = Path(__file__).resolve()
    for parent in current.parents:
        if (parent / "data").exists() or (parent / "src").exists() or (parent / ".env").exists():
            return parent
    return cwd


def resolve_path(project_root: Path, path_value: str) -> Path:
    path = Path(path_value)
    return path if path.is_absolute() else (project_root / path).resolve()


def configure_logging(level: str) -> None:
    logging.basicConfig(level=getattr(logging, level.upper()), format="%(asctime)s %(levelname)s %(name)s - %(message)s")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "GitHub API V4 semantic-first retriever with dynamic canonical "
            "fix discovery and strict leakage validation."
        )
    )
    parser.add_argument("--project-root", default=None)
    parser.add_argument("--env-file", default=None)
    parser.add_argument("--instances", default="data/swebenchpro/issue_mapping/swebenchpro.instances.with_issue_metadata.jsonl")
    parser.add_argument("--historical-issues", default="cache/github/outputs/swebenchpro_closed_issue_pr_patches.jsonl")
    parser.add_argument("--include-instances", default=None)
    parser.add_argument(
        "--output",
        default=(
            "cache/git_search/"
            "swebenchpro_github_api_v4_semantic_first.top10.jsonl"
        ),
    )
    parser.add_argument("--work-dir", default="cache/git_search_v4")
    parser.add_argument("--repo-checkout-root", default="git_repos")

    parser.add_argument(
        "--search-type",
        default="semantic",
        choices=["hybrid", "semantic", "lexical"],
    )
    parser.add_argument(
        "--fallback-search-type",
        default="hybrid",
        choices=["hybrid", "semantic", "lexical"],
    )
    parser.add_argument("--per-page", type=int, default=100)
    parser.add_argument("--search-pages", type=int, default=3)
    parser.add_argument("--fallback-search-pages", type=int, default=2)
    parser.add_argument("--max-search-hits-to-resolve", type=int, default=300)
    parser.add_argument("--max-candidates-per-instance", type=int, default=10)
    parser.add_argument(
        "--primary-query-text-max-chars",
        type=int,
        default=256,
        help=(
            "Maximum keyword-text characters for primary semantic/hybrid "
            "queries; values above GitHub's documented limit are capped at 256."
        ),
    )
    parser.add_argument(
        "--query-text-max-chars",
        type=int,
        default=256,
        help=(
            "Maximum keyword-text characters for extracted-keyword fallbacks; "
            "also capped by --primary-query-text-max-chars, the total-query "
            "budget, and 256."
        ),
    )
    parser.add_argument(
        "--github-query-max-total-chars",
        type=int,
        default=512,
        help=(
            "Local total-query cap for extracted-keyword fallback phases; this "
            "is separate from GitHub's 256-character keyword-text limit."
        ),
    )
    parser.add_argument(
        "--max-single-term-fallbacks",
        type=int,
        default=2,
        help=(
            "Maximum number of final lexical fallbacks built only from "
            "high-signal code identifiers."
        ),
    )
    parser.add_argument("--search-sleep-seconds", type=float, default=2.0)
    parser.add_argument("--text-match", action="store_true")

    # Kept for compatibility. In V4 the temporal boundary is always enabled and not optional.
    parser.add_argument("--disable-query-fallbacks", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--fallback-query-max-chars", type=int, default=220, help=argparse.SUPPRESS)
    parser.add_argument("--fallback-min-safe-candidates", type=int, default=None, help=argparse.SUPPRESS)

    parser.add_argument("--enable-issue-number-guard", action="store_true")
    parser.add_argument("--max-instances", type=int, default=None)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--refresh-instance", action="store_true")
    parser.add_argument("--refresh-search-cache", action="store_true")
    parser.add_argument("--no-patch-text", action="store_true", help="Store patch files on disk but omit patch text from JSONL rows.")

    parser.add_argument("--disable-ssl-verify", action="store_true", default=True)
    parser.add_argument("--trust-env", action="store_true", default=True)
    parser.add_argument("--timeout-seconds", type=float, default=60.0)
    parser.add_argument("--max-retries", type=int, default=5)
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    configure_logging(args.log_level)

    project_root = Path(args.project_root).resolve() if args.project_root else infer_project_root()
    if load_dotenv is not None:
        env_path = Path(args.env_file).resolve() if args.env_file else project_root / ".env"
        if env_path.exists():
            load_dotenv(env_path)

    instances_path = resolve_path(project_root, args.instances)
    historical_path = resolve_path(project_root, args.historical_issues)
    output_path = resolve_path(project_root, args.output)
    work_dir = resolve_path(project_root, args.work_dir)
    repo_checkout_root = resolve_path(project_root, args.repo_checkout_root)
    include_path = resolve_path(project_root, args.include_instances) if args.include_instances else None

    run_name = safe_filename_part(output_path.name)
    run_dir = work_dir / "runs" / run_name
    checkpoint_dir = run_dir / "checkpoints"
    instance_output_dir = run_dir / "instance_outputs"
    search_cache_dir = work_dir / "search_cache"
    commit_time_cache_dir = work_dir / "commit_time_cache"
    dynamic_cache_dir = work_dir / "dynamic_fix_cache"
    dynamic_patch_dir = work_dir / "dynamic_patches"
    stats_path = output_path.with_suffix(output_path.suffix + ".stats.json")

    if not instances_path.exists():
        raise FileNotFoundError(f"Instances JSONL not found: {instances_path}")
    if not historical_path.exists():
        raise FileNotFoundError(f"Historical issues JSONL not found: {historical_path}")

    tokens = load_github_tokens_from_env()
    if not tokens:
        raise RuntimeError("Set GITHUB_TOKEN or GITHUB_TOKEN_1..GITHUB_TOKEN_7 before running this script.")

    token_rotator = GithubTokenRotator(tokens)
    client = GithubClient(
        token_rotator=token_rotator,
        timeout=args.timeout_seconds,
        verify_ssl=not args.disable_ssl_verify,
        trust_env=args.trust_env,
        max_retries=args.max_retries,
    )

    try:
        all_instances = read_jsonl(instances_path)
        all_target_commits = {infer_target_commit_from_instance(item) for item in all_instances}
        all_target_commits = {sha for sha in all_target_commits if sha}

        include_ids = load_instance_filter(include_path)
        instances = list(all_instances)
        if include_ids is not None:
            before = len(instances)
            instances = [item for item in instances if instance_identifier(item) in include_ids]
            logger.info("Filtered instances by include file: %s -> %s", before, len(instances))
        if args.max_instances is not None:
            instances = instances[: args.max_instances]

        historical_lookup, historical_stats = load_historical_lookup(historical_path)

        logger.info("Project root: %s", project_root)
        logger.info("Instances input: %s", instances_path)
        logger.info("Historical 02 output: %s", historical_path)
        logger.info("Instances available: %s", len(all_instances))
        logger.info("Instances requested: %s", len(instances))
        logger.info("Historical lookup keys: %s", historical_stats.get("historical_lookup_keys"))
        logger.info("Global target commits blacklisted: %s", len(all_target_commits))
        logger.info("Primary GitHub search type: %s", args.search_type)
        logger.info(
            "Fallback GitHub search type: %s",
            args.fallback_search_type,
        )
        logger.info("Output: %s", output_path)
        logger.info("V4 boundary-aware query planning is always enabled.")
        logger.info("V4 dynamic fix discovery is always enabled for precollected cache misses and PR search hits.")

        checkpoints: List[Dict[str, Any]] = []
        aggregate_rejections: Counter[str] = Counter()
        aggregate_discovery_sources: Counter[str] = Counter()

        for idx, instance in enumerate(instances, start=1):
            logger.info("[%s/%s] Processing %s", idx, len(instances), instance_identifier(instance))
            checkpoint = process_instance(
                instance=instance,
                client=client,
                historical_lookup=historical_lookup,
                repo_checkout_root=repo_checkout_root,
                checkpoint_dir=checkpoint_dir,
                instance_output_dir=instance_output_dir,
                search_cache_dir=search_cache_dir,
                commit_time_cache_dir=commit_time_cache_dir,
                dynamic_cache_dir=dynamic_cache_dir,
                dynamic_patch_dir=dynamic_patch_dir,
                all_target_commits=all_target_commits,
                args=args,
            )
            checkpoints.append(checkpoint)
            aggregate_rejections.update(checkpoint.get("rejection_reasons") or {})
            aggregate_discovery_sources.update(checkpoint.get("dynamic_discovery_sources") or {})

        total_rows = merge_instance_outputs(instance_output_dir, output_path)
        summary = {
            "script_version": SCRIPT_VERSION,
            "instances_available_in_input": len(all_instances),
            "instances_requested": len(instances),
            "instances_done": sum(1 for c in checkpoints if c.get("status") == "done"),
            "instances_skipped": sum(1 for c in checkpoints if c.get("status") == "skipped"),
            "instances_error": sum(1 for c in checkpoints if c.get("status") == "error"),
            "output": str(output_path),
            "total_rows": total_rows,
            "search_type": args.search_type,
            "fallback_search_type": args.fallback_search_type,
            "search_policy": (
                search_policy_name(
                    args.search_type,
                    args.fallback_search_type,
                )
            ),
            "qwen_reranked": False,
            "ranking_source": "tier_then_github_rank_in_query",
            "boundary_aware_query_planning_enabled": True,
            "dynamic_fix_discovery_enabled": True,
            "strict_leakage_validation_enabled": True,
            "work_dir": str(work_dir),
            "run_dir": str(run_dir),
            "search_cache_dir": str(search_cache_dir),
            "commit_time_cache_dir": str(commit_time_cache_dir),
            "dynamic_fix_cache_dir": str(dynamic_cache_dir),
            "dynamic_patch_dir": str(dynamic_patch_dir),
            "global_target_commits_blacklisted": len(all_target_commits),
            "historical_02_output_stats": historical_stats,
            "aggregate_rejection_reasons": dict(aggregate_rejections),
            "aggregate_dynamic_discovery_sources": dict(aggregate_discovery_sources),
            "issue_number_guard_enabled": bool(args.enable_issue_number_guard),
            "checkpoints": checkpoints,
            "finished_at": isoformat_utc(dt.datetime.now(dt.timezone.utc)),
        }
        write_json_atomic(stats_path, summary)
        logger.info("Wrote %s rows to %s", total_rows, output_path)
        logger.info("Wrote stats to %s", stats_path)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    finally:
        client.close()

if __name__ == "__main__":
    main()
