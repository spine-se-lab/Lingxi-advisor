from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from .generation_contracts import (
    GenerationManifestRow,
    GenerationMode,
    knowledge_cache_key,
    validate_generation_mode,
)
from .knowledge_cache import KnowledgeCache
from .grounded_analysis.service import GroundedAnalysisService
from .light_generation.contracts import LightGenerationInput
from .light_generation.service import LightGenerationService

logger = logging.getLogger(__name__)

DEFAULT_TEMPLATE_VERSION = "pending_generation_template_v1"
DEFAULT_GENERATOR_MODEL = "pending"


class GenerationModeUnavailableError(RuntimeError):
    pass


def _canonical_candidate(
    candidate: Mapping[str, Any],
) -> tuple[dict[str, Any], LightGenerationInput]:
    value = LightGenerationInput.from_candidate(candidate)
    normalized = dict(candidate)
    normalized.update(
        {
            "instance_id": value.instance_id,
            "repo": value.repo,
            "problem_statement": value.problem_statement,
            "requirements": value.requirements,
            "historical_issue_description": (
                value.historical_issue_description
            ),
            "historical_patch": value.historical_patch,
            "historical_candidate_fingerprint": (
                value.historical_candidate_fingerprint
            ),
            "historical_patch_sha256": value.historical_patch_sha256,
            "historical_issue_number": value.historical_issue_number,
            "historical_issue_url": value.historical_issue_url,
            "historical_fix_commit": value.historical_fix_commit,
        }
    )
    return normalized, value


class GenerationDispatcher:
    """Cache-first router controlled by one user-selected global mode."""

    def __init__(
        self,
        *,
        knowledge_cache: KnowledgeCache,
        generation_mode: GenerationMode,
        template_version: str,
        generator_model: str,
        target_conditioned: bool,
        light_service_factory: Callable[[], LightGenerationService] | None = None,
        grounded_service_factory: (
            Callable[[], GroundedAnalysisService] | None
        ) = None,
    ) -> None:
        self.knowledge_cache = knowledge_cache
        self.generation_mode = validate_generation_mode(generation_mode)
        self.template_version = template_version
        self.generator_model = generator_model
        self.target_conditioned = target_conditioned
        self._light_service_factory = light_service_factory
        self._grounded_service_factory = grounded_service_factory
        self._light_service: LightGenerationService | None = None
        self._grounded_service: GroundedAnalysisService | None = None

    def _get_light_service(self) -> LightGenerationService:
        if self._light_service is None:
            if self._light_service_factory is None:
                raise GenerationModeUnavailableError(
                    "light generation service is not configured"
                )
            self._light_service = self._light_service_factory()
        return self._light_service

    def _get_grounded_service(self) -> GroundedAnalysisService:
        if self._grounded_service is None:
            if self._grounded_service_factory is None:
                raise GenerationModeUnavailableError(
                    "grounded analysis service is not configured"
                )
            self._grounded_service = self._grounded_service_factory()
        return self._grounded_service

    def dispatch(
        self, candidate: Mapping[str, Any], *, output_path: Path
    ) -> GenerationManifestRow:
        cache_key = knowledge_cache_key(
            candidate=candidate,
            generation_mode=self.generation_mode,
            template_version=self.template_version,
            generator_model=self.generator_model,
            target_conditioned=self.target_conditioned,
        )
        instance_id = str(
            candidate.get("instance_id") or "unknown_instance"
        ).strip()
        candidate_id = str(
            candidate.get("historical_candidate_fingerprint")
            or "unresolved"
        ).strip()
        logger.info(
            "Cache lookup: mode=%s instance=%s candidate=%s",
            self.generation_mode,
            instance_id,
            candidate_id,
        )
        logger.debug(
            "Cache identity: mode=%s candidate=%s cache_key=%s",
            self.generation_mode,
            candidate_id,
            cache_key,
        )

        # The per-key lock creates single-flight behavior: a second process waits,
        # rechecks, and observes the artifact instead of making a duplicate call.
        with self.knowledge_cache.generation_lock(
            generation_mode=self.generation_mode,
            cache_key=cache_key,
        ):
            supplied_fingerprint = str(
                candidate.get("historical_candidate_fingerprint") or ""
            ).strip()
            supplied_patch_sha256 = str(
                candidate.get("historical_patch_sha256") or ""
            ).strip()
            entry = self.knowledge_cache.lookup(
                generation_mode=self.generation_mode,
                cache_key=cache_key,
                historical_candidate_fingerprint=(
                    supplied_fingerprint or None
                ),
                historical_patch_sha256=(
                    supplied_patch_sha256 or None
                ),
                template_version=self.template_version,
                generator_model=self.generator_model,
                target_conditioned=self.target_conditioned,
            )
            if entry is not None:
                logger.info(
                    "Cache hit: mode=%s instance=%s candidate=%s",
                    self.generation_mode,
                    instance_id,
                    candidate_id,
                )
                published = self.knowledge_cache.publish(entry, output_path)
                logger.debug(
                    "Cached artifact published: cache=%s output=%s",
                    entry.artifact_path,
                    published,
                )
                return GenerationManifestRow(
                    instance_id=instance_id,
                    historical_candidate_fingerprint=(
                        str(
                            candidate.get(
                                "historical_candidate_fingerprint"
                            )
                            or entry.historical_candidate_fingerprint
                        )
                    ),
                    generation_mode=self.generation_mode,
                    cache_hit=True,
                    generation_status="completed",
                    knowledge_cache_key=cache_key,
                    knowledge_path=str(published),
                    cache_path=entry.artifact_path,
                    knowledge_sha256=entry.artifact_sha256,
                    template_version=self.template_version,
                    generator_model=self.generator_model,
                    target_conditioned=self.target_conditioned,
                )

            normalized, generation_input = _canonical_candidate(candidate)
            candidate_id = (
                generation_input.historical_candidate_fingerprint
            )
            logger.info(
                "Cache miss: mode=%s instance=%s candidate=%s; routing to %s",
                self.generation_mode,
                generation_input.instance_id,
                candidate_id,
                self.generation_mode,
            )
            if self.generation_mode == "light":
                logger.info(
                    "Light generation requested: instance=%s candidate=%s",
                    generation_input.instance_id,
                    candidate_id,
                )
                _, generated = self._get_light_service().generate(normalized)
                worktree_path = None
                worktree_reused = None
                repository_identity_verified = None
                grounding_validation = None
                worktree_post_verified = None
                context_budget: dict[str, Any] = {}
                worktree_gc_removed_count = 0
            elif self.generation_mode == "grounded_analysis":
                logger.info(
                    "Grounded analysis requested: instance=%s candidate=%s",
                    generation_input.instance_id,
                    candidate_id,
                )
                _, generated = self._get_grounded_service().generate(
                    normalized
                )
                worktree_path = generated.worktree_path
                worktree_reused = generated.worktree_reused
                grounding_validation = dict(
                    generated.grounding_validation
                )
                repository_identity_verified = bool(
                    grounding_validation.get(
                        "repository_identity_verified"
                    )
                )
                worktree_post_verified = (
                    generated.worktree_post_verified
                )
                context_budget = dict(generated.context_budget)
                worktree_gc_removed_count = (
                    generated.worktree_gc_removed_count
                )
            else:
                raise GenerationModeUnavailableError(
                    f"unsupported generation mode: {self.generation_mode}"
                )
            logger.info(
                "Generated XML validated; writing cache: mode=%s "
                "instance=%s candidate=%s",
                self.generation_mode,
                generation_input.instance_id,
                candidate_id,
            )
            entry = self.knowledge_cache.store(
                generation_mode=self.generation_mode,
                cache_key=cache_key,
                xml_text=generated.artifact_xml,
                historical_candidate_fingerprint=(
                    generation_input.historical_candidate_fingerprint
                ),
                historical_patch_sha256=(
                    generation_input.historical_patch_sha256
                ),
                template_version=self.template_version,
                generator_model=self.generator_model,
                target_conditioned=self.target_conditioned,
                instance_id=generation_input.instance_id,
            )
            published = self.knowledge_cache.publish(entry, output_path)
            logger.info(
                "Generated artifact cached and published: instance=%s "
                "candidate=%s output=%s",
                generation_input.instance_id,
                candidate_id,
                published,
            )
            return GenerationManifestRow(
                instance_id=generation_input.instance_id,
                historical_candidate_fingerprint=(
                    generation_input.historical_candidate_fingerprint
                ),
                generation_mode=self.generation_mode,
                cache_hit=False,
                generation_status="completed",
                knowledge_cache_key=cache_key,
                knowledge_path=str(published),
                cache_path=entry.artifact_path,
                knowledge_sha256=entry.artifact_sha256,
                template_version=self.template_version,
                generator_model=self.generator_model,
                target_conditioned=self.target_conditioned,
                worktree_path=worktree_path,
                worktree_reused=worktree_reused,
                repository_identity_verified=(
                    repository_identity_verified
                ),
                grounding_validation=grounding_validation,
                worktree_post_verified=worktree_post_verified,
                context_budget=context_budget,
                worktree_gc_removed_count=worktree_gc_removed_count,
                model_calls=[item.to_dict() for item in generated.calls],
                latency_seconds=generated.total_latency_seconds,
                cost_usd=generated.total_cost_usd,
            )


def build_pending_generation_manifest(
    *,
    selected_candidates: Iterable[Mapping[str, Any]],
    generation_mode: GenerationMode,
    knowledge_cache_dir: Path,
    template_version: str = DEFAULT_TEMPLATE_VERSION,
    generator_model: str = DEFAULT_GENERATOR_MODEL,
) -> list[dict[str, Any]]:
    """Compatibility helper for callers that only need a dry-run manifest."""

    rows: list[dict[str, Any]] = []
    for candidate in selected_candidates:
        normalized, value = _canonical_candidate(candidate)
        key = knowledge_cache_key(
            candidate=normalized,
            generation_mode=generation_mode,
            template_version=template_version,
            generator_model=generator_model,
        )
        rows.append(
            GenerationManifestRow(
                instance_id=value.instance_id,
                historical_candidate_fingerprint=(
                    value.historical_candidate_fingerprint
                ),
                generation_mode=generation_mode,
                cache_hit=False,
                generation_status="pending",
                knowledge_cache_key=key,
                knowledge_path=None,
                cache_path=str(
                    knowledge_cache_dir / generation_mode / f"{key}.xml"
                ),
                template_version=template_version,
                generator_model=generator_model,
            ).to_dict()
        )
    return rows
