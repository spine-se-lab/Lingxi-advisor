from __future__ import annotations

import dataclasses
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Mapping

SHA40_RE = re.compile(r"^[0-9a-fA-F]{40}$")
GITHUB_SEARCH_TEXT_MAX_CHARS = 256


def _text(value: Any) -> str:
    return str(value or "").strip()


def _path(value: Any) -> Path | None:
    if value in (None, ""):
        return None
    return Path(str(value)).expanduser()


@dataclass(frozen=True)
class SWEbenchProInstance:
    """Validated public SWE-bench Pro instance input."""

    repo: str
    instance_id: str
    base_commit: str
    problem_statement: str
    requirements: str = ""
    interface: str = ""
    repo_language: str = ""
    issue_specificity: str = ""
    issue_categories: str = ""
    instance_issue_number: int | None = None
    instance_create_at: str | None = None
    base_commit_created_at: str | None = None
    new_issue_search_boundary_at: str | None = None
    issue_mode: Literal["existing_target", "new_issue"] = "existing_target"
    target_leakage_check: bool = True

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "SWEbenchProInstance":
        if not isinstance(data, Mapping):
            raise TypeError("instance must be a JSON object / mapping")
        repo = _text(data.get("repo")).strip("/")
        instance_id = _text(data.get("instance_id"))
        base_commit = _text(data.get("base_commit")).lower()
        problem_statement = _text(data.get("problem_statement"))
        missing = [
            name
            for name, value in (
                ("repo", repo),
                ("instance_id", instance_id),
                ("base_commit", base_commit),
                ("problem_statement", problem_statement),
            )
            if not value
        ]
        if missing:
            raise ValueError(
                f"missing required SWE-bench Pro field(s): {', '.join(missing)}"
            )
        if "/" not in repo or repo.startswith("/") or repo.endswith("/"):
            raise ValueError("repo must be in 'owner/name' format")
        if not SHA40_RE.fullmatch(base_commit):
            raise ValueError("base_commit must be a 40-character hexadecimal SHA")

        raw_issue_number = data.get("instance_issue_number")
        issue_number: int | None = None
        if raw_issue_number not in (None, ""):
            try:
                parsed = int(raw_issue_number)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "instance_issue_number must be an integer when provided"
                ) from exc
            issue_number = parsed if parsed > 0 else None

        issue_mode = _text(data.get("issue_mode") or "existing_target")
        if issue_mode not in {"existing_target", "new_issue"}:
            raise ValueError(
                "issue_mode must be existing_target or new_issue"
            )
        raw_leakage_check = data.get("target_leakage_check")
        target_leakage_check = issue_mode == "existing_target"
        if raw_leakage_check is not None and not isinstance(
            raw_leakage_check, bool
        ):
            raise TypeError("target_leakage_check must be a boolean")
        if (
            raw_leakage_check is not None
            and raw_leakage_check != target_leakage_check
        ):
            raise ValueError(
                "target_leakage_check is derived from issue_mode and cannot "
                "be overridden"
            )

        return cls(
            repo=repo,
            instance_id=instance_id,
            base_commit=base_commit,
            problem_statement=problem_statement,
            requirements=_text(data.get("requirements")),
            interface=_text(data.get("interface")),
            repo_language=_text(data.get("repo_language")),
            issue_specificity=_text(data.get("issue_specificity")),
            issue_categories=_text(data.get("issue_categories")),
            instance_issue_number=issue_number,
            instance_create_at=_text(data.get("instance_create_at")) or None,
            base_commit_created_at=(
                _text(data.get("base_commit_created_at"))
                or _text(data.get("instance_base_commit_created_at"))
                or None
            ),
            new_issue_search_boundary_at=(
                _text(data.get("new_issue_search_boundary_at")) or None
            ),
            issue_mode=issue_mode,  # type: ignore[arg-type]
            target_leakage_check=target_leakage_check,
        )

    def retrieval_mapping(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "repo": self.repo,
            "instance_id": self.instance_id,
            "base_commit": self.base_commit,
            "problem_statement": self.problem_statement,
            "requirements": self.requirements,
            "interface": self.interface,
            "repo_language": self.repo_language,
            "issue_mode": self.issue_mode,
            "target_leakage_check": self.target_leakage_check,
        }
        if self.instance_issue_number is not None:
            result["instance_issue_number"] = self.instance_issue_number
        if self.instance_create_at:
            result["instance_create_at"] = self.instance_create_at
        if self.base_commit_created_at:
            result["base_commit_created_at"] = self.base_commit_created_at
        if self.new_issue_search_boundary_at:
            result["new_issue_search_boundary_at"] = (
                self.new_issue_search_boundary_at
            )
        return result

    def public_dict(self) -> dict[str, Any]:
        result = dataclasses.asdict(self)
        if self.new_issue_search_boundary_at is None:
            result.pop("new_issue_search_boundary_at")
        if self.issue_mode == "existing_target":
            result.pop("issue_mode")
        if self.target_leakage_check:
            result.pop("target_leakage_check")
        return result


@dataclass(frozen=True)
class CandidatePoolOptions:
    """Internal live-search options consumed by the GitHub search driver.

    ``pool_size`` is the requested downstream review-pool size. Live retrieval
    still collects the complete deduplicated union from every configured query.
    """

    pool_size: int = 5
    retrieval_strategy: Literal["bounded", "evaluation"] = "bounded"
    search_type: str = "semantic"
    fallback_search_type: str = "hybrid"
    per_page: int = 100
    search_pages: int = 3
    fallback_search_pages: int = 2
    max_search_hits_to_resolve: int = 300
    primary_query_text_max_chars: int = 256
    query_text_max_chars: int = 256
    github_query_max_total_chars: int = 512
    max_single_term_fallbacks: int = 2
    search_sleep_seconds: float = 0.0
    text_match: bool = False
    refresh_search_cache: bool = False
    refresh_closed_issues: bool = False
    closed_issues_ttl_seconds: int = 86_400
    refresh_closed_pulls: bool = False
    closed_pulls_ttl_seconds: int = 86_400
    max_phases: int | None = None
    include_patch_text: bool = True
    enable_issue_number_guard: bool = False
    enable_commit_message_fallback: bool = True
    refresh_repository: bool = False

    def validate(self) -> None:
        if self.pool_size < 1 or self.pool_size > 100:
            raise ValueError("pool_size must be between 1 and 100")
        if self.retrieval_strategy not in {"bounded", "evaluation"}:
            raise ValueError(
                "retrieval_strategy must be bounded or evaluation"
            )
        if self.search_type not in {"semantic", "hybrid", "lexical"}:
            raise ValueError("search_type must be semantic, hybrid, or lexical")
        if self.fallback_search_type not in {"semantic", "hybrid", "lexical"}:
            raise ValueError("fallback_search_type must be semantic, hybrid, or lexical")
        for name, value in (
            ("per_page", self.per_page),
            ("search_pages", self.search_pages),
            ("fallback_search_pages", self.fallback_search_pages),
            ("max_search_hits_to_resolve", self.max_search_hits_to_resolve),
            ("primary_query_text_max_chars", self.primary_query_text_max_chars),
            ("query_text_max_chars", self.query_text_max_chars),
            ("github_query_max_total_chars", self.github_query_max_total_chars),
            ("max_single_term_fallbacks", self.max_single_term_fallbacks),
        ):
            if value < 1:
                raise ValueError(f"{name} must be positive")
        if self.max_phases is not None and self.max_phases < 1:
            raise ValueError("max_phases must be positive when provided")
        if self.closed_issues_ttl_seconds < 0:
            raise ValueError("closed_issues_ttl_seconds cannot be negative")
        if self.closed_pulls_ttl_seconds < 0:
            raise ValueError("closed_pulls_ttl_seconds cannot be negative")
        if self.search_sleep_seconds < 0:
            raise ValueError("search_sleep_seconds cannot be negative")
        if self.primary_query_text_max_chars > GITHUB_SEARCH_TEXT_MAX_CHARS:
            raise ValueError(
                "primary_query_text_max_chars cannot exceed GitHub's "
                "256-character search-text limit"
            )
        if self.query_text_max_chars > self.primary_query_text_max_chars:
            raise ValueError(
                "query_text_max_chars cannot exceed "
                "primary_query_text_max_chars"
            )

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any] | None) -> "CandidatePoolOptions":
        if data is None:
            value = cls()
        else:
            allowed = {field.name for field in dataclasses.fields(cls)}
            unknown = sorted(set(data) - allowed)
            if unknown:
                raise ValueError(
                    f"unknown candidate-pool option(s): {', '.join(unknown)}"
                )
            value = cls(**dict(data))
        value.validate()
        return value

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass
class CandidatePoolResult:
    """Internal live-search result emitted by the GitHub search driver.

    ``returned_pool_size`` may exceed ``requested_pool_size`` because the result
    carries the complete initially eligible candidate union.
    """

    schema_version: int
    status: str
    request_id: str
    instance: dict[str, Any]
    boundary: dict[str, Any]
    requested_pool_size: int
    returned_pool_size: int
    search_exhausted: bool
    phases_processed: int
    total_phases: int
    candidates: list[dict[str, Any]] = field(default_factory=list)
    stats: dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass(frozen=True)
class SimilarityGateOptions:
    """LLM gate options for the current no-reranking retrieval flow."""

    minimum_similarity_score: int = 2
    maximum_misleading_risk: int = 2
    max_current_issue_chars: int = 16_000
    max_historical_issue_chars: int = 16_000
    max_patch_chars: int = 24_000

    def validate(self) -> None:
        if not 0 <= self.minimum_similarity_score <= 5:
            raise ValueError("minimum_similarity_score must be in [0, 5]")
        if not 0 <= self.maximum_misleading_risk <= 5:
            raise ValueError("maximum_misleading_risk must be in [0, 5]")
        for name, value in (
            ("max_current_issue_chars", self.max_current_issue_chars),
            ("max_historical_issue_chars", self.max_historical_issue_chars),
            ("max_patch_chars", self.max_patch_chars),
        ):
            if value < 256:
                raise ValueError(f"{name} must be at least 256")

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any] | None) -> "SimilarityGateOptions":
        if data is None:
            value = cls()
        else:
            allowed = {field.name for field in dataclasses.fields(cls)}
            unknown = sorted(set(data) - allowed)
            if unknown:
                raise ValueError(
                    f"unknown similarity-gate option(s): {', '.join(unknown)}"
                )
            value = cls(**dict(data))
        value.validate()
        return value

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass(frozen=True)
class SearchRetrievalOptions:
    """Public options for the refactored Search & Retrieval stage.

    ``search_candidate_count`` limits the safe candidates sent to the review
    gate; it does not stop live query execution or truncate the safe cache.
    """

    search_candidate_count: int = 5
    final_top_k: int = 3
    retrieval_strategy: Literal["bounded", "evaluation"] = "bounded"
    update_preretrieved: bool = False
    run_gate_for_preretrieved: bool = False
    skip_review_gate: bool = False
    search_type: str = "semantic"
    fallback_search_type: str = "hybrid"
    per_page: int = 100
    search_pages: int = 3
    fallback_search_pages: int = 2
    max_search_hits_to_resolve: int = 300
    primary_query_text_max_chars: int = 256
    query_text_max_chars: int = 256
    github_query_max_total_chars: int = 512
    max_single_term_fallbacks: int = 2
    search_sleep_seconds: float = 0.0
    text_match: bool = False
    refresh_search_cache: bool = False
    refresh_closed_issues: bool = False
    closed_issues_ttl_seconds: int = 86_400
    refresh_closed_pulls: bool = False
    closed_pulls_ttl_seconds: int = 86_400
    max_phases: int | None = None
    include_patch_text: bool = True
    enable_issue_number_guard: bool = False
    enable_commit_message_fallback: bool = True
    refresh_repository: bool = False

    def validate(self) -> None:
        if self.search_candidate_count < 1 or self.search_candidate_count > 100:
            raise ValueError("search_candidate_count must be between 1 and 100")
        if self.final_top_k < 1 or self.final_top_k > 20:
            raise ValueError("final_top_k must be between 1 and 20")
        if self.final_top_k > self.search_candidate_count:
            raise ValueError("final_top_k cannot exceed search_candidate_count")
        self.to_candidate_pool_options().validate()

    @classmethod
    def from_mapping(
        cls, data: Mapping[str, Any] | None
    ) -> "SearchRetrievalOptions":
        if data is None:
            value = cls()
        else:
            allowed = {field.name for field in dataclasses.fields(cls)}
            aliases = {"pool_size": "search_candidate_count"}
            payload = dict(data)
            for old, new in aliases.items():
                if old in payload and new not in payload:
                    payload[new] = payload.pop(old)
            unknown = sorted(set(payload) - allowed)
            if unknown:
                raise ValueError(
                    f"unknown search-retrieval option(s): {', '.join(unknown)}"
                )
            value = cls(**payload)
        value.validate()
        return value

    def to_candidate_pool_options(self) -> CandidatePoolOptions:
        return CandidatePoolOptions(
            pool_size=self.search_candidate_count,
            retrieval_strategy=self.retrieval_strategy,
            search_type=self.search_type,
            fallback_search_type=self.fallback_search_type,
            per_page=self.per_page,
            search_pages=self.search_pages,
            fallback_search_pages=self.fallback_search_pages,
            max_search_hits_to_resolve=self.max_search_hits_to_resolve,
            primary_query_text_max_chars=self.primary_query_text_max_chars,
            query_text_max_chars=self.query_text_max_chars,
            github_query_max_total_chars=self.github_query_max_total_chars,
            max_single_term_fallbacks=self.max_single_term_fallbacks,
            search_sleep_seconds=self.search_sleep_seconds,
            text_match=self.text_match,
            refresh_search_cache=self.refresh_search_cache,
            refresh_closed_issues=self.refresh_closed_issues,
            closed_issues_ttl_seconds=self.closed_issues_ttl_seconds,
            refresh_closed_pulls=self.refresh_closed_pulls,
            closed_pulls_ttl_seconds=self.closed_pulls_ttl_seconds,
            max_phases=self.max_phases,
            include_patch_text=self.include_patch_text,
            enable_issue_number_guard=self.enable_issue_number_guard,
            enable_commit_message_fallback=self.enable_commit_message_fallback,
            refresh_repository=self.refresh_repository,
        )

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


def candidate_patch_hash(patch: str) -> str:
    return hashlib.sha256(str(patch or "").encode("utf-8", errors="replace")).hexdigest()


@dataclass
class SearchRetrievalResult:
    schema_version: int
    status: str
    request_id: str
    instance: dict[str, Any]
    retrieval_source: str
    search_candidate_count: int
    final_top_k: int
    selected_count: int
    rejected_count: int
    selected_candidates: list[dict[str, Any]] = field(default_factory=list)
    rejected_candidates: list[dict[str, Any]] = field(default_factory=list)
    boundary: dict[str, Any] = field(default_factory=dict)
    stats: dict[str, Any] = field(default_factory=dict)
    output_dir: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)
