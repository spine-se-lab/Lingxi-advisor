from __future__ import annotations

import datetime as dt
import logging
from pathlib import Path
from typing import Any

from ..io_utils import read_json, read_jsonl, safe_part, write_json_atomic, write_jsonl_atomic
from ..locking import FileLock
from .. import github as v4

logger = logging.getLogger(__name__)


class ClosedPullBodyIndex:
    """Server-owned exhaustive index of explicit PR-body closing relations.

    This preserves the 02_git_utils fallback semantics without requiring an
    external closed-PR JSONL. The provider paginates the repository's complete
    closed-PR universe, caches it, and indexes only explicit same-repository
    ``fixes/closes/resolves`` references parsed by the shared V4 helper.

    The index may contain unmerged closed PR previews because the list endpoint
    is only used for discovery. ``FixDiscoveryService`` always fetches the full
    PR object and requires ``merged == True`` before constructing a fix record.
    """

    CACHE_SCHEMA_VERSION = 1

    def __init__(self, cache_root: Path) -> None:
        self.cache_root = cache_root
        self._memory: dict[tuple[str, int, bool], dict[int, list[int]]] = {}

    def _repo_dir(self, repo: str) -> Path:
        owner, name = repo.split("/", 1)
        return self.cache_root / "closed_pulls" / f"{safe_part(owner)}__{safe_part(name)}"

    @staticmethod
    def _cache_fresh(meta: dict[str, Any] | None, ttl_seconds: int) -> bool:
        if not meta or ttl_seconds == 0:
            return False
        fetched = v4.parse_datetime_to_utc(meta.get("fetched_at"))
        if fetched is None:
            return False
        age = dt.datetime.now(dt.timezone.utc) - fetched
        return age.total_seconds() <= ttl_seconds

    @staticmethod
    def _fetch_raw(repo: str, client: v4.GithubClient) -> list[dict[str, Any]]:
        owner, name = repo.split("/", 1)
        rows = list(
            client.paginate(
                f"/repos/{owner}/{name}/pulls",
                params={
                    "state": "closed",
                    "sort": "created",
                    "direction": "asc",
                    "per_page": 100,
                },
            )
        )
        return [row for row in rows if isinstance(row, dict)]

    @staticmethod
    def _sort_key(pr: dict[str, Any]) -> tuple[float, int]:
        timestamp = (
            pr.get("merged_at")
            or pr.get("closed_at")
            or pr.get("updated_at")
            or pr.get("created_at")
        )
        parsed = v4.parse_datetime_to_utc(timestamp)
        number = v4.parse_issue_number_int(pr.get("number")) or 0
        return (v4.datetime_to_ts(parsed), number)

    @classmethod
    def _build_rows(cls, repo: str, raw_pulls: list[dict[str, Any]]) -> list[dict[str, Any]]:
        by_issue: dict[int, list[dict[str, Any]]] = {}
        for pr in raw_pulls:
            pr_number = v4.parse_issue_number_int(pr.get("number"))
            if pr_number is None:
                continue
            text = f"{pr.get('title') or ''}\n\n{pr.get('body') or ''}"
            issue_numbers = v4.extract_closing_issue_numbers(text, repo=repo)
            if not issue_numbers:
                continue
            entry = {
                "pr_number": pr_number,
                "created_at": pr.get("created_at"),
                "updated_at": pr.get("updated_at"),
                "closed_at": pr.get("closed_at"),
                "merged_at": pr.get("merged_at"),
            }
            for issue_number in issue_numbers:
                by_issue.setdefault(int(issue_number), []).append(entry)

        rows: list[dict[str, Any]] = []
        for issue_number in sorted(by_issue):
            candidates = sorted(
                by_issue[issue_number],
                key=cls._sort_key,
                reverse=True,
            )
            pr_numbers: list[int] = []
            for item in candidates:
                number = int(item["pr_number"])
                if number not in pr_numbers:
                    pr_numbers.append(number)
            rows.append({"issue_number": issue_number, "pr_numbers": pr_numbers})
        return rows

    def load_matches(
        self,
        *,
        repo: str,
        client: v4.GithubClient,
        ttl_seconds: int,
        refresh: bool,
    ) -> dict[int, list[int]]:
        memory_key = (repo, ttl_seconds, refresh)
        if memory_key in self._memory:
            return self._memory[memory_key]

        repo_dir = self._repo_dir(repo)
        raw_path = repo_dir / "raw_closed_pulls.jsonl"
        index_path = repo_dir / "pr_body_closing_index.jsonl"
        meta_path = repo_dir / "sync_state.json"
        lock_path = repo_dir / ".sync.lock"
        repo_dir.mkdir(parents=True, exist_ok=True)

        with FileLock(lock_path):
            meta = read_json(meta_path)
            use_cache = (
                raw_path.exists()
                and index_path.exists()
                and not refresh
                and self._cache_fresh(meta, ttl_seconds)
                and (meta or {}).get("schema_version") == self.CACHE_SCHEMA_VERSION
            )
            if use_cache:
                index_rows = read_jsonl(index_path)
            else:
                logger.info("Fetching exhaustive closed-PR universe for %s", repo)
                try:
                    raw_pulls = self._fetch_raw(repo, client)
                except Exception:
                    if not raw_path.exists():
                        raise
                    logger.warning(
                        "Closed-PR refresh failed for %s; using stale server cache.",
                        repo,
                        exc_info=True,
                    )
                    raw_pulls = read_jsonl(raw_path)
                else:
                    write_jsonl_atomic(raw_path, raw_pulls)

                index_rows = self._build_rows(repo, raw_pulls)
                fetched_at = v4.isoformat_utc(dt.datetime.now(dt.timezone.utc))
                write_jsonl_atomic(index_path, index_rows)
                write_json_atomic(
                    meta_path,
                    {
                        "schema_version": self.CACHE_SCHEMA_VERSION,
                        "repo": repo,
                        "fetched_at": fetched_at,
                        "raw_closed_pull_count": len(raw_pulls),
                        "indexed_issue_count": len(index_rows),
                        "source": "github_rest_repos_pulls_state_closed_exhaustive",
                    },
                )

        result: dict[int, list[int]] = {}
        for row in index_rows:
            issue_number = v4.parse_issue_number_int(row.get("issue_number"))
            if issue_number is None:
                continue
            numbers: list[int] = []
            for value in row.get("pr_numbers") or []:
                number = v4.parse_issue_number_int(value)
                if number is not None and number not in numbers:
                    numbers.append(number)
            if numbers:
                result[issue_number] = numbers

        self._memory[memory_key] = result
        return result
