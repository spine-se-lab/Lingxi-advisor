from __future__ import annotations

import html
import logging
from pathlib import Path

from ..knowledge_template import assemble_knowledge_xml
from ..knowledge_validation import validate_generated_knowledge_xml
from .analyst import ANALYST_TAGS, GroundedAnalyst, parse_xml_fragment
from .contracts import (
    GroundedAnalysisConfig,
    GroundedAnalysisInput,
    GroundedAnalysisResult,
)
from .llm import (
    GroundedCompletionRunner,
    GroundedLLMClient,
    OpenAICompatibleGroundedClient,
)
from .summarizer import SUMMARY_TAGS, GroundedSummarizer
from .worktree_manager import WorktreeHandle

logger = logging.getLogger(__name__)


def validate_no_host_path_leak(
    xml_text: str,
    *,
    worktree: WorktreeHandle,
) -> None:
    value = str(xml_text or "")
    forbidden: set[str] = set()
    for raw in (worktree.worktree_path, worktree.repository_path):
        if not raw:
            continue
        resolved_path = Path(raw).expanduser().resolve()
        candidates = {
            str(raw),
            str(resolved_path),
            str(resolved_path.parent),
        }
        for candidate in candidates:
            if candidate in {"/", "."} or len(candidate) < 6:
                continue
            forbidden.update(
                {
                    candidate,
                    html.escape(candidate),
                    f"file://{candidate}",
                }
            )
    leaked = sorted(item for item in forbidden if item and item in value)
    if leaked:
        raise ValueError(
            "grounded knowledge XML leaked an absolute server path"
        )


class GroundedKnowledgeGenerator:
    """Analyst → Summarizer grounded historical knowledge pipeline."""

    def __init__(
        self,
        config: GroundedAnalysisConfig,
        *,
        client: GroundedLLMClient | None = None,
    ) -> None:
        config.validate()
        resolved_client = client or OpenAICompatibleGroundedClient(config)
        runner = GroundedCompletionRunner(
            config,
            client=resolved_client,
        )
        self.config = config
        self.analyst = GroundedAnalyst(config, runner=runner)
        self.summarizer = GroundedSummarizer(config, runner=runner)

    def generate(
        self,
        value: GroundedAnalysisInput,
        *,
        worktree: WorktreeHandle,
    ) -> GroundedAnalysisResult:
        worktree_path = Path(worktree.worktree_path)
        logger.info(
            "Grounded analysis started: instance=%s repo=%s "
            "historical_issue=#%d commit=%s worktree_reused=%s",
            value.instance_id,
            value.repo,
            value.historical_issue_number,
            value.historical_fix_commit,
            worktree.reused,
        )
        fine_xml, analyst_calls, analyst_context = self.analyst.analyze(
            value,
            worktree_path=worktree_path,
        )
        fine_xml, fine_children = parse_xml_fragment(
            fine_xml,
            expected_tags=ANALYST_TAGS,
        )
        validate_no_host_path_leak(fine_xml, worktree=worktree)
        summary_xml, summary_calls, summary_context = (
            self.summarizer.summarize(
            value,
            fine_grained_xml=fine_xml,
        )
        )
        summary_xml, summary_children = parse_xml_fragment(
            summary_xml,
            expected_tags=SUMMARY_TAGS,
        )
        validate_no_host_path_leak(summary_xml, worktree=worktree)

        artifact = assemble_knowledge_xml(
            fine_grained_children=fine_children,
            general_summary_children=summary_children,
        )
        validate_generated_knowledge_xml(artifact)
        validate_no_host_path_leak(artifact, worktree=worktree)
        calls = analyst_calls + summary_calls
        context_budget = {
            "analyst": analyst_context.to_dict(),
            "summarizer": summary_context.to_dict(),
            "compaction_count": (
                analyst_context.compaction_count
                + summary_context.compaction_count
            ),
            "compacted_group_count": (
                analyst_context.compacted_group_count
                + summary_context.compacted_group_count
            ),
            "peak_request_chars": max(
                analyst_context.peak_request_chars,
                summary_context.peak_request_chars,
            ),
        }
        logger.info(
            "Grounded analysis completed: instance=%s candidate=%s "
            "model_calls=%d llm_latency=%.2fs artifact_chars=%d",
            value.instance_id,
            value.historical_candidate_fingerprint,
            len(calls),
            sum(item.latency_seconds for item in calls),
            len(artifact),
        )
        return GroundedAnalysisResult(
            artifact_xml=artifact + "\n",
            fine_grained_xml=fine_xml,
            summary_xml=summary_xml,
            calls=calls,
            worktree_path=worktree.worktree_path,
            worktree_reused=worktree.reused,
            context_budget=context_budget,
        )
