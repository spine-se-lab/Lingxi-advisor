from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import Any

logger = logging.getLogger(__name__)
BatchRunner = Callable[[], Awaitable[dict[str, Any]]]

class BatchPreparationWorker:
    def __init__(self) -> None:
        self._tasks: dict[str, asyncio.Task[dict[str, Any]]] = {}

    def start(
        self,
        *,
        batch_id: str,
        run_batch: BatchRunner,
    ) -> None:
        active = self._tasks.get(batch_id)
        if active is not None and not active.done():
            return
        task = asyncio.create_task(
            run_batch(),
            name=f'knowledge-preparation-batch-{batch_id}',
        )
        self._tasks[batch_id] = task
        task.add_done_callback(
            lambda done, current=batch_id: self._finish(current, done)
        )

    def _finish(
        self,
        batch_id: str,
        task: asyncio.Task[dict[str, Any]],
    ) -> None:
        if self._tasks.get(batch_id) is task:
            self._tasks.pop(batch_id, None)
        try:
            task.result()
        except asyncio.CancelledError:
            logger.info('Batch cancelled: batch_id=%s', batch_id)
        except Exception:
            logger.exception('Batch failed: batch_id=%s', batch_id)

__all__ = ['BatchPreparationWorker']
