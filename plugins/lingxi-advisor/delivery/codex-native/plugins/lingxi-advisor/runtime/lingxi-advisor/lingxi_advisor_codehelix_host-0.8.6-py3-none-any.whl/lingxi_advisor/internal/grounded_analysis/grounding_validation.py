from __future__ import annotations

import ast
import dataclasses
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .contracts import GroundedAnalysisConfig, GroundedAnalysisInput
from .git_inspection import ReadOnlyGitInspector
from .worktree_manager import WorktreeHandle


@dataclass(frozen=True)
class GroundingConsistencyReport:
    policy: str
    status: str
    repository_identity_verified: bool
    repository_origin: str | None
    preflight_status: str
    patch_changed_paths: tuple[str, ...]
    commit_changed_paths: tuple[str, ...]
    changed_files_summary_paths: tuple[str, ...]
    historical_patch_ids: tuple[str, ...]
    commit_patch_ids: tuple[str, ...]
    checks: Mapping[str, str]
    warnings: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()

    @property
    def passed(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        data = dataclasses.asdict(self)
        data["passed"] = self.passed
        return data


class GroundingConsistencyError(RuntimeError):
    def __init__(self, report: GroundingConsistencyReport):
        self.report = report
        detail = "; ".join(report.errors) or "unknown consistency failure"
        super().__init__(f"grounding consistency validation failed: {detail}")


def _strip_git_prefix(path: str) -> str:
    value = str(path or "").strip()
    if value in {"", "/dev/null"}:
        return ""
    if value.startswith("a/") or value.startswith("b/"):
        value = value[2:]
    return value


_GIT_PATH_TOKEN_RE = re.compile(r'"(?:\\.|[^"])*"|\S+')
_SHA40_RE = re.compile(r"^[0-9a-f]{40}$")


def _decode_git_path_token(token: str) -> str:
    value = str(token or "").strip()
    if len(value) >= 2 and value.startswith('"') and value.endswith('"'):
        try:
            decoded = ast.literal_eval(value)
        except (SyntaxError, ValueError):
            return value.strip('"')
        if isinstance(decoded, str):
            try:
                return decoded.encode("latin-1").decode("utf-8")
            except (UnicodeEncodeError, UnicodeDecodeError):
                return decoded
    return value


def patch_changed_paths(patch_text: str) -> tuple[str, ...]:
    paths: set[str] = set()
    for line in str(patch_text or "").splitlines():
        if line.startswith("diff --git "):
            pieces = _GIT_PATH_TOKEN_RE.findall(line[len("diff --git ") :])
            for piece in pieces[:2]:
                normalized = _strip_git_prefix(_decode_git_path_token(piece))
                if normalized:
                    paths.add(normalized)
        elif line.startswith("--- ") or line.startswith("+++ "):
            token = line[4:].split("\t", 1)[0].strip()
            parsed = _GIT_PATH_TOKEN_RE.findall(token)
            token = _decode_git_path_token(parsed[0] if parsed else token)
            normalized = _strip_git_prefix(token)
            if normalized:
                paths.add(normalized)
    return tuple(sorted(paths))


def changed_files_summary_paths(
    changed_files: tuple[Mapping[str, Any], ...],
) -> tuple[str, ...]:
    paths: set[str] = set()
    for item in changed_files:
        for key in ("filename", "previous_filename"):
            value = str(item.get(key) or "").strip()
            if value:
                paths.add(value)
    return tuple(sorted(paths))


def _candidate_commit_ids(
    value: GroundedAnalysisInput,
    *,
    errors: list[str],
) -> tuple[tuple[str, ...], str, tuple[str, ...]]:
    raw = value.provenance.get("retrieved_commit_ids")
    if raw is None:
        return (
            (value.historical_fix_commit,),
            "historical_fix_commit",
            (),
        )
    if not isinstance(raw, (list, tuple)):
        errors.append("retrieved_commit_ids provenance is not a sequence")
        return (
            (value.historical_fix_commit,),
            "historical_fix_commit",
            (),
        )
    commits = tuple(str(item or "").strip().lower() for item in raw)
    if (
        not commits
        or len(commits) > 100
        or any(not _SHA40_RE.fullmatch(item) for item in commits)
    ):
        errors.append("retrieved_commit_ids contains an invalid commit")
        return (
            (value.historical_fix_commit,),
            "historical_fix_commit",
            (),
        )
    if len(set(commits)) != len(commits):
        errors.append("retrieved_commit_ids contains duplicate commits")
        return (
            (value.historical_fix_commit,),
            "historical_fix_commit",
            (),
        )
    if commits[-1] == value.historical_fix_commit:
        return commits, "retrieved_commit_ids", commits
    grounding_source = str(
        value.provenance.get("retrieved_grounding_commit_source") or ""
    ).strip()
    if grounding_source == "verified_merge_commit":
        # GitHub uses merge_commit_sha for merge, squash, and rebase outcomes.
        # A squash/rebase fix is not the final PR branch commit, so validate
        # the authoritative post-fix commit diff from the verified worktree.
        return (
            (value.historical_fix_commit,),
            "historical_fix_commit",
            commits,
        )
    errors.append("retrieved_commit_ids does not end at historical_fix_commit")
    return (
        (value.historical_fix_commit,),
        "historical_fix_commit",
        commits,
    )


def _verified_squash_patch_ids(
    value: GroundedAnalysisInput,
    *,
    inspector: ReadOnlyGitInspector,
    retrieved_commits: tuple[str, ...],
    historical_patch_ids: tuple[str, ...],
    fix_patch_ids: tuple[str, ...],
) -> tuple[tuple[str, ...], str | None]:
    """Validate a PR commit series against its verified squash/merge commit."""

    source = str(
        value.provenance.get("retrieved_grounding_commit_source") or ""
    ).strip()
    if source != "verified_merge_commit" or not retrieved_commits:
        return (), "verified merge commit provenance is unavailable"

    retrieved_patch_ids = inspector.stable_patch_ids(
        "\n\n".join(inspector.commit_diff(commit) for commit in retrieved_commits)
    )
    if retrieved_patch_ids != historical_patch_ids:
        return retrieved_patch_ids, (
            "historical patch does not match the retrieved PR commit series"
        )

    for previous, current in zip(
        retrieved_commits,
        retrieved_commits[1:],
    ):
        parents = inspector.commit_parents(current)
        if not parents or parents[0] != previous:
            return retrieved_patch_ids, (
                "retrieved PR commits are not a linear first-parent series"
            )

    first_parents = inspector.commit_parents(retrieved_commits[0])
    if not first_parents:
        return retrieved_patch_ids, (
            "retrieved PR commit series has no pre-fix base commit"
        )
    net_patch_ids = inspector.stable_patch_ids(
        inspector.revision_diff(
            first_parents[0],
            retrieved_commits[-1],
        )
    )
    if not net_patch_ids or net_patch_ids != fix_patch_ids:
        return retrieved_patch_ids, (
            "retrieved PR net diff does not match the verified fix commit"
        )
    return retrieved_patch_ids, None


class GroundingConsistencyValidator:
    """Validate selected evidence against the verified post-fix checkout."""

    def __init__(self, config: GroundedAnalysisConfig) -> None:
        self.config = config

    def required_evidence_commits(
        self,
        value: GroundedAnalysisInput,
        *,
        worktree: WorktreeHandle,
    ) -> tuple[str, ...]:
        """Return PR commits needed only for verified squash validation."""

        candidate_errors: list[str] = []
        commit_ids, commit_scope, retrieved_commits = _candidate_commit_ids(
            value,
            errors=candidate_errors,
        )
        if (
            candidate_errors
            or commit_scope != "historical_fix_commit"
            or not retrieved_commits
            or retrieved_commits == commit_ids
        ):
            return ()
        inspector = ReadOnlyGitInspector(
            Path(worktree.worktree_path),
            max_output_chars=self.config.max_tool_output_chars,
            timeout_seconds=min(60.0, self.config.timeout_seconds),
            max_file_bytes=self.config.max_file_bytes,
            max_search_results=self.config.max_search_results,
            max_glob_results=self.config.max_glob_results,
        )
        try:
            historical_ids = inspector.stable_patch_ids(value.historical_patch)
            fix_ids = inspector.stable_patch_ids(
                inspector.commit_diff(value.historical_fix_commit)
            )
        except RuntimeError:
            return ()
        if historical_ids and fix_ids and historical_ids != fix_ids:
            return retrieved_commits
        return ()

    @staticmethod
    def _sample_difference(left: set[str], right: set[str], *, label: str) -> str:
        only_left = sorted(left - right)[:8]
        only_right = sorted(right - left)[:8]
        return f"{label} mismatch (only_first={only_left}, only_second={only_right})"

    def _preflight_checks(
        self,
        value: GroundedAnalysisInput,
        *,
        errors: list[str],
    ) -> tuple[str, dict[str, str]]:
        preflight = value.grounding_preflight
        if not preflight:
            return "not_provided", {"grounding_preflight": "not_provided_optional"}
        status = str(preflight.get("status") or "unknown").strip()
        checks: dict[str, str] = {
            "grounding_preflight": "validated",
        }
        repo = str(preflight.get("repo") or "").strip()
        if repo.lower() != value.repo.lower():
            errors.append("grounding_preflight repo does not match the candidate repo")
        checkout_commit = str(preflight.get("checkout_commit") or "").strip().lower()
        if checkout_commit != value.historical_fix_commit:
            errors.append(
                "grounding_preflight checkout_commit does not match "
                "historical_fix_commit"
            )
        checkout_state = str(preflight.get("checkout_state") or "").strip()
        if checkout_state != "historical_fix_post_state":
            errors.append(
                "grounding_preflight checkout_state is not the post-fix state"
            )
        if preflight.get("restorable") is False or status == "unavailable":
            errors.append("grounding_preflight marks this candidate as unrestorable")
        return status, checks

    def validate(
        self,
        value: GroundedAnalysisInput,
        *,
        worktree: WorktreeHandle,
    ) -> GroundingConsistencyReport:
        errors: list[str] = []
        warnings: list[str] = []
        checks: dict[str, str] = {
            "historical_patch_sha256": "validated_during_input_normalization",
            "checkout_commit": "validated_by_worktree_manager",
            "worktree_clean": "validated_by_worktree_manager",
            "repository_identity": (
                "verified"
                if worktree.repository_identity_verified
                else "verification_disabled"
            ),
        }
        if (
            self.config.verify_repository_identity
            and not worktree.repository_identity_verified
        ):
            errors.append("repository identity was not verified")

        preflight_status, preflight_checks = self._preflight_checks(
            value,
            errors=errors,
        )
        checks.update(preflight_checks)

        patch_paths = patch_changed_paths(value.historical_patch)
        summary_paths = changed_files_summary_paths(value.changed_files)
        inspector = ReadOnlyGitInspector(
            Path(worktree.worktree_path),
            max_output_chars=self.config.max_tool_output_chars,
            timeout_seconds=min(60.0, self.config.timeout_seconds),
            max_file_bytes=self.config.max_file_bytes,
            max_search_results=self.config.max_search_results,
            max_glob_results=self.config.max_glob_results,
        )
        commit_ids, commit_scope, retrieved_commits = _candidate_commit_ids(
            value,
            errors=errors,
        )
        try:
            ancestry_matches = all(
                inspector.is_ancestor(
                    commit,
                    value.historical_fix_commit,
                )
                for commit in commit_ids
            )
        except RuntimeError as exc:
            errors.append(
                "retrieved commit ancestry could not be validated: "
                f"{type(exc).__name__}"
            )
            checks["retrieved_commit_ancestry"] = "unavailable"
        else:
            if ancestry_matches:
                checks["retrieved_commit_ancestry"] = (
                    "all_retrieved_commits_reachable_from_checkout"
                )
            else:
                errors.append(
                    "retrieved_commit_ids contains a commit that is not an "
                    "ancestor of historical_fix_commit"
                )
                checks["retrieved_commit_ancestry"] = "mismatch"
        commit_paths = tuple(
            sorted(
                {
                    path
                    for commit in commit_ids
                    for path in inspector.commit_changed_paths(commit)
                }
            )
        )
        checks["patch_commit_scope"] = commit_scope
        if not patch_paths:
            errors.append("historical patch does not expose any changed file paths")
        elif set(patch_paths) != set(commit_paths):
            errors.append(
                self._sample_difference(
                    set(patch_paths),
                    set(commit_paths),
                    label="historical patch vs checkout commit changed paths",
                )
            )
        else:
            checks["patch_commit_paths"] = "exact_match"

        if summary_paths:
            unsupported = set(summary_paths) - set(patch_paths)
            if unsupported:
                errors.append(
                    "changed_files summary contains paths absent from the "
                    f"historical patch: {sorted(unsupported)[:8]}"
                )
            else:
                checks["changed_files_summary"] = "all_reported_paths_present_in_patch"
        else:
            checks["changed_files_summary"] = "not_provided_optional"

        historical_patch_ids: tuple[str, ...] = ()
        commit_patch_ids: tuple[str, ...] = ()
        try:
            historical_patch_ids = inspector.stable_patch_ids(value.historical_patch)
            commit_patch_ids = inspector.stable_patch_ids(
                "\n\n".join(inspector.commit_diff(commit) for commit in commit_ids)
            )
        except RuntimeError as exc:
            warnings.append(
                f"stable patch-id comparison was unavailable: {type(exc).__name__}"
            )
            checks["stable_patch_id"] = "unavailable"
        else:
            if historical_patch_ids and commit_patch_ids:
                if historical_patch_ids == commit_patch_ids:
                    checks["stable_patch_id"] = (
                        "exact_match"
                        if len(historical_patch_ids) == 1
                        else "exact_match_multiple"
                    )
                elif (
                    commit_scope == "historical_fix_commit"
                    and retrieved_commits
                    and retrieved_commits != commit_ids
                ):
                    retrieved_patch_ids, squash_error = _verified_squash_patch_ids(
                        value,
                        inspector=inspector,
                        retrieved_commits=retrieved_commits,
                        historical_patch_ids=historical_patch_ids,
                        fix_patch_ids=commit_patch_ids,
                    )
                    if squash_error:
                        errors.append(squash_error)
                        checks["stable_patch_id"] = "mismatch"
                    else:
                        commit_patch_ids = retrieved_patch_ids
                        checks["stable_patch_id"] = "exact_net_match_squashed"
                else:
                    errors.append(
                        "historical patch content does not match the checkout "
                        "commit set under git patch-id --stable"
                    )
                    checks["stable_patch_id"] = "mismatch"
            elif not historical_patch_ids or not commit_patch_ids:
                warnings.append(
                    "stable patch-id comparison produced no comparable ID; "
                    "changed-path equality remains enforced"
                )
                checks["stable_patch_id"] = "not_comparable_empty"

        status = "passed"
        if errors and self.config.grounding_consistency_policy == "warn":
            status = "warning"
            warnings.extend(errors)
        elif errors:
            status = "failed"
        elif warnings:
            status = "passed_with_warnings"
        report = GroundingConsistencyReport(
            policy=self.config.grounding_consistency_policy,
            status=status,
            repository_identity_verified=(worktree.repository_identity_verified),
            repository_origin=worktree.repository_origin,
            preflight_status=preflight_status,
            patch_changed_paths=patch_paths,
            commit_changed_paths=commit_paths,
            changed_files_summary_paths=summary_paths,
            historical_patch_ids=historical_patch_ids,
            commit_patch_ids=commit_patch_ids,
            checks=checks,
            warnings=tuple(warnings),
            errors=tuple(errors),
        )
        if errors and self.config.grounding_consistency_policy == "strict":
            raise GroundingConsistencyError(report)
        return report
