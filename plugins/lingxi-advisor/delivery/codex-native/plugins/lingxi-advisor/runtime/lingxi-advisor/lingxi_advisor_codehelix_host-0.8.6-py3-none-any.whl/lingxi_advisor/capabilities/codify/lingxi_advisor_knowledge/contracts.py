from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, TypeAlias

from ....artifacts.interface import KnowledgeArtifactRef
from ....internal.generation_contracts import GenerationMode
from ....internal.preparation_contracts import (
    PreparationRequest,
    PreparationResult,
)

HistoricalCandidate: TypeAlias = Mapping[str, Any]


@dataclass(frozen=True)
class CodifyEnsureSettings:
    """Server-owned configuration bound to the path-free ensure interface."""

    knowledge_cache_dir: Path
    output_root: Path
    generator_model: str
    template_versions: Mapping[GenerationMode, str]
    allow_clone: bool = False
    allow_fetch: bool = False
    repository_root: Path | None = None
    historical_worktree_root: Path | None = None
    runtime_options: Mapping[GenerationMode, Mapping[str, Any]] = field(
        default_factory=dict
    )

    def template_version(self, generation_mode: GenerationMode) -> str:
        value = str(self.template_versions.get(generation_mode) or "").strip()
        if not value:
            raise ValueError(
                f"template version is not configured for {generation_mode}"
            )
        return value


__all__ = [
    "CodifyEnsureSettings",
    "HistoricalCandidate",
    "KnowledgeArtifactRef",
    "PreparationRequest",
    "PreparationResult",
]

