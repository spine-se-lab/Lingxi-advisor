"""Private implementation modules shared by LingxiAdvisor capabilities."""
