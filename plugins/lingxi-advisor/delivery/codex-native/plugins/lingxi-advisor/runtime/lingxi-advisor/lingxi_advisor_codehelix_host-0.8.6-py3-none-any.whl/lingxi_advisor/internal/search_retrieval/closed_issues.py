from __future__ import annotations

import datetime as dt
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..io_utils import read_json, read_jsonl, safe_part, write_json_atomic, write_jsonl_atomic
from ..locking import FileLock
from .. import github as v4

logger = logging.getLogger(__name__)


@dataclass
class ClosedIssueCatalog:
    repo: str
    fetched_from_cache: bool
    stale_cache_used: bool
    fetched_at: str
    raw_item_count: int
    closed_issue_count: int
    eligible_issue_count: int
    issues_by_number: dict[int, dict[str, Any]] = field(default_factory=dict)
    rejection_counts: dict[str, int] = field(default_factory=dict)

    def to_summary(self) -> dict[str, Any]:
        return {
            "repo": self.repo,
            "fetched_from_cache": self.fetched_from_cache,
            "stale_cache_used": self.stale_cache_used,
            "fetched_at": self.fetched_at,
            "raw_item_count": self.raw_item_count,
            "closed_issue_count": self.closed_issue_count,
            "eligible_issue_count": self.eligible_issue_count,
            "rejection_counts": self.rejection_counts,
        }


class ClosedIssueProvider:
    """Server-owned closed-issue universe, following 02_git_utils semantics.

    GitHub's `/issues` endpoint returns both issues and PR pseudo-issues. The raw
    universe is cached per repository and PR pseudo-issues are removed before
    building the eligible issue map.
    """

    CACHE_SCHEMA_VERSION = 1

    def __init__(self, cache_root: Path):
        self.cache_root = cache_root

    def _repo_dir(self, repo: str) -> Path:
        owner, name = repo.split("/", 1)
        return self.cache_root / "closed_issues" / f"{safe_part(owner)}__{safe_part(name)}"

    @staticmethod
    def _cache_fresh(meta: dict[str, Any] | None, ttl_seconds: int) -> bool:
        if not meta or ttl_seconds == 0:
            return False
        fetched = v4.parse_datetime_to_utc(meta.get("fetched_at"))
        if fetched is None:
            return False
        age = dt.datetime.now(dt.timezone.utc) - fetched
        return age.total_seconds() <= ttl_seconds

    def _fetch_raw(self, repo: str, client: v4.GithubClient) -> list[dict[str, Any]]:
        owner, name = repo.split("/", 1)
        rows = list(
            client.paginate(
                f"/repos/{owner}/{name}/issues",
                params={
                    "state": "closed",
                    "sort": "created",
                    "direction": "asc",
                    "per_page": 100,
                },
            )
        )
        return [row for row in rows if isinstance(row, dict)]

    def load(
        self,
        *,
        repo: str,
        client: v4.GithubClient,
        boundary_ts: float,
        target_issue_number: int | None,
        ttl_seconds: int,
        refresh: bool,
        enable_issue_number_guard: bool,
    ) -> ClosedIssueCatalog:
        repo_dir = self._repo_dir(repo)
        raw_path = repo_dir / "raw_closed_items.jsonl"
        meta_path = repo_dir / "sync_state.json"
        lock_path = repo_dir / ".sync.lock"
        repo_dir.mkdir(parents=True, exist_ok=True)

        with FileLock(lock_path):
            meta = read_json(meta_path)
            use_cache = (
                raw_path.exists()
                and not refresh
                and self._cache_fresh(meta, ttl_seconds)
            )
            stale_cache_used = False
            if use_cache:
                raw_items = read_jsonl(raw_path)
                fetched_at = str((meta or {}).get("fetched_at") or "")
            else:
                logger.info("Fetching closed issue universe for %s", repo)
                try:
                    raw_items = self._fetch_raw(repo, client)
                except Exception:
                    if not raw_path.exists():
                        raise
                    logger.warning(
                        "Closed-issue refresh failed for %s; using stale server cache.",
                        repo,
                        exc_info=True,
                    )
                    raw_items = read_jsonl(raw_path)
                    fetched_at = str((meta or {}).get("fetched_at") or "")
                    use_cache = True
                    stale_cache_used = True
                else:
                    fetched_at = v4.isoformat_utc(dt.datetime.now(dt.timezone.utc))
                    write_jsonl_atomic(raw_path, raw_items)
                    write_json_atomic(
                        meta_path,
                        {
                            "schema_version": self.CACHE_SCHEMA_VERSION,
                            "repo": repo,
                            "fetched_at": fetched_at,
                            "raw_item_count": len(raw_items),
                            "source": "github_rest_repos_issues_state_closed",
                        },
                    )

        rejection: dict[str, int] = {}

        def reject(reason: str) -> None:
            rejection[reason] = rejection.get(reason, 0) + 1

        closed_issues: list[dict[str, Any]] = []
        eligible: dict[int, dict[str, Any]] = {}
        for item in raw_items:
            if "pull_request" in item:
                reject("pull_request_pseudo_issue")
                continue
            number = v4.parse_issue_number_int(item.get("number"))
            if number is None:
                reject("missing_issue_number")
                continue
            if str(item.get("state") or "").lower() != "closed":
                reject("not_closed")
                continue
            closed_issues.append(item)

            created = v4.parse_datetime_to_utc(item.get("created_at"))
            created_ts = v4.datetime_to_ts(created)
            if created_ts <= 0.0:
                reject("missing_issue_created_at")
                continue
            if created_ts >= boundary_ts:
                reject("issue_created_at_not_before_boundary")
                continue
            if target_issue_number is not None and number == target_issue_number:
                reject("current_issue")
                continue
            if (
                enable_issue_number_guard
                and target_issue_number is not None
                and number >= target_issue_number
            ):
                reject("issue_number_not_older")
                continue
            eligible[number] = item

        return ClosedIssueCatalog(
            repo=repo,
            fetched_from_cache=use_cache,
            stale_cache_used=stale_cache_used,
            fetched_at=fetched_at,
            raw_item_count=len(raw_items),
            closed_issue_count=len(closed_issues),
            eligible_issue_count=len(eligible),
            issues_by_number=eligible,
            rejection_counts=rejection,
        )
