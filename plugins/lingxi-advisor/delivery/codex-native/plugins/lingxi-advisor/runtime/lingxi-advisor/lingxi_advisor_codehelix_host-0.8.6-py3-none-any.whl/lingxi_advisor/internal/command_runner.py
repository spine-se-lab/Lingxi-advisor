from __future__ import annotations

from .execution import bounded_timeout, checkpoint

import os
import signal
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Iterable


class CommandPolicyError(ValueError):
    """Raised when a subprocess request violates the fixed command policy."""


@dataclass(frozen=True)
class CommandResult:
    args: tuple[str, ...]
    returncode: int
    stdout: bytes
    stderr: bytes

    def stdout_text(self) -> str:
        return self.stdout.decode("utf-8", errors="replace")

    def stderr_text(self) -> str:
        return self.stderr.decode("utf-8", errors="replace")


_UNSAFE_GIT_ENV_NAMES = {
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_ASKPASS",
    "GIT_ATTR_NOSYSTEM",
    "GIT_CEILING_DIRECTORIES",
    "GIT_COMMON_DIR",
    "GIT_CONFIG",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_GLOBAL",
    "GIT_CONFIG_NOSYSTEM",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_SYSTEM",
    "GIT_DIFF_OPTS",
    "GIT_DIR",
    "GIT_EXEC_PATH",
    "GIT_EXTERNAL_DIFF",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_PAGER",
    "GIT_PREFIX",
    "GIT_PROXY_COMMAND",
    "GIT_SHALLOW_FILE",
    "GIT_SSH",
    "GIT_SSH_COMMAND",
    "GIT_SSL_NO_VERIFY",
    "GIT_TEMPLATE_DIR",
    "GIT_WORK_TREE",
    "SSH_ASKPASS",
}

_SAFE_GIT_TRANSPORT_KEYS = frozenset(
    {
        "http.sslbackend",
        "http.sslcainfo",
        "http.sslcapath",
        "http.schannelusesslcainfo",
    }
)


def _windows_system_executable(name: str) -> Path | None:
    """Resolve a Windows system executable without trusting PATH or env vars."""

    if os.name != "nt":
        return None
    try:
        import ctypes

        buffer = ctypes.create_unicode_buffer(32_768)
        length = ctypes.windll.kernel32.GetSystemDirectoryW(  # type: ignore[attr-defined]
            buffer,
            len(buffer),
        )
    except (AttributeError, OSError):
        return None
    if length <= 0 or length >= len(buffer):
        return None
    candidate = Path(buffer.value) / name
    return candidate if candidate.is_file() else None


def _windows_job_for_process(
    process: subprocess.Popen[bytes],
) -> int | None:
    """Assign a new process to a Job before it can create lasting children."""

    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateJobObjectW.argtypes = [
            wintypes.LPVOID,
            wintypes.LPCWSTR,
        ]
        kernel32.CreateJobObjectW.restype = wintypes.HANDLE
        kernel32.AssignProcessToJobObject.argtypes = [
            wintypes.HANDLE,
            wintypes.HANDLE,
        ]
        kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL
        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            return None
        process_handle = wintypes.HANDLE(int(process._handle))  # type: ignore[attr-defined]
        if not kernel32.AssignProcessToJobObject(job, process_handle):
            kernel32.CloseHandle(job)
            return None
        return int(job)
    except (AttributeError, OSError, TypeError, ValueError):
        return None


def _terminate_windows_job(job_handle: int | None) -> bool:
    if os.name != "nt" or job_handle is None:
        return False
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.TerminateJobObject.argtypes = [
            wintypes.HANDLE,
            wintypes.UINT,
        ]
        kernel32.TerminateJobObject.restype = wintypes.BOOL
        return bool(
            kernel32.TerminateJobObject(
                wintypes.HANDLE(job_handle),
                1,
            )
        )
    except (AttributeError, OSError, TypeError, ValueError):
        return False


def _close_windows_job(job_handle: int | None) -> None:
    if os.name != "nt" or job_handle is None:
        return
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL
        kernel32.CloseHandle(wintypes.HANDLE(job_handle))
    except (AttributeError, OSError, TypeError, ValueError):
        pass


def _terminate_process_tree(
    process: subprocess.Popen[bytes],
    *,
    windows_job: int | None = None,
) -> None:
    """Best-effort bounded termination for a timed-out process and children."""

    if _terminate_windows_job(windows_job):
        try:
            process.wait(timeout=2)
        except (OSError, subprocess.SubprocessError):
            pass
        return
    if os.name == "nt":
        if process.poll() is not None:
            return
        taskkill = _windows_system_executable("taskkill.exe")
        if taskkill is not None:
            try:
                killer = subprocess.Popen(
                    [
                        str(taskkill),
                        "/PID",
                        str(process.pid),
                        "/T",
                        "/F",
                    ],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    shell=False,
                )
                try:
                    killer.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    killer.kill()
                    killer.wait(timeout=1)
            except (OSError, subprocess.SubprocessError):
                pass
    else:
        # The process-group leader may already have exited while descendants
        # keep inherited pipes open.  Kill the group even in that state.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass
    if process.poll() is None:
        try:
            process.kill()
        except OSError:
            pass
    try:
        process.wait(timeout=2)
    except (OSError, subprocess.SubprocessError):
        pass


def _close_pipe(stream: IO[bytes] | None) -> None:
    if stream is None:
        return
    try:
        stream.close()
    except OSError:
        pass


def _bounded_run(
    args: list[str] | tuple[str, ...],
    *,
    cwd: Path | None = None,
    stdout: int = subprocess.PIPE,
    stderr: int = subprocess.PIPE,
    timeout: float,
    env: dict[str, str] | None = None,
    input_bytes: bytes | None = None,
) -> subprocess.CompletedProcess[bytes]:
    """Run without a shell and never wait unboundedly after timeout.

    subprocess.run(timeout=...) kills only its direct child. On Windows a
    Git-for-Windows launcher can leave the real Git child holding captured pipe
    handles open, after which subprocess.run waits forever while cleaning up.
    A dedicated process group plus bounded tree termination avoids that mode.
    """

    group_kwargs: dict[str, object]
    if os.name == "nt":
        group_kwargs = {
            "creationflags": getattr(
                subprocess,
                "CREATE_NEW_PROCESS_GROUP",
                0,
            )
        }
    else:
        group_kwargs = {"start_new_session": True}
    process = subprocess.Popen(
        list(args),
        cwd=cwd,
        stdin=(subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL),
        stdout=stdout,
        stderr=stderr,
        env=env,
        shell=False,
        **group_kwargs,
    )
    windows_job = _windows_job_for_process(process)
    try:
        output, error = process.communicate(
            input=input_bytes,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        _terminate_process_tree(process, windows_job=windows_job)
        try:
            process.communicate(timeout=2)
        except (OSError, subprocess.SubprocessError):
            _close_pipe(process.stdout)
            _close_pipe(process.stderr)
        raise subprocess.TimeoutExpired(
            cmd=list(args),
            timeout=timeout,
            output=exc.output,
            stderr=exc.stderr,
        ) from exc
    finally:
        _close_windows_job(windows_job)
    return subprocess.CompletedProcess(
        args=list(args),
        returncode=process.returncode,
        stdout=output or b"",
        stderr=error or b"",
    )


def _safe_git_transport_config() -> tuple[tuple[str, str], ...]:
    """Read only non-executable Git TLS trust settings.

    LingxiAdvisor commands intentionally ignore normal global/system Git config so
    aliases, hooks, filters, diff drivers, and credential helpers cannot affect
    the restricted subprocess boundary.  Corporate CA configuration must still
    be preserved, otherwise Git for Windows can reject an otherwise trusted
    HTTPS chain when a partial clone lazily fetches objects.
    """

    discovery_env = dict(os.environ)
    for key in list(discovery_env):
        if (
            key in _UNSAFE_GIT_ENV_NAMES
            or key.startswith("GIT_CONFIG_KEY_")
            or key.startswith("GIT_CONFIG_VALUE_")
        ):
            discovery_env.pop(key, None)
    selected: dict[str, str] = {}
    for scope in ("--system", "--global"):
        try:
            proc = _bounded_run(
                [
                    "git",
                    "config",
                    scope,
                    "--get-regexp",
                    (
                        r"^http\.(sslBackend|sslCAInfo|sslCAPath|"
                        r"schannelUseSSLCAInfo)$"
                    ),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=10,
                env=discovery_env,
            )
        except (OSError, subprocess.SubprocessError):
            continue
        if proc.returncode not in {0, 1}:
            continue
        for raw_line in proc.stdout.decode(
            "utf-8",
            errors="replace",
        ).splitlines():
            key, separator, value = raw_line.partition(" ")
            normalized_key = key.strip().lower()
            normalized_value = value.strip()
            if (
                separator
                and normalized_key in _SAFE_GIT_TRANSPORT_KEYS
                and normalized_value
                and len(normalized_value) <= 4_096
                and not any(
                    character in normalized_value for character in ("\x00", "\r", "\n")
                )
            ):
                selected[normalized_key] = normalized_value
    if os.name == "nt":
        selected.setdefault("http.sslbackend", "schannel")
    return tuple(selected.items())


def _apply_git_transport_config(
    env: dict[str, str],
    values: tuple[tuple[str, str], ...],
) -> None:
    env["GIT_CONFIG_COUNT"] = str(len(values))
    for index, (key, value) in enumerate(values):
        env[f"GIT_CONFIG_KEY_{index}"] = key
        env[f"GIT_CONFIG_VALUE_{index}"] = value


def _sanitized_environment(*, read_only: bool) -> dict[str, str]:
    """Keep normal network/certificate settings but remove Git redirection."""

    env = dict(os.environ)
    for key in list(env):
        if (
            key in _UNSAFE_GIT_ENV_NAMES
            or key.startswith("GIT_CONFIG_KEY_")
            or key.startswith("GIT_CONFIG_VALUE_")
        ):
            env.pop(key, None)
    # Repository-local configuration remains available for repository identity
    # and remotes, while user/system config cannot install aliases, diff
    # drivers, filters, pagers, or hooks for this process.
    env["GIT_CONFIG_GLOBAL"] = os.devnull
    env["GIT_CONFIG_SYSTEM"] = os.devnull
    env["GIT_CONFIG_NOSYSTEM"] = "1"
    env["GIT_PAGER"] = "cat"
    env["PAGER"] = "cat"
    env["GIT_TERMINAL_PROMPT"] = "0"
    if read_only:
        env["GIT_OPTIONAL_LOCKS"] = "0"
        env["GIT_NO_LAZY_FETCH"] = "1"
    else:
        env.pop("GIT_OPTIONAL_LOCKS", None)
        env.pop("GIT_NO_LAZY_FETCH", None)
    return env


class RestrictedSubprocessRunner:
    """No-shell subprocess boundary with an executable allowlist.

    This is an injectable LingxiAdvisor-internal policy boundary rather than a
    general shell runner. Each capability chooses its exact executable
    allowlist and whether commands must be read-only.
    """

    def __init__(
        self,
        *,
        allowed_executables: Iterable[str],
        read_only: bool,
        allow_git_lazy_fetch: bool | None = None,
        preserve_git_transport_config: bool = True,
    ) -> None:
        allowed = {
            Path(str(item)).name for item in allowed_executables if str(item).strip()
        }
        if not allowed:
            raise ValueError("at least one executable must be allowed")
        self.allowed_executables = frozenset(allowed)
        self.read_only = read_only
        self.allow_git_lazy_fetch = (
            not read_only
            if allow_git_lazy_fetch is None
            else bool(allow_git_lazy_fetch)
        )
        self._git_transport_config = (
            _safe_git_transport_config()
            if "git" in allowed and preserve_git_transport_config
            else ()
        )

    def run(
        self,
        args: list[str] | tuple[str, ...],
        *,
        cwd: Path | None = None,
        timeout_seconds: float,
        input_bytes: bytes | None = None,
    ) -> CommandResult:
        if not args:
            raise CommandPolicyError("command arguments cannot be empty")
        normalized = tuple(str(item) for item in args)
        if any("\x00" in item for item in normalized):
            raise CommandPolicyError("command arguments cannot contain NUL")
        executable = Path(normalized[0]).name
        if executable not in self.allowed_executables:
            raise CommandPolicyError(
                f"executable is not allowed by command policy: {executable}"
            )
        checkpoint()
        timeout_seconds = bounded_timeout(timeout_seconds)
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        run_cwd = cwd.expanduser().resolve() if cwd is not None else None
        try:
            environment = _sanitized_environment(read_only=self.read_only)
            if executable == "git":
                if not self.allow_git_lazy_fetch:
                    environment["GIT_NO_LAZY_FETCH"] = "1"
                _apply_git_transport_config(
                    environment,
                    self._git_transport_config,
                )
            proc = _bounded_run(
                list(normalized),
                cwd=run_cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout_seconds,
                env=environment,
                input_bytes=input_bytes,
            )
        except FileNotFoundError as exc:
            raise RuntimeError(
                f"required executable is not installed or not on PATH: {executable}"
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(
                "restricted command timed out after "
                f"{timeout_seconds:g} seconds: {executable}"
            ) from exc
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError(
                f"restricted command could not run: {executable}"
            ) from exc
        return CommandResult(
            args=normalized,
            returncode=proc.returncode,
            stdout=proc.stdout,
            stderr=proc.stderr,
        )
