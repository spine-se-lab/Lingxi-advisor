from __future__ import annotations

from ..execution import bounded_execution

from ..policy import ExecutionPolicy

import datetime as dt
import hashlib
import json
import logging
from pathlib import Path
from typing import Any, Callable, Mapping

from ...config import ServerSettings
from ..io_utils import safe_part, write_json_atomic, write_jsonl_atomic
from .candidate_schema import canonical_candidate_row
from .contracts import (
    SearchRetrievalOptions,
    SearchRetrievalResult,
    SimilarityGateOptions,
    SWEbenchProInstance,
)
from .grounding import GroundingPreflightService
from .preretrieved_store import PreretrievedStore
from .safety import (
    LeakageDetector,
    PostRetrievalSafetyDecision,
    PostRetrievalSafetyGate,
)
from .selection import FinalTopKSelector, SelectionResult
from .similarity_gate import (
    JudgeClient,
    OpenAICompatibleJudgeClient,
    SimilarityGate,
)

logger = logging.getLogger(__name__)

PRE_REVIEW_SELECTION_POLICY = "retrieval_tier_then_github_rank_in_query_v1"


def _log_value(value: Any, *, fallback: str = "not_provided") -> str:
    normalized = " ".join(str(value or "").split())
    return normalized[:160] if normalized else fallback


class SearchRetrievalService:
    """Current production Search & Retrieval stage.

    This service intentionally stops before Knowledge Generation. It emits the
    selected historical candidates and a stable handoff schema that generation
    modes can consume independently.
    """

    SCHEMA_VERSION = 3

    def __init__(
        self,
        settings: ServerSettings | None = None,
        *,
        judge_client_factory: Callable[[], JudgeClient] | None = None,
        policy: ExecutionPolicy | None = None,
        leakage_detector: LeakageDetector | None = None,
    ) -> None:
        self.policy = policy or ExecutionPolicy()
        self.settings = (settings or ServerSettings()).resolved()
        self._judge_client_factory = judge_client_factory
        self._leakage_detector = leakage_detector or PostRetrievalSafetyGate()
        self.settings.ensure_directories()
        assert self.settings.cache_root is not None
        assert self.settings.repository_root is not None
        self.grounding_preflight = GroundingPreflightService(
            repository_root=self.settings.repository_root
        )

    def _github_client(self) -> Any:
        self.policy.require("allow_live_search")
        from .. import github as v4

        if not self.settings.github_tokens:
            raise RuntimeError(
                "No GitHub token configured. Set GITHUB_TOKEN or GITHUB_TOKEN_1..."
            )
        rotator = v4.GithubTokenRotator(self.settings.github_tokens)
        return v4.GithubClient(
            token_rotator=rotator,
            timeout=self.settings.github_timeout_seconds,
            verify_ssl=self.settings.verify_ssl,
            trust_env=self.settings.trust_env,
            max_retries=self.settings.github_max_retries,
        )

    def _judge_client(self) -> JudgeClient:
        self.policy.require("allow_model_calls")
        if self._judge_client_factory is not None:
            return self._judge_client_factory()
        if not self.settings.judge_api_key or not self.settings.judge_model:
            raise RuntimeError(
                "LLM gate requires LINGXI_ADVISOR_JUDGE_API_KEY and "
                "LINGXI_ADVISOR_JUDGE_MODEL, or an Agent Host model backend."
            )
        return OpenAICompatibleJudgeClient(
            api_key=self.settings.judge_api_key,
            model=self.settings.judge_model,
            base_url=self.settings.judge_base_url,
            timeout_seconds=self.settings.judge_timeout_seconds,
            max_retries=self.settings.judge_max_retries,
            max_output_tokens=self.settings.judge_max_output_tokens,
            verify_ssl=self.settings.judge_verify_ssl,
            trust_env=self.settings.judge_trust_env,
        )

    def _enrich_github_issue_fallback(
        self,
        instance: Mapping[str, Any],
    ) -> dict[str, Any]:
        repo = str(instance.get("repo") or "").strip().strip("/")
        raw_issue_number = (
            instance.get("issue_number")
            or instance.get("instance_issue_number")
        )
        try:
            issue_number = int(raw_issue_number)
        except (TypeError, ValueError) as exc:
            raise ValueError("issue_number must be a positive integer") from exc
        if not repo or "/" not in repo:
            raise ValueError(
                "GitHub issue fallback requires repo in owner/name format"
            )
        if issue_number < 1:
            raise ValueError("issue_number must be a positive integer")

        client = self._github_client()
        try:
            issue = client.get_issue(repo, issue_number)
            if not isinstance(issue, Mapping):
                raise ValueError(f"GitHub issue not found: {repo}#{issue_number}")
            created_at = str(issue.get("created_at") or "").strip()
            issue_mode = str(
                instance.get("issue_mode") or "existing_target"
            ).strip()
            if issue_mode not in {"existing_target", "new_issue"}:
                raise ValueError(
                    "issue_mode must be existing_target or new_issue"
                )
            if issue_mode == "existing_target" and not created_at:
                raise ValueError("GitHub issue response is missing created_at")

            problem_statement = str(
                instance.get("problem_statement") or ""
            ).strip()
            if not problem_statement:
                title = str(issue.get("title") or "").strip()
                body = str(issue.get("body") or "").strip()
                problem_statement = "\n\n".join(
                    part for part in (title, body) if part
                )
            if not problem_statement:
                raise ValueError(
                    "GitHub issue response is missing title and body"
                )

            base_commit = str(instance.get("base_commit") or "").strip()
            if base_commit:
                commit = client.get_commit(repo, base_commit)
            else:
                commit_at = created_at
                if issue_mode == "new_issue":
                    from .. import github as v4

                    commit_at = v4.isoformat_utc(
                        dt.datetime.now(dt.timezone.utc)
                    )
                commit = client.get_commit_at_or_before(repo, commit_at)
            if not isinstance(commit, Mapping):
                raise ValueError(
                    "Unable to resolve a base commit for GitHub issue"
                )
            base_commit = str(commit.get("sha") or base_commit).strip()
            if not base_commit:
                raise ValueError("GitHub commit response is missing sha")
        finally:
            client.close()

        commit_data = commit.get("commit")
        commit_data = commit_data if isinstance(commit_data, Mapping) else {}
        committer = commit_data.get("committer")
        committer = committer if isinstance(committer, Mapping) else {}
        author = commit_data.get("author")
        author = author if isinstance(author, Mapping) else {}
        base_created_at = str(
            committer.get("date") or author.get("date") or ""
        ).strip()

        enriched = dict(instance)
        instance_id = str(instance.get("instance_id") or "").strip()
        if not instance_id:
            repo_slug = repo.replace("/", "__")
            instance_id = f"github-{repo_slug}-issue-{issue_number}"
        enriched["instance_id"] = instance_id
        enriched["base_commit"] = base_commit
        enriched["problem_statement"] = problem_statement
        enriched["instance_issue_number"] = issue_number
        enriched.pop("issue_number", None)
        enriched.pop("_lingxi_advisor_new_issue_search", None)
        if issue_mode == "existing_target":
            enriched["instance_create_at"] = created_at
        else:
            enriched.pop("instance_create_at", None)
        if base_created_at:
            enriched["base_commit_created_at"] = base_created_at
        return enriched

    def _enrich_new_issue_fallback(
        self,
        instance: Mapping[str, Any],
    ) -> dict[str, Any]:
        repo = str(instance.get("repo") or "").strip().strip("/")
        if not repo or "/" not in repo:
            raise ValueError(
                "New-issue live search requires repo in owner/name format"
            )

        from .. import github as v4

        boundary_at = dt.datetime.now(dt.timezone.utc)
        boundary_iso = v4.isoformat_utc(boundary_at)
        client = self._github_client()
        try:
            commit = client.get_commit_at_or_before(repo, boundary_iso)
            if not isinstance(commit, Mapping):
                raise ValueError(
                    "Unable to resolve the latest base commit for new-issue "
                    "live search"
                )
        finally:
            client.close()

        base_commit = str(commit.get("sha") or "").strip()
        if not base_commit:
            raise ValueError("GitHub commit response is missing sha")
        commit_data = commit.get("commit")
        commit_data = commit_data if isinstance(commit_data, Mapping) else {}
        committer = commit_data.get("committer")
        committer = committer if isinstance(committer, Mapping) else {}
        author = commit_data.get("author")
        author = author if isinstance(author, Mapping) else {}
        base_created_at = str(
            committer.get("date") or author.get("date") or ""
        ).strip()

        enriched = dict(instance)
        enriched.pop("_lingxi_advisor_new_issue_search", None)
        enriched["base_commit"] = base_commit
        enriched["issue_mode"] = "new_issue"
        enriched["target_leakage_check"] = False
        if base_created_at:
            enriched["base_commit_created_at"] = base_created_at
        return enriched

    @staticmethod
    def _close_judge_client(client: JudgeClient) -> None:
        close = getattr(client, "close", None)
        if callable(close):
            close()

    def _build_retriever(self, client: Any) -> Any:
        from .closed_issues import ClosedIssueProvider
        from .closed_pulls import ClosedPullBodyIndex
        from .fix_discovery import FixDiscoveryService
        from .github_search import CandidatePoolRetriever
        from .repository import CommitClosingIndex, RepositoryProvider

        assert self.settings.cache_root is not None
        assert self.settings.repository_root is not None
        repository_provider = RepositoryProvider(
            repository_root=self.settings.repository_root,
            cache_root=self.settings.cache_root,
        )
        return CandidatePoolRetriever(
            client=client,
            cache_root=self.settings.cache_root,
            closed_issue_provider=ClosedIssueProvider(self.settings.cache_root),
            fix_discovery=FixDiscoveryService(
                cache_root=self.settings.cache_root,
                patch_root=self.settings.cache_root / "patches",
                repository_provider=repository_provider,
                commit_index=CommitClosingIndex(
                    cache_root=self.settings.cache_root,
                    repository_provider=repository_provider,
                ),
                pr_body_index=ClosedPullBodyIndex(self.settings.cache_root),
            ),
            repository_provider=repository_provider,
        )

    @staticmethod
    def _request_id(
        *,
        instance: SWEbenchProInstance,
        options: SearchRetrievalOptions,
        gate_options: SimilarityGateOptions,
        preretrieved_dir: Path,
    ) -> str:
        payload = {
            "schema_version": SearchRetrievalService.SCHEMA_VERSION,
            "instance": instance.public_dict(),
            "options": options.to_dict(),
            "gate_options": gate_options.to_dict(),
            "preretrieved_dir": str(preretrieved_dir),
        }
        return hashlib.sha256(
            json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()[:24]

    @bounded_execution
    def run(
        self,
        instance: Mapping[str, Any] | SWEbenchProInstance,
        options: Mapping[str, Any] | SearchRetrievalOptions | None = None,
        gate_options: Mapping[str, Any] | SimilarityGateOptions | None = None,
        *,
        preretrieved_dir: str | Path | None = None,
        write_artifacts: bool = True,
        refresh_instance_metadata: bool = False,
        use_test_patch_for_metadata: bool = False,
    ) -> SearchRetrievalResult:
        raw_instance = (
            instance.public_dict()
            if isinstance(instance, SWEbenchProInstance)
            else dict(instance)
        )
        primary_context_complete = all(
            str(raw_instance.get(name) or "").strip()
            for name in (
                "repo",
                "instance_id",
                "base_commit",
                "problem_statement",
            )
        )
        fallback_issue_number = (
            raw_instance.get("issue_number")
            or raw_instance.get("instance_issue_number")
        )
        if (
            not primary_context_complete
            and fallback_issue_number not in (None, "")
        ):
            raw_instance["issue_number"] = fallback_issue_number
            raw_instance = self._enrich_github_issue_fallback(raw_instance)
        elif (
            not primary_context_complete
            and raw_instance.get("_lingxi_advisor_new_issue_search") is True
        ):
            raw_instance = self._enrich_new_issue_fallback(raw_instance)
        normalized_options = (
            options
            if isinstance(options, SearchRetrievalOptions)
            else SearchRetrievalOptions.from_mapping(options)
        )
        if normalized_options.update_preretrieved:
            self.policy.require("allow_update_preretrieved")
        if refresh_instance_metadata or normalized_options.refresh_search_cache:
            self.policy.require("allow_refresh")
        normalized_gate_options = (
            gate_options
            if isinstance(gate_options, SimilarityGateOptions)
            else SimilarityGateOptions.from_mapping(gate_options)
        )

        preretrieved_root = (
            Path(preretrieved_dir).expanduser().resolve()
            if preretrieved_dir is not None
            else self.settings.project_root / "preretrieved_issues"
        )
        normalized_instance = SWEbenchProInstance.from_mapping(raw_instance)
        request_id = self._request_id(
            instance=normalized_instance,
            options=normalized_options,
            gate_options=normalized_gate_options,
            preretrieved_dir=preretrieved_root,
        )

        logger.info(
            "Historical retrieval context resolved: repo=%s issue_type=%s "
            "leakage_check=%s",
            _log_value(normalized_instance.repo),
            normalized_instance.issue_mode,
            normalized_instance.target_leakage_check,
        )

        store = PreretrievedStore(preretrieved_root)
        preretrieved_rows, preretrieved_rejections = store.find(normalized_instance)
        if preretrieved_rows:
            logger.info(
                "Pre-retrieved candidate lookup completed: matches=%d "
                "rejected=%d live_search=false",
                len(preretrieved_rows),
                len(preretrieved_rejections),
            )
            selection = self._select_preretrieved(
                instance=normalized_instance,
                rows=preretrieved_rows,
                options=normalized_options,
                gate_options=normalized_gate_options,
            )
            logger.info(
                "Candidate filtering completed: source=preretrieved input=%d "
                "selected=%d rejected=%d review_gate=%s",
                len(preretrieved_rows),
                len(selection.selected),
                len(selection.rejected),
                normalized_options.run_gate_for_preretrieved,
            )
            if normalized_options.run_gate_for_preretrieved:
                logger.info(
                    "Review gate completed: evaluated=%d selected=%d "
                    "rejected=%d",
                    len(selection.gate_audit),
                    len(selection.selected),
                    len(selection.rejected),
                )
            result = self._build_result(
                request_id=request_id,
                instance=normalized_instance,
                retrieval_source="preretrieved",
                options=normalized_options,
                selected=selection.selected,
                rejected=[*preretrieved_rejections, *selection.rejected],
                boundary={},
                stats={
                    "preretrieved_dir": str(preretrieved_root),
                    "preretrieved_hit": True,
                    "preretrieved_rows_for_instance": len(preretrieved_rows),
                    "preretrieved_rejected_rows": len(preretrieved_rejections),
                    "live_github_search_ran": False,
                    "llm_gate_ran": normalized_options.run_gate_for_preretrieved,
                    "gate_audit_count": len(selection.gate_audit),
                },
                gate_audit=selection.gate_audit,
                search_audit=[],
                rejection_audit=preretrieved_rejections,
                write_artifacts=write_artifacts,
                gate_options=normalized_gate_options,
            )
            logger.info(
                "Historical retrieval finished: status=%s source=%s "
                "selected=%d rejected=%d",
                result.status,
                result.retrieval_source,
                result.selected_count,
                result.rejected_count,
            )
            return result

        logger.info(
            "Pre-retrieved candidate lookup completed: matches=0 rejected=%d "
            "live_search=true",
            len(preretrieved_rejections),
        )

        live_result = self._run_live_search(
            raw_instance=raw_instance,
            options=normalized_options,
            gate_options=normalized_gate_options,
            preretrieved_dir=preretrieved_root,
            refresh_instance_metadata=refresh_instance_metadata,
            use_test_patch_for_metadata=use_test_patch_for_metadata,
        )
        if normalized_options.update_preretrieved and live_result.selected_candidates:
            update_stats = store.append_selected(
                instance=SWEbenchProInstance.from_mapping(live_result.instance),
                rows=live_result.selected_candidates,
                source_run_id=live_result.request_id,
            )
            live_result.stats["preretrieved_update"] = update_stats
            logger.info(
                "Pre-retrieved candidate store updated: appended=%s",
                update_stats.get("appended_rows", 0),
            )
        search_audit = live_result.stats.pop("_search_audit", [])
        rejection_audit = live_result.stats.pop("_rejection_audit", [])
        gate_audit = live_result.stats.pop("_gate_audit", [])
        safe_candidate_pool = live_result.stats.pop("_safe_candidate_pool", [])
        review_candidate_pool = live_result.stats.pop("_review_candidate_pool", [])
        if write_artifacts and live_result.output_dir is None:
            self._write_artifacts(
                result=live_result,
                options=normalized_options,
                gate_options=normalized_gate_options,
                search_audit=search_audit,
                rejection_audit=rejection_audit,
                gate_audit=gate_audit,
                safe_candidate_pool=safe_candidate_pool,
                review_candidate_pool=review_candidate_pool,
            )
        logger.info(
            "Historical retrieval finished: status=%s source=%s selected=%d "
            "rejected=%d",
            live_result.status,
            live_result.retrieval_source,
            live_result.selected_count,
            live_result.rejected_count,
        )
        return live_result

    def find_existing(
        self,
        *,
        issue_description: str,
        context: Mapping[str, Any],
        options: SearchRetrievalOptions,
        gate_options: SimilarityGateOptions,
        preretrieved_dir: str | Path | None = None,
    ) -> SearchRetrievalResult:
        """Select existing approved rows for the portable Runtime contract."""

        options.validate()
        gate_options.validate()
        root = (
            Path(preretrieved_dir).expanduser().resolve()
            if preretrieved_dir is not None
            else self.settings.project_root / "preretrieved_issues"
        )
        rows, rejected = PreretrievedStore(root).find_portable(
            issue_description=issue_description,
            context=context,
        )
        selected = [dict(row) for row in rows[: options.final_top_k]]
        payload = {
            "issue_description": issue_description,
            "context": dict(context),
            "generation_independent": True,
            "options": options.to_dict(),
            "gate_options": gate_options.to_dict(),
            "preretrieved_dir": str(root),
        }
        request_id = hashlib.sha256(
            json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()[:24]
        status = "completed" if selected else "no_candidates"
        result = SearchRetrievalResult(
            schema_version=self.SCHEMA_VERSION,
            status=status,
            request_id=request_id,
            instance={
                "instance_id": str(
                    context.get("instance_id")
                    or context.get("issue_id")
                    or ""
                ),
                "repo": str(context.get("repo") or ""),
                "problem_statement": issue_description,
            },
            retrieval_source="existing_preretrieved",
            search_candidate_count=options.search_candidate_count,
            final_top_k=options.final_top_k,
            selected_count=len(selected),
            rejected_count=len(rejected) + max(0, len(rows) - len(selected)),
            selected_candidates=selected,
            rejected_candidates=rejected,
            stats={
                "preretrieved_hit": bool(rows),
                "live_github_search_ran": False,
                "llm_gate_ran": False,
                "portable_existing_only": True,
                "matching_rows": len(rows),
            },
        )
        logger.info(
            "Approved pre-retrieved lookup completed: status=%s selected=%d "
            "rejected=%d live_search=false",
            result.status,
            result.selected_count,
            result.rejected_count,
        )
        return result

    def _select_preretrieved(
        self,
        *,
        instance: SWEbenchProInstance,
        rows: list[dict[str, Any]],
        options: SearchRetrievalOptions,
        gate_options: SimilarityGateOptions,
    ) -> SelectionResult:
        selector = FinalTopKSelector(grounding_preflight=self.grounding_preflight)
        if not options.run_gate_for_preretrieved:
            return selector.from_preretrieved(rows=rows, final_top_k=options.final_top_k)

        judge_client = self._judge_client()
        try:
            gate = SimilarityGate(client=judge_client, options=gate_options)
            decisions = []
            source_boundary = self._boundary_from_rows(rows)
            for index, row in enumerate(rows[: options.search_candidate_count]):
                safety = self._leakage_detector.evaluate(
                    row=row,
                    source_instance=instance.public_dict(),
                    source_boundary=source_boundary,
                    target_leakage_check=(
                        instance.target_leakage_check
                    ),
                )
                decisions.append(
                    gate.evaluate(
                        row=row,
                        instance=instance,
                        safety=safety,
                        candidate_position=index,
                    )
                )
        finally:
            self._close_judge_client(judge_client)
        return selector.from_gate_decisions(
            rows=rows,
            decisions=decisions,
            instance=instance,
            final_top_k=options.final_top_k,
        )

    def _run_live_search(
        self,
        *,
        raw_instance: Mapping[str, Any],
        options: SearchRetrievalOptions,
        gate_options: SimilarityGateOptions,
        preretrieved_dir: Path,
        refresh_instance_metadata: bool,
        use_test_patch_for_metadata: bool,
    ) -> SearchRetrievalResult:
        from .instance_enrichment import SWEbenchProMetadataEnricher

        enrichment = SWEbenchProMetadataEnricher(self.settings).enrich(
            raw_instance,
            refresh=refresh_instance_metadata,
            use_test_patch=use_test_patch_for_metadata,
        )
        instance = SWEbenchProInstance.from_mapping(enrichment.instance)
        request_id = self._request_id(
            instance=instance,
            options=options,
            gate_options=gate_options,
            preretrieved_dir=preretrieved_dir,
        )

        try:
            client = self._github_client()
            try:
                retriever = self._build_retriever(client)
                (
                    candidate_result,
                    search_audit,
                    rejection_audit,
                ) = retriever.retrieve(
                    instance,
                    options.to_candidate_pool_options(),
                )
            finally:
                client.close()
        except Exception as exc:
            logger.error(
                "Historical retrieval failed: stage=github_retrieval repo=%s "
                "reason=%s can_continue=false",
                _log_value(instance.repo),
                type(exc).__name__,
            )
            raise

        logger.info(
            "Historical candidate retrieval completed: status=%s "
            "candidates=%d",
            candidate_result.status,
            len(candidate_result.candidates),
        )

        if candidate_result.status == "failed":
            logger.error(
                "Historical retrieval failed: stage=candidate_retrieval "
                "reason=candidate_pool_failed can_continue=false"
            )
            return self._build_result(
                request_id=request_id,
                instance=instance,
                retrieval_source="live_github_search",
                options=options,
                selected=[],
                rejected=[],
                boundary=candidate_result.boundary,
                stats={
                    "preretrieved_hit": False,
                    "live_github_search_ran": True,
                    "candidate_pool_status": candidate_result.status,
                    "candidate_pool_error": candidate_result.error,
                    "candidate_pool_stats": candidate_result.stats,
                    "instance_metadata_enrichment": enrichment.audit,
                    "_search_audit": search_audit,
                    "_rejection_audit": rejection_audit,
                    "_gate_audit": [],
                },
                gate_audit=[],
                search_audit=search_audit,
                rejection_audit=rejection_audit,
                write_artifacts=False,
                gate_options=gate_options,
                error=candidate_result.error,
            )

        rows = [
            canonical_candidate_row(
                row,
                instance=instance,
                retrieval_source="live_github_search",
                retrieval_rank=index + 1,
            )
            for index, row in enumerate(candidate_result.candidates)
        ]

        safety_audit: list[dict[str, Any]] = []
        safety_decisions = []
        for row in rows:
            safety = self._leakage_detector.evaluate(
                row=row,
                source_instance=instance.public_dict(),
                source_boundary=candidate_result.boundary,
                target_leakage_check=instance.target_leakage_check,
            )
            safety_decisions.append(safety)
            safety_audit.append(safety.to_dict())

        (
            safe_candidate_pool,
            review_candidate_pool,
            review_safety_decisions,
            safety_rejected,
        ) = self._build_post_safety_pools(
            rows=rows,
            safety_decisions=safety_decisions,
            review_candidate_count=options.search_candidate_count,
        )
        logger.info(
            "Safety filtering completed: evaluated=%d safe=%d rejected=%d "
            "leakage_check=%s",
            len(rows),
            len(safe_candidate_pool),
            len(safety_rejected),
            instance.target_leakage_check,
        )

        if options.skip_review_gate:
            logger.warning(
                "Review gate skipped by request: candidates=%d",
                len(review_candidate_pool),
            )
            pre_gate_rows: list[dict[str, Any]] = []
            for row in review_candidate_pool:
                payload = dict(row)
                payload["llm_gate_decision"] = "not_run"
                payload["llm_gate_reason"] = "Review gate explicitly skipped."
                payload["review_gate_skipped"] = True
                pre_gate_rows.append(payload)
            stats = {
                "preretrieved_hit": False,
                "live_github_search_ran": True,
                "candidate_pool_status": candidate_result.status,
                "search_candidate_count": options.search_candidate_count,
                "candidate_union_count": len(rows),
                "post_retrieval_safety_evaluated_count": len(rows),
                "safe_candidates_collected": len(safe_candidate_pool),
                "pre_gate_candidate_count": len(pre_gate_rows),
                "post_retrieval_safety_rejected_count": len(safety_rejected),
                "pre_review_selection_policy": PRE_REVIEW_SELECTION_POLICY,
                "llm_gate_ran": False,
                "llm_gate_judged_count": 0,
                "review_gate_skipped": True,
                "candidate_pool_stats": candidate_result.stats,
                "instance_metadata_enrichment": enrichment.audit,
                "safety_audit_count": len(safety_audit),
                "_search_audit": search_audit,
                "_rejection_audit": [*rejection_audit, *safety_audit],
                "_gate_audit": [],
                "_safe_candidate_pool": safe_candidate_pool,
                "_review_candidate_pool": review_candidate_pool,
            }
            return self._build_result(
                request_id=request_id,
                instance=instance,
                retrieval_source="live_github_search_pre_gate",
                options=options,
                selected=pre_gate_rows,
                rejected=safety_rejected,
                boundary=candidate_result.boundary,
                stats=stats,
                gate_audit=[],
                search_audit=search_audit,
                rejection_audit=[*rejection_audit, *safety_audit],
                write_artifacts=False,
                gate_options=gate_options,
            )

        judge_client = self._judge_client()
        try:
            gate = SimilarityGate(client=judge_client, options=gate_options)
            decisions = []
            for index, (row, safety) in enumerate(
                zip(review_candidate_pool, review_safety_decisions)
            ):
                decisions.append(
                    gate.evaluate(
                        row=row,
                        instance=instance,
                        safety=safety,
                        candidate_position=index,
                    )
                )
        finally:
            self._close_judge_client(judge_client)

        selector = FinalTopKSelector(grounding_preflight=self.grounding_preflight)
        selection = selector.from_gate_decisions(
            rows=review_candidate_pool,
            decisions=decisions,
            instance=instance,
            final_top_k=options.final_top_k,
        )
        logger.info(
            "Review gate completed: evaluated=%d selected=%d rejected=%d",
            len(decisions),
            len(selection.selected),
            len(selection.rejected),
        )
        stats = {
            "preretrieved_hit": False,
            "live_github_search_ran": True,
            "candidate_pool_status": candidate_result.status,
            "search_candidate_count": options.search_candidate_count,
            "candidate_union_count": len(rows),
            "post_retrieval_safety_evaluated_count": len(rows),
            "safe_candidates_collected": len(safe_candidate_pool),
            "review_candidate_pool_count": len(review_candidate_pool),
            "post_retrieval_safety_rejected_count": len(safety_rejected),
            "pre_review_selection_policy": PRE_REVIEW_SELECTION_POLICY,
            "llm_gate_evaluated_count": len(decisions),
            "llm_gate_judged_count": sum(
                1 for decision in decisions if decision.judge_ran
            ),
            "llm_gate_ran": True,
            "review_gate_skipped": False,
            "candidate_pool_stats": candidate_result.stats,
            "instance_metadata_enrichment": enrichment.audit,
            "safety_audit_count": len(safety_audit),
            "_search_audit": search_audit,
            "_rejection_audit": [*rejection_audit, *safety_audit],
            "_gate_audit": selection.gate_audit,
            "_safe_candidate_pool": safe_candidate_pool,
            "_review_candidate_pool": review_candidate_pool,
        }
        return self._build_result(
            request_id=request_id,
            instance=instance,
            retrieval_source="live_github_search",
            options=options,
            selected=selection.selected,
            rejected=[*safety_rejected, *selection.rejected],
            boundary=candidate_result.boundary,
            stats=stats,
            gate_audit=selection.gate_audit,
            search_audit=search_audit,
            rejection_audit=[*rejection_audit, *safety_audit],
            write_artifacts=False,
            gate_options=gate_options,
        )

    @staticmethod
    def _ranking_int(value: Any, *, minimum: int) -> int:
        if value is None or isinstance(value, bool):
            return 10**12
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            return 10**12
        return parsed if parsed >= minimum else 10**12

    @classmethod
    def _safe_candidate_sort_key(
        cls,
        row: Mapping[str, Any],
        encounter_index: int,
    ) -> tuple[int, int, int, int]:
        return (
            cls._ranking_int(row.get("retrieval_tier"), minimum=0),
            cls._ranking_int(row.get("github_rank_in_query"), minimum=1),
            cls._ranking_int(
                row.get("github_global_encounter_order"),
                minimum=1,
            ),
            encounter_index,
        )

    @classmethod
    def _build_post_safety_pools(
        cls,
        *,
        rows: list[dict[str, Any]],
        safety_decisions: list[PostRetrievalSafetyDecision],
        review_candidate_count: int,
    ) -> tuple[
        list[dict[str, Any]],
        list[dict[str, Any]],
        list[PostRetrievalSafetyDecision],
        list[dict[str, Any]],
    ]:
        if len(rows) != len(safety_decisions):
            raise ValueError(
                "rows and post-retrieval safety decisions must have equal lengths"
            )

        safe_entries: list[
            tuple[dict[str, Any], PostRetrievalSafetyDecision, int]
        ] = []
        rejected: list[dict[str, Any]] = []
        for encounter_index, (row, safety) in enumerate(
            zip(rows, safety_decisions)
        ):
            payload = dict(row)
            payload["post_retrieval_safety_passed"] = safety.passed
            payload["post_retrieval_safety_reasons"] = list(safety.reasons)
            payload["post_retrieval_safety_version"] = safety.safety_version
            if safety.passed:
                payload["llm_gate_decision"] = "not_run"
                payload["llm_gate_reason"] = (
                    "Candidate passed post-retrieval safety; review has not run."
                )
                safe_entries.append((payload, safety, encounter_index))
            else:
                payload["selected_for_review_gate"] = False
                payload["llm_gate_decision"] = "not_run_safety_rejected"
                payload["llm_gate_reason"] = (
                    "Candidate failed the post-retrieval safety recheck and was "
                    "excluded from the review pool."
                )
                rejected.append(payload)

        safe_entries.sort(
            key=lambda item: cls._safe_candidate_sort_key(item[0], item[2])
        )
        safe_candidate_pool: list[dict[str, Any]] = []
        review_candidate_pool: list[dict[str, Any]] = []
        review_safety_decisions: list[PostRetrievalSafetyDecision] = []
        for safe_position, (payload, safety, _encounter_index) in enumerate(
            safe_entries
        ):
            selected_for_review = safe_position < review_candidate_count
            payload["safe_candidate_pool_position"] = safe_position
            payload["safe_candidate_pool_rank"] = safe_position + 1
            payload["pre_review_selection_policy"] = PRE_REVIEW_SELECTION_POLICY
            payload["selected_for_review_gate"] = selected_for_review
            if selected_for_review:
                payload["review_candidate_pool_position"] = safe_position
                payload["review_candidate_pool_rank"] = safe_position + 1
                review_candidate_pool.append(payload)
                review_safety_decisions.append(safety)
            else:
                payload["llm_gate_reason"] = (
                    "Candidate is safe but outside the configured review-candidate "
                    "limit."
                )
            safe_candidate_pool.append(payload)

        return (
            safe_candidate_pool,
            review_candidate_pool,
            review_safety_decisions,
            rejected,
        )

    @staticmethod
    def _partition_pre_gate_candidates(
        rows: list[dict[str, Any]],
        safety_audit: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Compatibility helper for report builders using serialized audits."""

        if len(rows) != len(safety_audit):
            raise ValueError(
                "rows and post-retrieval safety audits must have equal lengths"
            )
        safe: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []
        for row, audit in zip(rows, safety_audit):
            payload = dict(row)
            passed = bool(audit.get("passed"))
            payload["post_retrieval_safety_passed"] = passed
            payload["post_retrieval_safety_reasons"] = list(
                audit.get("reasons") or []
            )
            if passed:
                payload["llm_gate_decision"] = "not_run"
                payload["review_gate_skipped"] = True
                safe.append(payload)
            else:
                rejected.append(payload)
        return safe, rejected

    @staticmethod
    def _boundary_from_rows(rows: list[Mapping[str, Any]]) -> dict[str, Any]:
        for row in rows:
            iso = row.get("leakage_boundary_iso")
            timestamp = row.get("leakage_boundary_ts")
            if iso or timestamp:
                return {
                    "iso": iso,
                    "timestamp": timestamp,
                    "source": row.get("leakage_boundary_source") or "preretrieved_row",
                }
        return {}

    def _build_result(
        self,
        *,
        request_id: str,
        instance: SWEbenchProInstance,
        retrieval_source: str,
        options: SearchRetrievalOptions,
        selected: list[dict[str, Any]],
        rejected: list[dict[str, Any]],
        boundary: dict[str, Any],
        stats: dict[str, Any],
        gate_audit: list[dict[str, Any]],
        search_audit: list[dict[str, Any]],
        rejection_audit: list[dict[str, Any]],
        write_artifacts: bool,
        gate_options: SimilarityGateOptions,
        error: str | None = None,
    ) -> SearchRetrievalResult:
        gate_failures = [row for row in gate_audit if row.get("decision_source") in {
            "judge_call_error", "judge_invalid_json", "judge_schema_reject",
        }]
        stats = {**stats, "llm_gate_failure_count": len(gate_failures)}
        if not selected and gate_failures and not error:
            error = (f"LLM gate failed for {len(gate_failures)} candidate(s); "
                     "no knowledge selected. Inspect gate_audit for model failure details.")
        if error:
            status = "failed"
        elif len(selected) >= options.final_top_k:
            status = "completed"
        elif selected:
            status = "partial"
        else:
            status = "no_candidates"
        result = SearchRetrievalResult(
            schema_version=self.SCHEMA_VERSION,
            status=status,
            request_id=request_id,
            instance=instance.public_dict(),
            retrieval_source=retrieval_source,
            search_candidate_count=options.search_candidate_count,
            final_top_k=options.final_top_k,
            selected_count=len(selected),
            rejected_count=len(rejected),
            selected_candidates=selected,
            rejected_candidates=rejected,
            boundary=boundary,
            stats=stats,
            error=error,
        )
        if write_artifacts:
            self._write_artifacts(
                result=result,
                options=options,
                gate_options=gate_options,
                search_audit=search_audit,
                rejection_audit=rejection_audit,
                gate_audit=gate_audit,
            )
        return result

    def _write_artifacts(
        self,
        *,
        result: SearchRetrievalResult,
        options: SearchRetrievalOptions,
        gate_options: SimilarityGateOptions,
        search_audit: list[dict[str, Any]],
        rejection_audit: list[dict[str, Any]],
        gate_audit: list[dict[str, Any]],
        safe_candidate_pool: list[dict[str, Any]] | None = None,
        review_candidate_pool: list[dict[str, Any]] | None = None,
    ) -> Path:
        assert self.settings.output_root is not None
        safe_pool_rows = safe_candidate_pool or []
        review_pool_rows = review_candidate_pool or []
        instance_id = str(result.instance.get("instance_id") or "unknown")
        run_dir = (
            self.settings.output_root
            / "search_retrieval_runs"
            / safe_part(instance_id)
            / result.request_id
        )
        write_json_atomic(
            run_dir / "request.json",
            {
                "schema_version": self.SCHEMA_VERSION,
                "instance": result.instance,
                "options": options.to_dict(),
                "gate_options": gate_options.to_dict(),
            },
        )
        write_jsonl_atomic(run_dir / "safe_candidate_pool.jsonl", safe_pool_rows)
        write_jsonl_atomic(
            run_dir / "review_candidate_pool.jsonl",
            review_pool_rows,
        )
        write_jsonl_atomic(run_dir / "selected_historical_issues.jsonl", result.selected_candidates)
        write_jsonl_atomic(run_dir / "rejected_historical_issues.jsonl", result.rejected_candidates)
        write_jsonl_atomic(run_dir / "search_audit.jsonl", search_audit)
        write_jsonl_atomic(run_dir / "rejection_audit.jsonl", rejection_audit)
        write_jsonl_atomic(run_dir / "gate_audit.jsonl", gate_audit)
        summary = {
            "schema_version": self.SCHEMA_VERSION,
            "status": result.status,
            "request_id": result.request_id,
            "retrieval_source": result.retrieval_source,
            "search_candidate_count": result.search_candidate_count,
            "final_top_k": result.final_top_k,
            "selected_count": result.selected_count,
            "rejected_count": result.rejected_count,
            "safe_candidate_pool_count": len(safe_pool_rows),
            "review_candidate_pool_count": len(review_pool_rows),
            "stats": result.stats,
            "error": result.error,
        }
        write_json_atomic(run_dir / "summary.json", summary)
        result.output_dir = str(run_dir)
        write_json_atomic(run_dir / "result.json", result.to_dict())
        write_json_atomic(
            run_dir / "manifest.json",
            {
                "schema_version": self.SCHEMA_VERSION,
                "request_id": result.request_id,
                "status": result.status,
                "request": str(run_dir / "request.json"),
                "safe_candidate_pool": str(
                    run_dir / "safe_candidate_pool.jsonl"
                ),
                "review_candidate_pool": str(
                    run_dir / "review_candidate_pool.jsonl"
                ),
                "selected_historical_issues": str(
                    run_dir / "selected_historical_issues.jsonl"
                ),
                "rejected_historical_issues": str(
                    run_dir / "rejected_historical_issues.jsonl"
                ),
                "search_audit": str(run_dir / "search_audit.jsonl"),
                "rejection_audit": str(run_dir / "rejection_audit.jsonl"),
                "gate_audit": str(run_dir / "gate_audit.jsonl"),
                "summary": str(run_dir / "summary.json"),
                "result": str(run_dir / "result.json"),
            },
        )
        return run_dir
