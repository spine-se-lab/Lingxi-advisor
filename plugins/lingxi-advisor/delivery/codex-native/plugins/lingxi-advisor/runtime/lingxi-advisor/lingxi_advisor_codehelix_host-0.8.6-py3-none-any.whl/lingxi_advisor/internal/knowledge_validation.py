"""Shared content validation for generated, cached and published knowledge."""
from __future__ import annotations

import hashlib
import xml.etree.ElementTree as ET

from .knowledge_template import (
    FINE_GRAINED_TAGS,
    GENERAL_SUMMARY_TAGS,
    KNOWLEDGE_ROOT_TAG,
    KNOWLEDGE_SECTION_TAGS,
)


def validate_knowledge_xml(xml_text: str) -> ET.Element:
    try:
        root = ET.fromstring(str(xml_text or ""))
    except ET.ParseError as exc:
        raise ValueError(f"knowledge artifact is not well-formed XML: {exc}") from exc
    if root.tag != KNOWLEDGE_ROOT_TAG:
        raise ValueError(
            f"knowledge artifact root must be <{KNOWLEDGE_ROOT_TAG}>"
        )
    if root.attrib:
        raise ValueError("knowledge artifact root must not contain metadata")
    actual = tuple(child.tag for child in list(root))
    if actual != KNOWLEDGE_SECTION_TAGS:
        raise ValueError(
            "knowledge artifact sections must be "
            f"{KNOWLEDGE_SECTION_TAGS}, got {actual}"
        )
    return root


def validate_generated_knowledge_xml(xml_text: str) -> ET.Element:
    """Validate the exact canonical structure emitted by generators."""

    root = validate_knowledge_xml(xml_text)
    expected_by_section = (
        FINE_GRAINED_TAGS,
        GENERAL_SUMMARY_TAGS,
    )
    for section, expected in zip(root, expected_by_section):
        actual = tuple(child.tag for child in section)
        if actual != expected:
            raise ValueError(
                f"generated <{section.tag}> sections must be {expected}, "
                f"got {actual}"
            )
        empty = [
            child.tag
            for child in section
            if not "".join(child.itertext()).strip()
        ]
        if empty:
            raise ValueError(
                f"generated <{section.tag}> sections must be non-empty: "
                + ", ".join(empty)
            )
    return root


def validate_knowledge_content(xml_text: str, *, expected_sha256: str | None = None) -> str:
    """Validate the exact text being returned, then return its digest."""
    validate_knowledge_xml(xml_text)
    digest = hashlib.sha256(xml_text.encode("utf-8")).hexdigest()
    if expected_sha256 is not None and expected_sha256 != digest:
        raise ValueError("knowledge artifact SHA-256 does not match recorded content")
    return digest
