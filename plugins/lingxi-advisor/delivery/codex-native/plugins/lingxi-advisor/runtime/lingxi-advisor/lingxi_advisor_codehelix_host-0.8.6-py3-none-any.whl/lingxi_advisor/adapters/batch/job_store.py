from __future__ import annotations

import hashlib
import json
import logging
import re
from collections import Counter
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ...internal.io_utils import safe_part, write_json_atomic, write_jsonl_atomic
from ...internal.locking import FileLock
from ...capabilities.codify.batch_preparation.state import BatchItemState

logger = logging.getLogger(__name__)

BATCH_SCHEMA_VERSION = 2
BATCH_INPUT_LABEL = "<server-configured>"
_BATCH_ID_RE = re.compile(r"^[0-9a-f]{24}$")

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise
    except Exception as exc:
        raise ValueError(f"invalid batch state file: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"batch state must be a JSON object: {path}")
    return value


def _batch_request_id(
    *,
    instances: Sequence[Mapping[str, Any]],
    preparation_options: Mapping[str, Any],
) -> str:
    payload = {
        "schema_version": BATCH_SCHEMA_VERSION,
        "instances": list(instances),
        "preparation_options": dict(preparation_options),
    }
    return hashlib.sha256(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()[:24]


class FilesystemBatchJobStore:
    """Persist batch requests, manifests, item results, and indexes."""

    def __init__(self, *, output_root: Path) -> None:
        self.output_root = output_root.expanduser().resolve()
        self.root = self.output_root / "knowledge_preparation_batches"

    def initialize(
        self,
        *,
        instances: Sequence[Mapping[str, Any]],
        preparation_options: Mapping[str, Any],
        resume: bool,
    ) -> dict[str, Any]:
        normalized_instances = [dict(item) for item in instances]
        normalized_options = dict(preparation_options)
        batch_id = _batch_request_id(
            instances=normalized_instances,
            preparation_options=normalized_options,
        )
        run_dir = self._run_dir(batch_id)
        lock_path = self.root / ".locks" / f"{batch_id}.lock"

        try:
            with FileLock(lock_path, blocking=False):
                request_path = run_dir / "request.json"
                manifest_path = run_dir / "manifest.json"
                if request_path.is_file():
                    existing = _read_object(request_path)
                    if (
                        existing.get("instances") != normalized_instances
                        or existing.get("preparation_options")
                        != normalized_options
                    ):
                        raise RuntimeError(
                            "stored batch request does not match its "
                            "batch_id"
                        )
                else:
                    write_json_atomic(
                        request_path,
                        {
                            "schema_version": BATCH_SCHEMA_VERSION,
                            "batch_id": batch_id,
                            "input_file": BATCH_INPUT_LABEL,
                            "instances": normalized_instances,
                            "preparation_options": normalized_options,
                        },
                    )

                if not resume or not manifest_path.is_file():
                    manifest = self._new_manifest(
                        batch_id=batch_id,
                        instances=normalized_instances,
                    )
                    self._save_manifest(run_dir, manifest)
                    self._write_indexes(run_dir, manifest)
        except BlockingIOError:
            pass

        return self.get(batch_id=batch_id, offset=0, limit=0)

    def lock(self, batch_id: str) -> FileLock:
        self._validate_batch_id(batch_id)
        return FileLock(
            self.root / '.locks' / f'{batch_id}.lock',
            blocking=False,
        )

    def read_request(self, batch_id: str) -> dict[str, Any]:
        self._validate_batch_id(batch_id)
        return _read_object(self._run_dir(batch_id) / 'request.json')

    def read_manifest(self, batch_id: str) -> dict[str, Any]:
        self._validate_batch_id(batch_id)
        return _read_object(self._run_dir(batch_id) / 'manifest.json')

    def save_manifest(
        self,
        batch_id: str,
        manifest: dict[str, Any],
    ) -> None:
        self._validate_batch_id(batch_id)
        self._save_manifest(self._run_dir(batch_id), manifest)

    def save_item_result(
        self,
        *,
        batch_id: str,
        ordinal: int,
        instance_id: str,
        result: Mapping[str, Any],
        attempt: int = 0,
    ) -> str:
        self._validate_batch_id(batch_id)
        filename = f'{ordinal:06d}_{safe_part(instance_id)}.attempt-{attempt}.json'
        relative = f'items/{filename}'
        write_json_atomic(
            self._run_dir(batch_id) / relative,
            dict(result),
        )
        return relative

    def commit_item_result(
        self, *, batch_id: str, manifest: dict[str, Any],
        item: dict[str, Any], result: Mapping[str, Any],
    ) -> None:
        """Commit immutable attempt result, then manifest, then derived indexes.

        The caller holds the batch lock. A crash before the manifest commit
        leaves an unreferenced result; recovery retries that interrupted item.
        Readers never use results.jsonl as authoritative state.
        """
        state = BatchItemState.read(item).finish(str(result.get('status') or 'failed'))
        result_file = self.save_item_result(
            batch_id=batch_id, ordinal=int(item['ordinal']),
            instance_id=str(item.get('instance_id') or ''), result=result,
            attempt=state.attempts,
        )
        state.apply(item)
        item.update(
            request_id=str(result.get('request_id') or '') or None,
            retryable=bool(result.get('retryable')),
            error=str(result.get('error') or '').strip() or None,
            last_finished_at=_utc_now(), result_file=result_file,
        )
        self.save_manifest(batch_id, manifest)
        self.write_indexes(batch_id, manifest)

    def rebuild_indexes(self, batch_id: str) -> None:
        with self.lock(batch_id):
            self._write_indexes(self._run_dir(batch_id), self.read_manifest(batch_id))

    def write_indexes(
        self,
        batch_id: str,
        manifest: Mapping[str, Any],
    ) -> None:
        self._validate_batch_id(batch_id)
        try:
            self._write_indexes(self._run_dir(batch_id), manifest)
        except OSError:
            # The committed manifest remains authoritative and readable.
            logger.warning("Batch index update deferred: batch_id=%s", batch_id)

    def get(
        self,
        *,
        batch_id: str,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        self._validate_batch_id(batch_id)
        if offset < 0:
            raise ValueError("offset cannot be negative")
        if limit < 0 or limit > 100:
            raise ValueError("limit must be between 0 and 100")

        manifest = _read_object(
            self._run_dir(batch_id) / "manifest.json"
        )
        raw_items = manifest.get("items")
        if not isinstance(raw_items, list):
            raise ValueError("stored batch manifest has no item list")
        items = [
            self._public_item(item)
            for item in raw_items[offset : offset + limit]
            if isinstance(item, Mapping)
        ]
        next_offset = offset + len(items)
        if next_offset >= len(raw_items):
            next_offset = None

        return {
            "schema_version": manifest.get("schema_version"),
            "batch_id": manifest.get("batch_id"),
            "status": manifest.get("status"),
            "input_file": BATCH_INPUT_LABEL,
            "total_count": manifest.get("total_count"),
            "pending_count": manifest.get("pending_count"),
            "running_count": manifest.get("running_count"),
            "completed_count": manifest.get("completed_count"),
            "partial_count": manifest.get("partial_count"),
            "no_candidates_count": manifest.get(
                "no_candidates_count"
            ),
            "failed_count": manifest.get("failed_count"),
            "created_at": manifest.get("created_at"),
            "started_at": manifest.get("started_at"),
            "finished_at": manifest.get("finished_at"),
            "updated_at": manifest.get("updated_at"),
            "error": manifest.get("error"),
            "offset": offset,
            "limit": limit,
            "next_offset": next_offset,
            "items": items,
        }

    def _new_manifest(
        self,
        *,
        batch_id: str,
        instances: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        now = _utc_now()
        manifest: dict[str, Any] = {
            "schema_version": BATCH_SCHEMA_VERSION,
            "batch_id": batch_id,
            "status": "queued",
            "created_at": now,
            "started_at": None,
            "finished_at": None,
            "updated_at": now,
            "error": None,
            "items": [
                {
                    "ordinal": index,
                    "instance_id": str(
                        instance.get("instance_id") or ""
                    ),
                    "status": "pending",
                    "attempts": 0,
                    "request_id": None,
                    "retryable": False,
                    "error": None,
                    "last_started_at": None,
                    "last_finished_at": None,
                    "result_file": None,
                }
                for index, instance in enumerate(instances, start=1)
            ],
        }
        self._refresh_counts(manifest)
        return manifest

    def _save_manifest(
        self,
        run_dir: Path,
        manifest: dict[str, Any],
    ) -> None:
        manifest["updated_at"] = _utc_now()
        self._refresh_counts(manifest)
        write_json_atomic(run_dir / "manifest.json", manifest)

    def _write_indexes(
        self,
        run_dir: Path,
        manifest: Mapping[str, Any],
    ) -> None:
        result_rows: list[dict[str, Any]] = []
        failure_rows: list[dict[str, Any]] = []
        for raw_item in manifest.get("items", []):
            if not isinstance(raw_item, Mapping):
                continue
            result_file = str(raw_item.get("result_file") or "")
            if result_file:
                path = (run_dir / result_file).resolve()
                if run_dir.resolve() not in path.parents:
                    raise ValueError("batch result path escapes its run")
                if path.is_file():
                    result_rows.append(_read_object(path))
            if raw_item.get("status") == "failed":
                failure_rows.append(self._public_item(raw_item))
        write_jsonl_atomic(run_dir / "results.jsonl", result_rows)
        write_jsonl_atomic(run_dir / "failures.jsonl", failure_rows)

    @staticmethod
    def _refresh_counts(manifest: dict[str, Any]) -> None:
        items = manifest.get("items")
        if not isinstance(items, list):
            return
        counts = Counter(
            str(item.get("status") or "")
            for item in items
            if isinstance(item, Mapping)
        )
        manifest["total_count"] = len(items)
        manifest["pending_count"] = counts["pending"]
        manifest["running_count"] = counts["running"]
        manifest["completed_count"] = counts["completed"]
        manifest["partial_count"] = counts["partial"]
        manifest["no_candidates_count"] = counts["no_candidates"]
        manifest["failed_count"] = counts["failed"]

    @staticmethod
    def _public_item(item: Mapping[str, Any]) -> dict[str, Any]:
        return {
            "ordinal": item.get("ordinal"),
            "instance_id": item.get("instance_id"),
            "status": item.get("status"),
            "attempts": item.get("attempts"),
            "request_id": item.get("request_id"),
            "retryable": bool(item.get("retryable")),
            "error": item.get("error"),
            "last_started_at": item.get("last_started_at"),
            "last_finished_at": item.get("last_finished_at"),
        }

    def _run_dir(self, batch_id: str) -> Path:
        self._validate_batch_id(batch_id)
        return self.root / batch_id

    @staticmethod
    def _validate_batch_id(batch_id: str) -> None:
        if not _BATCH_ID_RE.fullmatch(str(batch_id or "")):
            raise ValueError(
                "batch_id must be a 24-character lowercase hex value"
            )
