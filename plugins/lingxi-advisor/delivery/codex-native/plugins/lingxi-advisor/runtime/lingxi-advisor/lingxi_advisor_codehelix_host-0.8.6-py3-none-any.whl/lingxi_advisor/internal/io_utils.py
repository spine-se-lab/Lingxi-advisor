from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Iterator, TextIO

from .execution import checkpoint


def safe_part(value: str, max_len: int = 180) -> str:
    result = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip()).strip("._") or "empty"
    if len(result) > max_len:
        digest = hashlib.sha256(result.encode("utf-8")).hexdigest()[:12]
        result = f"{result[: max_len - 13]}_{digest}"
    return result


def read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return value if isinstance(value, dict) else None


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line_no, raw in enumerate(handle, start=1):
            line = raw.strip()
            if not line:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid JSONL at {path}:{line_no}: {exc}") from exc
            if not isinstance(value, dict):
                raise ValueError(f"expected object at {path}:{line_no}")
            rows.append(value)
    return rows


@contextmanager
def _atomic_text_writer(path: Path) -> Iterator[TextIO]:
    checkpoint()
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            yield handle
            handle.flush()
            os.fsync(handle.fileno())
        for attempt in range(100):
            try:
                checkpoint()
                os.replace(temporary, path)
                break
            except PermissionError:
                if attempt == 99:
                    raise
                time.sleep(0.01)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def write_json_atomic(path: Path, value: Any) -> None:
    with _atomic_text_writer(path) as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2))


def write_jsonl_atomic(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    with _atomic_text_writer(path) as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_text_atomic(path: Path, text: str) -> None:
    with _atomic_text_writer(path) as handle:
        handle.write(text)


def write_lines_atomic(path: Path, values: Iterable[str]) -> None:
    lines = [str(value).strip() for value in values if str(value).strip()]
    write_text_atomic(path, "".join(f"{line}\n" for line in lines))
