from __future__ import annotations

import logging

from ..knowledge_template import GENERAL_SUMMARY_TAGS
from ..light_generation.contracts import ModelCallStats
from . import prompts
from .analyst import parse_xml_fragment
from .context_budget import ContextBudget, ContextBudgetSnapshot
from .contracts import GroundedAnalysisConfig, GroundedAnalysisInput
from .llm import GroundedCompletionRunner

logger = logging.getLogger(__name__)

SUMMARY_TAGS = GENERAL_SUMMARY_TAGS


class GroundedSummarizer:
    """Tool-free LingxiKnowledgeSummarizer pass over grounded analysis."""

    def __init__(
        self,
        config: GroundedAnalysisConfig,
        *,
        runner: GroundedCompletionRunner,
    ) -> None:
        self.config = config
        self.runner = runner

    def summarize(
        self,
        value: GroundedAnalysisInput,
        *,
        fine_grained_xml: str,
    ) -> tuple[
        str,
        tuple[ModelCallStats, ...],
        ContextBudgetSnapshot,
    ]:
        base_messages: list[dict[str, object]] = [
            {
                "role": "system",
                "content": prompts.secured_system_prompt(
                    prompts.SUMMARIZER_SYSTEM_PROMPT
                ),
            },
            {
                "role": "user",
                "content": prompts.summarizer_user_prompt(
                    value,
                    fine_grained_xml=fine_grained_xml,
                    config=self.config,
                ),
            },
        ]
        history_groups: list[list[dict[str, object]]] = []
        context_budget = ContextBudget(
            max_context_chars=self.config.max_context_chars,
            reserved_context_fraction=(
                self.config.reserved_context_fraction
            ),
            max_output_tokens=self.config.max_output_tokens,
            chars_per_token=self.config.context_chars_per_token,
            max_compacted_tool_output_chars=(
                self.config.max_compacted_tool_output_chars
            ),
        )
        calls: list[ModelCallStats] = []
        for round_index in range(1, self.config.max_attempts + 1):
            messages = context_budget.build(
                base_messages=base_messages,
                history_groups=history_groups,
                tools=(),
            )
            completion, stats = self.runner.complete(
                tag=f"grounded_summary_round_{round_index}",
                stage_name=f"Grounded Summarizer round {round_index}",
                messages=messages,
                tools=(),
            )
            calls.append(stats)
            try:
                xml, _ = parse_xml_fragment(
                    completion.content,
                    expected_tags=SUMMARY_TAGS,
                )
            except ValueError as exc:
                logger.warning(
                    "Grounded Summarizer returned invalid XML: round=%d "
                    "error=%s",
                    round_index,
                    exc,
                )
                history_groups.append(
                    [
                        {
                            "role": "assistant",
                            "content": completion.content[
                                : self.config.max_tool_output_chars
                            ],
                        },
                        {
                            "role": "user",
                            "content": (
                                "Your previous response was invalid: "
                                f"{exc}. Return only the ten required "
                                "non-empty XML sections in the exact order."
                            ),
                        },
                    ]
                )
                continue
            logger.info(
                "Grounded Summarizer completed: rounds=%d summary_chars=%d",
                round_index,
                len(xml),
            )
            snapshot = context_budget.snapshot()
            logger.info(
                "Grounded Summarizer context budget: peak_chars=%d "
                "request_budget=%d compactions=%d compacted_groups=%d",
                snapshot.peak_request_chars,
                snapshot.request_budget_chars,
                snapshot.compaction_count,
                snapshot.compacted_group_count,
            )
            return xml, tuple(calls), snapshot
        raise RuntimeError(
            "Grounded Summarizer did not produce valid XML within "
            f"{self.config.max_attempts} rounds"
        )
