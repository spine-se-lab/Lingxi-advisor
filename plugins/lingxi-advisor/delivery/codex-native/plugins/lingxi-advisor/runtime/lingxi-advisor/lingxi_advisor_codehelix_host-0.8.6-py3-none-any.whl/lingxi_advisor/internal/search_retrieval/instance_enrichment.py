from __future__ import annotations

import argparse
import hashlib
import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ...config import ServerSettings
from ..io_utils import read_json, safe_part, write_json_atomic
from ..locking import FileLock
from .repository import RepositoryProvider
from ..vendor import swebenchpro_issue_reverse_lookup as reverse_lookup

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class InstanceMetadataEnrichmentResult:
    instance: dict[str, Any]
    audit: dict[str, Any]


class SWEbenchProMetadataEnricher:
    """Default pre-retrieval enrichment for raw SWE-bench Pro rows.

    Raw SWE-bench Pro objects do not carry the upstream issue identity or the
    relevant timestamps. This component runs the supplied reverse-lookup logic
    before the closed-issue catalog / git-util stage and appends only canonical
    metadata fields consumed downstream:

    * ``instance_issue_number``
    * ``instance_create_at``
    * ``base_commit_created_at``

    The target patch is used only inside this enrichment boundary. It is never
    copied into ``SWEbenchProInstance`` or the V4 historical-search mapping.
    """

    SCHEMA_VERSION = 5

    def __init__(self, settings: ServerSettings):
        self.settings = settings.resolved()
        assert self.settings.cache_root is not None
        assert self.settings.repository_root is not None
        self.cache_root = self.settings.cache_root / "instance_metadata"
        self.repository_root = self.settings.repository_root
        self.repository_provider = RepositoryProvider(
            repository_root=self.repository_root,
            cache_root=self.settings.cache_root,
        )
        self.cache_root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _fingerprint(instance: Mapping[str, Any], *, use_test_patch: bool) -> str:
        payload = {
            "schema_version": SWEbenchProMetadataEnricher.SCHEMA_VERSION,
            "repo": str(instance.get("repo") or ""),
            "instance_id": str(instance.get("instance_id") or ""),
            "base_commit": str(instance.get("base_commit") or ""),
            "patch_sha256": hashlib.sha256(
                str(instance.get("patch") or "").encode("utf-8")
            ).hexdigest(),
            "test_patch_sha256": (
                hashlib.sha256(
                    str(instance.get("test_patch") or "").encode("utf-8")
                ).hexdigest()
                if use_test_patch
                else None
            ),
            "use_test_patch": bool(use_test_patch),
        }
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest()[:24]

    def _cache_dir(self, instance: Mapping[str, Any], *, use_test_patch: bool) -> Path:
        instance_id = safe_part(str(instance.get("instance_id") or "unknown"))
        return (
            self.cache_root
            / instance_id
            / self._fingerprint(instance, use_test_patch=use_test_patch)
        )

    @staticmethod
    def _args(*, use_test_patch: bool) -> argparse.Namespace:
        # Preserve the reverse-lookup script's operational defaults.
        return argparse.Namespace(
            use_test_patch=use_test_patch,
            max_commits_per_instance=1500,
            min_score=0.05,
            top_k=10,
            github_top_n=10,
            max_pulls_per_commit=5,
            disable_issue_search_fallback=False,
            issue_search_max_queries=3,
            issue_search_per_query=10,
            issue_search_top_k=10,
            issue_search_min_score=0.18,
            issue_search_type="lexical",
            allow_pr_as_issue_fallback=False,
        )

    @staticmethod
    def _positive_int(value: Any) -> int | None:
        if value in (None, ""):
            return None
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            return None
        return parsed if parsed > 0 else None

    @classmethod
    def _provided_metadata(
        cls,
        instance: Mapping[str, Any],
    ) -> tuple[int | None, str | None, str | None]:
        issue_number = cls._positive_int(instance.get("instance_issue_number"))
        issue_created_at = str(instance.get("instance_create_at") or "").strip() or None
        base_commit_created_at = (
            str(
                instance.get("base_commit_created_at")
                or instance.get("instance_base_commit_created_at")
                or ""
            ).strip()
            or None
        )
        return issue_number, issue_created_at, base_commit_created_at

    @staticmethod
    def _apply_cached_metadata(
        raw: Mapping[str, Any],
        cached: Mapping[str, Any],
    ) -> dict[str, Any]:
        enriched = dict(raw)
        for field in (
            "instance_issue_number",
            "instance_create_at",
            "base_commit_created_at",
        ):
            value = cached.get(field)
            if value not in (None, ""):
                enriched[field] = value
        return enriched

    def enrich(
        self,
        instance: Mapping[str, Any],
        *,
        refresh: bool = False,
        use_test_patch: bool = False,
    ) -> InstanceMetadataEnrichmentResult:
        if not isinstance(instance, Mapping):
            raise TypeError("SWE-bench Pro metadata enrichment input must be a mapping")

        raw = dict(instance)
        provided_number, provided_issue_time, provided_base_time = self._provided_metadata(raw)
        if (
            provided_number is not None
            and provided_issue_time
            and provided_base_time
            and not refresh
        ):
            return InstanceMetadataEnrichmentResult(
                instance=raw,
                audit={
                    "schema_version": self.SCHEMA_VERSION,
                    "mode": "swebench_pro_reverse_lookup_default",
                    "status": "provided_metadata_reused",
                    "instance_issue_number": provided_number,
                    "instance_create_at": provided_issue_time,
                    "base_commit_created_at": provided_base_time,
                    "gold_patch_consumed": False,
                    "use_test_patch": False,
                    "cache_hit": False,
                },
            )

        repo_name = str(raw.get("repo") or "").strip()
        instance_id = str(raw.get("instance_id") or "").strip()
        base_commit = str(raw.get("base_commit") or "").strip()
        patch = str(raw.get("patch") or "")
        if not repo_name or "/" not in repo_name:
            raise ValueError("metadata enrichment requires repo in owner/name format")
        if not instance_id:
            raise ValueError("metadata enrichment requires instance_id")
        if not base_commit:
            raise ValueError("metadata enrichment requires base_commit")

        cache_dir = self._cache_dir(raw, use_test_patch=use_test_patch)
        metadata_path = cache_dir / "enriched_metadata.json"
        check_path = cache_dir / "reverse_lookup_check.json"
        lock_path = cache_dir / ".enrichment.lock"
        cache_dir.mkdir(parents=True, exist_ok=True)

        with FileLock(lock_path):
            cached = read_json(metadata_path)
            if not refresh and isinstance(cached, dict):
                enriched = self._apply_cached_metadata(raw, cached)
                audit = dict(cached.get("audit") or {})
                audit["cache_hit"] = True
                audit["check_path"] = str(check_path)
                return InstanceMetadataEnrichmentResult(instance=enriched, audit=audit)

            if not patch.strip():
                enriched = dict(raw)
                audit = {
                    "schema_version": self.SCHEMA_VERSION,
                    "mode": "swebench_pro_reverse_lookup_default",
                    "status": "skipped_missing_target_patch",
                    "instance_issue_number": provided_number,
                    "instance_create_at": provided_issue_time,
                    "base_commit_created_at": provided_base_time,
                    "gold_patch_consumed": False,
                    "use_test_patch": False,
                    "cache_hit": False,
                    "check_path": None,
                }
                write_json_atomic(
                    metadata_path,
                    {
                        "schema_version": self.SCHEMA_VERSION,
                        "repo": repo_name,
                        "instance_id": instance_id,
                        "instance_issue_number": provided_number,
                        "instance_create_at": provided_issue_time,
                        "base_commit_created_at": provided_base_time,
                        "audit": audit,
                    },
                )
                return InstanceMetadataEnrichmentResult(instance=enriched, audit=audit)

            # Reuse the same server-owned repository cache as later git-util
            # fallbacks, then let the supplied reverse-lookup implementation
            # fetch PR refs exactly as it did in the original pipeline.
            repo_path = self.repository_provider.ensure_repository(
                repo_name,
                refresh=refresh,
            )
            repo = reverse_lookup.GitRepo(owner_repo=repo_name, repo_dir=repo_path)
            repo.prepare(fetch_pr_refs=True)

            base_commit_created_at = (
                repo.commit_date(base_commit)
                or provided_base_time
            )
            enriched = dict(raw)
            if base_commit_created_at:
                enriched["base_commit_created_at"] = base_commit_created_at

            token = self.settings.github_tokens[0] if self.settings.github_tokens else None
            gh = reverse_lookup.GitHubClient(
                token=token,
                cache_dir=self.cache_root / "github_api",
                sleep=0.5,
            )
            args = self._args(use_test_patch=use_test_patch)

            try:
                result = reverse_lookup.reverse_link_instance(
                    raw,
                    repo=repo,
                    gh=gh,
                    args=args,
                )
                selection = reverse_lookup.select_instance_issue_fields(
                    result,
                    allow_pr_as_issue_fallback=False,
                )
            except Exception as exc:
                logger.exception("SWE-bench Pro reverse lookup failed for %s", instance_id)
                if provided_number is not None:
                    enriched["instance_issue_number"] = provided_number
                if provided_issue_time:
                    enriched["instance_create_at"] = provided_issue_time
                audit = {
                    "schema_version": self.SCHEMA_VERSION,
                    "mode": "swebench_pro_reverse_lookup_default",
                    "status": "reverse_lookup_failed_fallback_to_base_commit",
                    "error": str(exc),
                    "instance_issue_number": enriched.get("instance_issue_number"),
                    "instance_create_at": enriched.get("instance_create_at"),
                    "base_commit_created_at": enriched.get("base_commit_created_at"),
                    "gold_patch_consumed": True,
                    "use_test_patch": bool(use_test_patch),
                    "cache_hit": False,
                    "check_path": None,
                }
                # Do not cache transient failures as successful enrichment.
                return InstanceMetadataEnrichmentResult(instance=enriched, audit=audit)

            selected_number = self._positive_int(selection.get("instance_issue_number"))
            selected_issue_time = str(selection.get("instance_create_at") or "").strip() or None
            if selected_number is not None:
                enriched["instance_issue_number"] = selected_number
            elif provided_number is not None:
                enriched["instance_issue_number"] = provided_number
            if selected_issue_time:
                enriched["instance_create_at"] = selected_issue_time
            elif provided_issue_time:
                enriched["instance_create_at"] = provided_issue_time

            # reverse_link_instance already resolved this from the repository;
            # prefer it over the preliminary lookup for exact provenance.
            resolved_base_time = str(result.get("base_commit_date") or "").strip() or base_commit_created_at
            if resolved_base_time:
                enriched["base_commit_created_at"] = resolved_base_time

            check_record = reverse_lookup.build_check_record(raw, result, selection)
            write_json_atomic(check_path, check_record)

            audit = {
                "schema_version": self.SCHEMA_VERSION,
                "mode": "swebench_pro_reverse_lookup_default",
                "status": selection.get("selection_status") or result.get("status") or "unknown",
                "selection_source": selection.get("selection_source"),
                "selection_candidate_rank": selection.get("selection_candidate_rank"),
                "selection_commit_sha": selection.get("selection_commit_sha"),
                "selection_score": selection.get("selection_score"),
                "selection_confidence_bucket": selection.get("selection_confidence_bucket"),
                "selection_issue_url": selection.get("selection_issue_url"),
                "selection_issue_title": selection.get("selection_issue_title"),
                "instance_issue_number": enriched.get("instance_issue_number"),
                "instance_create_at": enriched.get("instance_create_at"),
                "base_commit_created_at": enriched.get("base_commit_created_at"),
                "reverse_lookup_status": result.get("status"),
                "gold_patch_consumed": True,
                "use_test_patch": bool(use_test_patch),
                "cache_hit": False,
                "check_path": str(check_path),
            }
            write_json_atomic(
                metadata_path,
                {
                    "schema_version": self.SCHEMA_VERSION,
                    "repo": repo_name,
                    "instance_id": instance_id,
                    "instance_issue_number": enriched.get("instance_issue_number"),
                    "instance_create_at": enriched.get("instance_create_at"),
                    "base_commit_created_at": enriched.get("base_commit_created_at"),
                    "audit": audit,
                },
            )
            return InstanceMetadataEnrichmentResult(instance=enriched, audit=audit)
