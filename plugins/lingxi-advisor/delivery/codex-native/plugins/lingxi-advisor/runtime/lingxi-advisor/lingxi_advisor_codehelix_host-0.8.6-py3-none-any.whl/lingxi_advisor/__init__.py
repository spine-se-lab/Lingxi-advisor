"""Canonical LingxiAdvisor capability package."""

from .api import (
    LingxiAdvisorCapabilities,
    apply_lingxi_advisors,
    apply_lingxi_advisors_async,
    build_lingxi_advisor_capabilities,
    generate_historical_knowledge,
    generate_historical_knowledge_async,
    prepare_historical_knowledge,
    prepare_historical_knowledge_async,
    search_historical_issues,
    search_historical_issues_async,
    search_lingxi_advisors,
    search_lingxi_advisors_async,
)
from .artifacts import (
    FilesystemKnowledgeArtifactStore,
    KnowledgeArtifact,
    KnowledgeArtifactRef,
    KnowledgeArtifactStore,
)
from .capabilities.activate.lingxi_advisor_search import (
    DefaultTargetIssueResolver,
    KnowledgeMatch,
    LingxiAdvisorActivationSearch,
    LingxiAdvisorSearchRequest,
    LingxiAdvisorSearchResult,
    TargetIssue,
    TargetIssueResolver,
)
from .capabilities.activate.lingxi_advisor_apply import (
    KnowledgeChunk,
    LingxiAdvisorActivationApply,
    LingxiAdvisorApplyRequest,
    LingxiAdvisorApplyResult,
)
from .capabilities.codify.lingxi_advisor_knowledge import LingxiAdvisorCodify

__version__ = "0.8.6"

__all__ = [
    "FilesystemKnowledgeArtifactStore",
    "DefaultTargetIssueResolver",
    "KnowledgeArtifact",
    "KnowledgeArtifactRef",
    "KnowledgeArtifactStore",
    "KnowledgeChunk",
    "KnowledgeMatch",
    "LingxiAdvisorActivationApply",
    "LingxiAdvisorActivationSearch",
    "LingxiAdvisorApplyRequest",
    "LingxiAdvisorApplyResult",
    "LingxiAdvisorCapabilities",
    "LingxiAdvisorCodify",
    "LingxiAdvisorSearchRequest",
    "LingxiAdvisorSearchResult",
    "TargetIssue",
    "TargetIssueResolver",
    "__version__",
    "apply_lingxi_advisors",
    "apply_lingxi_advisors_async",
    "build_lingxi_advisor_capabilities",
    "generate_historical_knowledge",
    "generate_historical_knowledge_async",
    "lingxi.advisor.prepare_historical_knowledge",
    "prepare_historical_knowledge_async",
    "search_historical_issues",
    "search_historical_issues_async",
    "search_lingxi_advisors",
    "search_lingxi_advisors_async",
]
