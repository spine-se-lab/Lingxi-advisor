from __future__ import annotations

from ....internal.execution import run_blocking, failure_details

import asyncio
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from ....internal.knowledge_validation import validate_knowledge_content
from ....internal.preparation_contracts import PreparationRequest
from ....internal.preparation_service import preparation_runs_root
from ....internal.search_retrieval.contracts import (
    SWEbenchProInstance,
    SearchRetrievalOptions,
    SimilarityGateOptions,
)
from ..lingxi_advisor_knowledge import LingxiAdvisorCodify
from .contracts import (
    BatchPreparationOptions,
    BatchPreparationRequest,
    PrepareBatchItem,
)
from .ports import BatchInputSource
from .state import BatchItemState

_REQUEST_ID_RE = re.compile(r'^[0-9a-f]{24}$')
_SUCCESS_ITEM_STATUSES = {'completed', 'partial', 'no_candidates'}
_FINAL_ITEM_STATUSES = _SUCCESS_ITEM_STATUSES | {'failed'}

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

class LingxiAdvisorCodifyOperation:
    def __init__(
        self,
        *,
        codify: LingxiAdvisorCodify,
        preretrieved_dir: Path,
    ) -> None:
        self.codify = codify
        self.preretrieved_dir = preretrieved_dir.expanduser().resolve()

    async def prepare(
        self,
        instance: Mapping[str, Any],
        options: BatchPreparationOptions,
    ) -> dict[str, Any]:
        request = self.request(instance, options)
        result = await run_blocking(self.codify.prepare, request)
        return result.to_dict()

    def request(
        self,
        instance: Mapping[str, Any],
        options: BatchPreparationOptions,
    ) -> PreparationRequest:
        options.validate()
        settings = self.codify.ensure_settings
        mode = options.generation_mode
        request = PreparationRequest(
            instance=SWEbenchProInstance.from_mapping(instance),
            search_options=SearchRetrievalOptions(
                search_candidate_count=options.search_candidate_count,
                final_top_k=options.final_top_k,
                update_preretrieved=options.update_preretrieved,
                run_gate_for_preretrieved=options.run_gate_for_preretrieved,
                search_type=options.search_type,
                fallback_search_type=options.fallback_search_type,
                refresh_search_cache=options.refresh_search_cache,
            ),
            gate_options=SimilarityGateOptions(
                minimum_similarity_score=options.minimum_similarity_score,
                maximum_misleading_risk=options.maximum_misleading_risk,
            ),
            generation_mode=mode,
            preretrieved_dir=self.preretrieved_dir,
            knowledge_cache_dir=settings.knowledge_cache_dir,
            output_root=settings.output_root,
            template_version=settings.template_version(mode),
            generator_model=settings.generator_model,
            resume=options.resume,
            refresh_instance_metadata=options.refresh_instance_metadata,
            allow_clone=(
                settings.allow_clone if mode == 'grounded_analysis' else False
            ),
            allow_fetch=(
                settings.allow_fetch if mode == 'grounded_analysis' else False
            ),
            repository_root=(
                settings.repository_root if mode == 'grounded_analysis' else None
            ),
            historical_worktree_root=(
                settings.historical_worktree_root
                if mode == 'grounded_analysis'
                else None
            ),
            generation_runtime_options=dict(
                settings.runtime_options.get(mode, {})
            ),
        )
        request.validate()
        return request

class LingxiAdvisorCodifyBatch:
    def __init__(
        self,
        *,
        operation: LingxiAdvisorCodifyOperation,
        input_source: BatchInputSource,
        job_store: Any,
        worker: Any,
        prepared_view: Any,
        max_batch_size: int,
    ) -> None:
        self.operation = operation
        self.input_source = input_source
        self.job_store = job_store
        self.worker = worker
        self.prepared_view = prepared_view
        self.max_batch_size = max_batch_size

    async def start(
        self,
        request: BatchPreparationRequest,
    ) -> dict[str, Any]:
        request.options.validate()
        instances = self.input_source.load(
            max_batch_size=self.max_batch_size,
        )
        batch = self.job_store.initialize(
            instances=instances,
            preparation_options=request.options.preparation_options(),
            resume=request.resume,
        )
        batch_id = str(batch['batch_id'])

        async def prepare_item(
            instance: Mapping[str, Any],
        ) -> dict[str, Any]:
            return await self.operation.prepare(instance, request.options)

        self.worker.start(
            batch_id=batch_id,
            run_batch=lambda: self._run(
                batch_id=batch_id,
                prepare_item=prepare_item,
                continue_on_error=request.continue_on_error,
                retry_failed=request.retry_failed,
            ),
        )
        await asyncio.sleep(0)
        return self.get_batch(batch_id=batch_id, offset=0, limit=0)

    async def _run(
        self,
        *,
        batch_id: str,
        prepare_item: PrepareBatchItem,
        continue_on_error: bool,
        retry_failed: bool,
        max_attempts_per_item: int = 2,
    ) -> dict[str, Any]:
        if max_attempts_per_item < 1:
            raise ValueError('max_attempts_per_item must be positive')
        try:
            lock = self.job_store.lock(batch_id)
            lock.__enter__()
        except BlockingIOError:
            return self.get_batch(batch_id=batch_id, offset=0, limit=0)

        try:
            request = self.job_store.read_request(batch_id)
            manifest = self.job_store.read_manifest(batch_id)
            instances = request.get('instances')
            if not isinstance(instances, list):
                raise ValueError('stored batch request has no instance list')
            items = manifest.get('items')
            if not isinstance(items, list) or len(items) != len(instances):
                raise ValueError(
                    'stored batch manifest does not match its request'
                )

            for item in items:
                if item.get('status') == 'running':
                    item['status'] = 'pending'
                    item['error'] = (
                        'Interrupted before the previous attempt completed.'
                    )

            manifest['status'] = 'running'
            manifest['started_at'] = (
                manifest.get('started_at') or _utc_now()
            )
            manifest['finished_at'] = None
            manifest['error'] = None
            manifest['continue_on_error'] = bool(continue_on_error)
            self.job_store.save_manifest(batch_id, manifest)

            for item, instance in zip(items, instances, strict=True):
                if not isinstance(item, dict):
                    raise ValueError('stored batch item is not an object')
                if not isinstance(instance, Mapping):
                    raise ValueError(
                        'stored batch instance is not an object'
                    )
                if item.get('status') in _SUCCESS_ITEM_STATUSES:
                    continue

                attempts_before = int(item.get('attempts') or 0)
                if item.get('status') == 'failed':
                    can_resume_retry = (
                        bool(item.get('retryable'))
                        and attempts_before < max_attempts_per_item
                    )
                    if not retry_failed and not can_resume_retry:
                        continue
                attempt_limit = (
                    attempts_before + max_attempts_per_item
                    if retry_failed and item.get('status') == 'failed'
                    else max_attempts_per_item
                )
                if attempts_before >= attempt_limit:
                    item['status'] = 'failed'
                    item['retryable'] = True
                    item['error'] = (
                        'The previous attempt was interrupted after the '
                        'automatic retry limit was reached.'
                    )
                    item['last_finished_at'] = _utc_now()
                    self.job_store.save_manifest(batch_id, manifest)
                    self.job_store.write_indexes(batch_id, manifest)

                while int(item.get('attempts') or 0) < attempt_limit:
                    BatchItemState.read(item).start().apply(item)
                    item['last_started_at'] = _utc_now()
                    item['last_finished_at'] = None
                    item['error'] = None
                    self.job_store.save_manifest(batch_id, manifest)

                    try:
                        result = await prepare_item(instance)
                    except Exception as exc:
                        result = {
                            'status': 'failed',
                            'instance_id': item.get('instance_id'),
                            'request_id': None,
                            'retryable': self._exception_is_retryable(exc),
                            'error': f'{type(exc).__name__}: {exc}',
                            'knowledge_artifacts': [],
                        }

                    self._apply_item_result(
                        batch_id=batch_id,
                        manifest=manifest,
                        item=item,
                        result=result,
                    )

                    if item.get('status') != 'failed':
                        break
                    if not item.get('retryable'):
                        break

                if (
                    item.get('status') == 'failed'
                    and not continue_on_error
                ):
                    manifest['status'] = 'stopped'
                    manifest['error'] = (
                        'Batch stopped after an item failure.'
                    )
                    break

            if manifest.get('status') != 'stopped':
                self._set_final_batch_status(manifest)
            manifest['finished_at'] = _utc_now()
            self.job_store.save_manifest(batch_id, manifest)
            self.job_store.write_indexes(batch_id, manifest)
        except Exception as exc:
            try:
                manifest = self.job_store.read_manifest(batch_id)
                manifest['status'] = 'failed'
                manifest['error'] = f'{type(exc).__name__}: {exc}'
                manifest['finished_at'] = _utc_now()
                self.job_store.save_manifest(batch_id, manifest)
            except Exception:
                pass
        finally:
            lock.__exit__(None, None, None)

        return self.get_batch(batch_id=batch_id, offset=0, limit=0)

    def _apply_item_result(
        self,
        *,
        batch_id: str,
        manifest: dict[str, Any],
        item: dict[str, Any],
        result: Mapping[str, Any],
    ) -> None:
        status = str(result.get('status') or 'failed')
        if status not in _FINAL_ITEM_STATUSES:
            result = {
                **dict(result),
                'status': 'failed',
                'retryable': False,
                'error': (
                    'single-instance pipeline returned unsupported status: '
                    f'{status}'
                ),
            }
            status = 'failed'

        self.job_store.commit_item_result(
            batch_id=batch_id, manifest=manifest, item=item, result=result,
        )

    @staticmethod
    def _set_final_batch_status(manifest: dict[str, Any]) -> None:
        items = manifest.get('items') or []
        statuses = [
            str(item.get('status') or '')
            for item in items
            if isinstance(item, Mapping)
        ]
        if any(status in {'pending', 'running'} for status in statuses):
            manifest['status'] = 'stopped'
        elif 'failed' in statuses:
            manifest['status'] = 'completed_with_failures'
        else:
            manifest['status'] = 'completed'

    @staticmethod
    def _exception_is_retryable(exc: Exception) -> bool:
        return failure_details(exc)[1]

    def get_batch(
        self,
        *,
        batch_id: str,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        return self.job_store.get(
            batch_id=batch_id,
            offset=offset,
            limit=limit,
        )

    def get_result(self, request_id: str) -> dict[str, Any]:
        return self.prepared_view.get_result(request_id)

class PreparedKnowledgeView:
    def __init__(
        self,
        *,
        output_root: Path,
        max_knowledge_chars: int,
    ) -> None:
        self.output_root = output_root.expanduser().resolve()
        self.max_knowledge_chars = max_knowledge_chars

    def get_result(self, request_id: str) -> dict[str, Any]:
        run_dir = self._resolve_run(request_id)
        value = json.loads(
            (run_dir / 'result.json').read_text(encoding='utf-8')
        )
        if not isinstance(value, dict):
            raise ValueError('stored preparation result is not an object')
        return value

    def read(self, *, request_id: str, artifact_name: str) -> str:
        run_dir = self._resolve_run(request_id)
        if (
            not artifact_name
            or Path(artifact_name).name != artifact_name
            or not artifact_name.endswith('.xml')
        ):
            raise ValueError('artifact_name must be one XML basename')
        result = self.get_result(request_id)
        allowed = {
            str(item.get('artifact_name') or ''): item
            for item in result.get('knowledge_artifacts', [])
            if isinstance(item, Mapping)
        }
        if artifact_name not in allowed:
            raise FileNotFoundError(
                'artifact is not published by this preparation run'
            )
        path = (run_dir / 'knowledge' / artifact_name).resolve()
        if run_dir.resolve() not in path.parents:
            raise ValueError('artifact path escapes the preparation run')
        xml_text = path.read_text(encoding='utf-8')
        validate_knowledge_content(
            xml_text, expected_sha256=str(allowed[artifact_name].get("sha256") or "")
        )
        if len(xml_text) > self.max_knowledge_chars:
            raise ValueError(
                'knowledge artifact exceeds the server response limit'
            )
        return xml_text

    def _resolve_run(self, request_id: str) -> Path:
        if not _REQUEST_ID_RE.fullmatch(str(request_id or '')):
            raise ValueError(
                'request_id must be a 24-character lowercase hex value'
            )
        root = preparation_runs_root(self.output_root).resolve()
        matches = [
            path.resolve()
            for path in root.glob(f'*/{request_id}')
            if path.is_dir() and (path / 'result.json').is_file()
        ]
        safe_matches = [path for path in matches if root in path.parents]
        if not safe_matches:
            raise FileNotFoundError(
                f'preparation request not found: {request_id}'
            )
        if len(safe_matches) > 1:
            raise RuntimeError(
                f'preparation request is ambiguous: {request_id}'
            )
        return safe_matches[0]

__all__ = [
    'PreparedKnowledgeView',
    'LingxiAdvisorCodifyBatch',
    'LingxiAdvisorCodifyOperation',
]
