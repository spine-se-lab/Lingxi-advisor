"""Pure GitHub query construction; target patch data is never query input."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

from .common import (
    DERIVED_ISSUE_TITLE_MAX_CHARS,
    GITHUB_SEARCH_TEXT_MAX_CHARS,
    SCRIPT_VERSION,
    normalize_repo,
    safe_int,
    safe_str,
)


_SEARCH_QUERY_COMPONENTS: Dict[str, Dict[str, str]] = {}


def register_search_query_components(
    *,
    query: str,
    base: str,
    problem_text: str,
    requirements_text: str,
) -> None:
    _SEARCH_QUERY_COMPONENTS[query] = {
        "base": base,
        "problem_text": problem_text,
        "requirements_text": requirements_text,
    }


def prefix_at_word_boundary(text: str, max_chars: int) -> str:
    """Compatibility helper returning a prefix without synthetic ellipses."""
    text = re.sub(r"\s+", " ", text).strip()
    if max_chars <= 0 or not text:
        return ""
    if len(text) <= max_chars:
        return text
    value = text[:max_chars].rstrip()
    boundary = value.rfind(" ")
    if boundary > 0:
        value = value[:boundary].rstrip()
    return value


def compose_registered_search_query(
    components: Dict[str, str],
    *,
    problem_chars: int,
    requirements_chars: int,
) -> Tuple[str, int, int]:
    """Compatibility helper for composing a field-prioritized prefix query.

    Live search no longer calls this after a response error; all production
    query bounding happens before the first request in build_search_plan().
    """
    base = components["base"]
    problem = prefix_at_word_boundary(
        components["problem_text"],
        problem_chars,
    )
    requirements = prefix_at_word_boundary(
        components["requirements_text"],
        requirements_chars,
    )
    query_text = " ".join(
        part for part in (problem, requirements) if part
    )
    query = f"{base} {query_text}".strip() if query_text else base
    return query, len(problem), len(requirements)


def effective_query_component_lengths(
    original_query: str,
    effective_query: str,
) -> Dict[str, Any]:
    components = _SEARCH_QUERY_COMPONENTS.get(original_query)
    if not components:
        return {
            "effective_query_text": "",
            "problem_original_chars": None,
            "problem_effective_chars": None,
            "requirements_original_chars": None,
            "requirements_effective_chars": None,
        }

    base = components["base"]
    problem = components["problem_text"]
    requirements = components["requirements_text"]
    prefix = f"{base} "
    effective_text = (
        effective_query[len(prefix):]
        if effective_query.startswith(prefix)
        else ""
    )

    if effective_text.startswith(problem):
        problem_effective_chars = len(problem)
        remainder = effective_text[len(problem):].lstrip()
        requirements_effective_chars = min(
            len(remainder),
            len(requirements),
        )
    else:
        problem_effective_chars = min(
            len(effective_text),
            len(problem),
        )
        requirements_effective_chars = 0

    return {
        "effective_query_text": effective_text,
        "problem_original_chars": len(problem),
        "problem_effective_chars": problem_effective_chars,
        "requirements_original_chars": len(requirements),
        "requirements_effective_chars": requirements_effective_chars,
    }


QUERY_SECTION_LABEL_RE = re.compile(
    r"\b(?:title|description|issue description|current behavior|actual behavior|observed behavior|"
    r"expected behavior|steps to reproduce|requirements|acceptance criteria|problem statement)\b\s*[:：]?",
    flags=re.IGNORECASE,
)


QUERY_STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "into", "when", "then", "than", "there",
    "their", "should", "would", "could", "current", "expected", "actual", "behavior", "description",
    "issue", "problem", "requirements", "steps", "reproduce", "using", "used", "user", "users", "via",
    "does", "not", "can", "cannot", "will", "also", "after", "before", "some", "time", "correctly",
    "correct", "incorrect", "fails", "failure", "error", "errors", "support", "add", "move", "make",
    "because", "where", "what", "which", "while", "these", "those", "them", "they", "have", "has", "had",
    "into", "onto", "only", "same", "each", "more", "less", "been", "being", "over", "under", "again",
}


def strip_code_fences(text: str) -> str:
    return re.sub(r"```.*?```", " ", text, flags=re.DOTALL)


def clean_query_text(text: str) -> str:
    text = strip_code_fences(text)
    text = re.sub(r"https?://\S+", " ", text)
    text = QUERY_SECTION_LABEL_RE.sub(" ", text)
    text = text.replace("#title:", " ").replace("# Title:", " ")
    text = re.sub(r"\b(?:n|rn)\b", " ", text)
    return text


def instance_problem_source_text(instance: Dict[str, Any]) -> str:
    return safe_str(instance.get("problem_statement"))


def semantic_issue_query_text(text: str, max_chars: int) -> str:
    """Keep the issue's natural-language intent for the primary semantic search."""
    text = strip_code_fences(text)
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"(?m)^\s*#+\s*", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= max_chars:
        return text
    shortened = text[:max_chars]
    sentence_end = max(shortened.rfind(". "), shortened.rfind("; "))
    if sentence_end >= max_chars // 2:
        return shortened[: sentence_end + 1].strip()
    return shortened.rsplit(" ", 1)[0].strip()


def normalize_github_query_term(term: str) -> str:
    term = re.sub(r"\s+", " ", safe_str(term)).strip()
    term = term.replace('"', " ").replace("\\", " ")
    term = re.sub(r"[()<>{}\[\]]+", " ", term)
    term = re.sub(r"\s+", " ", term).strip(" `'\t\r\n")
    return term


def quote_github_term(term: str) -> str:
    term = normalize_github_query_term(term)
    if not term:
        return ""
    if (
        re.search(r"\s", term)
        or any(char in term for char in (":", "#", "@"))
        or term.startswith("-")
        or term.upper() in {"AND", "OR", "NOT"}
    ):
        return f'"{term}"'
    return term


def quote_github_exact_term(term: str) -> str:
    term = normalize_github_query_term(term)
    return f'"{term}"' if term else ""


def compact_query_terms(text: str, max_chars: int) -> str:
    text = clean_query_text(text)
    text = re.sub(r"[^A-Za-z0-9_./:#@+\-\s\"']+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(" ", 1)[0].strip()


def is_query_serialization_artifact(term: str) -> bool:
    """Reject escaped-layout residue such as nConfig and prose slash joins."""
    normalized = normalize_github_query_term(term)
    if re.fullmatch(r"(?:n|rn)[A-Z][a-z]{2,}", normalized):
        return True
    return normalized.casefold() in {
        "idle/open",
        "missing/unsafe",
        "sync/connection",
    }


def extract_ranked_query_terms(text: str, *, max_terms: int = 30) -> List[str]:
    text = clean_query_text(text)
    raw_tokens = re.findall(r"[A-Za-z0-9][A-Za-z0-9_./:#@+\-]{1,}", text)
    counts: Counter[str] = Counter()
    first_seen: Dict[str, str] = {}
    first_position: Dict[str, int] = {}
    for position, token in enumerate(raw_tokens):
        cleaned = token.strip(".,;:()[]{}<>`'\"")
        if (
            len(cleaned) < 3
            or cleaned.isdigit()
            or is_query_serialization_artifact(cleaned)
        ):
            continue
        key = cleaned.lower()
        if key in QUERY_STOPWORDS or len(key) > 80:
            continue
        counts[key] += 1
        first_seen.setdefault(key, cleaned)
        first_position.setdefault(key, position)

    def score(key: str) -> Tuple[int, int, int]:
        token = first_seen[key]
        technical_bonus = 0
        if any(ch in token for ch in (".", "/", "_", "-", ":", "#", "@", "+")):
            technical_bonus += 5
        if re.search(r"[a-z][A-Z]", token) or re.search(r"[A-Z]{2,}", token):
            technical_bonus += 2
        if re.search(r"(?:Error|Exception|Timeout|Config|Router|Route|API|HTTP|JSON|CLI|URL|URI|Token|Key|Schema|Model|View|Controller|Service|Store|Cache)", token):
            technical_bonus += 2
        return (-technical_bonus, -counts[key], first_position[key])

    ranked = sorted(counts, key=score)
    return [first_seen[key] for key in ranked[:max_terms]]


def extract_error_phrases(text: str, max_phrases: int = 5) -> List[str]:
    phrases: List[str] = []
    cleaned = clean_query_text(text)
    pattern = (
        r"([A-Za-z_][A-Za-z0-9_.]*Error|"
        r"[A-Za-z_][A-Za-z0-9_.]*Exception|"
        r"Traceback|TypeError|ValueError|KeyError|TimeoutError|"
        r"ReferenceError|SyntaxError)"
        r"(?:[:\s]+[^\n.!?;]{0,80})?"
    )
    for match in re.finditer(pattern, cleaned):
        phrase = re.sub(r"\s+", " ", match.group(0)).strip()
        phrase = trim_query_text_to_word_boundary(phrase, 80)
        if len(phrase) >= 5 and phrase not in phrases:
            phrases.append(phrase)
        if len(phrases) >= max_phrases:
            break
    return phrases


def extract_component_terms(text: str, max_terms: int = 10) -> List[str]:
    cleaned = clean_query_text(text)
    candidates = re.findall(r"(?:[A-Za-z0-9_\-]+/)+[A-Za-z0-9_.\-]+|[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z0-9_.]+|[A-Za-z_][A-Za-z0-9_]*(?:Service|Controller|Router|Route|Model|View|Store|Cache|Config|Manager|Provider|Plugin|Middleware)", cleaned)
    result: List[str] = []
    seen: set[str] = set()
    for cand in candidates:
        key = cand.lower()
        if key not in seen and len(cand) <= 80:
            result.append(cand)
            seen.add(key)
        if len(result) >= max_terms:
            break
    return result


HIGH_SIGNAL_GENERIC_TERMS = {
    "api",
    "cache",
    "cli",
    "config",
    "configuration",
    "controller",
    "error",
    "errors",
    "exception",
    "http",
    "https",
    "json",
    "key",
    "manager",
    "middleware",
    "model",
    "plugin",
    "provider",
    "route",
    "router",
    "schema",
    "service",
    "store",
    "timeout",
    "token",
    "uri",
    "url",
    "view",
}


ERROR_IDENTIFIER_RE = re.compile(
    r"(?:[A-Za-z_][A-Za-z0-9_.]*(?:Error|Exception)|"
    r"Traceback|TypeError|ValueError|KeyError|TimeoutError|"
    r"ReferenceError|SyntaxError)"
)


def extract_problem_statement_title(
    value: Any,
    *,
    max_chars: int = DERIVED_ISSUE_TITLE_MAX_CHARS,
) -> str:
    """Derive a bounded title without expanding the public instance contract."""
    text = decode_json_string_literal(value)
    if not text:
        return ""
    text = (
        text.replace("\\r\\n", "\n")
        .replace("\\n", "\n")
        .replace("\\r", "\n")
    )
    lines: list[str] = []
    fence_marker: str | None = None
    for raw_line in text.splitlines():
        line = raw_line.strip()
        fence_match = re.match(r"^(`{3,}|~{3,})", line)
        if fence_match:
            marker = fence_match.group(1)[0]
            if fence_marker is None:
                fence_marker = marker
            elif marker == fence_marker:
                fence_marker = None
            continue
        if fence_marker is None:
            lines.append(line)

    markdown_title_pattern = re.compile(r"^\s*#{1,6}\s*")
    labeled_title_pattern = re.compile(
        r"^\s*(?:issue\s+title|title)\s*[:：]\s*(.+?)\s*$",
        re.I,
    )
    title_label_only_pattern = re.compile(
        r"^\s*(?:issue\s+title|title)\s*[:：]?\s*$",
        re.I,
    )

    def clean_line(line: str) -> str:
        candidate = markdown_title_pattern.sub("", line)
        candidate = re.sub(
            r"^\s*(?:[-*+]|\d+[.)])\s+",
            "",
            candidate,
        )
        return candidate.strip(" `*_\t")

    title = ""
    for line_index, line in enumerate(lines):
        is_markdown_heading = bool(markdown_title_pattern.match(line))
        candidate = clean_line(line)
        if not candidate:
            continue
        labeled_match = labeled_title_pattern.match(candidate)
        if labeled_match and labeled_match.group(1).strip():
            title = labeled_match.group(1).strip()
            break
        if title_label_only_pattern.fullmatch(candidate):
            for following_line in lines[line_index + 1 :]:
                following_candidate = clean_line(following_line)
                if (
                    not following_candidate
                    or QUERY_SECTION_LABEL_RE.fullmatch(following_candidate)
                ):
                    continue
                title = following_candidate
                break
            if title:
                break
        if is_markdown_heading:
            if not QUERY_SECTION_LABEL_RE.fullmatch(candidate):
                title = candidate
                break

    if not title:
        for line in lines:
            candidate = clean_line(line)
            if not candidate or candidate == "```":
                continue
            labeled_match = labeled_title_pattern.match(candidate)
            if labeled_match and labeled_match.group(1).strip():
                title = labeled_match.group(1).strip()
                break
            if title_label_only_pattern.fullmatch(candidate):
                continue
            if QUERY_SECTION_LABEL_RE.fullmatch(candidate):
                continue
            title = candidate
            break

    title = normalize_search_field(title)
    return trim_query_text_to_word_boundary(title, max_chars)


def merge_ranked_keyword_terms(text: str) -> List[str]:
    """Merge extraction signals in priority order with case-insensitive dedupe."""
    error_phrases = extract_error_phrases(text, max_phrases=10)
    components = extract_component_terms(text, max_terms=64)
    ranked_terms = extract_ranked_query_terms(text, max_terms=256)
    result: List[str] = []
    seen: set[str] = set()
    for term in (*error_phrases, *components, *ranked_terms):
        normalized = normalize_github_query_term(term)
        key = normalized.casefold()
        if not normalized or key in seen or is_query_serialization_artifact(normalized):
            continue
        result.append(normalized)
        seen.add(key)
    return result


def is_high_signal_query_term(term: str) -> bool:
    """Keep code-like identifiers while excluding broad repository vocabulary."""
    term = normalize_github_query_term(term)
    if (
        not term
        or len(term) < 5
        or len(term) > 80
        or re.search(r"\s", term)
        or term.casefold() in HIGH_SIGNAL_GENERIC_TERMS
        or is_query_serialization_artifact(term)
    ):
        return False
    if ERROR_IDENTIFIER_RE.fullmatch(term):
        return True
    if any(delimiter in term for delimiter in ("::", "/", ".", "_")):
        return bool(re.search(r"[A-Za-z]", term))
    if re.search(r"[a-z][A-Z]", term):
        return True
    if re.fullmatch(r"[A-Z][A-Za-z0-9]+", term) and sum(
        1 for char in term if char.isupper()
    ) >= 2:
        return True
    if re.fullmatch(r"[A-Z][A-Z0-9_]+", term) and len(term) >= 6:
        return True
    return False


def extract_high_signal_query_terms(
    text: str,
    ranked_terms: Sequence[str],
) -> List[str]:
    """Return exact-search-safe identifiers for broad lexical fallbacks."""
    candidates: List[str] = []
    for phrase in extract_error_phrases(text, max_phrases=10):
        match = ERROR_IDENTIFIER_RE.match(phrase)
        if match:
            candidates.append(match.group(0))
    candidates.extend(extract_component_terms(text, max_terms=64))
    candidates.extend(ranked_terms)

    result: List[str] = []
    seen: set[str] = set()
    for term in candidates:
        normalized = normalize_github_query_term(term)
        key = normalized.casefold()
        if key in seen or not is_high_signal_query_term(normalized):
            continue
        result.append(normalized)
        seen.add(key)
    return result


def pack_query_terms(
    terms: Sequence[str],
    *,
    max_chars: int,
    quote_terms: bool = True,
) -> Tuple[str, List[str]]:
    """Fill a query budget without cutting a term, quote, or identifier."""
    if max_chars <= 0:
        return "", []
    query_parts: List[str] = []
    used_terms: List[str] = []
    seen: set[str] = set()
    for term in terms:
        normalized = normalize_github_query_term(term)
        key = normalized.casefold()
        if not normalized or key in seen:
            continue
        query_part = quote_github_term(normalized) if quote_terms else normalized
        candidate = " ".join((*query_parts, query_part))
        if len(candidate) > max_chars:
            if not query_parts:
                continue
            break
        query_parts.append(query_part)
        used_terms.append(normalized)
        seen.add(key)
    return " ".join(query_parts), used_terms


def pack_or_query(
    terms: Sequence[str],
    *,
    max_terms: int,
    max_chars: int,
) -> Tuple[str, List[str]]:
    # GitHub allows at most five Boolean operators, so an OR group can contain
    # no more than six terms. Parentheses keep every branch under the repo/time
    # qualifiers prepended by fit_github_query().
    if max_chars <= 0:
        return "", []
    query_parts: List[str] = []
    used_terms: List[str] = []
    seen: set[str] = set()
    for term in terms:
        if len(used_terms) >= min(max_terms, 6):
            break
        normalized = normalize_github_query_term(term)
        key = normalized.casefold()
        if not normalized or key in seen:
            continue
        query_part = quote_github_term(normalized)
        candidate_parts = [*query_parts, query_part]
        candidate_body = " OR ".join(candidate_parts)
        candidate = (
            f"({candidate_body})"
            if len(candidate_parts) > 1
            else candidate_body
        )
        if len(candidate) > max_chars:
            if not query_parts:
                continue
            break
        query_parts.append(query_part)
        used_terms.append(normalized)
        seen.add(key)
    body = " OR ".join(query_parts)
    return (f"({body})" if len(query_parts) > 1 else body), used_terms


def or_query(terms: Sequence[str], max_terms: int, max_chars: int) -> str:
    query, _ = pack_or_query(
        terms,
        max_terms=max_terms,
        max_chars=max_chars,
    )
    return query


def phrase_query(terms: Sequence[str], max_terms: int, max_chars: int) -> str:
    quoted = [quote_github_term(t) for t in terms[:max_terms]]
    quoted = [q for q in quoted if q]
    text = " ".join(quoted)
    if len(text) <= max_chars:
        return text
    return compact_query_terms(text, max_chars=max_chars)


def boundary_search_date_exclusive(boundary_ts: float) -> str:
    # Use next-day exclusive date so same-day earlier issues are not excluded by GitHub's date-only search.
    boundary_dt = dt.datetime.fromtimestamp(boundary_ts, tz=dt.timezone.utc)
    return (boundary_dt.date() + dt.timedelta(days=1)).isoformat()


def fit_github_query(base: str, query_text: str, max_total_chars: int) -> str:
    base = re.sub(r"\s+", " ", base).strip()
    query_text = re.sub(r"\s+", " ", query_text).strip()
    if not query_text:
        return base
    if re.search(r"\bOR\b", query_text) and not (
        query_text.startswith("(") and query_text.endswith(")")
    ):
        query_text = f"({query_text})"
    full = f"{base} {query_text}".strip()
    if len(full) <= max_total_chars:
        return full
    available = max(0, max_total_chars - len(base) - 1)
    if available <= 0:
        return base
    shortened = query_text[:available].rsplit(" ", 1)[0].strip()
    return f"{base} {shortened}".strip() if shortened else base


def build_query_text_variants(instance: Dict[str, Any], args: argparse.Namespace) -> List[Dict[str, str]]:
    source = instance_problem_source_text(instance)
    terms = extract_ranked_query_terms(source, max_terms=30)
    error_phrases = extract_error_phrases(source, max_phrases=5)
    components = extract_component_terms(source, max_terms=10)
    variants: List[Dict[str, str]] = []
    seen: set[str] = set()

    def add(name: str, text: str) -> None:
        text = compact_query_terms(text, max_chars=args.query_text_max_chars)
        if not text:
            return
        key = text.lower()
        if key in seen:
            return
        seen.add(key)
        variants.append({"query_variant": name, "query_text": text})

    if error_phrases:
        add("error_phrase", phrase_query(error_phrases, max_terms=2, max_chars=args.query_text_max_chars))
    if components:
        add("component_terms", phrase_query(components, max_terms=4, max_chars=args.query_text_max_chars))
    if terms:
        add("technical_or_8", or_query(terms, max_terms=8, max_chars=args.query_text_max_chars))
        add("technical_or_5", or_query(terms, max_terms=5, max_chars=args.query_text_max_chars))
        add("technical_and_4", phrase_query(terms, max_terms=4, max_chars=args.query_text_max_chars))
        add("technical_or_3", or_query(terms, max_terms=3, max_chars=args.query_text_max_chars))
    # Intent fallback uses the first informative lines, but heavily compacted.
    cleaned = clean_query_text(source)
    lines = [re.sub(r"\s+", " ", line).strip() for line in cleaned.splitlines()]
    lines = [line for line in lines if len(line) >= 20]
    add("problem_intent", " ".join(lines[:2]) + " " + " ".join(terms[:5]))
    for idx, term in enumerate(terms[: args.max_single_term_fallbacks], start=1):
        add(f"single_term_{idx}", quote_github_term(term))
    return variants


def decode_json_string_literal(value: Any) -> str:
    """Decode exactly one layer when the complete field is a JSON string."""
    text = safe_str(value)
    if len(text) < 2 or text[0] != '"' or text[-1] != '"':
        return text
    try:
        decoded = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text
    return decoded if isinstance(decoded, str) else text


def normalize_search_field(value: Any) -> str:
    """Normalize a field for use as GitHub search text only.

    The original instance field remains unchanged for the LLM gate and
    generation stages. This copy removes serialization residue, Markdown
    delimiters, and syntax that GitHub advanced search could interpret as
    qualifiers, ranges, grouping, phrase search, or negation.
    """
    text = decode_json_string_literal(value)
    if not text:
        return ""

    # Some datasets contain a quoted string that is not valid JSON after an
    # earlier serialization step. Remove one matching outer quote pair.
    text = text.strip()
    if (
        len(text) >= 2
        and text[0] == text[-1]
        and text[0] in {"'", '"'}
    ):
        text = text[1:-1].strip()

    # Decode residual escaped layout markers without applying unicode_escape
    # to ordinary code, paths, or backslash sequences.
    text = (
        text.replace("\\r\\n", "\n")
        .replace("\\n", "\n")
        .replace("\\r", "\n")
        .replace("\\t", " ")
    )

    # Remove Markdown delimiters but retain code-block and inline-code content.
    text = text.replace("```", " ").replace("`", " ")
    text = text.replace("**", " ")
    # Remove only Markdown heading markers, not the heading text.
    text = re.sub(r"(?m)^\s*#{1,6}\s*", "", text)

    # Neutralize advanced-search syntax while retaining the adjacent words.
    text = text.replace('"', " ")
    text = text.replace("\\", " ")
    text = text.replace(":", " ")
    text = re.sub(r"[()<>{}\[\]]+", " ", text)
    text = re.sub(r"(?<!\S)-(?=\S)", " ", text)

    # Avoid accidental advanced-search Boolean operators.
    text = re.sub(
        r"\b(?:AND|OR|NOT)\b",
        lambda match: match.group(0).lower(),
        text,
    )

    return re.sub(r"\s+", " ", text).strip()


def normalize_problem_statement_for_search(instance: Dict[str, Any]) -> str:
    """Compatibility wrapper returning the complete normalized problem text."""
    return normalize_search_field(instance.get("problem_statement"))


def trim_query_text_to_word_boundary(
    text: str,
    max_chars: int,
    *,
    keep_tail: bool = False,
) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    if max_chars <= 0 or not text:
        return ""
    if len(text) <= max_chars:
        return text
    if keep_tail:
        value = text[-max_chars:]
        first_space = value.find(" ")
        return value[first_space + 1 :].strip() if first_space >= 0 else value
    value = text[:max_chars]
    last_space = value.rfind(" ")
    return value[:last_space].strip() if last_space > 0 else value.strip()


def compose_bounded_search_text(
    problem_text: str,
    requirements_text: str,
    max_chars: int,
) -> Tuple[str, str, str]:
    """Compose a bounded semantic query from intent plus full-text signals."""
    if not problem_text or max_chars <= 0:
        return "", "", ""

    normalized_problem = normalize_search_field(problem_text)
    ranked_terms = merge_ranked_keyword_terms(normalized_problem)
    high_signal_terms = extract_high_signal_query_terms(
        normalized_problem,
        ranked_terms,
    )
    signal_budget = min(96, max(48, max_chars // 3))
    intent_budget = max(1, max_chars - signal_budget - 1)
    problem_part = semantic_issue_query_text(normalized_problem, intent_budget)

    appended_signals: List[str] = []
    query_text = problem_part
    for term in (*high_signal_terms, *ranked_terms):
        normalized = normalize_github_query_term(term)
        if (
            not normalized
            or is_query_serialization_artifact(normalized)
            or normalized.casefold() in query_text.casefold()
        ):
            continue
        candidate = f"{query_text} {normalized}".strip()
        if len(candidate) > max_chars:
            continue
        query_text = candidate
        appended_signals.append(normalized)
        if len(" ".join(appended_signals)) >= signal_budget:
            break

    problem_query_part = query_text
    requirements_part = ""
    remaining = max_chars - len(query_text)
    if requirements_text and remaining > 1:
        requirements_part = trim_query_text_to_word_boundary(
            normalize_search_field(requirements_text),
            remaining - 1,
        )
        if requirements_part:
            query_text = f"{query_text} {requirements_part}".strip()
    return query_text, problem_query_part, requirements_part


def direct_problem_statement_excerpt(text: str, max_chars: int) -> str:
    """Return a direct head/final-sentence excerpt for condensed fallback only."""
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= max_chars:
        return text
    separator = " ... "
    available = max_chars - len(separator)
    if available <= 24:
        return trim_query_text_to_word_boundary(text, max_chars)

    sentences = [
        part.strip()
        for part in re.split(r"(?<=[.!?])\s+", text)
        if part.strip()
    ]
    final_sentence = sentences[-1] if len(sentences) >= 2 else ""
    desired_tail = max(1, int(available * 0.36))
    if final_sentence:
        desired_tail = max(desired_tail, min(len(final_sentence), available))
    tail_budget = min(desired_tail, max(1, int(available * 0.60)))
    head_budget = max(1, available - tail_budget)
    head = trim_query_text_to_word_boundary(text, head_budget)
    tail_source = final_sentence or text
    tail = trim_query_text_to_word_boundary(
        tail_source,
        tail_budget,
        keep_tail=len(tail_source) > tail_budget,
    )
    if not tail or tail.casefold() in head.casefold():
        return trim_query_text_to_word_boundary(text, max_chars)
    return f"{head}{separator}{tail}".strip()


def condensed_problem_statement_query(text: str, max_chars: int) -> str:
    """Create the final fallback from direct problem-statement sentences."""
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= max_chars:
        return text
    sentences = [
        part.strip()
        for part in re.split(r"(?<=[.!?])\s+", text)
        if part.strip()
    ]
    if len(sentences) >= 2:
        first_and_last = f"{sentences[0]} {sentences[-1]}".strip()
        if first_and_last:
            return direct_problem_statement_excerpt(first_and_last, max_chars)
    return direct_problem_statement_excerpt(text, max_chars)


def compose_problem_statement_query(
    base: str,
    query_text: str,
    max_total_chars: int,
) -> Tuple[str, str, bool]:
    """Compose a locally bounded query for the condensed Tier-2 fallback."""
    base = re.sub(r"\s+", " ", base).strip()
    query_text = re.sub(r"\s+", " ", query_text).strip()
    if not query_text:
        return base, "", False
    full = f"{base} {query_text}".strip()
    if len(full) <= max_total_chars:
        return full, query_text, False
    available = max(0, max_total_chars - len(base) - 1)
    if available <= 0:
        return base, "", True
    sent_text = direct_problem_statement_excerpt(query_text, available)
    return f"{base} {sent_text}".strip(), sent_text, True


def build_search_plan(
    instance: Dict[str, Any],
    boundary_ts: float,
    args: argparse.Namespace,
) -> List[Dict[str, Any]]:
    """Build the semantic-first, issue-only retrieval plan.

    Tier 0 and Tier 1 retain the same bounded problem/requirements text and
    change only the requested search type. Later tiers progressively broaden
    recall using extracted keywords, a problem-derived title, a guarded OR
    query, and exact high-signal single-term lexical searches.
    """
    repo = normalize_repo(instance.get("repo"))
    boundary_date = (
        boundary_search_date_exclusive(boundary_ts)
        if boundary_ts > 0.0
        else ""
    )
    problem_text = normalize_search_field(instance.get("problem_statement"))
    requirements_text = ""
    if not repo or not problem_text:
        return []

    primary_search_type = safe_str(
        getattr(args, "primary_search_type", None)
        or getattr(args, "search_type", None)
        or "semantic"
    ).lower()
    fallback_search_type = safe_str(
        getattr(args, "fallback_search_type", None) or "hybrid"
    ).lower()
    configured_primary_max_chars = safe_int(
        getattr(args, "primary_query_text_max_chars", 256),
        256,
    )
    search_text_max_chars = min(
        GITHUB_SEARCH_TEXT_MAX_CHARS,
        max(1, configured_primary_max_chars),
    )
    fallback_max_chars = min(
        search_text_max_chars,
        max(
            1,
            safe_int(
                getattr(args, "query_text_max_chars", 256),
                256,
            ),
        ),
    )
    max_total_chars = safe_int(
        getattr(args, "github_query_max_total_chars", 512),
        512,
    )

    base = f"repo:{repo} is:issue is:closed"
    if boundary_date:
        base += f" created:<{boundary_date}"
    fallback_text_budget = min(
        fallback_max_chars,
        max(0, max_total_chars - len(base) - 1),
    )
    primary_text, planned_problem, planned_requirements = (
        compose_bounded_search_text(
            problem_text,
            requirements_text,
            search_text_max_chars,
        )
    )
    primary_query = f"{base} {primary_text}".strip()
    register_search_query_components(
        query=primary_query,
        base=base,
        problem_text=planned_problem,
        requirements_text=planned_requirements,
    )

    phases: List[Dict[str, Any]] = []
    phase_keys: set[Tuple[str, str]] = set()

    def add_phase(
        *,
        phase: str,
        tier: int,
        search_type: str,
        query_variant: str,
        query_text: str,
        github_query: str,
        pages: int,
        hard_truncated: bool,
        phase_problem_chars: int,
        phase_requirements_chars: int,
        extracted_keywords_used: Sequence[str] = (),
        derived_issue_title: str = "",
    ) -> bool:
        key = (search_type.casefold(), github_query.casefold())
        if not query_text or key in phase_keys:
            return False
        phase_keys.add(key)
        phases.append(
            {
                "phase": phase,
                "tier": tier,
                "kind": "issue",
                "search_type": search_type,
                "query_variant": query_variant,
                "query_text": query_text,
                "github_query": github_query,
                "query_base": base,
                "pages": int(pages),
                "fallback_only": tier > 0,
                "problem_statement_original_chars": len(problem_text),
                "problem_statement_planned_chars": phase_problem_chars,
                "requirements_original_chars": len(requirements_text),
                "requirements_planned_chars": phase_requirements_chars,
                "query_text_sent_chars": len(query_text),
                "query_text_truncated": (
                    phase_problem_chars < len(problem_text)
                    or phase_requirements_chars < len(requirements_text)
                ),
                "github_query_hard_truncated": hard_truncated,
                "extracted_keyword_count": len(extracted_keywords_used),
                "extracted_keywords_used": list(extracted_keywords_used),
                "derived_issue_title": derived_issue_title,
            }
        )
        return True

    bounded_variant = (
        "bounded_problem_statement_plus_requirements"
        if planned_requirements
        else "bounded_problem_statement"
    )
    add_phase(
        phase=f"{primary_search_type}_bounded_problem_statement",
        tier=0,
        search_type=primary_search_type,
        query_variant=bounded_variant,
        query_text=primary_text,
        github_query=primary_query,
        pages=getattr(args, "search_pages", 3),
        hard_truncated=False,
        phase_problem_chars=len(planned_problem),
        phase_requirements_chars=len(planned_requirements),
    )

    if fallback_search_type != primary_search_type:
        add_phase(
            phase=f"{fallback_search_type}_bounded_problem_statement",
            tier=1,
            search_type=fallback_search_type,
            query_variant=bounded_variant,
            query_text=primary_text,
            github_query=primary_query,
            pages=getattr(args, "fallback_search_pages", 2),
            hard_truncated=False,
            phase_problem_chars=len(planned_problem),
            phase_requirements_chars=len(planned_requirements),
        )

    # Every fallback consumes the same normalized representation used by the
    # primary semantic query. This prevents escaped layout residue from being
    # reintroduced by keyword extraction.
    keyword_source = problem_text
    ranked_keywords = merge_ranked_keyword_terms(keyword_source)
    compact_keyword_budget = min(fallback_text_budget, 160)
    keyword_text, keyword_terms_used = pack_query_terms(
        ranked_keywords,
        max_chars=compact_keyword_budget,
    )

    def add_keyword_phase(
        *,
        phase: str,
        tier: int,
        search_type: str,
        query_variant: str,
        query_text: str,
        keywords_used: Sequence[str],
        derived_title: str = "",
    ) -> None:
        if not query_text:
            return
        github_query = f"{base} {query_text}".strip()
        register_search_query_components(
            query=github_query,
            base=base,
            problem_text=query_text,
            requirements_text="",
        )
        add_phase(
            phase=phase,
            tier=tier,
            search_type=search_type,
            query_variant=query_variant,
            query_text=query_text,
            github_query=github_query,
            pages=getattr(args, "fallback_search_pages", 2),
            hard_truncated=False,
            phase_problem_chars=len(query_text),
            phase_requirements_chars=0,
            extracted_keywords_used=keywords_used,
            derived_issue_title=derived_title,
        )

    high_signal_terms = extract_high_signal_query_terms(
        keyword_source,
        ranked_keywords,
    )
    technical_or_text, technical_or_terms = pack_or_query(
        high_signal_terms,
        max_terms=5,
        max_chars=fallback_text_budget,
    )
    if len(technical_or_terms) >= 2:
        add_keyword_phase(
            phase="lexical_technical_or_5",
            tier=2,
            search_type="lexical",
            query_variant="technical_or_5",
            query_text=technical_or_text,
            keywords_used=technical_or_terms,
        )

    add_keyword_phase(
        phase="hybrid_extracted_keywords",
        tier=3,
        search_type="hybrid",
        query_variant="full_extracted_keywords",
        query_text=keyword_text,
        keywords_used=keyword_terms_used,
    )
    add_keyword_phase(
        phase="semantic_extracted_keywords",
        tier=4,
        search_type="semantic",
        query_variant="full_extracted_keywords",
        query_text=keyword_text,
        keywords_used=keyword_terms_used,
    )

    derived_title = extract_problem_statement_title(
        instance.get("problem_statement"),
    )
    title_keyword_text, title_query_terms = pack_query_terms(
        [derived_title, *ranked_keywords] if derived_title else ranked_keywords,
        max_chars=min(fallback_text_budget, 180),
        # Phrase quotes make GitHub silently classify this requested semantic
        # query as lexical. Keep the same title+keyword intent as plain text.
        quote_terms=False,
    )
    title_key = derived_title.casefold()
    title_keywords_used = [
        term
        for term in title_query_terms
        if term.casefold() != title_key
    ]
    if derived_title:
        add_keyword_phase(
            phase="semantic_title_only",
            tier=5,
            search_type="semantic",
            query_variant="derived_issue_title_only",
            query_text=derived_title,
            keywords_used=(),
            derived_title=derived_title,
        )
        add_keyword_phase(
            phase="semantic_title_and_extracted_keywords",
            tier=6,
            search_type="semantic",
            query_variant="derived_issue_title_plus_extracted_keywords",
            query_text=title_keyword_text,
            keywords_used=title_keywords_used,
            derived_title=derived_title,
        )
        add_keyword_phase(
            phase="hybrid_title_and_extracted_keywords",
            tier=7,
            search_type="hybrid",
            query_variant="derived_issue_title_plus_extracted_keywords",
            query_text=title_keyword_text,
            keywords_used=title_keywords_used,
            derived_title=derived_title,
        )

    max_single_term_fallbacks = max(
        0,
        safe_int(getattr(args, "max_single_term_fallbacks", 2), 2),
    )
    for index, term in enumerate(
        high_signal_terms[:max_single_term_fallbacks],
        start=1,
    ):
        exact_term = quote_github_exact_term(term)
        if not exact_term or len(exact_term) > fallback_text_budget:
            continue
        add_keyword_phase(
            phase=f"lexical_high_signal_single_term_{index}",
            tier=7 + index,
            search_type="lexical",
            query_variant=f"high_signal_single_term_{index}",
            query_text=exact_term,
            keywords_used=[term],
        )

    return phases


def search_policy_name(primary_search_type: str, fallback_search_type: str) -> str:
    return (
        f"{primary_search_type}_signal_dense_then_"
        f"{fallback_search_type}_signal_dense_then_"
        "lexical_technical_or_5_then_"
        "hybrid_semantic_extracted_keywords_then_"
        "semantic_title_then_semantic_hybrid_title_keywords_then_"
        "lexical_high_signal_single_terms"
    )


def search_cache_path(cache_dir: Path, query: str, search_type: str, per_page: int, page: int) -> Path:
    digest = hashlib.md5(
        (
            f"{SCRIPT_VERSION}\n"
            f"{search_type}\n"
            f"{per_page}\n"
            f"{page}\n"
            f"{query}"
        ).encode("utf-8")
    ).hexdigest()
    return cache_dir / f"{digest}.json"
