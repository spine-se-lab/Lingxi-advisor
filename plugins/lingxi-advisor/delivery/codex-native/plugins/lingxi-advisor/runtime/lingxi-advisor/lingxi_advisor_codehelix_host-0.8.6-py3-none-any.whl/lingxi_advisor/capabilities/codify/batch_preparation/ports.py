from __future__ import annotations

from typing import Any, Protocol


class BatchInputSource(Protocol):
    """Provide one server-authorized set of public preparation inputs."""

    def load(self, *, max_batch_size: int) -> list[dict[str, Any]]: ...


__all__ = ['BatchInputSource']
