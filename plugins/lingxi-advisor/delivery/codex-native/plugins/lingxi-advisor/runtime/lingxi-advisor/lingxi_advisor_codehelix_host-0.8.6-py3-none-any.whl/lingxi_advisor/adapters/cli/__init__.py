"""Command-line adapters."""
