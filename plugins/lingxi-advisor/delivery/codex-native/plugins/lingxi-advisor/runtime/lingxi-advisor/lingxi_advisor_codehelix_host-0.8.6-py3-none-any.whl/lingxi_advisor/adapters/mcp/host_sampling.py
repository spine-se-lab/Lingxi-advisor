from __future__ import annotations

from ...internal.execution import checkpoint, bounded_timeout, ExecutionFailure
from ...config import ServerSettings
import time

import asyncio
import json
from concurrent.futures import TimeoutError as FutureTimeoutError
from typing import Any, Mapping, Sequence

from ...internal.grounded_analysis.contracts import (
    AgentCompletion,
    AgentToolCall,
)
from ...internal.light_generation.generator import (
    LLMCompletion,
)


class AgentHostModelUnavailableError(RuntimeError):
    """Raised when an MCP client cannot provide host-side sampling."""


class HostSamplingBridge:
    """Synchronous model adapters backed by the current MCP client session.

    LingxiAdvisor's existing Gate and Generation implementations are synchronous.
    MCP tools run them in a worker thread; this bridge schedules
    ``sampling/createMessage`` on the tool's event loop without changing the
    underlying algorithms or their response validation.
    """

    def __init__(
        self,
        *,
        session: Any,
        event_loop: asyncio.AbstractEventLoop,
        related_request_id: str | None,
        timeout_seconds: float = 300.0,
    ) -> None:
        if session is None or not callable(
            getattr(session, "create_message", None)
        ):
            raise AgentHostModelUnavailableError(
                "The current Agent Host does not expose MCP sampling."
            )
        client_params = getattr(session, "client_params", None)
        capabilities = getattr(client_params, "capabilities", None)
        if client_params is not None and getattr(
            capabilities, "sampling", None
        ) is None:
            raise AgentHostModelUnavailableError(
                "The current Agent Host did not advertise MCP sampling."
            )
        if timeout_seconds <= 0:
            raise ValueError("host sampling timeout must be positive")
        self._session = session
        self._event_loop = event_loop
        self._related_request_id = related_request_id
        self._timeout_seconds = timeout_seconds

    def judge_client(self, *, max_output_tokens: int | None = None) -> "HostSamplingJudgeClient":
        return HostSamplingJudgeClient(self, max_output_tokens=max_output_tokens)

    def light_client(self) -> "HostSamplingLightClient":
        return HostSamplingLightClient(self)

    def grounded_client(self) -> "HostSamplingGroundedClient":
        return HostSamplingGroundedClient(self)

    def sample(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        system_prompt: str | None,
        max_tokens: int,
        temperature: float,
        tools: Sequence[Mapping[str, Any]] = (),
    ) -> tuple[str, str, tuple[AgentToolCall, ...]]:
        coroutine = self._sample_async(
            messages=messages,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            tools=tools,
        )
        future = asyncio.run_coroutine_threadsafe(
            coroutine,
            self._event_loop,
        )
        try:
            deadline = time.monotonic() + self._timeout_seconds
            while True:
                checkpoint()
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise FutureTimeoutError()
                try:
                    return future.result(timeout=min(0.1, bounded_timeout(remaining)))
                except FutureTimeoutError:
                    continue
        except FutureTimeoutError as exc:
            future.cancel()
            raise AgentHostModelUnavailableError(
                "Agent Host sampling timed out."
            ) from exc
        except ExecutionFailure:
            future.cancel()
            raise
        except Exception as exc:
            raise AgentHostModelUnavailableError(
                f"Agent Host sampling failed: {exc}"
            ) from exc

    async def _sample_async(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        system_prompt: str | None,
        max_tokens: int,
        temperature: float,
        tools: Sequence[Mapping[str, Any]],
    ) -> tuple[str, str, tuple[AgentToolCall, ...]]:
        try:
            from mcp import types
        except ImportError as exc:  # pragma: no cover - MCP adapter extra
            raise AgentHostModelUnavailableError(
                "MCP sampling requires the lingxi_advisor[mcp] extra."
            ) from exc

        sampling_messages, embedded_system = _sampling_messages(
            messages,
            types=types,
        )
        all_system = "\n\n".join(
            item
            for item in (system_prompt, embedded_system)
            if item and item.strip()
        ) or None
        mcp_tools = [_mcp_tool(item, types=types) for item in tools]
        kwargs: dict[str, Any] = {
            "messages": sampling_messages,
            "max_tokens": max_tokens,
            "system_prompt": all_system,
            "include_context": "none",
            "temperature": temperature,
            "related_request_id": self._related_request_id,
        }
        if mcp_tools:
            kwargs["tools"] = mcp_tools
            kwargs["tool_choice"] = types.ToolChoice(mode="auto")
        response = await self._session.create_message(**kwargs)
        if getattr(response, "stopReason", None) == "maxTokens":
            raise ExecutionFailure("model_output_limit", "Agent Host model exhausted its output token budget")
        content = getattr(response, "content", None)
        blocks = content if isinstance(content, list) else [content]
        text_parts: list[str] = []
        tool_calls: list[AgentToolCall] = []
        for block in blocks:
            block_type = _field(block, "type")
            if block_type == "text":
                text_parts.append(str(_field(block, "text") or ""))
            elif block_type == "tool_use":
                payload = _field(block, "input")
                if not isinstance(payload, Mapping):
                    payload = {}
                tool_calls.append(
                    AgentToolCall(
                        id=str(_field(block, "id") or ""),
                        name=str(_field(block, "name") or ""),
                        arguments=json.dumps(
                            dict(payload),
                            ensure_ascii=False,
                        ),
                    )
                )
        model = str(getattr(response, "model", None) or "agent-host")
        return "\n".join(text_parts), model, tuple(tool_calls)


class HostSamplingJudgeClient:
    def __init__(self, bridge: HostSamplingBridge, *, max_output_tokens: int | None = None) -> None:
        self._bridge = bridge
        self._max_output_tokens = (ServerSettings().judge_max_output_tokens
                                   if max_output_tokens is None else max_output_tokens)

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        content, _model, _calls = self._bridge.sample(
            messages=({"role": "user", "content": user_prompt},),
            system_prompt=system_prompt,
            max_tokens=self._max_output_tokens,
            temperature=0.0,
        )
        return content

    def close(self) -> None:
        return None


class HostSamplingLightClient:
    def __init__(self, bridge: HostSamplingBridge) -> None:
        self._bridge = bridge

    def complete(
        self,
        *,
        prompt: str,
        model: str,
        temperature: float,
        max_output_tokens: int,
    ) -> LLMCompletion:
        content, response_model, _calls = self._bridge.sample(
            messages=({"role": "user", "content": prompt},),
            system_prompt=(
                "Produce evidence-grounded software-engineering knowledge "
                "as well-formed XML."
            ),
            max_tokens=max_output_tokens,
            temperature=temperature,
        )
        return LLMCompletion(
            content=content,
            model=response_model or model,
            usage={},
        )


class HostSamplingGroundedClient:
    def __init__(self, bridge: HostSamplingBridge) -> None:
        self._bridge = bridge

    def complete(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        model: str,
        temperature: float,
        max_output_tokens: int,
    ) -> AgentCompletion:
        content, response_model, tool_calls = self._bridge.sample(
            messages=messages,
            system_prompt=None,
            max_tokens=max_output_tokens,
            temperature=temperature,
            tools=tools,
        )
        return AgentCompletion(
            content=content,
            model=response_model or model,
            usage={},
            tool_calls=tool_calls,
        )


def _field(value: Any, name: str) -> Any:
    if isinstance(value, Mapping):
        return value.get(name)
    return getattr(value, name, None)


def _message_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, Sequence) and not isinstance(
        content, (str, bytes)
    ):
        return "\n".join(
            str(_field(item, "text") or "")
            for item in content
            if _field(item, "type") in (None, "text")
        )
    return str(content or "")


def _sampling_messages(
    messages: Sequence[Mapping[str, Any]],
    *,
    types: Any,
) -> tuple[list[Any], str | None]:
    result: list[Any] = []
    system_parts: list[str] = []
    for message in messages:
        role = str(message.get("role") or "user")
        if role == "system":
            system_parts.append(_message_text(message.get("content")))
            continue
        if role == "tool":
            block = types.ToolResultContent(
                type='tool_result',
                toolUseId=str(message.get("tool_call_id") or ""),
                content=[types.TextContent(
                    type="text", text=_message_text(message.get("content")),
                )],
            )
            # MCP requires all results for one assistant tool-use turn in the
            # immediately following user message. OpenAI represents those same
            # results as separate role=tool messages, so coalesce that run.
            previous = result[-1] if result else None
            previous_blocks = previous.content_as_list if previous else []
            if previous and previous.role == 'user' and previous_blocks and all(
                item.type == 'tool_result' for item in previous_blocks
            ):
                previous.content = [*previous_blocks, block]
            else:
                result.append(types.SamplingMessage(role='user', content=block))
            continue
        blocks: list[Any] = []
        content = _message_text(message.get("content"))
        if content:
            blocks.append(types.TextContent(type="text", text=content))
        for index, call in enumerate(message.get("tool_calls") or ()):
            function = _field(call, "function") or {}
            raw_arguments = _field(function, "arguments") or "{}"
            if isinstance(raw_arguments, Mapping):
                arguments = dict(raw_arguments)
            else:
                try:
                    parsed = json.loads(str(raw_arguments))
                except json.JSONDecodeError:
                    parsed = {}
                arguments = parsed if isinstance(parsed, dict) else {}
            blocks.append(
                types.ToolUseContent(
                    type="tool_use",
                    id=str(_field(call, "id") or f"call_{index}"),
                    name=str(_field(function, "name") or ""),
                    input=arguments,
                )
            )
        if not blocks:
            blocks.append(types.TextContent(type="text", text=""))
        result.append(
            types.SamplingMessage(
                role="assistant" if role == "assistant" else "user",
                content=blocks if len(blocks) > 1 else blocks[0],
            )
        )
    if not result:
        result.append(
            types.SamplingMessage(
                role="user",
                content=types.TextContent(type="text", text=""),
            )
        )
    system_prompt = "\n\n".join(
        item for item in system_parts if item.strip()
    ) or None
    return result, system_prompt


def _mcp_tool(value: Mapping[str, Any], *, types: Any) -> Any:
    function = value.get("function")
    payload = function if isinstance(function, Mapping) else value
    schema = payload.get("parameters") or payload.get("inputSchema") or {
        "type": "object",
        "properties": {},
    }
    return types.Tool(
        name=str(payload.get("name") or ""),
        description=str(payload.get("description") or ""),
        inputSchema=dict(schema),
    )


__all__ = [
    "AgentHostModelUnavailableError",
    "HostSamplingBridge",
    "HostSamplingGroundedClient",
    "HostSamplingJudgeClient",
    "HostSamplingLightClient",
]
