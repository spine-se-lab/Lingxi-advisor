"""Path-free LingxiAdvisor artifact contracts and adapters."""

from .filesystem import FilesystemKnowledgeArtifactStore
from .interface import (
    KnowledgeArtifact,
    KnowledgeArtifactRef,
    KnowledgeArtifactStore,
)

__all__ = [
    "FilesystemKnowledgeArtifactStore",
    "KnowledgeArtifact",
    "KnowledgeArtifactRef",
    "KnowledgeArtifactStore",
]
