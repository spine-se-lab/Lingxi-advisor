from __future__ import annotations

import codecs
import os
import re
from pathlib import Path
from typing import Any

from .command_runner import RestrictedSubprocessRunner

_REVISION_RE = re.compile(r"^(?:HEAD|[0-9a-fA-F]{7,40})(?:[~^][0-9]*)*$")
_PATCH_ID_RE = re.compile(r"^[0-9a-f]{40}$")


class InspectionScopeError(ValueError):
    pass


class BinaryFileError(ValueError):
    pass


class ReadOnlyGitInspector:
    """Bounded read-only inspection scoped to one verified worktree."""

    def __init__(
        self,
        worktree_path: Path,
        *,
        max_output_chars: int = 16_000,
        timeout_seconds: float = 30.0,
        max_file_bytes: int = 2_000_000,
        max_search_results: int = 200,
        max_glob_results: int = 500,
        runner: RestrictedSubprocessRunner | None = None,
    ) -> None:
        self.root = worktree_path.expanduser().resolve()
        if not self.root.is_dir():
            raise FileNotFoundError(f"verified worktree does not exist: {self.root}")
        if max_output_chars < 1:
            raise ValueError("max_output_chars must be positive")
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        if max_file_bytes < 1_000:
            raise ValueError("max_file_bytes must be at least 1000")
        if max_search_results < 1 or max_glob_results < 1:
            raise ValueError("search and glob result limits must be positive")
        self.max_output_chars = max_output_chars
        self.timeout_seconds = timeout_seconds
        self.max_file_bytes = max_file_bytes
        self.max_search_results = max_search_results
        self.max_glob_results = max_glob_results
        self.max_validation_output_bytes = max(16_000_000, max_file_bytes)
        self._runner = runner or RestrictedSubprocessRunner(
            allowed_executables=("git", "rg"),
            read_only=True,
            preserve_git_transport_config=False,
        )

    @staticmethod
    def _git_prefix() -> list[str]:
        return [
            "git",
            "-c",
            f"core.hooksPath={os.devnull}",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.longpaths=true",
            "--no-pager",
        ]

    def _bounded(self, text: str) -> str:
        value = str(text or "")
        if len(value) <= self.max_output_chars:
            return value
        omitted = len(value) - self.max_output_chars
        return (
            value[: self.max_output_chars]
            + f"\n[tool output truncated; omitted_chars={omitted}]\n"
        )

    @staticmethod
    def _limit_lines(text: str, limit: int, label: str) -> str:
        lines = text.splitlines()
        if len(lines) <= limit:
            return text
        omitted = len(lines) - limit
        return (
            "\n".join(lines[:limit])
            + f"\n[{label} truncated; omitted_results={omitted}]\n"
        )

    def _resolve(self, value: str, *, must_exist: bool = True) -> Path:
        raw = str(value or ".").strip() or "."
        supplied = Path(raw)
        if supplied.is_absolute():
            raise InspectionScopeError(
                "absolute paths are not allowed; use a repository-relative path"
            )
        if ".." in supplied.parts:
            raise InspectionScopeError("path traversal is not allowed")
        candidate = (self.root / supplied).resolve(strict=False)
        if not candidate.is_relative_to(self.root):
            raise InspectionScopeError("path escapes the verified historical worktree")
        if must_exist and not candidate.exists():
            raise FileNotFoundError(f"repository-relative path does not exist: {raw}")
        return candidate

    def _pathspec(self, value: str) -> str:
        raw = str(value or "").strip()
        if not raw or len(raw) > 1_000 or "\x00" in raw or "\n" in raw or "\r" in raw:
            raise InspectionScopeError("Git path must contain 1-1000 safe characters")
        supplied = Path(raw)
        if supplied.is_absolute() or ".." in supplied.parts:
            raise InspectionScopeError(
                "Git paths must be repository-relative and cannot traverse"
            )
        normalized = supplied.as_posix()
        while normalized.startswith("./"):
            normalized = normalized[2:]
        if not normalized or normalized.startswith(":"):
            raise InspectionScopeError(
                "Git pathspec magic and empty paths are not allowed"
            )
        return normalized

    @staticmethod
    def _glob_pattern(value: str) -> str:
        pattern = str(value or "").strip()
        if (
            not pattern
            or len(pattern) > 300
            or Path(pattern).is_absolute()
            or ".." in Path(pattern).parts
            or "\x00" in pattern
            or "\n" in pattern
            or "\r" in pattern
        ):
            raise InspectionScopeError(
                "glob must be a safe repository-relative pattern"
            )
        return pattern

    def _relative(self, path: Path) -> str:
        relative = path.relative_to(self.root)
        return "." if str(relative) == "." else relative.as_posix()

    def _run(
        self,
        args: list[str],
        *,
        accepted_returncodes: tuple[int, ...] = (0,),
        bounded: bool = True,
        input_bytes: bytes | None = None,
    ) -> str:
        try:
            proc = self._runner.run(
                args,
                cwd=self.root,
                timeout_seconds=self.timeout_seconds,
                input_bytes=input_bytes,
            )
        except Exception as exc:
            raise RuntimeError(
                f"read-only inspection command could not run: {args[0]}"
            ) from exc
        if proc.returncode not in accepted_returncodes:
            detail = self._bounded(proc.stderr_text().strip())
            raise RuntimeError(
                f"read-only inspection command failed ({proc.returncode}): "
                f"{detail or 'no stderr'}"
            )
        if not bounded and len(proc.stdout) > self.max_validation_output_bytes:
            raise RuntimeError(
                "read-only validation output exceeded the configured hard cap"
            )
        text = proc.stdout_text()
        return self._bounded(text) if bounded else text

    def _run_bytes(
        self,
        args: list[str],
        *,
        accepted_returncodes: tuple[int, ...] = (0,),
    ) -> bytes:
        try:
            proc = self._runner.run(
                args,
                cwd=self.root,
                timeout_seconds=self.timeout_seconds,
            )
        except Exception as exc:
            raise RuntimeError(
                f"read-only inspection command could not run: {args[0]}"
            ) from exc
        if proc.returncode not in accepted_returncodes:
            detail = self._bounded(proc.stderr_text().strip())
            raise RuntimeError(
                f"read-only inspection command failed ({proc.returncode}): "
                f"{detail or 'no stderr'}"
            )
        if len(proc.stdout) > self.max_file_bytes:
            raise ValueError(f"file exceeds read limit of {self.max_file_bytes} bytes")
        return proc.stdout

    def _run_validation_bytes(
        self,
        args: list[str],
        *,
        accepted_returncodes: tuple[int, ...] = (0,),
    ) -> bytes:
        try:
            proc = self._runner.run(
                args,
                cwd=self.root,
                timeout_seconds=self.timeout_seconds,
            )
        except Exception as exc:
            raise RuntimeError(
                f"read-only inspection command could not run: {args[0]}"
            ) from exc
        if proc.returncode not in accepted_returncodes:
            detail = self._bounded(proc.stderr_text().strip())
            raise RuntimeError(
                f"read-only inspection command failed ({proc.returncode}): "
                f"{detail or 'no stderr'}"
            )
        if len(proc.stdout) > self.max_validation_output_bytes:
            raise RuntimeError(
                "read-only validation output exceeded the configured hard cap"
            )
        return proc.stdout

    @staticmethod
    def _revision(value: Any, *, default: str) -> str:
        revision = str(value or default).strip()
        if not _REVISION_RE.fullmatch(revision):
            raise InspectionScopeError(
                "revision must be HEAD, a 7-40 character SHA, or a "
                "revision with ^/~ ancestry suffixes"
            )
        return revision

    @staticmethod
    def _decode_text(data: bytes) -> tuple[str, str]:
        if data.startswith(codecs.BOM_UTF32_LE) or data.startswith(codecs.BOM_UTF32_BE):
            return data.decode("utf-32"), "utf-32"
        if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
            return data.decode("utf-16"), "utf-16"
        if data.startswith(codecs.BOM_UTF8):
            return data.decode("utf-8-sig"), "utf-8-sig"
        if b"\x00" in data:
            raise BinaryFileError("binary file content is not exposed")
        try:
            return data.decode("utf-8"), "utf-8"
        except UnicodeDecodeError:
            text = data.decode("latin-1")
            if text:
                printable = sum(char.isprintable() or char in "\n\r\t" for char in text)
                if printable / len(text) < 0.85:
                    raise BinaryFileError("file does not appear to be readable text")
            return text, "latin-1"

    def _render_file(
        self,
        *,
        data: bytes,
        label: str,
        start_line: int,
        end_line: int | None,
    ) -> str:
        text, encoding = self._decode_text(data)
        start = max(1, int(start_line))
        end = int(end_line) if end_line is not None else start + 399
        if end < start:
            raise ValueError("end_line cannot be smaller than start_line")
        end = min(end, start + 999)
        lines = text.splitlines()
        selected = lines[start - 1 : end]
        rendered = "\n".join(
            f"{line_no}: {line}" for line_no, line in enumerate(selected, start=start)
        )
        actual_end = start + len(selected) - 1
        header = (
            f"[file={label} encoding={encoding} lines={start}-{actual_end} "
            f"total_lines={len(lines)}]\n"
        )
        return self._bounded(header + rendered)

    def read_file(
        self,
        path: str,
        *,
        start_line: int = 1,
        end_line: int | None = None,
    ) -> str:
        resolved = self._resolve(path)
        if not resolved.is_file():
            raise InspectionScopeError("read_file target must be a regular file")
        try:
            with resolved.open("rb") as handle:
                data = handle.read(self.max_file_bytes + 1)
        except OSError as exc:
            raise RuntimeError(f"could not read {path}") from exc
        if len(data) > self.max_file_bytes:
            raise ValueError(f"file exceeds read limit of {self.max_file_bytes} bytes")
        return self._render_file(
            data=data,
            label=self._relative(resolved),
            start_line=start_line,
            end_line=end_line,
        )

    def grep(
        self,
        pattern: str,
        *,
        path: str = ".",
        glob: str | None = None,
    ) -> str:
        expression = str(pattern or "")
        if not expression or len(expression) > 1_000:
            raise ValueError("grep pattern must contain 1-1000 characters")
        resolved = self._resolve(path)
        command = [
            "rg",
            "--line-number",
            "--column",
            "--no-heading",
            "--color",
            "never",
            "--no-messages",
            "--max-columns",
            "500",
            "--max-filesize",
            str(self.max_file_bytes),
        ]
        if glob:
            command.extend(["--glob", self._glob_pattern(glob)])
        command.extend(["--", expression, self._relative(resolved)])
        output = self._run(
            command,
            accepted_returncodes=(0, 1),
            bounded=False,
        )
        output = self._limit_lines(output, self.max_search_results, "grep results")
        return self._bounded(output) or "[no matches]"

    def glob(self, pattern: str) -> str:
        value = self._glob_pattern(pattern)
        output = self._run(
            ["rg", "--files", "--glob", value],
            accepted_returncodes=(0, 1),
            bounded=False,
        )
        output = self._limit_lines(output, self.max_glob_results, "glob results")
        return self._bounded(output) or "[no files matched]"

    def git_show(
        self,
        *,
        revision: str = "HEAD",
        path: str | None = None,
    ) -> str:
        resolved_revision = self._revision(revision, default="HEAD")
        command = [
            *self._git_prefix(),
            "show",
            "--no-ext-diff",
            "--no-textconv",
            "--format=fuller",
            "--patch",
            resolved_revision,
        ]
        if path:
            command.extend(["--", self._pathspec(path)])
        return self._run(command)

    def git_diff(
        self,
        *,
        base: str = "HEAD^",
        target: str = "HEAD",
        path: str | None = None,
    ) -> str:
        resolved_base = self._revision(base, default="HEAD^")
        resolved_target = self._revision(target, default="HEAD")
        command = [
            *self._git_prefix(),
            "diff",
            "--no-ext-diff",
            "--no-textconv",
            resolved_base,
            resolved_target,
        ]
        if path:
            command.extend(["--", self._pathspec(path)])
        return self._run(command)

    def git_log(
        self,
        *,
        max_count: int = 10,
        path: str | None = None,
    ) -> str:
        count = min(20, max(1, int(max_count)))
        command = [
            *self._git_prefix(),
            "log",
            f"--max-count={count}",
            "--date=iso-strict",
            "--format=%H%n%ad%n%s%n%b%n---",
            "HEAD",
        ]
        if path:
            command.extend(["--", self._pathspec(path)])
        return self._run(command)

    def git_read_file(
        self,
        *,
        revision: str = "HEAD^",
        path: str,
        start_line: int = 1,
        end_line: int | None = None,
    ) -> str:
        resolved_revision = self._revision(revision, default="HEAD^")
        pathspec = self._pathspec(path)
        object_spec = f"{resolved_revision}:{pathspec}"
        object_type = self._run(
            [*self._git_prefix(), "cat-file", "-t", object_spec],
            bounded=False,
        ).strip()
        if object_type != "blob":
            raise InspectionScopeError(
                "restricted_git_read_file target must be a file blob"
            )
        data = self._run_bytes([*self._git_prefix(), "cat-file", "blob", object_spec])
        return self._render_file(
            data=data,
            label=f"{resolved_revision}:{pathspec}",
            start_line=start_line,
            end_line=end_line,
        )

    def _parents(self, revision: str) -> tuple[str, ...]:
        resolved = self._revision(revision, default="HEAD")
        line = self._run(
            [
                *self._git_prefix(),
                "rev-list",
                "--parents",
                "-n",
                "1",
                resolved,
            ],
            bounded=False,
        ).strip()
        pieces = line.split()
        return tuple(pieces[1:])

    def commit_parents(self, revision: str = "HEAD") -> tuple[str, ...]:
        """Return commit parents without exposing an unrestricted revision."""

        return self._parents(revision)

    def revision_diff(self, base: str, target: str) -> str:
        """Return an untruncated binary-safe diff for consistency validation."""

        resolved_base = self._revision(base, default="HEAD^")
        resolved_target = self._revision(target, default="HEAD")
        return self._run(
            [
                *self._git_prefix(),
                "diff",
                "--no-ext-diff",
                "--no-textconv",
                "--binary",
                "--full-index",
                "--no-color",
                resolved_base,
                resolved_target,
            ],
            bounded=False,
        )

    def is_ancestor(self, ancestor: str, descendant: str = "HEAD") -> bool:
        resolved_ancestor = self._revision(ancestor, default="HEAD")
        resolved_descendant = self._revision(descendant, default="HEAD")
        try:
            proc = self._runner.run(
                [
                    *self._git_prefix(),
                    "merge-base",
                    "--is-ancestor",
                    resolved_ancestor,
                    resolved_descendant,
                ],
                cwd=self.root,
                timeout_seconds=self.timeout_seconds,
            )
        except Exception as exc:
            raise RuntimeError(
                "read-only commit ancestry inspection could not run"
            ) from exc
        if proc.returncode not in {0, 1}:
            detail = self._bounded(proc.stderr_text().strip())
            raise RuntimeError(
                "read-only commit ancestry inspection failed "
                f"({proc.returncode}): {detail or 'no stderr'}"
            )
        return proc.returncode == 0

    def commit_changed_paths(self, revision: str = "HEAD") -> tuple[str, ...]:
        resolved = self._revision(revision, default="HEAD")
        parents = self._parents(resolved)
        if parents:
            command = [
                *self._git_prefix(),
                "diff",
                "--no-ext-diff",
                "--no-textconv",
                "--name-status",
                "-z",
                "-M",
                "-C",
                parents[0],
                resolved,
            ]
        else:
            command = [
                *self._git_prefix(),
                "diff-tree",
                "--root",
                "--no-commit-id",
                "--name-status",
                "-z",
                "-r",
                "-M",
                "-C",
                resolved,
            ]
        output = self._run_validation_bytes(command)
        paths: set[str] = set()
        fields = [
            item.decode("utf-8", errors="replace")
            for item in output.split(b"\x00")
            if item
        ]
        index = 0
        while index < len(fields):
            status_field = fields[index]
            index += 1
            inline = status_field.split("\t")
            status = inline[0]
            inline_paths = inline[1:]
            path_count = 2 if status[:1] in {"R", "C"} else 1
            current_paths = list(inline_paths)
            while len(current_paths) < path_count and index < len(fields):
                current_paths.append(fields[index])
                index += 1
            paths.update(path for path in current_paths if path)
        return tuple(sorted(paths))

    def commit_diff(self, revision: str = "HEAD") -> str:
        resolved = self._revision(revision, default="HEAD")
        parents = self._parents(resolved)
        if parents:
            command = [
                *self._git_prefix(),
                "diff",
                "--no-ext-diff",
                "--no-textconv",
                "--binary",
                "--full-index",
                "--no-color",
                parents[0],
                resolved,
            ]
        else:
            command = [
                *self._git_prefix(),
                "show",
                "--no-ext-diff",
                "--no-textconv",
                "--binary",
                "--full-index",
                "--no-color",
                "--format=",
                resolved,
            ]
        return self._run(command, bounded=False)

    def stable_patch_ids(self, patch_text: str) -> tuple[str, ...]:
        value = str(patch_text or "")
        if not value.strip():
            return ()
        output = self._run(
            [*self._git_prefix(), "patch-id", "--stable"],
            bounded=False,
            input_bytes=value.encode("utf-8", errors="replace"),
        )
        ids: list[str] = []
        for line in output.splitlines():
            patch_id = line.split(maxsplit=1)[0].lower() if line else ""
            if _PATCH_ID_RE.fullmatch(patch_id):
                ids.append(patch_id)
        return tuple(ids)
