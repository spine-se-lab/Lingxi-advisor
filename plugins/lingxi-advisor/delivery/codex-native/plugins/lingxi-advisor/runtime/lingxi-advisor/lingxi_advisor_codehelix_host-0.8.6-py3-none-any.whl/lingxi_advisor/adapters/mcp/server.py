from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import Any

from ...api import build_lingxi_advisor_capabilities
from ...internal.policy import ExecutionPolicy
from ...capabilities.codify.batch_preparation import (
    PreparedKnowledgeView,
    LingxiAdvisorCodifyBatch,
    LingxiAdvisorCodifyOperation,
)
from ...config import DEFAULT_PROJECT_ROOT, ServerSettings
from ..batch import (
    BatchPreparationWorker,
    FilesystemBatchInputSource,
    FilesystemBatchJobStore,
)
from .gateway import (
    MCPServerPolicy,
    LingxiAdvisorOperatorMCPAdapter,
    _redact_paths,
)
from .operator_tools import _register_operator_tools
from .runtime_tools import _register_runtime_tools

logger = logging.getLogger(__name__)

RUNTIME_INSTRUCTIONS = (
    'Use lingxi.advisor.search for a concrete uncertainty, then pass the '
    'returned knowledge_matches to lingxi.advisor.apply.'
)
OPERATOR_INSTRUCTIONS = (
    'Prepare, monitor, inspect, and read reusable LingxiAdvisor knowledge.'
)

def _fast_mcp(
    *,
    profile: str,
    host: str,
    port: int,
) -> Any:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise RuntimeError(
            'Install lingxi_advisor with its mcp extra to run the server.'
        ) from exc
    try:
        from mcp.server.fastmcp.server import Settings as FastMCPSettings
        FastMCPSettings.model_rebuild()
    except (ImportError, AttributeError, NameError, TypeError):
        logger.debug('FastMCP settings rebuild was not required', exc_info=True)
    return FastMCP(
        f'LingxiAdvisor {profile.title()}',
        instructions=(
            RUNTIME_INSTRUCTIONS if profile == 'runtime'
            else OPERATOR_INSTRUCTIONS
        ),
        host=host,
        port=port,
        stateless_http=True,
        json_response=True,
    )

def create_mcp_server(
    *,
    profile: str = 'runtime',
    settings: ServerSettings | None = None,
    policy: MCPServerPolicy | None = None,
    preretrieved_dir: Path | None = None,
    knowledge_cache_dir: Path | None = None,
    host: str = '127.0.0.1',
    port: int = 8000,
) -> Any:
    if profile not in {'runtime', 'operator'}:
        raise ValueError('profile must be runtime or operator')
    resolved = (settings or ServerSettings()).resolved()
    server_policy = policy or MCPServerPolicy()
    server_policy.validate()
    execution_policy = ExecutionPolicy(
        allow_live_search=server_policy.allow_live_search,
        allow_update_preretrieved=server_policy.allow_update_preretrieved,
        allow_refresh=server_policy.allow_refresh,
    )
    capabilities = build_lingxi_advisor_capabilities(
        settings=resolved,
        execution_policy=execution_policy,
        preretrieved_dir=preretrieved_dir,
        knowledge_cache_dir=knowledge_cache_dir,
        allow_clone=server_policy.allow_clone,
        allow_fetch=server_policy.allow_fetch,
    )
    resolved_preretrieved = (
        preretrieved_dir.expanduser().resolve()
        if preretrieved_dir is not None
        else resolved.project_root / 'preretrieved_issues'
    )
    mcp = _fast_mcp(profile=profile, host=host, port=port)
    if profile == 'runtime':
        _register_runtime_tools(
            mcp,
            activation=capabilities.activation,
            apply_capability=capabilities.apply,
            policy=server_policy,
            settings=resolved,
            host_capabilities_factory=lambda bridge: (
                build_lingxi_advisor_capabilities(
                    settings=resolved,
                    execution_policy=execution_policy,
                    preretrieved_dir=preretrieved_dir,
                    knowledge_cache_dir=knowledge_cache_dir,
                    allow_clone=server_policy.allow_clone,
                    allow_fetch=server_policy.allow_fetch,
                    judge_client_factory=(
                        None if resolved.judge_model_configured
                        else lambda: bridge.judge_client(max_output_tokens=resolved.judge_max_output_tokens)
                    ),
                    light_client=(
                        None if resolved.generator_model_configured
                        else bridge.light_client()
                    ),
                    grounded_client=(
                        None if resolved.generator_model_configured
                        else bridge.grounded_client()
                    ),
                )
            ),
            path_redactor=lambda value: _redact_paths(
                value,
                (
                    (resolved.historical_worktree_root, '<worktree_root>'),
                    (resolved.repository_root, '<repository_root>'),
                    (
                        capabilities.codify.ensure_settings.knowledge_cache_dir,
                        '<knowledge_cache_dir>',
                    ),
                    (resolved_preretrieved, '<preretrieved_dir>'),
                    (resolved.cache_root, '<cache_root>'),
                    (resolved.output_root, '<output_root>'),
                    (resolved.project_root, '<project_root>'),
                ),
            ),
        )
        return mcp
    assert resolved.output_root is not None
    operation = LingxiAdvisorCodifyOperation(
        codify=capabilities.codify,
        preretrieved_dir=resolved_preretrieved,
    )
    input_source = FilesystemBatchInputSource(path=resolved.batch_input_path)
    job_store = FilesystemBatchJobStore(output_root=resolved.output_root)
    worker = BatchPreparationWorker()
    view = PreparedKnowledgeView(
        output_root=resolved.output_root,
        max_knowledge_chars=server_policy.max_knowledge_chars,
    )
    batch = LingxiAdvisorCodifyBatch(
        operation=operation,
        input_source=input_source,
        job_store=job_store,
        worker=worker,
        prepared_view=view,
        max_batch_size=server_policy.max_batch_size,
    )
    operator = LingxiAdvisorOperatorMCPAdapter(
        settings=resolved,
        operation=operation,
        batch=batch,
        prepared_view=view,
        policy=server_policy,
    )
    _register_operator_tools(mcp, operator=operator)
    return mcp

def create_runtime_mcp_server(**kwargs: Any) -> Any:
    return create_mcp_server(profile='runtime', **kwargs)


def create_operator_mcp_server(**kwargs: Any) -> Any:
    return create_mcp_server(profile='operator', **kwargs)

def _load_dotenv(path: Path) -> None:
    if not path.is_file():
        return
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    load_dotenv(path, override=False)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Run an assembled LingxiAdvisor delivery profile.'
    )
    parser.add_argument(
        '--profile',
        choices=['runtime', 'operator'],
        default='runtime',
    )
    parser.add_argument(
        '--transport',
        choices=['stdio', 'streamable-http'],
        default='stdio',
    )
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--project-root', type=Path, default=DEFAULT_PROJECT_ROOT)
    parser.add_argument('--env-file', type=Path)
    parser.add_argument('--preretrieved-dir', type=Path)
    parser.add_argument('--knowledge-cache-dir', type=Path)
    parser.add_argument('--cache-root', type=Path)
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--repository-root', type=Path)
    parser.add_argument('--historical-worktree-root', type=Path)
    parser.add_argument(
        '--batch-input',
        type=Path,
        help=(
            'Server-owned JSONL input for Operator batch preparation. '
            'Can also be set with LINGXI_ADVISOR_BATCH_INPUT_PATH.'
        ),
    )
    parser.add_argument(
        '--allowed-generation-mode',
        action='append',
        choices=['light', 'grounded_analysis'],
    )
    parser.add_argument(
        '--allow-live-search',
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument('--allow-update-preretrieved', action='store_true')
    parser.add_argument('--allow-refresh', action='store_true')
    parser.add_argument('--allow-clone', action='store_true')
    parser.add_argument('--allow-fetch', action='store_true')
    parser.add_argument('--max-search-candidate-count', type=int, default=20)
    parser.add_argument('--max-final-top-k', type=int, default=5)
    parser.add_argument('--max-knowledge-chars', type=int, default=1_000_000)
    parser.add_argument('--max-batch-size', type=int, default=1_000)
    parser.add_argument('--disable-ssl-verify', action='store_true')
    parser.add_argument('--no-trust-env', action='store_true')
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
    )
    return parser.parse_args()

def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    )
    project_root = args.project_root.expanduser().resolve()
    _load_dotenv(
        (args.env_file or project_root / '.env').expanduser().resolve()
    )
    settings = ServerSettings(
        project_root=project_root,
        cache_root=args.cache_root,
        output_root=args.output_root,
        repository_root=args.repository_root,
        historical_worktree_root=args.historical_worktree_root,
        batch_input_path=args.batch_input,
        verify_ssl=not args.disable_ssl_verify,
        trust_env=not args.no_trust_env,
    )
    policy = MCPServerPolicy(
        allowed_generation_modes=tuple(
            args.allowed_generation_mode or ('light', 'grounded_analysis')
        ),
        allow_live_search=args.allow_live_search,
        allow_update_preretrieved=args.allow_update_preretrieved,
        allow_refresh=args.allow_refresh,
        allow_clone=args.allow_clone,
        allow_fetch=args.allow_fetch,
        max_search_candidate_count=args.max_search_candidate_count,
        max_final_top_k=args.max_final_top_k,
        max_knowledge_chars=args.max_knowledge_chars,
        max_batch_size=args.max_batch_size,
    )
    server = create_mcp_server(
        profile=args.profile,
        settings=settings,
        policy=policy,
        preretrieved_dir=args.preretrieved_dir,
        knowledge_cache_dir=args.knowledge_cache_dir,
        host=args.host,
        port=args.port,
    )
    logger.info('Starting LingxiAdvisor %s profile', args.profile)
    server.run(transport=args.transport)


if __name__ == '__main__':
    main()

__all__ = [
    'create_mcp_server',
    'create_operator_mcp_server',
    'create_runtime_mcp_server',
]
