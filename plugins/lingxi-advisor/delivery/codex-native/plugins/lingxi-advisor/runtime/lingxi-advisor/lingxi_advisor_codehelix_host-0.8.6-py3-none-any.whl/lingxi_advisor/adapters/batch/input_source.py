from __future__ import annotations

from pathlib import Path
from typing import Any

from ...internal.io_utils import read_jsonl
from ...internal.search_retrieval.contracts import SWEbenchProInstance


class FilesystemBatchInputSource:
    """Load and validate the JSONL authorized by an Operator Host."""

    def __init__(self, *, path: Path | None) -> None:
        self.path = (
            path.expanduser().resolve()
            if path is not None
            else None
        )

    def load(self, *, max_batch_size: int) -> list[dict[str, Any]]:
        if max_batch_size < 1:
            raise ValueError('max_batch_size must be positive')
        if self.path is None:
            raise RuntimeError(
                'batch input is not configured by the Operator Host'
            )
        if not self.path.is_file():
            raise FileNotFoundError('configured batch input does not exist')

        rows = read_jsonl(self.path)
        if not rows:
            raise ValueError('configured batch input is empty')
        if len(rows) > max_batch_size:
            raise ValueError(
                'batch input exceeds the server limit '
                f'({len(rows)} > {max_batch_size})'
            )

        instances: list[dict[str, Any]] = []
        seen: set[str] = set()
        for line_no, row in enumerate(rows, start=1):
            try:
                normalized = SWEbenchProInstance.from_mapping(row)
            except Exception as exc:
                raise ValueError(
                    'invalid instance at configured batch input line '
                    f'{line_no}: {exc}'
                ) from exc
            if normalized.instance_id in seen:
                raise ValueError(
                    'duplicate instance_id at configured batch input line '
                    f'{line_no}: {normalized.instance_id}'
                )
            seen.add(normalized.instance_id)
            instances.append(normalized.public_dict())
        return instances


__all__ = ['FilesystemBatchInputSource']
