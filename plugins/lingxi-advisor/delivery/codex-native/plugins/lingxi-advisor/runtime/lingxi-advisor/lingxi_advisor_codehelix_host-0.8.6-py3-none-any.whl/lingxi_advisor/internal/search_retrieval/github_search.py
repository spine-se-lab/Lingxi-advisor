from __future__ import annotations

import collections
import hashlib
import json
import logging
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from .closed_issues import ClosedIssueProvider
from .contracts import CandidatePoolOptions, CandidatePoolResult, SWEbenchProInstance
from .fix_discovery import FixDiscoveryService
from .repository import RepositoryProvider
from .. import github as v4

logger = logging.getLogger(__name__)


class CandidatePoolRetriever:
    SCHEMA_VERSION = 6

    def __init__(
        self,
        *,
        client: v4.GithubClient,
        cache_root: Path,
        closed_issue_provider: ClosedIssueProvider,
        fix_discovery: FixDiscoveryService,
        repository_provider: RepositoryProvider,
    ) -> None:
        self.client = client
        self.cache_root = cache_root
        self.closed_issue_provider = closed_issue_provider
        self.fix_discovery = fix_discovery
        self.repository_provider = repository_provider

    @staticmethod
    def _request_id(instance: SWEbenchProInstance, options: CandidatePoolOptions) -> str:
        payload = {
            "instance": instance.public_dict(),
            "options": options.to_dict(),
            "retriever_schema": CandidatePoolRetriever.SCHEMA_VERSION,
            "v4_backend": v4.SCRIPT_VERSION,
        }
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest()[:24]

    @staticmethod
    def _backend_args(options: CandidatePoolOptions) -> SimpleNamespace:
        return SimpleNamespace(
            primary_search_type=options.search_type,
            fallback_search_type=options.fallback_search_type,
            primary_query_text_max_chars=(
                options.primary_query_text_max_chars
            ),
            query_text_max_chars=options.query_text_max_chars,
            github_query_max_total_chars=(
                options.github_query_max_total_chars
            ),
            max_single_term_fallbacks=options.max_single_term_fallbacks,
            search_pages=options.search_pages,
            fallback_search_pages=options.fallback_search_pages,
        )

    @staticmethod
    def _candidate_patch_present(record: dict[str, Any]) -> bool:
        return bool(
            v4.safe_str(record.get("retrieved_issue_ground_truth_patch"))
            or v4.safe_str(record.get("retrieved_patch"))
        )

    @staticmethod
    def _sanitize_output_row(row: dict[str, Any], pool_position: int) -> dict[str, Any]:
        """Preserve legacy-compatible fields without mislabeling GitHub score."""
        github_score = v4.safe_float(row.get("github_search_score"), 0.0)
        row["candidate_pool_position"] = pool_position
        row["reranked_position"] = pool_position
        row["qwen_reranked"] = False
        row["retrieval_similarity_estimate"] = None
        row["relevance_score"] = None
        row["github_search_score"] = github_score
        row["ranking_source"] = row.get("ranking_source") or "github_search_candidate_pool"
        row["candidate_pool_stage"] = (
            "semantic_first_closed_issue_search_and_fix_discovery"
        )
        return row

    def retrieve(
        self,
        instance: SWEbenchProInstance,
        options: CandidatePoolOptions,
    ) -> tuple[CandidatePoolResult, list[dict[str, Any]], list[dict[str, Any]]]:
        options.validate()
        request_id = self._request_id(instance, options)
        is_evaluation = options.retrieval_strategy == "evaluation"
        backend_instance = instance.retrieval_mapping()
        repo = instance.repo
        repo_identity = v4.repo_identity_key(repo)
        existing_repo_path = self.repository_provider.repo_path(repo)
        repo_checkout = existing_repo_path if (existing_repo_path / ".git").exists() else None

        base_time, base_time_source = v4.resolve_base_commit_time(
            instance=backend_instance,
            repo_checkout=repo_checkout,
            client=self.client,
            cache_dir=self.cache_root / "commit_times",
        )
        if instance.target_leakage_check:
            boundary_ts, boundary_iso, boundary_source = v4.compute_boundary(
                backend_instance, base_time
            )
        else:
            boundary_ts, boundary_iso = 0.0, ""
            boundary_source = "target_specific_leakage_check_disabled"
        if instance.target_leakage_check and boundary_ts <= 0.0:
            result = CandidatePoolResult(
                schema_version=self.SCHEMA_VERSION,
                status="failed",
                request_id=request_id,
                instance=instance.public_dict(),
                boundary={
                    "timestamp": None,
                    "iso": None,
                    "source": boundary_source,
                    "base_commit_time_source": base_time_source,
                },
                requested_pool_size=options.pool_size,
                returned_pool_size=0,
                search_exhausted=False,
                phases_processed=0,
                total_phases=0,
                error="Unable to resolve a trustworthy base-commit temporal boundary.",
            )
            return result, [], []

        catalog = None
        if is_evaluation:
            logger.info(
                "Evaluation retrieval is loading the closed-issue catalog for %s; "
                "this may take several minutes on an uncached repository.",
                repo,
            )
            catalog = self.closed_issue_provider.load(
                repo=repo,
                client=self.client,
                boundary_ts=boundary_ts,
                target_issue_number=(
                    instance.instance_issue_number
                    if instance.target_leakage_check
                    else None
                ),
                ttl_seconds=options.closed_issues_ttl_seconds,
                refresh=options.refresh_closed_issues,
                enable_issue_number_guard=(
                    options.enable_issue_number_guard
                    and instance.target_leakage_check
                ),
            )

        args = self._backend_args(options)
        full_plan = v4.build_search_plan(backend_instance, boundary_ts, args)
        plan = full_plan[: options.max_phases] if options.max_phases is not None else full_plan
        search_cache_dir = self.cache_root / "github_search"

        target_commit = (
            v4.infer_target_commit_from_instance(backend_instance)
            if instance.target_leakage_check
            else ""
        )
        # MCP/tool semantics are instance-local: reject the current solution commit
        # (including serialized mentions), but do not blacklist target commits from
        # unrelated benchmark instances. Temporal boundaries handle future fixes.
        current_instance_forbidden_commits = {target_commit} if target_commit else set()

        candidates: list[dict[str, Any]] = []
        emitted_record_keys: set[str] = set()
        unique_hit_keys: set[str] = set()
        search_audit: list[dict[str, Any]] = []
        rejection_audit: list[dict[str, Any]] = []
        rejection_counts: collections.Counter[str] = collections.Counter()
        discovery_sources: collections.Counter[str] = collections.Counter()
        observed_repository_names: collections.Counter[str] = collections.Counter()
        repository_case_only_matches = 0
        search_failures: list[dict[str, Any]] = []
        incomplete_search_responses = 0
        global_rank = 0
        phases_processed = 0

        for phase_index, phase in enumerate(plan):
            phases_processed += 1
            phase_name = str(phase["phase"])
            retrieval_tier = int(phase.get("tier") or 0)
            search_kind = str(phase["kind"])
            phase_search_type = str(
                phase.get("search_type") or options.search_type
            )
            query_variant = str(phase.get("query_variant") or "")
            github_query = str(phase["github_query"])
            query_text = str(phase.get("query_text") or "")
            pages = int(phase["pages"])
            before_count = len(candidates)
            phase_rejections: collections.Counter[str] = collections.Counter()
            ranked_hits: list[dict[str, Any]] = []
            phase_raw_items = 0
            phase_unique_hits = 0
            phase_observed_repository_names: collections.Counter[str] = (
                collections.Counter()
            )
            phase_repository_case_only_matches = 0
            phase_pages_processed = 0
            requested_search_type = phase_search_type
            actual_search_type = phase_search_type
            search_fallback_reason: Any = None
            search_response_metadata: dict[str, Any] = {}
            search_type_fallback = False
            phase_error: dict[str, Any] | None = None
            phase_incomplete_results = False
            logger.info(
                "Retrieval phase %d/%d started: strategy=%s phase=%s candidates=%d/%d",
                phase_index + 1,
                len(plan),
                options.retrieval_strategy,
                phase_name,
                len(candidates),
                options.pool_size,
            )

            for page in range(1, pages + 1):
                wrapped = v4.run_search_with_cache(
                    client=self.client,
                    query=github_query,
                    search_type=phase_search_type,
                    per_page=options.per_page,
                    page=page,
                    text_match=options.text_match,
                    cache_dir=search_cache_dir,
                    refresh_cache=options.refresh_search_cache,
                    sleep_seconds=options.search_sleep_seconds,
                )
                payload = wrapped.get("payload") or {}
                if bool(payload.get("incomplete_results")):
                    phase_incomplete_results = True
                    incomplete_search_responses += 1
                requested_search_type = str(
                    wrapped.get("requested_search_type")
                    or phase_search_type
                )
                actual_search_type = str(
                    wrapped.get("actual_search_type")
                    or payload.get("search_type")
                    or requested_search_type
                )
                search_fallback_reason = wrapped.get("search_fallback_reason")
                search_response_metadata = wrapped.get("search_response_metadata")
                if not isinstance(search_response_metadata, dict):
                    search_response_metadata = {
                        key: value
                        for key, value in payload.items()
                        if key not in {"items", "total_count", "incomplete_results"}
                    }
                search_type_fallback = bool(
                    wrapped.get("search_type_fallback")
                    or actual_search_type != requested_search_type
                    or search_fallback_reason
                )
                query_error = str(
                    payload.get("query_error")
                    or wrapped.get("query_error")
                    or ""
                ).strip()
                if query_error:
                    phase_error = {
                        "phase": phase_name,
                        "page": page,
                        "requested_search_type": requested_search_type,
                        "actual_search_type": actual_search_type,
                        "status_code": payload.get(
                            "query_error_status_code"
                        ),
                        "error": query_error,
                    }
                    search_failures.append(phase_error)
                    phase_pages_processed += 1
                    break
                items = payload.get("items") or []
                if not isinstance(items, list):
                    items = []
                phase_pages_processed += 1
                phase_raw_items += len(items)
                if not items:
                    break

                for page_position, item in enumerate(items):
                    if not isinstance(item, dict):
                        continue
                    rank_in_query = (
                        (page - 1) * options.per_page
                        + page_position
                        + 1
                    )
                    global_rank += 1
                    item_repo = v4.normalize_repo(
                        str(item.get("repository_url") or "").split("/repos/")[-1]
                    )
                    if item_repo:
                        observed_repository_names[item_repo] += 1
                        phase_observed_repository_names[item_repo] += 1
                    if item_repo and v4.repo_identity_key(item_repo) != repo_identity:
                        reason = "repo_mismatch_search_hit"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        continue
                    if item_repo and item_repo != repo:
                        repository_case_only_matches += 1
                        phase_repository_case_only_matches += 1
                    is_pr = "pull_request" in item
                    if search_kind == "issue" and is_pr:
                        reason = "pr_pseudo_issue_search_hit"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        continue
                    if search_kind == "pr" and not is_pr:
                        continue
                    number = v4.parse_issue_number_int(item.get("number"))
                    if number is None:
                        reason = "missing_search_hit_number"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        continue
                    hit_key = f"{search_kind}:{repo}#{number}"
                    if hit_key in unique_hit_keys:
                        reason = "duplicate_search_hit"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        continue
                    unique_hit_keys.add(hit_key)
                    early_reject = (
                        v4.early_hit_time_rejects(item, boundary_ts)
                        if instance.target_leakage_check
                        else None
                    )
                    if early_reject:
                        rejection_counts[early_reject] += 1
                        phase_rejections[early_reject] += 1
                        rejection_audit.append({
                            "phase": phase_name,
                            "kind": search_kind,
                            "number": number,
                            "reason": early_reject,
                        })
                        continue
                    hit = dict(item)
                    hit["_global_rank"] = global_rank
                    hit["_github_rank_in_query"] = rank_in_query
                    hit["_github_page"] = page
                    hit["_page_position"] = page_position
                    hit["_retrieval_tier"] = retrieval_tier
                    hit["_phase_search_type"] = phase_search_type
                    hit["_github_requested_search_type"] = requested_search_type
                    hit["_github_actual_search_type"] = actual_search_type
                    hit["_github_search_type_fallback"] = search_type_fallback
                    hit["_github_search_fallback_reason"] = search_fallback_reason
                    hit["_github_search_response_metadata"] = search_response_metadata
                    ranked_hits.append(hit)
                    phase_unique_hits += 1

            # Preserve GitHub's result order for this exact query. The
            # numeric search score is provenance only and is commonly constant.
            ranked_hits.sort(
                key=lambda item: int(
                    item.get("_github_rank_in_query") or 10**12
                )
            )

            for hit in ranked_hits[: options.max_search_hits_to_resolve]:
                number = v4.parse_issue_number_int(hit.get("number"))
                if number is None:
                    continue

                records: list[tuple[dict[str, Any], str]] = []
                if search_kind == "issue":
                    issue = (
                        catalog.issues_by_number.get(number)
                        if catalog is not None
                        else dict(hit)
                    )
                    if issue is None:
                        reason = "issue_not_in_eligible_closed_issue_universe"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        rejection_audit.append({
                            "phase": phase_name,
                            "kind": search_kind,
                            "number": number,
                            "reason": reason,
                        })
                        continue
                    record, source = self.fix_discovery.discover_issue(
                        repo=repo,
                        issue_number=number,
                        issue=issue,
                        client=self.client,
                        include_patch_text=options.include_patch_text,
                        enable_commit_message_fallback=options.enable_commit_message_fallback,
                        refresh_repository=options.refresh_repository,
                        closed_pulls_ttl_seconds=options.closed_pulls_ttl_seconds,
                        refresh_closed_pulls=options.refresh_closed_pulls,
                        allow_exhaustive_fallbacks=is_evaluation,
                    )
                    discovery_sources[source] += 1
                    if record is None:
                        rejection_counts[source] += 1
                        phase_rejections[source] += 1
                        rejection_audit.append({
                            "phase": phase_name,
                            "kind": search_kind,
                            "number": number,
                            "reason": source,
                        })
                        continue
                    records.append((record, source))
                else:
                    pr_records, source = self.fix_discovery.discover_pr(
                        repo=repo,
                        pr_number=number,
                        eligible_issues=(
                            catalog.issues_by_number
                            if catalog is not None
                            else None
                        ),
                        client=self.client,
                        include_patch_text=options.include_patch_text,
                    )
                    discovery_sources[source] += 1
                    if not pr_records:
                        rejection_counts[source] += 1
                        phase_rejections[source] += 1
                        rejection_audit.append({
                            "phase": phase_name,
                            "kind": search_kind,
                            "number": number,
                            "reason": source,
                        })
                        continue
                    records.extend((record, source) for record in pr_records)

                for record, source in records:
                    issue_number = v4.parse_issue_number_int(record.get("issue_number"))
                    if issue_number is None or (
                        catalog is not None
                        and issue_number not in catalog.issues_by_number
                    ):
                        reason = "resolved_record_not_an_eligible_closed_issue"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        continue
                    unique_key = v4.record_unique_key(record)
                    if unique_key in emitted_record_keys:
                        reason = "duplicate_resolved_issue"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        continue
                    if options.include_patch_text and not self._candidate_patch_present(record):
                        reason = "missing_historical_patch"
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        rejection_audit.append({
                            "phase": phase_name,
                            "kind": search_kind,
                            "number": issue_number,
                            "reason": reason,
                            "source": source,
                        })
                        continue

                    safe, reason, details = v4.validate_candidate(
                        instance=backend_instance,
                        record=record,
                        base_time=base_time,
                        all_target_commits=current_instance_forbidden_commits,
                        enable_issue_number_guard=(
                            options.enable_issue_number_guard
                            and instance.target_leakage_check
                        ),
                        enable_target_leakage_check=(
                            instance.target_leakage_check
                        ),
                    )
                    if not safe:
                        rejection_counts[reason] += 1
                        phase_rejections[reason] += 1
                        rejection_audit.append({
                            "phase": phase_name,
                            "kind": search_kind,
                            "number": issue_number,
                            "reason": reason,
                            "source": source,
                            "details": details,
                        })
                        continue

                    row = v4.make_output_record(
                        instance=backend_instance,
                        historical_record=record,
                        github_hit=hit,
                        query_text=query_text,
                        github_query=github_query,
                        search_phase=phase_name,
                        search_kind=search_kind,
                        search_type=phase_search_type,
                        search_rank=int(
                            hit.get("_github_rank_in_query") or 0
                        ),
                        safe_position=len(candidates),
                        base_time=base_time,
                        base_time_source=base_time_source,
                        leakage_details=details,
                        record_origin=source,
                    )
                    row = self._sanitize_output_row(row, len(candidates))
                    row["retrieval_tier"] = retrieval_tier
                    row["query_variant"] = query_variant
                    row["github_rank_in_query"] = int(
                        hit.get("_github_rank_in_query") or 0
                    )
                    row["github_result_page"] = int(
                        hit.get("_github_page") or 0
                    )
                    row["github_global_encounter_order"] = int(
                        hit.get("_global_rank") or 0
                    )
                    row["problem_statement_original_chars"] = int(
                        phase.get("problem_statement_original_chars")
                        or len(instance.problem_statement)
                    )
                    row["query_text_sent_chars"] = int(
                        phase.get("query_text_sent_chars")
                        or len(query_text)
                    )
                    row["query_text_truncated"] = bool(
                        phase.get("query_text_truncated")
                    )
                    row["github_query_hard_truncated"] = bool(
                        phase.get("github_query_hard_truncated")
                    )
                    row["extracted_keyword_count"] = int(
                        phase.get("extracted_keyword_count") or 0
                    )
                    row["extracted_keywords_used"] = list(
                        phase.get("extracted_keywords_used") or []
                    )
                    row["derived_issue_title"] = str(
                        phase.get("derived_issue_title") or ""
                    )
                    row["github_requested_search_type"] = hit.get(
                        "_github_requested_search_type"
                    )
                    row["github_actual_search_type"] = hit.get(
                        "_github_actual_search_type"
                    )
                    row["github_search_type_fallback"] = hit.get(
                        "_github_search_type_fallback", False
                    )
                    row["github_search_fallback_reason"] = hit.get(
                        "_github_search_fallback_reason"
                    )
                    row["github_search_response_metadata"] = hit.get(
                        "_github_search_response_metadata", {}
                    )
                    row["closed_issue_catalog_source"] = (
                        "github_rest_closed_issue_universe"
                        if catalog is not None
                        else "bounded_search_hit"
                    )
                    row["closed_issue_catalog_fetched_at"] = (
                        catalog.fetched_at if catalog is not None else None
                    )
                    candidates.append(row)
                    emitted_record_keys.add(unique_key)
                    if not is_evaluation and len(candidates) >= options.pool_size:
                        break
                if not is_evaluation and len(candidates) >= options.pool_size:
                    break

            search_audit.append(
                {
                    "phase_index": phase_index,
                    "phase": phase_name,
                    "retrieval_tier": retrieval_tier,
                    "kind": search_kind,
                    "query_variant": query_variant,
                    "query_text": query_text,
                    "github_query": github_query,
                    "extracted_keyword_count": int(
                        phase.get("extracted_keyword_count") or 0
                    ),
                    "extracted_keywords_used": list(
                        phase.get("extracted_keywords_used") or []
                    ),
                    "derived_issue_title": str(
                        phase.get("derived_issue_title") or ""
                    ),
                    "requested_search_type": requested_search_type,
                    "actual_search_type": actual_search_type,
                    "search_type_fallback": search_type_fallback,
                    "search_fallback_reason": search_fallback_reason,
                    "search_response_metadata": search_response_metadata,
                    "status": (
                        "search_failed"
                        if phase_error is not None
                        else "incomplete"
                        if phase_incomplete_results
                        else "completed"
                    ),
                    "query_error": (
                        phase_error["error"]
                        if phase_error is not None
                        else None
                    ),
                    "pages_configured": pages,
                    "pages_processed": phase_pages_processed,
                    "raw_items": phase_raw_items,
                    "raw_items_before_repository_filter": phase_raw_items,
                    "observed_repository_names": dict(
                        phase_observed_repository_names
                    ),
                    "repository_case_only_matches": (
                        phase_repository_case_only_matches
                    ),
                    "unique_hits": phase_unique_hits,
                    "records_added": len(candidates) - before_count,
                    "pool_size_after_phase": len(candidates),
                    "candidate_union_size_after_phase": len(candidates),
                    "rejection_counts": dict(phase_rejections),
                }
            )
            logger.info(
                "Retrieval phase %d/%d finished: strategy=%s phase=%s "
                "status=%s candidates=%d/%d",
                phase_index + 1,
                len(plan),
                options.retrieval_strategy,
                phase_name,
                search_audit[-1]["status"],
                len(candidates),
                options.pool_size,
            )
            if not is_evaluation and len(candidates) >= options.pool_size:
                break

        search_exhausted = (
            not search_failures
            and not incomplete_search_responses
            and phases_processed >= len(full_plan)
        )
        if incomplete_search_responses and candidates:
            status = "partial"
        elif len(candidates) >= options.pool_size:
            status = "completed"
        elif candidates:
            status = "partial"
        elif search_failures or incomplete_search_responses:
            status = "failed"
        else:
            status = "no_candidates"
        error = (
            (
                f"{len(search_failures)} GitHub search phase(s) failed; "
                f"{incomplete_search_responses} response(s) were incomplete."
            )
            if status == "failed"
            else None
        )
        result = CandidatePoolResult(
            schema_version=self.SCHEMA_VERSION,
            status=status,
            request_id=request_id,
            instance=instance.public_dict(),
            boundary={
                "timestamp": (
                    boundary_ts if instance.target_leakage_check else None
                ),
                "iso": boundary_iso or None,
                "source": boundary_source,
                "base_commit_time_source": base_time_source,
            },
            requested_pool_size=options.pool_size,
            returned_pool_size=len(candidates),
            search_exhausted=search_exhausted,
            phases_processed=phases_processed,
            total_phases=len(full_plan),
            candidates=candidates,
            stats={
                "retrieval_strategy": options.retrieval_strategy,
                "closed_issue_catalog": (
                    catalog.to_summary() if catalog is not None else None
                ),
                "unique_search_hits": len(unique_hit_keys),
                "resolved_unique_issues": len(emitted_record_keys),
                "rejection_counts": dict(rejection_counts),
                "discovery_sources": dict(discovery_sources),
                "observed_repository_names": dict(observed_repository_names),
                "repository_case_only_matches": repository_case_only_matches,
                "primary_search_type": options.search_type,
                "fallback_search_type": options.fallback_search_type,
                "search_policy": v4.search_policy_name(
                    options.search_type,
                    options.fallback_search_type,
                ),
                "collection_policy": (
                    "all_configured_queries_complete_deduplicated_union"
                    if is_evaluation
                    else "bounded_stop_after_requested_pool"
                ),
                "selection_limit_applied_during_retrieval": not is_evaluation,
                "candidate_union_count": len(candidates),
                "ranking_policy": "deferred_until_post_retrieval_safety",
                "phases_available": len(full_plan),
                "phases_in_current_budget": len(plan),
                "phase_budget_limited": len(plan) < len(full_plan),
                "v4_backend_version": v4.SCRIPT_VERSION,
                "target_commit_policy": "current_instance_only",
                "target_leakage_check": instance.target_leakage_check,
                "search_failures": search_failures,
                "incomplete_search_responses": incomplete_search_responses,
            },
            error=error,
        )
        return result, search_audit, rejection_audit
