from __future__ import annotations

import errno
from pathlib import Path
from types import TracebackType

from filelock import FileLock as _PlatformFileLock
from filelock import Timeout as _LockTimeout
from .execution import checkpoint, bounded_timeout


class FileLock:
    """Cross-platform lock for concurrent CLI and MCP worker processes."""

    def __init__(self, path: Path, *, blocking: bool = True):
        self.path = path
        self.blocking = blocking
        self._lock = _PlatformFileLock(str(path))
        self.acquired = False

    def __enter__(self) -> "FileLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.acquired:
            return self
        try:
            while True:
                checkpoint()
                try:
                    self._lock.acquire(timeout=bounded_timeout(0.1) if self.blocking else 0)
                    break
                except _LockTimeout:
                    if not self.blocking:
                        raise
        except _LockTimeout as exc:
            raise BlockingIOError(
                errno.EWOULDBLOCK,
                f"lock is already held: {self.path}",
            ) from exc
        self.acquired = True
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if self.acquired:
            self._lock.release()
        self.acquired = False
