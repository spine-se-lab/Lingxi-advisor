from __future__ import annotations

import dataclasses
import hashlib
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping

from ....artifacts.interface import KnowledgeArtifactRef
from ....internal.generation_contracts import (
    GenerationMode,
    validate_generation_mode,
)
from ....internal.search_retrieval.contracts import (
    SWEbenchProInstance,
    SearchRetrievalOptions,
    SimilarityGateOptions,
)
from .issue_resolution import (
    DefaultTargetIssueResolver,
    TargetIssue,
    TargetIssueResolver,
)

LINGXI_ADVISOR_SEARCH_SCHEMA_VERSION = 1
LingxiAdvisorSearchStatus = Literal[
    "completed",
    "miss",
    "partial",
    "no_candidates",
    "failed",
]


@dataclass(frozen=True)
class LingxiAdvisorSearchRequest:
    """Portable runtime request for issue text or a GitHub issue identity."""

    issue_description: str
    context: Mapping[str, Any] = field(default_factory=dict)
    target_issue: TargetIssue | None = None
    generation_mode: GenerationMode = "light"
    search_options: SearchRetrievalOptions = field(
        default_factory=SearchRetrievalOptions
    )
    gate_options: SimilarityGateOptions = field(
        default_factory=SimilarityGateOptions
    )
    resume: bool = True
    refresh_instance_metadata: bool = False
    target_issue_resolver: TargetIssueResolver = field(
        default_factory=DefaultTargetIssueResolver,
        repr=False,
        compare=False,
    )

    def validate(self) -> None:
        if not isinstance(self.context, Mapping):
            raise TypeError("context must be a mapping")
        description = self.issue_description.strip()
        github_issue_can_supply_description = bool(
            self.search_options.retrieval_strategy == "bounded"
            and self.repository
            and self.issue_number is not None
        )
        if not description and not github_issue_can_supply_description:
            raise ValueError(
                "issue_description cannot be empty unless bounded Search "
                "receives repo and issue_number"
            )
        if len(self.issue_description) > 200_000:
            raise ValueError("issue_description exceeds the runtime limit")
        if self.target_issue is not None:
            self.target_issue.validate()
        forbidden = {
            "patch",
            "target_patch",
            "test_patch",
            "gold_patch",
            "hidden_tests",
            "api_key",
            "credentials",
            "server_path",
        }
        supplied_forbidden = sorted(
            str(key)
            for key in self.context
            if str(key).strip().lower() in forbidden
        )
        if supplied_forbidden:
            raise ValueError(
                "context contains forbidden field(s): "
                + ", ".join(supplied_forbidden)
            )
        self.resolved_target_issue
        validate_generation_mode(self.generation_mode)
        self.search_options.validate()
        self.gate_options.validate()

    @property
    def repository(self) -> str:
        """Caller-supplied repository; never inferred by the runtime."""

        return str(self.context.get("repo") or "").strip().strip("/")

    @property
    def resolved_target_issue(self) -> TargetIssue | None:
        return self.target_issue_resolver.resolve(
            explicit_target=self.target_issue,
            context=self.context,
        )

    @property
    def resolved_issue_mode(self) -> Literal["existing_target", "new_issue"]:
        if self.search_options.retrieval_strategy != "evaluation":
            return "new_issue"
        return (
            "existing_target"
            if self.resolved_target_issue is not None
            else "new_issue"
        )

    @property
    def target_leakage_check_enabled(self) -> bool:
        """Only evaluation targets use target-specific leakage checks."""

        return self.resolved_issue_mode == "existing_target"

    @property
    def instance_id(self) -> str:
        target = self.resolved_target_issue
        explicit = target.instance_id if target is not None else ""
        if explicit:
            return explicit
        repo = self.repository
        issue_number = self.issue_number
        if repo and issue_number is not None:
            repo_slug = repo.replace("/", "__")
            return f"github-{repo_slug}-issue-{issue_number}"
        if self.new_issue_live_search:
            normalized_issue = " ".join(self.issue_description.split())
            digest = hashlib.sha256(
                f"{repo.lower()}\0{normalized_issue}".encode("utf-8")
            ).hexdigest()[:16]
            repo_slug = repo.replace("/", "__")
            return f"github-{repo_slug}-new-{digest}"
        return ""

    @property
    def issue_number(self) -> int | None:
        target = self.resolved_target_issue
        return target.issue_number if target is not None else None

    @property
    def new_issue_live_search(self) -> bool:
        """Whether repository context describes an unfiled new issue."""

        repo = self.repository
        return bool(
            repo
            and self.resolved_issue_mode == "new_issue"
        )

    def live_instance(self) -> dict[str, Any] | None:
        """Return context for either the primary or GitHub fallback path."""

        internal = self.internal_instance()
        if internal is not None:
            return internal.public_dict()
        repo = str(self.context.get("repo") or "").strip()
        if not repo:
            return None
        payload = dict(self.context)
        if self.issue_number is None:
            if not self.new_issue_live_search:
                return None
            payload["_lingxi_advisor_new_issue_search"] = True
        else:
            payload["issue_number"] = self.issue_number
            payload["instance_issue_number"] = self.issue_number
            if self.resolved_issue_mode == "new_issue":
                payload["_lingxi_advisor_new_issue_search"] = True
        target = self.resolved_target_issue
        if target is not None and target.created_at:
            payload["instance_create_at"] = target.created_at
        payload["instance_id"] = self.instance_id
        payload["problem_statement"] = self.issue_description
        payload["issue_mode"] = self.resolved_issue_mode
        payload["target_leakage_check"] = (
            self.target_leakage_check_enabled
        )
        return payload

    def internal_instance(self) -> SWEbenchProInstance | None:
        """Adapt complete context to the internal SWE-bench retrieval type."""

        payload = dict(self.context)
        if "instance_id" not in payload and payload.get("issue_id"):
            payload["instance_id"] = payload["issue_id"]
        target = self.resolved_target_issue
        if target is not None:
            if target.instance_id:
                payload["instance_id"] = target.instance_id
            if target.issue_number is not None:
                payload["instance_issue_number"] = target.issue_number
            if target.created_at:
                payload["instance_create_at"] = target.created_at
        payload["problem_statement"] = self.issue_description
        payload["issue_mode"] = self.resolved_issue_mode
        payload["target_leakage_check"] = (
            self.target_leakage_check_enabled
        )
        required = (
            "repo",
            "instance_id",
            "base_commit",
            "problem_statement",
        )
        if not all(str(payload.get(name) or "").strip() for name in required):
            return None
        return SWEbenchProInstance.from_mapping(payload)

    @classmethod
    def from_instance(
        cls,
        instance: Mapping[str, Any] | SWEbenchProInstance,
        **kwargs: Any,
    ) -> "LingxiAdvisorSearchRequest":
        normalized = (
            instance
            if isinstance(instance, SWEbenchProInstance)
            else SWEbenchProInstance.from_mapping(instance)
        )
        kwargs.setdefault(
            "target_issue",
            TargetIssue(
                instance_id=normalized.instance_id,
                issue_number=normalized.instance_issue_number,
                created_at=normalized.instance_create_at,
            ),
        )
        value = cls(
            issue_description=normalized.problem_statement,
            context=normalized.public_dict(),
            **kwargs,
        )
        value.validate()
        return value

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "issue_description": self.issue_description,
            "context": dict(self.context),
            "target_issue": (
                self.target_issue.to_dict()
                if self.target_issue is not None
                else None
            ),
            "generation_mode": self.generation_mode,
            "search_options": self.search_options.to_dict(),
            "gate_options": self.gate_options.to_dict(),
            "resume": self.resume,
            "refresh_instance_metadata": (
                self.refresh_instance_metadata
            ),
        }

    @classmethod
    def from_mapping(
        cls,
        value: Mapping[str, Any],
    ) -> "LingxiAdvisorSearchRequest":
        search_value = value.get("search_options")
        search_options = (
            search_value
            if isinstance(search_value, SearchRetrievalOptions)
            else SearchRetrievalOptions.from_mapping(search_value)  # type: ignore[arg-type]
        )
        gate_value = value.get("gate_options")
        gate_options = (
            gate_value
            if isinstance(gate_value, SimilarityGateOptions)
            else SimilarityGateOptions.from_mapping(gate_value)  # type: ignore[arg-type]
        )
        issue_description = str(
            value.get("issue_description")
            or value.get("problem_statement")
            or ""
        )
        if (
            value.get("issue_description")
            and value.get("problem_statement")
            and str(value["issue_description"]).strip()
            != str(value["problem_statement"]).strip()
        ):
            raise ValueError(
                "issue_description conflicts with problem_statement"
            )
        target_value = value.get("target_issue")
        target_issue = (
            target_value
            if isinstance(target_value, TargetIssue)
            else TargetIssue.from_mapping(target_value)
            if isinstance(target_value, Mapping)
            else None
        )
        if target_value is not None and target_issue is None:
            raise TypeError("target_issue must be a mapping")
        if "leakage_check" in value:
            raise ValueError(
                "leakage_check is derived by LingxiAdvisor and cannot be set"
            )
        request = cls(
            issue_description=issue_description,
            context=(
                dict(value.get("context") or {})
                if isinstance(value.get("context") or {}, Mapping)
                else value.get("context")  # type: ignore[arg-type]
            ),
            target_issue=target_issue,
            generation_mode=str(
                value.get("generation_mode") or "light"
            ),  # type: ignore[arg-type]
            search_options=search_options,
            gate_options=gate_options,
            resume=bool(value.get("resume", True)),
            refresh_instance_metadata=bool(
                value.get("refresh_instance_metadata", False)
            ),
        )
        request.validate()
        return request


@dataclass(frozen=True)
class KnowledgeMatch:
    artifact_ref: KnowledgeArtifactRef
    knowledge_xml: str
    artifact_sha256: str
    repo: str
    historical_issue_number: int | None
    historical_issue_url: str
    historical_issue_title: str
    historical_candidate_fingerprint: str
    cache_hit: bool
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "KnowledgeMatch":
        if not isinstance(value, Mapping):
            raise TypeError("knowledge match must be a mapping")
        ref_value = value.get("artifact_ref")
        if isinstance(ref_value, KnowledgeArtifactRef):
            artifact_ref = ref_value
        elif isinstance(ref_value, Mapping):
            artifact_ref = KnowledgeArtifactRef.from_mapping(ref_value)
        else:
            raise ValueError("knowledge match requires artifact_ref")
        issue_number_value = value.get("historical_issue_number")
        issue_number: int | None = None
        if issue_number_value not in (None, ""):
            try:
                issue_number = int(issue_number_value)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "historical_issue_number must be an integer"
                ) from exc
            if issue_number < 1:
                raise ValueError(
                    "historical_issue_number must be positive"
                )
        metadata = value.get("metadata")
        if metadata is not None and not isinstance(metadata, Mapping):
            raise TypeError("knowledge match metadata must be a mapping")
        return cls(
            artifact_ref=artifact_ref,
            knowledge_xml=str(value.get("knowledge_xml") or ""),
            artifact_sha256=str(value.get("artifact_sha256") or ""),
            repo=str(value.get("repo") or ""),
            historical_issue_number=issue_number,
            historical_issue_url=str(
                value.get("historical_issue_url") or ""
            ),
            historical_issue_title=str(
                value.get("historical_issue_title") or ""
            ),
            historical_candidate_fingerprint=str(
                value.get("historical_candidate_fingerprint") or ""
            ),
            cache_hit=bool(value.get("cache_hit", False)),
            metadata=dict(metadata or {}),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "artifact_ref": self.artifact_ref.to_dict(),
            "knowledge_xml": self.knowledge_xml,
            "artifact_sha256": self.artifact_sha256,
            "repo": self.repo,
            "historical_issue_number": self.historical_issue_number,
            "historical_issue_url": self.historical_issue_url,
            "historical_issue_title": self.historical_issue_title,
            "historical_candidate_fingerprint": (
                self.historical_candidate_fingerprint
            ),
            "cache_hit": self.cache_hit,
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True)
class UnresolvedKnowledge:
    artifact_ref: KnowledgeArtifactRef | None
    repo: str
    historical_issue_number: int | None
    historical_candidate_fingerprint: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "artifact_ref": (
                self.artifact_ref.to_dict()
                if self.artifact_ref is not None
                else None
            ),
            "repo": self.repo,
            "historical_issue_number": self.historical_issue_number,
            "historical_candidate_fingerprint": (
                self.historical_candidate_fingerprint
            ),
            "reason": self.reason,
        }


@dataclass
class LingxiAdvisorSearchResult:
    schema_version: int
    status: LingxiAdvisorSearchStatus
    instance_id: str
    generation_mode: GenerationMode
    prepare_if_missing: bool
    issue_mode: Literal["existing_target", "new_issue"]
    target_leakage_check: bool
    retrieval_status: str
    retrieval_source: str
    selected_count: int
    rejected_count: int
    completed_count: int
    cache_hit_count: int
    generated_count: int
    missing_count: int
    failed_count: int
    knowledge_matches: list[KnowledgeMatch] = field(default_factory=list)
    unresolved_knowledge: list[UnresolvedKnowledge] = field(
        default_factory=list
    )
    retrieval_request_id: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        value = dataclasses.asdict(self)
        value["knowledge_matches"] = [
            item.to_dict() for item in self.knowledge_matches
        ]
        value["unresolved_knowledge"] = [
            item.to_dict() for item in self.unresolved_knowledge
        ]
        return value


__all__ = [
    "KnowledgeMatch",
    "LINGXI_ADVISOR_SEARCH_SCHEMA_VERSION",
    "LingxiAdvisorSearchRequest",
    "LingxiAdvisorSearchResult",
    "LingxiAdvisorSearchStatus",
    "TargetIssue",
    "UnresolvedKnowledge",
]
