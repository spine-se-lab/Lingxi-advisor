from __future__ import annotations

from ..execution import checkpoint, bounded_timeout, interruptible_sleep, ExecutionFailure

from ..knowledge_template import (
    GENERAL_SUMMARY_TAGS,
    LIGHT_FINE_GRAINED_1_TAGS,
    LIGHT_FINE_GRAINED_2_TAGS,
    assemble_knowledge_xml,
)
from ..knowledge_validation import validate_generated_knowledge_xml

import html
import logging
import random
import re
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol

from ..tls import httpx_verify

from . import prompts
from .contracts import (
    LightGenerationInput,
    LightGenerationResult,
    LightGeneratorConfig,
    ModelCallStats,
)

logger = logging.getLogger(__name__)

FINE_GRAINED_1_TAGS = LIGHT_FINE_GRAINED_1_TAGS
FINE_GRAINED_2_TAGS = LIGHT_FINE_GRAINED_2_TAGS
GENERAL_TAGS = GENERAL_SUMMARY_TAGS
STAGE_NAMES = {
    "light_fg1": "FG1 repository/dependency/call-trace analysis",
    "light_fg2": "FG2 root-cause/fix/test analysis",
    "light_summary": "General transferable summary",
}


@dataclass(frozen=True)
class LLMCompletion:
    content: str
    model: str
    usage: Mapping[str, Any]


class LLMClient(Protocol):
    def complete(
        self,
        *,
        prompt: str,
        model: str,
        temperature: float,
        max_output_tokens: int,
    ) -> LLMCompletion: ...


class OpenAICompatibleLLMClient:
    """Small lazy OpenAI-compatible adapter.

    Imports and network client construction occur only after the dispatcher has
    established that the knowledge cache missed.
    """

    def __init__(self, config: LightGeneratorConfig):
        try:
            import httpx
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError(
                "Light generation requires the 'openai' and 'httpx' packages"
            ) from exc

        http_client = httpx.Client(
            timeout=config.timeout_seconds,
            verify=httpx_verify(config.verify_ssl),
            trust_env=config.trust_env,
        )
        self._client = OpenAI(
            base_url=config.base_url,
            api_key=config.api_key,
            http_client=http_client,
            timeout=config.timeout_seconds,
            max_retries=0,
        )

    def complete(
        self,
        *,
        prompt: str,
        model: str,
        temperature: float,
        max_output_tokens: int,
    ) -> LLMCompletion:
        checkpoint()
        response = self._client.chat.completions.create(
            timeout=bounded_timeout(self._client.timeout),            model=model,
            temperature=temperature,
            max_tokens=max_output_tokens,
            messages=(
                {
                    "role": "system",
                    "content": (
                        "You produce evidence-grounded software-engineering "
                        "knowledge as well-formed XML."
                    ),
                },
                {"role": "user", "content": prompt},
            ),
        )
        content = _safe_get(
            response, "choices", 0, "message", "content", default=""
        )
        return LLMCompletion(
            content=str(content or ""),
            model=str(_safe_get(response, "model", default=model) or model),
            usage=_usage_mapping(response),
        )


def _safe_get(obj: Any, *keys: Any, default: Any = None) -> Any:
    current = obj
    for key in keys:
        if current is None:
            return default
        if isinstance(current, Mapping):
            current = current.get(key, default)
        elif isinstance(current, (list, tuple)) and isinstance(key, int):
            if not 0 <= key < len(current):
                return default
            current = current[key]
        elif isinstance(key, str):
            current = getattr(current, key, default)
        else:
            return default
    return current


def _usage_mapping(response: Any) -> dict[str, Any]:
    usage = _safe_get(response, "usage", default=None)
    cost = (
        _safe_get(usage, "cost", default=None)
        or _safe_get(usage, "total_cost", default=None)
        or _safe_get(response, "cost", default=None)
        or _safe_get(response, "total_cost", default=None)
        or 0.0
    )
    try:
        cost_value = float(cost)
    except (TypeError, ValueError):
        cost_value = 0.0
    return {
        "prompt_tokens": _safe_get(usage, "prompt_tokens", default=None),
        "completion_tokens": _safe_get(
            usage, "completion_tokens", default=None
        ),
        "total_tokens": _safe_get(usage, "total_tokens", default=None),
        "cost_usd": cost_value,
    }


def _int_or_none(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _short_error(exc: BaseException, max_chars: int = 500) -> str:
    value = " ".join(str(exc).split())
    if len(value) <= max_chars:
        return value
    return value[: max_chars - 3] + "..."


def _recover_xml_text_sections(
    value: str,
    *,
    expected_tags: tuple[str, ...],
) -> tuple[str, list[ET.Element], tuple[str, ...]] | None:
    """Conservatively escape malformed text inside an exact XML shape."""

    cursor = 0
    sections: list[tuple[str, str]] = []
    for tag in expected_tags:
        while cursor < len(value) and value[cursor].isspace():
            cursor += 1
        opening = f"<{tag}>"
        closing = f"</{tag}>"
        if not value.startswith(opening, cursor):
            return None
        content_start = cursor + len(opening)
        content_end = value.find(closing, content_start)
        if content_end < 0:
            return None
        sections.append((tag, value[content_start:content_end]))
        cursor = content_end + len(closing)
    if value[cursor:].strip():
        return None

    children: list[ET.Element] = []
    repaired_tags: list[str] = []
    for tag, content in sections:
        child = ET.Element(tag)
        try:
            inner = ET.fromstring(f"<section>{content}</section>")
        except ET.ParseError:
            child.text = html.unescape(content)
            repaired_tags.append(tag)
        else:
            child.text = inner.text
            for nested in list(inner):
                child.append(nested)
        children.append(child)
    if not repaired_tags:
        return None
    normalized = "\n".join(
        ET.tostring(child, encoding="unicode") for child in children
    )
    return normalized, children, tuple(repaired_tags)


def _require_nonempty_sections(children: list[ET.Element]) -> None:
    empty = [
        child.tag
        for child in children
        if not "".join(child.itertext()).strip()
    ]
    if empty:
        raise ValueError(
            "Light XML sections must be non-empty: " + ", ".join(empty)
        )


def _xml_fragment(text: str, *, expected_tags: tuple[str, ...]) -> tuple[str, list[ET.Element]]:
    value = str(text or "").strip()
    value = re.sub(r"^```(?:xml)?\s*", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\s*```$", "", value)
    value = re.sub(r"<\?xml[^>]*\?>", "", value, flags=re.IGNORECASE).strip()
    start = value.find("<")
    end = value.rfind(">")
    if start < 0 or end <= start:
        raise ValueError("model response does not contain XML")
    value = value[start : end + 1]
    try:
        wrapper = ET.fromstring(f"<fragment>{value}</fragment>")
    except ET.ParseError as exc:
        recovered = _recover_xml_text_sections(
            value,
            expected_tags=expected_tags,
        )
        if recovered is None:
            raise ValueError(
                f"model response is not well-formed XML: {exc}"
            ) from exc
        normalized, children, repaired_tags = recovered
        logger.warning(
            "Normalized invalid XML-like text inside model response: "
            "sections=%s parse_error=%s",
            ",".join(repaired_tags),
            _short_error(exc),
        )
        _require_nonempty_sections(children)
        return normalized, children
    children = list(wrapper)
    actual_tags = tuple(child.tag for child in children)
    if actual_tags != expected_tags:
        raise ValueError(
            "unexpected XML top-level tags: "
            f"expected {expected_tags}, got {actual_tags}"
        )
    _require_nonempty_sections(children)
    return value, children



def _target_context(value: LightGenerationInput) -> str:
    problem = value.problem_statement or "[not provided]"
    requirements = value.requirements or "[not provided]"
    return f"""Target issue context (transfer context only; never treat it as historical evidence):
<target_problem_statement>
{problem}
</target_problem_statement>
<target_requirements>
{requirements}
</target_requirements>"""


def _metadata(value: LightGenerationInput) -> str:
    rows = (
        ("repo", value.repo),
        ("instance_id", value.instance_id),
        ("historical_issue_number", value.historical_issue_number),
        ("historical_issue_url", value.historical_issue_url),
        ("historical_fix_commit", value.historical_fix_commit),
        (
            "historical_candidate_fingerprint",
            value.historical_candidate_fingerprint,
        ),
        ("historical_patch_sha256", value.historical_patch_sha256),
    )
    lines = ["Historical candidate provenance:"]
    lines.extend(
        f"- {key}: {item}"
        for key, item in rows
        if item is not None and str(item).strip()
    )
    lines.extend(
        f"- {key}: {item}"
        for key, item in sorted(value.provenance.items())
        if item is not None and str(item).strip()
    )
    return "\n".join(lines)


def _changed_files_summary(
    changed_files: tuple[Mapping[str, Any], ...], max_items: int = 30
) -> str:
    if not changed_files:
        return "Changed files summary: not provided."
    lines = ["Changed files (from the historical fix):"]
    for item in changed_files[:max_items]:
        filename = str(item.get("filename") or "").strip()
        if not filename:
            continue
        details = [
            str(item[key])
            for key in ("status",)
            if item.get(key) not in (None, "")
        ]
        if item.get("additions") is not None:
            details.append(f"+{item['additions']}")
        if item.get("deletions") is not None:
            details.append(f"-{item['deletions']}")
        suffix = f" ({', '.join(details)})" if details else ""
        lines.append(f"- {filename}{suffix}")
    if len(changed_files) > max_items:
        lines.append(f"- [{len(changed_files) - max_items} additional files omitted]")
    return "\n".join(lines)


def _truncate_middle(text: str, max_chars: int, label: str) -> str:
    value = str(text or "")
    if len(value) <= max_chars:
        return value
    marker = (
        f"\n\n[... TRUNCATED {label}: original_chars={len(value)}, "
        f"kept_chars={max_chars} ...]\n\n"
    )
    if max_chars <= len(marker) + 200:
        return value[:max_chars]
    keep = max_chars - len(marker)
    head = int(keep * 0.65)
    return value[:head] + marker + value[-(keep - head) :]


def _truncate_patch_file_aware(patch: str, max_chars: int) -> str:
    value = str(patch or "")
    if len(value) <= max_chars:
        return value
    chunks = [
        chunk
        for chunk in re.split(r"(?m)(?=^diff --git )", value)
        if chunk.strip()
    ]
    if len(chunks) <= 1:
        return _truncate_middle(value, max_chars, "historical_patch")
    budget = max_chars
    per_chunk = max(1_000, budget // len(chunks))
    kept: list[str] = []
    used = 0
    for chunk in chunks:
        remaining = budget - used
        if remaining <= 0:
            break
        shortened = _truncate_middle(
            chunk, min(per_chunk, remaining), "historical_patch_file"
        )
        kept.append(shortened)
        used += len(shortened) + 1
    return "\n".join(kept)


def _is_context_length_error(exc: BaseException) -> bool:
    message = str(exc).lower()
    return "context length" in message or "maximum context" in message


def _context_retry_ratio(exc: BaseException, prompt_chars: int) -> float:
    message = str(exc)
    limit = re.search(
        r"maximum context length is\s+(\d+)\s+tokens",
        message,
        flags=re.IGNORECASE,
    )
    output = re.search(
        r"requested\s+(\d+)\s+output tokens",
        message,
        flags=re.IGNORECASE,
    )
    if limit and output and prompt_chars > 0:
        available_input = max(1, int(limit.group(1)) - int(output.group(1)))
        estimated_input = max(1, int(prompt_chars / 3.5))
        return max(0.03, min(0.90, (available_input * 0.85) / estimated_input))
    return 0.50


def _shrink_evidence(
    issue_or_analysis: str, patch: str, ratio: float
) -> tuple[str, str]:
    old_total = len(issue_or_analysis) + len(patch)
    target_total = min(old_total, max(10_000, int(old_total * ratio)))
    if old_total <= target_total:
        return issue_or_analysis, patch
    issue_budget = min(len(issue_or_analysis), max(4_000, int(target_total * 0.40)))
    patch_budget = max(1_000, target_total - issue_budget)
    return (
        _truncate_middle(issue_or_analysis, issue_budget, "historical_issue"),
        _truncate_patch_file_aware(patch, patch_budget),
    )


class LightKnowledgeGenerator:
    """Three-pass Light generator refactored from the legacy dataset runner."""

    def __init__(
        self,
        config: LightGeneratorConfig,
        *,
        client: LLMClient | None = None,
        sleep: Callable[[float], None] = interruptible_sleep,
    ):
        config.validate()
        self.config = config
        self.client = client or OpenAICompatibleLLMClient(config)
        self._sleep = sleep

    def _invoke(
        self,
        *,
        tag: str,
        prompt_builder: Callable[[str, str], str],
        issue_or_analysis: str,
        patch: str,
        response_normalizer: Callable[[str], str] | None = None,
    ) -> tuple[str, ModelCallStats]:
        dynamic_text = issue_or_analysis
        dynamic_patch = patch
        last_error: BaseException | None = None
        failed_attempt_latency = 0.0
        response_correction = ""
        stage_name = STAGE_NAMES.get(tag, tag)
        for attempt in range(1, self.config.max_attempts + 1):
            prompt = prompt_builder(dynamic_text, dynamic_patch)
            if response_correction:
                prompt = f"{prompt.rstrip()}\n\n{response_correction}\n"
            logger.info(
                "LLM stage started: stage=%s attempt=%d/%d",
                stage_name,
                attempt,
                self.config.max_attempts,
            )
            logger.debug(
                "LLM request details: tag=%s prompt_chars=%d "
                "evidence_chars=%d patch_chars=%d max_output_tokens=%d",
                tag,
                len(prompt),
                len(dynamic_text),
                len(dynamic_patch),
                self.config.max_output_tokens,
            )
            started = time.monotonic()
            try:
                completion = self.client.complete(
                    prompt=prompt,
                    model=self.config.model,
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_output_tokens,
                )
                normalized_content = completion.content
                if response_normalizer is not None:
                    normalized_content = response_normalizer(
                        completion.content
                    )
                latency = time.monotonic() - started
                usage = completion.usage
                total_tokens = _int_or_none(usage.get("total_tokens"))
                logger.info(
                    "LLM stage completed: stage=%s attempt=%d/%d "
                    "latency=%.2fs total_tokens=%s response_chars=%d",
                    stage_name,
                    attempt,
                    self.config.max_attempts,
                    latency,
                    total_tokens if total_tokens is not None else "unknown",
                    len(normalized_content),
                )
                return normalized_content, ModelCallStats(
                    tag=tag,
                    model=completion.model or self.config.model,
                    attempt=attempt,
                    latency_seconds=failed_attempt_latency + latency,
                    attempt_count=attempt,
                    failed_attempt_latency_seconds=failed_attempt_latency,
                    prompt_tokens=_int_or_none(usage.get("prompt_tokens")),
                    completion_tokens=_int_or_none(
                        usage.get("completion_tokens")
                    ),
                    total_tokens=_int_or_none(usage.get("total_tokens")),
                    cost_usd=float(usage.get("cost_usd") or 0.0),
                )
            except ExecutionFailure:
                raise
            except Exception as exc:
                last_error = exc
                latency = time.monotonic() - started
                failed_attempt_latency += latency
                logger.warning(
                    "LLM stage failed: stage=%s attempt=%d/%d "
                    "latency=%.2fs error=%s: %s",
                    stage_name,
                    attempt,
                    self.config.max_attempts,
                    latency,
                    type(exc).__name__,
                    _short_error(exc),
                )
                if _is_context_length_error(exc):
                    old_text_chars = len(dynamic_text)
                    old_patch_chars = len(dynamic_patch)
                    dynamic_text, dynamic_patch = _shrink_evidence(
                        dynamic_text,
                        dynamic_patch,
                        _context_retry_ratio(exc, len(prompt)),
                    )
                    logger.warning(
                        "Context evidence reduced before retry: stage=%s "
                        "evidence_chars=%d->%d patch_chars=%d->%d",
                        stage_name,
                        old_text_chars,
                        len(dynamic_text),
                        old_patch_chars,
                        len(dynamic_patch),
                    )
                elif isinstance(exc, ValueError):
                    response_correction = (
                        "CORRECTION REQUIRED FOR THIS RETRY:\n"
                        "- The previous response failed XML validation: "
                        f"{_short_error(exc, max_chars=240)}\n"
                        "- Return every requested top-level XML element "
                        "exactly once and in the required order.\n"
                        "- Keep code, comparison operators, and HTML/XML-like "
                        "tokens as text by escaping &, <, and >. For example, "
                        "write the literal HTML token as &lt;label&gt;.\n"
                        "- Return XML only, without Markdown fences or prose."
                    )
                if attempt < self.config.max_attempts:
                    wait = min(
                        self.config.retry_max_sleep_seconds,
                        self.config.retry_base_sleep_seconds * (2 ** (attempt - 1)),
                    )
                    wait_with_jitter = wait + random.random() if wait > 0 else 0.0
                    logger.warning(
                        "Retrying LLM stage: stage=%s next_attempt=%d/%d "
                        "wait=%.2fs",
                        stage_name,
                        attempt + 1,
                        self.config.max_attempts,
                        wait_with_jitter,
                    )
                    if wait > 0:
                        self._sleep(wait_with_jitter)
        raise RuntimeError(
            f"Light generator call {tag!r} failed after "
            f"{self.config.max_attempts} attempts"
        ) from last_error

    def _prompt_builder(
        self,
        template: Any,
        value: LightGenerationInput,
        *,
        analysis: bool = False,
    ) -> Callable[[str, str], str]:
        changed_files = _changed_files_summary(value.changed_files)
        suffix = (
            prompts.GENERAL_SUFFIX if analysis else prompts.FINE_GRAINED_SUFFIX
        )

        def build(dynamic_text: str, dynamic_patch: str) -> str:
            substitutions = {
                "TARGET_CONTEXT": "",
                "METADATA": "",
                "CHANGED_FILES_SUMMARY": changed_files,
                "PATCH": dynamic_patch,
                "SUFFIX": suffix,
            }
            if analysis:
                substitutions["REQUIREMENT_ANALYSIS"] = dynamic_text
            else:
                substitutions["REQUIREMENT_REPORT"] = dynamic_text
            return template.substitute(**substitutions)

        return build

    def generate(self, value: LightGenerationInput) -> LightGenerationResult:
        logger.info(
            "Light generation started: instance=%s repo=%s "
            "historical_issue=%s candidate=%s",
            value.instance_id,
            value.repo,
            (
                f"#{value.historical_issue_number}"
                if value.historical_issue_number is not None
                else "unknown"
            ),
            value.historical_candidate_fingerprint,
        )
        fg1_raw, fg1_stats = self._invoke(
            tag="light_fg1",
            prompt_builder=self._prompt_builder(
                prompts.FINE_GRAINED_PROMPT_1, value
            ),
            issue_or_analysis=value.historical_issue_description,
            patch=value.historical_patch,
            response_normalizer=lambda text: _xml_fragment(
                text, expected_tags=FINE_GRAINED_1_TAGS
            )[0],
        )
        fg1_xml, fg1_children = _xml_fragment(
            fg1_raw, expected_tags=FINE_GRAINED_1_TAGS
        )

        fg2_raw, fg2_stats = self._invoke(
            tag="light_fg2",
            prompt_builder=self._prompt_builder(
                prompts.FINE_GRAINED_PROMPT_2, value
            ),
            issue_or_analysis=value.historical_issue_description,
            patch=value.historical_patch,
            response_normalizer=lambda text: _xml_fragment(
                text, expected_tags=FINE_GRAINED_2_TAGS
            )[0],
        )
        fg2_xml, fg2_children = _xml_fragment(
            fg2_raw, expected_tags=FINE_GRAINED_2_TAGS
        )

        summary_context = value.historical_issue_description
        if self.config.aspect_mode == "g_from_issue_plus_fg_calltrace":
            call_trace = next(
                (child for child in fg1_children if child.tag == "call_trace"),
                None,
            )
            if call_trace is not None:
                summary_context += "\n\n" + ET.tostring(
                    call_trace, encoding="unicode"
                )
        summary_raw, summary_stats = self._invoke(
            tag="light_summary",
            prompt_builder=self._prompt_builder(
                prompts.GENERAL_PROMPT_1, value, analysis=True
            ),
            issue_or_analysis=summary_context,
            patch=value.historical_patch,
            response_normalizer=lambda text: _xml_fragment(
                text, expected_tags=GENERAL_TAGS
            )[0],
        )
        summary_xml, summary_children = _xml_fragment(
            summary_raw, expected_tags=GENERAL_TAGS
        )

        artifact = assemble_knowledge_xml(
            fine_grained_children=(*fg1_children, *fg2_children),
            general_summary_children=summary_children,
        )
        validate_generated_knowledge_xml(artifact)
        total_latency = (
            fg1_stats.latency_seconds
            + fg2_stats.latency_seconds
            + summary_stats.latency_seconds
        )
        logger.info(
            "Light generation completed: instance=%s candidate=%s "
            "model_calls=%d llm_latency=%.2fs artifact_chars=%d",
            value.instance_id,
            value.historical_candidate_fingerprint,
            sum(
                item.attempt_count
                for item in (fg1_stats, fg2_stats, summary_stats)
            ),
            total_latency,
            len(artifact),
        )

        return LightGenerationResult(
            artifact_xml=artifact + "\n",
            fine_grained_xml=fg1_xml + "\n" + fg2_xml,
            summary_xml=summary_xml,
            calls=(fg1_stats, fg2_stats, summary_stats),
        )


def escaped_xml_text(value: str) -> str:
    """Public helper retained for callers that need safe XML text snippets."""

    return html.escape(str(value or ""), quote=False)
