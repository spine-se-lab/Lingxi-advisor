from __future__ import annotations

import dataclasses
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .generation_contracts import GENERATION_SCHEMA_VERSION
from .knowledge_validation import validate_knowledge_content, validate_knowledge_xml
from .io_utils import (
    read_json,
    read_jsonl,
    write_json_atomic,
    write_jsonl_atomic,
    write_text_atomic,
)
from .locking import FileLock


@dataclass(frozen=True)
class KnowledgeCacheEntry:
    knowledge_cache_key: str
    generation_mode: str
    artifact_path: str
    artifact_sha256: str
    artifact_schema_version: int
    historical_candidate_fingerprint: str
    historical_patch_sha256: str
    template_version: str
    generator_model: str
    target_conditioned: bool
    instance_id: str

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "KnowledgeCacheEntry":
        allowed = {item.name for item in dataclasses.fields(cls)}
        return cls(**{key: value[key] for key in allowed})

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


class KnowledgeCache:
    """Validated, concurrency-safe filesystem cache for generated XML."""

    def __init__(self, root: Path):
        self.root = root.expanduser().resolve()

    @property
    def manifest_path(self) -> Path:
        return self.root / "manifest.jsonl"

    def artifact_path(self, *, generation_mode: str, cache_key: str) -> Path:
        return self.root / generation_mode / f"{cache_key}.xml"

    def entry_manifest_path(
        self, *, generation_mode: str, cache_key: str
    ) -> Path:
        return self.root / generation_mode / f"{cache_key}.manifest.json"

    def generation_lock(
        self, *, generation_mode: str, cache_key: str
    ) -> FileLock:
        return FileLock(
            self.root / ".locks" / generation_mode / f"{cache_key}.lock"
        )

    @staticmethod
    def _validate_xml(xml_text: str, generation_mode: str) -> None:
        validate_knowledge_xml(xml_text)

    def read(
        self,
        *,
        generation_mode: str,
        cache_key: str,
        historical_candidate_fingerprint: str | None = None,
        historical_patch_sha256: str | None = None,
        template_version: str | None = None,
        generator_model: str | None = None,
        target_conditioned: bool | None = None,
    ) -> tuple[KnowledgeCacheEntry, str] | None:
        artifact_path = self.artifact_path(
            generation_mode=generation_mode, cache_key=cache_key
        )
        entry_path = self.entry_manifest_path(
            generation_mode=generation_mode, cache_key=cache_key
        )
        value = read_json(entry_path)
        if value is None or not artifact_path.is_file():
            return None
        try:
            entry = KnowledgeCacheEntry.from_dict(value)
        except (KeyError, TypeError, ValueError):
            return None
        if (
            entry.knowledge_cache_key != cache_key
            or entry.generation_mode != generation_mode
            or entry.artifact_schema_version != GENERATION_SCHEMA_VERSION
        ):
            return None
        expected_values = (
            (
                historical_candidate_fingerprint,
                entry.historical_candidate_fingerprint,
            ),
            (
                historical_patch_sha256,
                entry.historical_patch_sha256,
            ),
            (template_version, entry.template_version),
            (generator_model, entry.generator_model),
        )
        if any(
            expected is not None and expected != actual
            for expected, actual in expected_values
        ):
            return None
        if (
            target_conditioned is not None
            and target_conditioned != entry.target_conditioned
        ):
            return None
        try:
            xml_text = artifact_path.read_text(encoding="utf-8")
            validate_knowledge_content(xml_text, expected_sha256=entry.artifact_sha256)
        except (OSError, UnicodeError, ValueError):
            return None
        if Path(entry.artifact_path).resolve() != artifact_path.resolve():
            return None
        return entry, xml_text

    def lookup(self, *, generation_mode: str, cache_key: str, **provenance: Any) -> KnowledgeCacheEntry | None:
        snapshot = self.read(generation_mode=generation_mode, cache_key=cache_key, **provenance)
        return snapshot[0] if snapshot is not None else None

    def has_valid_artifact(
        self,
        *,
        generation_mode: str,
        cache_key: str,
        historical_candidate_fingerprint: str | None = None,
        historical_patch_sha256: str | None = None,
        template_version: str | None = None,
        generator_model: str | None = None,
        target_conditioned: bool | None = None,
    ) -> bool:
        return (
            self.lookup(
                generation_mode=generation_mode,
                cache_key=cache_key,
                historical_candidate_fingerprint=(
                    historical_candidate_fingerprint
                ),
                historical_patch_sha256=historical_patch_sha256,
                template_version=template_version,
                generator_model=generator_model,
                target_conditioned=target_conditioned,
            )
            is not None
        )

    def store(
        self,
        *,
        generation_mode: str,
        cache_key: str,
        xml_text: str,
        historical_candidate_fingerprint: str,
        historical_patch_sha256: str,
        template_version: str,
        generator_model: str,
        target_conditioned: bool,
        instance_id: str,
    ) -> KnowledgeCacheEntry:
        """Store an artifact while the caller holds its generation lock."""

        self._validate_xml(xml_text, generation_mode)
        artifact_path = self.artifact_path(
            generation_mode=generation_mode, cache_key=cache_key
        )
        artifact_sha256 = hashlib.sha256(xml_text.encode("utf-8")).hexdigest()
        entry = KnowledgeCacheEntry(
            knowledge_cache_key=cache_key,
            generation_mode=generation_mode,
            artifact_path=str(artifact_path),
            artifact_sha256=artifact_sha256,
            artifact_schema_version=GENERATION_SCHEMA_VERSION,
            historical_candidate_fingerprint=historical_candidate_fingerprint,
            historical_patch_sha256=historical_patch_sha256,
            template_version=template_version,
            generator_model=generator_model,
            target_conditioned=target_conditioned,
            instance_id=instance_id,
        )
        write_text_atomic(artifact_path, xml_text)
        write_json_atomic(
            self.entry_manifest_path(
                generation_mode=generation_mode, cache_key=cache_key
            ),
            entry.to_dict(),
        )
        self._upsert_manifest(entry)
        return entry

    def _upsert_manifest(self, entry: KnowledgeCacheEntry) -> None:
        with FileLock(self.root / ".locks" / "manifest.lock"):
            rows = read_jsonl(self.manifest_path)
            rows_by_identity = {
                (
                    str(row.get("generation_mode") or ""),
                    str(row.get("knowledge_cache_key") or ""),
                ): row
                for row in rows
            }
            rows_by_identity[
                (entry.generation_mode, entry.knowledge_cache_key)
            ] = entry.to_dict()
            write_jsonl_atomic(
                self.manifest_path,
                (
                    rows_by_identity[key]
                    for key in sorted(rows_by_identity)
                ),
            )

    def publish(
        self, entry: KnowledgeCacheEntry, output_path: Path
    ) -> Path:
        source = Path(entry.artifact_path)
        xml_text = source.read_text(encoding="utf-8")
        validate_knowledge_content(xml_text, expected_sha256=entry.artifact_sha256)
        write_text_atomic(output_path, xml_text)
        return output_path
