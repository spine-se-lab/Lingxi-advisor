"""Repository-free XML knowledge generation from selected historical issues."""

from .contracts import (
    LightGenerationInput,
    LightGenerationResult,
    LightGeneratorConfig,
    ModelCallStats,
)
from ..knowledge_validation import validate_knowledge_xml
from .generator import LightKnowledgeGenerator
from .service import LightGenerationService

__all__ = [
    "LightGenerationInput",
    "LightGenerationResult",
    "LightGeneratorConfig",
    "LightGenerationService",
    "LightKnowledgeGenerator",
    "ModelCallStats",
    "validate_knowledge_xml",
]
