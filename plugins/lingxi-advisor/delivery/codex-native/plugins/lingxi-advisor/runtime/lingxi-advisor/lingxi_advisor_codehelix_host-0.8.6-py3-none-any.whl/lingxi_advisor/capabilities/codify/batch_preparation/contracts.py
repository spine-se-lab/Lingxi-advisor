from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Mapping

from ....internal.generation_contracts import GenerationMode, validate_generation_mode


@dataclass(frozen=True)
class BatchPreparationOptions:
    generation_mode: GenerationMode = 'light'
    search_candidate_count: int = 5
    final_top_k: int = 3
    update_preretrieved: bool = False
    run_gate_for_preretrieved: bool = False
    search_type: str = 'semantic'
    fallback_search_type: str = 'hybrid'
    minimum_similarity_score: int = 2
    maximum_misleading_risk: int = 3
    resume: bool = True
    refresh_instance_metadata: bool = False
    refresh_search_cache: bool = False

    def validate(self) -> None:
        validate_generation_mode(self.generation_mode)
        if self.search_candidate_count < 1:
            raise ValueError('search_candidate_count must be positive')
        if self.final_top_k < 1:
            raise ValueError('final_top_k must be positive')
        if self.final_top_k > self.search_candidate_count:
            raise ValueError('final_top_k cannot exceed search_candidate_count')

    def preparation_options(self) -> dict[str, Any]:
        self.validate()
        return {
            'generation_mode': self.generation_mode,
            'search_candidate_count': self.search_candidate_count,
            'final_top_k': self.final_top_k,
            'update_preretrieved': self.update_preretrieved,
            'run_gate_for_preretrieved': self.run_gate_for_preretrieved,
            'search_type': self.search_type,
            'fallback_search_type': self.fallback_search_type,
            'minimum_similarity_score': self.minimum_similarity_score,
            'maximum_misleading_risk': self.maximum_misleading_risk,
            'refresh_instance_metadata': self.refresh_instance_metadata,
            'refresh_search_cache': self.refresh_search_cache,
        }

@dataclass(frozen=True)
class BatchPreparationRequest:
    options: BatchPreparationOptions = BatchPreparationOptions()
    resume: bool = True
    continue_on_error: bool = True
    retry_failed: bool = False

PrepareBatchItem = Callable[
    [Mapping[str, Any]], Awaitable[dict[str, Any]]
]

__all__ = [
    'BatchPreparationOptions',
    'BatchPreparationRequest',
    'PrepareBatchItem',
]
