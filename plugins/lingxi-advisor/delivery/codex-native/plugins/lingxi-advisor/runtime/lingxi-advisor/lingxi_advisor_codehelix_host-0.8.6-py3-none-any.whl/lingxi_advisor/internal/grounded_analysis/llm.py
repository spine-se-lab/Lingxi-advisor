from __future__ import annotations

from ..execution import checkpoint, bounded_timeout, interruptible_sleep, ExecutionFailure

import json
import logging
import random
import time
from typing import Any, Callable, Mapping, Protocol, Sequence

from ..light_generation.contracts import ModelCallStats
from ..tls import httpx_verify
from .contracts import (
    AgentCompletion,
    AgentToolCall,
    GroundedAnalysisConfig,
)

logger = logging.getLogger(__name__)


class GroundedLLMClient(Protocol):
    def complete(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        model: str,
        temperature: float,
        max_output_tokens: int,
    ) -> AgentCompletion: ...


def _safe_get(obj: Any, *keys: Any, default: Any = None) -> Any:
    current = obj
    for key in keys:
        if current is None:
            return default
        if isinstance(current, Mapping):
            current = current.get(key, default)
        elif isinstance(current, (list, tuple)) and isinstance(key, int):
            if not 0 <= key < len(current):
                return default
            current = current[key]
        elif isinstance(key, str):
            current = getattr(current, key, default)
        else:
            return default
    return current


def _usage_mapping(response: Any) -> dict[str, Any]:
    usage = _safe_get(response, "usage", default=None)
    cost = (
        _safe_get(usage, "cost", default=None)
        or _safe_get(usage, "total_cost", default=None)
        or _safe_get(response, "cost", default=None)
        or _safe_get(response, "total_cost", default=None)
        or 0.0
    )
    try:
        cost_value = float(cost)
    except (TypeError, ValueError):
        cost_value = 0.0
    return {
        "prompt_tokens": _safe_get(usage, "prompt_tokens", default=None),
        "completion_tokens": _safe_get(
            usage, "completion_tokens", default=None
        ),
        "total_tokens": _safe_get(usage, "total_tokens", default=None),
        "cost_usd": cost_value,
    }


def _int_or_none(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _short_error(exc: BaseException, max_chars: int = 500) -> str:
    value = " ".join(str(exc).split())
    if len(value) <= max_chars:
        return value
    return value[: max_chars - 3] + "..."


class OpenAICompatibleGroundedClient:
    """OpenAI-compatible chat adapter with tool-call support."""

    def __init__(self, config: GroundedAnalysisConfig):
        try:
            import httpx
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError(
                "Grounded analysis requires the 'openai' and 'httpx' packages"
            ) from exc

        http_client = httpx.Client(
            timeout=config.timeout_seconds,
            verify=httpx_verify(config.verify_ssl),
            trust_env=config.trust_env,
        )
        self._client = OpenAI(
            base_url=config.base_url,
            api_key=config.api_key,
            http_client=http_client,
            timeout=config.timeout_seconds,
            max_retries=0,
        )

    def complete(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        model: str,
        temperature: float,
        max_output_tokens: int,
    ) -> AgentCompletion:
        kwargs: dict[str, Any] = {
            "model": model,
            "temperature": temperature,
            "max_tokens": max_output_tokens,
            "messages": list(messages),
        }
        if tools:
            kwargs["tools"] = list(tools)
            kwargs["tool_choice"] = "auto"
        checkpoint()
        response = self._client.chat.completions.create(timeout=bounded_timeout(self._client.timeout), **kwargs)
        message = _safe_get(response, "choices", 0, "message", default=None)
        raw_calls = _safe_get(message, "tool_calls", default=None) or ()
        tool_calls: list[AgentToolCall] = []
        for index, item in enumerate(raw_calls):
            arguments = _safe_get(
                item, "function", "arguments", default="{}"
            )
            if isinstance(arguments, Mapping):
                arguments = json.dumps(arguments, ensure_ascii=False)
            tool_calls.append(
                AgentToolCall(
                    id=str(
                        _safe_get(item, "id", default=f"call_{index}") or
                        f"call_{index}"
                    ),
                    name=str(
                        _safe_get(item, "function", "name", default="") or ""
                    ),
                    arguments=str(arguments or "{}"),
                )
            )
        return AgentCompletion(
            content=str(_safe_get(message, "content", default="") or ""),
            model=str(_safe_get(response, "model", default=model) or model),
            usage=_usage_mapping(response),
            tool_calls=tuple(tool_calls),
        )


class GroundedCompletionRunner:
    """Retry and observe one grounded chat-completion round."""

    def __init__(
        self,
        config: GroundedAnalysisConfig,
        *,
        client: GroundedLLMClient,
        sleep: Callable[[float], None] = interruptible_sleep,
    ) -> None:
        self.config = config
        self.client = client
        self._sleep = sleep

    def complete(
        self,
        *,
        tag: str,
        stage_name: str,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> tuple[AgentCompletion, ModelCallStats]:
        last_error: BaseException | None = None
        for attempt in range(1, self.config.max_attempts + 1):
            logger.info(
                "Grounded LLM stage started: stage=%s attempt=%d/%d",
                stage_name,
                attempt,
                self.config.max_attempts,
            )
            logger.debug(
                "Grounded LLM request: tag=%s messages=%d tools=%d "
                "max_output_tokens=%d",
                tag,
                len(messages),
                len(tools),
                self.config.max_output_tokens,
            )
            started = time.monotonic()
            try:
                completion = self.client.complete(
                    messages=messages,
                    tools=tools,
                    model=self.config.model,
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_output_tokens,
                )
            except ExecutionFailure:
                raise
            except Exception as exc:
                last_error = exc
                latency = time.monotonic() - started
                logger.warning(
                    "Grounded LLM stage failed: stage=%s attempt=%d/%d "
                    "latency=%.2fs error=%s: %s",
                    stage_name,
                    attempt,
                    self.config.max_attempts,
                    latency,
                    type(exc).__name__,
                    _short_error(exc),
                )
                if attempt < self.config.max_attempts:
                    wait = min(
                        self.config.retry_max_sleep_seconds,
                        self.config.retry_base_sleep_seconds
                        * (2 ** (attempt - 1)),
                    )
                    wait_with_jitter = (
                        wait + random.random() if wait > 0 else 0.0
                    )
                    logger.warning(
                        "Retrying grounded LLM stage: stage=%s "
                        "next_attempt=%d/%d wait=%.2fs",
                        stage_name,
                        attempt + 1,
                        self.config.max_attempts,
                        wait_with_jitter,
                    )
                    if wait > 0:
                        self._sleep(wait_with_jitter)
                continue

            latency = time.monotonic() - started
            usage = completion.usage
            total_tokens = _int_or_none(usage.get("total_tokens"))
            logger.info(
                "Grounded LLM stage completed: stage=%s attempt=%d/%d "
                "latency=%.2fs total_tokens=%s response_chars=%d "
                "tool_calls=%d",
                stage_name,
                attempt,
                self.config.max_attempts,
                latency,
                total_tokens if total_tokens is not None else "unknown",
                len(completion.content),
                len(completion.tool_calls),
            )
            return completion, ModelCallStats(
                tag=tag,
                model=completion.model or self.config.model,
                attempt=attempt,
                latency_seconds=latency,
                prompt_tokens=_int_or_none(usage.get("prompt_tokens")),
                completion_tokens=_int_or_none(
                    usage.get("completion_tokens")
                ),
                total_tokens=total_tokens,
                cost_usd=float(usage.get("cost_usd") or 0.0),
            )
        raise RuntimeError(
            f"grounded model call {tag!r} failed after "
            f"{self.config.max_attempts} attempts"
        ) from last_error
