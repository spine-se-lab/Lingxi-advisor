from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

from ...config import DEFAULT_PROJECT_ROOT, ServerSettings
from ...internal.search_retrieval.contracts import (
    SearchRetrievalOptions,
    SimilarityGateOptions,
)
from ...internal.search_retrieval.service import SearchRetrievalService


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run the refactored Search & Retrieval stage: pre-retrieved lookup "
            "or live GitHub search, safety validation, LLM gate, and final Top-K."
        )
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--instance-json", type=Path)
    source.add_argument("--instance-stdin", action="store_true")

    parser.add_argument("--project-root", type=Path, default=DEFAULT_PROJECT_ROOT)
    parser.add_argument("--env-file", type=Path, default=None)
    parser.add_argument("--preretrieved-dir", type=Path, default=None)
    parser.add_argument("--output-root", type=Path, default=None)
    parser.add_argument("--cache-root", type=Path, default=None)
    parser.add_argument("--repository-root", type=Path, default=None)

    parser.add_argument(
        "--search-candidate-count",
        type=int,
        default=10,
        help=(
            "Maximum safe candidates selected from the complete query union "
            "for LLM review."
        ),
    )
    parser.add_argument("--final-top-k", type=int, default=3)
    parser.add_argument("--update-preretrieved", action="store_true")
    parser.add_argument("--run-gate-for-preretrieved", action="store_true")
    parser.add_argument(
        "--skip-review-gate",
        action="store_true",
        help=(
            "Run all live queries, fix discovery, safety validation, and "
            "deterministic review-pool selection without calling the LLM gate."
        ),
    )

    parser.add_argument("--search-type", choices=["semantic", "hybrid", "lexical"], default="semantic")
    parser.add_argument("--fallback-search-type", choices=["semantic", "hybrid", "lexical"], default="hybrid")
    parser.add_argument("--per-page", type=int, default=100)
    parser.add_argument("--search-pages", type=int, default=3)
    parser.add_argument("--fallback-search-pages", type=int, default=2)
    parser.add_argument("--max-search-hits-to-resolve", type=int, default=300)
    parser.add_argument(
        "--primary-query-text-max-chars",
        type=int,
        default=256,
        help=(
            "Maximum GitHub search keyword-text characters; cannot exceed 256."
        ),
    )
    parser.add_argument(
        "--query-text-max-chars",
        type=int,
        default=256,
        help=(
            "Maximum keyword-text characters for extracted-keyword fallbacks; "
            "cannot exceed --primary-query-text-max-chars."
        ),
    )
    parser.add_argument(
        "--github-query-max-total-chars",
        type=int,
        default=512,
        help=(
            "Local total-query cap for extracted-keyword fallback phases; "
            "GitHub's official 256-character limit applies to keyword text."
        ),
    )
    parser.add_argument(
        "--max-single-term-fallbacks",
        type=int,
        default=2,
        help=(
            "Maximum number of final lexical fallbacks built only from "
            "high-signal code identifiers."
        ),
    )
    parser.add_argument("--max-phases", type=int, default=None)
    parser.add_argument("--refresh-closed-issues", action="store_true")
    parser.add_argument("--refresh-closed-pulls", action="store_true")
    parser.add_argument("--refresh-search-cache", action="store_true")
    parser.add_argument("--refresh-repository", action="store_true")
    parser.add_argument("--disable-commit-message-fallback", action="store_true")
    parser.add_argument("--no-patch-text", action="store_true")
    parser.add_argument("--enable-issue-number-guard", action="store_true")
    parser.add_argument("--closed-issues-ttl-seconds", type=int, default=86_400)
    parser.add_argument("--closed-pulls-ttl-seconds", type=int, default=86_400)
    parser.add_argument("--search-sleep-seconds", type=float, default=0.0)

    parser.add_argument("--minimum-similarity-score", type=int, default=2)
    parser.add_argument("--maximum-misleading-risk", type=int, default=3)
    parser.add_argument("--refresh-instance-metadata", action="store_true")
    parser.add_argument("--reverse-lookup-use-test-patch", action="store_true")
    parser.add_argument("--disable-ssl-verify", action="store_true")
    parser.add_argument("--no-trust-env", action="store_true")
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
    )
    return parser.parse_args()


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    load_dotenv(path, override=False)


def load_instance(args: argparse.Namespace) -> dict[str, Any]:
    if args.instance_stdin:
        raw = sys.stdin.read()
    else:
        assert args.instance_json is not None
        raw = args.instance_json.read_text(encoding="utf-8")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("input must contain exactly one JSON object")
    return value


def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    project_root = args.project_root.expanduser().resolve()
    env_file = args.env_file or (project_root / ".env")
    _load_dotenv(env_file)

    settings = ServerSettings(
        project_root=project_root,
        cache_root=args.cache_root,
        output_root=args.output_root,
        repository_root=args.repository_root,
        verify_ssl=not args.disable_ssl_verify,
        trust_env=not args.no_trust_env,
    )
    options = SearchRetrievalOptions(
        search_candidate_count=args.search_candidate_count,
        final_top_k=args.final_top_k,
        update_preretrieved=args.update_preretrieved,
        run_gate_for_preretrieved=args.run_gate_for_preretrieved,
        skip_review_gate=args.skip_review_gate,
        search_type=args.search_type,
        fallback_search_type=args.fallback_search_type,
        per_page=args.per_page,
        search_pages=args.search_pages,
        fallback_search_pages=args.fallback_search_pages,
        max_search_hits_to_resolve=args.max_search_hits_to_resolve,
        primary_query_text_max_chars=args.primary_query_text_max_chars,
        query_text_max_chars=args.query_text_max_chars,
        github_query_max_total_chars=args.github_query_max_total_chars,
        max_single_term_fallbacks=args.max_single_term_fallbacks,
        max_phases=args.max_phases,
        refresh_closed_issues=args.refresh_closed_issues,
        refresh_closed_pulls=args.refresh_closed_pulls,
        refresh_search_cache=args.refresh_search_cache,
        refresh_repository=args.refresh_repository,
        enable_commit_message_fallback=not args.disable_commit_message_fallback,
        include_patch_text=not args.no_patch_text,
        enable_issue_number_guard=args.enable_issue_number_guard,
        closed_issues_ttl_seconds=args.closed_issues_ttl_seconds,
        closed_pulls_ttl_seconds=args.closed_pulls_ttl_seconds,
        search_sleep_seconds=args.search_sleep_seconds,
    )
    gate_options = SimilarityGateOptions(
        minimum_similarity_score=args.minimum_similarity_score,
        maximum_misleading_risk=args.maximum_misleading_risk,
    )
    result = SearchRetrievalService(settings=settings).run(
        load_instance(args),
        options,
        gate_options,
        preretrieved_dir=args.preretrieved_dir,
        write_artifacts=True,
        refresh_instance_metadata=args.refresh_instance_metadata,
        use_test_patch_for_metadata=args.reverse_lookup_use_test_patch,
    )
    print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    if result.status == "failed":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
